/**
 * UI-layer sanity run — everything in src/ui that does NOT need vscode.
 *
 * The UI layer is deliberately split: `src/ui/pure.ts`, `src/ui/targets.ts` and
 * `src/ui/baseline.ts` are pure functions over the store/query contracts, and
 * hover.ts / lens.ts / panel.ts / commands.ts are thin vscode glue over them.
 * That split is what makes this file possible — it imports the logic directly
 * and asserts it against REAL bundles built from the fixtures.
 *
 * Run:  npx tsc --outDir out && node out/sanity/ui-sanity.js
 */

import * as fs from 'node:fs';
import * as path from 'node:path';

import type { Endpoint, InvocationRecord } from '../types.js';
import { silentLogger } from '../util/logger.js';
import { buildIndex } from '../coordinator/build.js';
import { IndexRegistry } from '../daemon/daemon.js';
import { hashContent } from '../lm/extractor.js';
import {
  changeSummary,
  consumersOf,
  declaringTypeOf,
  endpointHoverMarkdown,
  endpointLensTitle,
  endpointPickLabel,
  endpointRoute,
  formatConfidence,
  formatLmCacheContent,
  invocationHoverMarkdown,
  invocationLensTitle,
  lmCacheDirFor,
  lmCacheEntryPathFor,
  orderRootsForResult,
  prettyChunk,
  repoRootFromIndexPath,
  resolveFileAgainstRoots,
  shortFingerprint,
  stripCodeFence,
  summarizeResult,
  validateBlastRadiusResult,
} from '../ui/pure.js';
import { consumerCountFor, resolveInvocationTargets } from '../ui/targets.js';
import { hasBaseline, minimalBundle, readBaseline, writeBaseline, clearBaseline } from '../ui/baseline.js';
import { selectChange } from '../ui/demo.js';
import { currentLabel, isBusy, resetBusyForTests, runExclusive } from '../ui/exclusive.js';
import { CancelledError } from '../ui/progress-error.js';
import {
  BUILT_AT,
  Checks,
  REPO_ROOT,
  SCRATCH_ROOT,
  configFor,
  makeProvider,
  materialize,
} from './fixture-build.js';

const c = new Checks();
const SCRATCH = path.join(SCRATCH_ROOT, 'ui-sanity');

async function main(): Promise<void> {
  fs.rmSync(SCRATCH, { recursive: true, force: true });
  fs.mkdirSync(SCRATCH, { recursive: true });

  /* ================================================================= *
   * 1. Pure formatting — no bundles needed
   * ================================================================= */
  c.section('lens titles');
  c.eq('endpointLensTitle(0)', endpointLensTitle(0), '$(radio-tower) 0 consumers · Show blast radius');
  c.eq('endpointLensTitle(1) is singular', endpointLensTitle(1), '$(radio-tower) 1 consumer · Show blast radius');
  c.eq('endpointLensTitle(3)', endpointLensTitle(3), '$(radio-tower) 3 consumers · Show blast radius');
  c.eq('endpointLensTitle(-1) clamps', endpointLensTitle(-1), '$(radio-tower) 0 consumers · Show blast radius');
  c.eq(
    'invocationLensTitle(null)',
    invocationLensTitle(null),
    '$(question) Unresolved target · click to inspect',
  );
  c.eq(
    'invocationLensTitle(resolved)',
    invocationLensTitle({
      producerRepo: 'cdu',
      endpointId: 'abc',
      route: 'GET /api/v1/customers/{id}',
      confidence: 0.95,
    }),
    '$(arrow-right) Calls cdu:GET /api/v1/customers/{id} · confidence 0.95',
  );
  c.eq(
    'invocationLensTitle falls back to the id when no route is known',
    invocationLensTitle({ producerRepo: 'cdu', endpointId: 'abc123', confidence: 1 }),
    '$(arrow-right) Calls cdu:abc123 · confidence 1',
  );

  c.section('confidence + fingerprint formatting');
  c.eq('formatConfidence(0.95)', formatConfidence(0.95), '0.95');
  c.eq('formatConfidence(0.8)', formatConfidence(0.8), '0.8');
  c.eq('formatConfidence(0.9499)', formatConfidence(0.9499), '0.95');
  c.eq('formatConfidence(NaN)', formatConfidence(Number.NaN), '0');
  c.eq('shortFingerprint(null)', shortFingerprint(null), '(none)');
  c.eq('shortFingerprint truncates to 12', shortFingerprint('0123456789abcdef'), '0123456789ab');
  c.eq('shortFingerprint keeps short values', shortFingerprint('abc'), 'abc');

  c.section('endpointRoute');
  c.eq(
    'REST route',
    endpointRoute({ transport: 'rest', verb: 'GET', path_template: '/a/{id}', destination: null }),
    'GET /a/{id}',
  );
  c.eq(
    'kafka falls back to destination',
    endpointRoute({ transport: 'kafka', verb: null, path_template: null, destination: 'customer.events' }),
    'customer.events',
  );
  c.eq(
    'nothing known',
    endpointRoute({ transport: 'rest', verb: null, path_template: null, destination: null }),
    '(no route)',
  );

  /* ================================================================= *
   * 2. LM cache path + envelope formatting
   * ================================================================= */
  c.section('lm cache paths');
  const content = 'class Foo {}\n';
  const expectedHash = hashContent(content);
  c.eq(
    'cache path is <root>/.codeindex/lm_cache/<sha256>.json',
    lmCacheEntryPathFor('/repo', content),
    path.join('/repo', '.codeindex', 'lm_cache', `${expectedHash}.json`),
  );
  c.check(
    'cache key matches the extractor’s hashContent exactly',
    lmCacheEntryPathFor('/repo', content).includes(expectedHash),
    expectedHash.slice(0, 16),
  );
  c.eq('cache dir', lmCacheDirFor('/repo'), path.join('/repo', '.codeindex', 'lm_cache'));

  c.section('lm cache envelope formatting');
  c.eq(
    'a plain JSON-string entry is unwrapped and pretty-printed',
    formatLmCacheContent(JSON.stringify('{"endpoints":[]}')),
    '{\n  "endpoints": []\n}',
  );
  const multi = formatLmCacheContent(
    JSON.stringify({ __codeindex_lm_chunks__: ['{"a":1}', '```json\n{"b":2}\n```'] }),
  );
  c.check('multi-chunk envelope banners each chunk', multi.includes('// ---- chunk 1 of 2 ----'), '');
  c.check('multi-chunk envelope banners the last chunk', multi.includes('// ---- chunk 2 of 2 ----'), '');
  c.check('multi-chunk chunk 1 is pretty-printed', multi.includes('"a": 1'), '');
  c.check('multi-chunk chunk 2 is de-fenced and pretty-printed', multi.includes('"b": 2'), '');
  c.check('multi-chunk output carries no ``` fence', !multi.includes('```'), '');
  c.eq('non-JSON content passes through verbatim', formatLmCacheContent('not json at all'), 'not json at all');
  c.eq('stripCodeFence removes a ```json fence', stripCodeFence('```json\n{"x":1}\n```'), '{"x":1}');
  c.eq('stripCodeFence leaves unfenced text alone', stripCodeFence('  {"x":1} '), '{"x":1}');
  c.eq('prettyChunk pretty-prints valid JSON', prettyChunk('{"x":1}'), '{\n  "x": 1\n}');
  c.eq('prettyChunk returns garbage unchanged', prettyChunk('garbage'), 'garbage');

  /* ================================================================= *
   * 3. Path / repo-root resolution
   * ================================================================= */
  c.section('repo root + file resolution');
  c.eq('indexPath -> repo root (.codeindex dir)', repoRootFromIndexPath('/a/b/.codeindex'), '/a/b');
  c.eq('indexPath -> repo root (meta.json)', repoRootFromIndexPath('/a/b/.codeindex/meta.json'), '/a/b');
  c.eq('indexPath -> repo root (already a root)', repoRootFromIndexPath('/a/b'), '/a/b');

  const roots = [
    { repo: 'cdu', repoRoot: '/repos/cdu' },
    { repo: 'pou', repoRoot: '/repos/pou' },
  ];
  const onlyPou = (p: string): boolean => p.startsWith('/repos/pou/');
  c.eq(
    'a relative path resolves against the root that actually has the file',
    resolveFileAgainstRoots('src/main/java/A.java', roots, onlyPou),
    { absolutePath: path.join('/repos/pou', 'src/main/java/A.java'), repo: 'pou' },
  );
  c.eq(
    'producer wins when both roots have the file',
    resolveFileAgainstRoots('src/A.java', roots, () => true),
    { absolutePath: path.join('/repos/cdu', 'src/A.java'), repo: 'cdu' },
  );
  c.eq(
    'an unresolvable path returns null rather than guessing',
    resolveFileAgainstRoots('src/Nope.java', roots, () => false),
    null,
  );
  c.eq('an empty path returns null', resolveFileAgainstRoots('', roots, () => true), null);
  c.eq(
    'windows separators are normalized',
    resolveFileAgainstRoots('src\\main\\A.java', roots, onlyPou),
    { absolutePath: path.join('/repos/pou', 'src/main/A.java'), repo: 'pou' },
  );

  /* ================================================================= *
   * 4. Build both fixture repos for the real-data assertions
   * ================================================================= */
  c.section('fixture builds');
  const cdu = materialize(SCRATCH, 'cdu');
  const pou = materialize(SCRATCH, 'pou');

  const cduBuild = await buildIndex({
    repoRoot: cdu.root,
    repo: 'cdu',
    provider: makeProvider(cdu.responseDir),
    model: 'mock-model',
    config: configFor('cdu'),
    logger: silentLogger,
    builtAt: BUILT_AT,
  });
  const pouBuild = await buildIndex({
    repoRoot: pou.root,
    repo: 'pou',
    provider: makeProvider(pou.responseDir),
    model: 'mock-model',
    config: configFor('pou'),
    logger: silentLogger,
    builtAt: BUILT_AT,
  });
  c.check('cdu built endpoints', cduBuild.endpoints.length > 0, `${cduBuild.endpoints.length}`);
  c.check('pou built records', pouBuild.records.length > 0, `${pouBuild.records.length}`);

  const registry = new IndexRegistry(silentLogger);
  const cduRepo = registry.load(cdu.root, silentLogger, 'cdu');
  const pouRepo = registry.load(pou.root, silentLogger, 'pou');

  /* ================================================================= *
   * 5. Hover markdown against real endpoints
   * ================================================================= */
  c.section('endpoint hover markdown');
  const putEndpoint = cduRepo.bundle.endpoints.find((e) => e.verb === 'PUT');
  c.check('cdu has a PUT endpoint', putEndpoint !== undefined, putEndpoint?.id ?? 'none');

  if (putEndpoint !== undefined) {
    const md = endpointHoverMarkdown(putEndpoint, 'cdu', [
      { repo: 'pou', manifest: pouRepo.bundle.manifest },
    ]);
    c.check('hover names the repo', md.includes('endpoint in `cdu`'), '');
    c.check('hover shows the transport', md.includes('**Transport:** `rest`'), '');
    c.check('hover shows the route', md.includes('PUT /api/v1/customers/{id}'), '');
    c.check(
      'hover shows the short fingerprint',
      md.includes(`\`${shortFingerprint(putEndpoint.fingerprint)}\``),
      shortFingerprint(putEndpoint.fingerprint),
    );
    c.check('hover has a logical_name line', md.includes('**Logical name:**'), '');
    c.check('hover reports pou as a consumer', md.includes('`pou`'), '');

    // THE CDU EDGE CASE: the mapping annotations live on the interface, so the
    // hover must name the declaring type as well as the handler class.
    const declaring = declaringTypeOf(putEndpoint);
    c.eq('declaring_type is the interface, not the controller', declaring, 'com.acme.cdu.api.CustomerApi');
    c.check('hover surfaces the declaring interface', md.includes('**Declared on:** `com.acme.cdu.api.CustomerApi`'), '');

    const consuming = consumersOf(putEndpoint, [{ repo: 'pou', manifest: pouRepo.bundle.manifest }]);
    c.eq('consumersOf finds pou', consuming.map((x) => x.repo), ['pou']);
    c.check('consumersOf reports why', (consuming[0]?.signals.length ?? 0) > 0, consuming[0]?.signals.join(', ') ?? '');

    const noConsumers = endpointHoverMarkdown(putEndpoint, 'cdu', []);
    c.check(
      'hover explains an empty consumer configuration',
      noConsumers.includes('No consumer repos configured'),
      '',
    );
  }

  c.section('invocation hover markdown');
  const invocations = pouRepo.index.invocations;
  c.check('pou has invocations', invocations.length > 0, `${invocations.length}`);
  const inv: InvocationRecord | undefined = invocations[0];
  if (inv !== undefined) {
    const unresolvedMd = invocationHoverMarkdown(inv, 'pou', null);
    c.check('unresolved hover says so plainly', unresolvedMd.includes('**Target:** _unresolved_'), '');
    c.check('unresolved hover still names the transport', unresolvedMd.includes('**Transport:**'), '');

    const resolvedMd = invocationHoverMarkdown(inv, 'pou', {
      producerRepo: 'cdu',
      endpointId: 'x',
      route: 'GET /api/v1/customers/{id}',
      matchedVia: ['dto_shape_match', 'property_value:services.cdu.base-url'],
      confidence: 0.95,
    });
    c.check('resolved hover names the target repo', resolvedMd.includes('**Target:** `cdu`'), '');
    c.check('resolved hover lists matched_via', resolvedMd.includes('`dto_shape_match`'), '');
    c.check('resolved hover shows confidence', resolvedMd.includes('**Confidence:** 0.95'), '');
  }

  /* ================================================================= *
   * 6. Invocation target resolution + lens counts
   * ================================================================= */
  c.section('invocation target resolution');
  const targets = resolveInvocationTargets(pouRepo, [cduRepo, pouRepo], silentLogger);
  c.check('at least one pou invocation resolves to a cdu endpoint', targets.size > 0, `${targets.size} resolved`);
  const firstTarget = [...targets.values()][0];
  if (firstTarget !== undefined) {
    c.eq('target producer is cdu', firstTarget.producerRepo, 'cdu');
    c.check('target confidence is a real number', firstTarget.confidence > 0, String(firstTarget.confidence));
    c.check('target carries matched_via reasons', firstTarget.matchedVia.length > 0, firstTarget.matchedVia.join(','));
    c.check(
      'a resolved lens title renders from a real target',
      invocationLensTitle(firstTarget).startsWith('$(arrow-right) Calls cdu:'),
      invocationLensTitle(firstTarget),
    );
  }

  c.section('lens consumer counts');
  const counts = cduRepo.bundle.endpoints.map((ep: Endpoint) =>
    consumerCountFor(ep, [cduRepo, pouRepo], 'cdu', silentLogger),
  );
  c.check('at least one cdu endpoint counts pou as a consumer', counts.some((n) => n > 0), counts.join(','));
  c.check('a producer never counts itself', counts.every((n) => n <= 1), counts.join(','));

  c.section('endpoint pick labels');
  const anyEndpoint = cduRepo.bundle.endpoints[0];
  if (anyEndpoint !== undefined) {
    c.check(
      'pick label leads with the transport',
      endpointPickLabel(anyEndpoint).startsWith(`${anyEndpoint.transport} · `),
      endpointPickLabel(anyEndpoint),
    );
  }

  /* ================================================================= *
   * 7. Result validation, summaries and root ordering
   * ================================================================= */
  c.section('blast radius payload validation');
  const result = registry.blastRadius('cdu', ['pou'], cduRepo.bundle.endpoints[0]?.id ?? '', {
    logger: silentLogger,
  });
  c.eq('a real result validates clean', validateBlastRadiusResult(result), []);
  c.check('summarizeResult mentions the consumer count', summarizeResult(result).includes('consumer(s) consumed'), '');
  c.check('null is rejected', validateBlastRadiusResult(null).length > 0, '');
  c.check('a non-object is rejected', validateBlastRadiusResult(42).length > 0, '');
  c.check(
    'a result missing consumer_blast_radius is rejected',
    validateBlastRadiusResult({ ...result, consumer_blast_radius: undefined }).length > 0,
    '',
  );
  c.check(
    'a result with a malformed consumer entry is rejected',
    validateBlastRadiusResult({ ...result, consumer_blast_radius: [{ repo: 'x' }] }).length > 0,
    '',
  );

  c.section('root ordering for openLocation');
  const ordered = orderRootsForResult(result, [
    { repo: 'pou', repoRoot: pou.root },
    { repo: 'cdu', repoRoot: cdu.root },
  ]);
  c.eq('producer root is probed first', ordered[0]?.repo, 'cdu');
  c.eq('consumer root comes next', ordered[1]?.repo, 'pou');

  /* ================================================================= *
   * 8. Demo baseline round-trip
   * ================================================================= */
  c.section('demo baseline');
  clearBaseline(cdu.root);
  c.eq('no baseline before the first run', hasBaseline(cdu.root), false);
  c.eq('readBaseline returns null with no baseline', readBaseline(cdu.root, silentLogger), null);

  const written = writeBaseline(cdu.root, silentLogger);
  c.check('writeBaseline snapshots fingerprints', written.fingerprints > 0, `${written.fingerprints}`);
  c.check('writeBaseline snapshots endpoints', written.endpoints > 0, `${written.endpoints}`);
  c.check('writeBaseline snapshots dto records', written.dtos > 0, `${written.dtos}`);
  c.eq('hasBaseline is true afterwards', hasBaseline(cdu.root), true);

  const baseline = readBaseline(cdu.root, silentLogger);
  c.check('baseline reads back', baseline !== null, '');
  c.check(
    'baseline carries a bundle view (needed for rename pairing + dto diffs)',
    baseline?.bundle !== null,
    '',
  );
  c.eq(
    'baseline endpoint count round-trips',
    baseline?.bundle?.endpoints.length,
    cduRepo.bundle.endpoints.length,
  );
  c.check(
    'baseline exposes dto records under byKind',
    (baseline?.bundle?.byKind.dto.length ?? 0) > 0,
    `${baseline?.bundle?.byKind.dto.length ?? 0}`,
  );

  const minimal = minimalBundle('/tmp/x', [], []);
  c.eq('minimalBundle has every record kind bucket', Object.keys(minimal.byKind).length, 10);
  c.eq('minimalBundle is well-formed when empty', minimal.endpoints.length, 0);

  /* ================================================================= *
   * 9. Demo change selection priority
   * ================================================================= */
  c.section('demo change selection');
  const mk = (id: string, kind: 'added' | 'removed' | 'modified'): never =>
    ({ id, change_kind: kind, diff_reason: [], diff_details: [] }) as never;
  c.eq('modified wins over added and removed', selectChange([mk('a', 'added'), mk('m', 'modified')])?.id, 'm');
  c.eq('added wins over removed', selectChange([mk('r', 'removed'), mk('a', 'added')])?.id, 'a');
  c.eq('removed is the last resort', selectChange([mk('r', 'removed')])?.id, 'r');
  c.eq('no changes selects nothing', selectChange([]), null);

  c.section('change summaries');
  const summary = changeSummary({
    id: 'x',
    change_kind: 'modified',
    diff_reason: ['path_changed'],
    diff_details: [],
    handler_symbol: null,
    file: null,
    line: null,
    transport: 'rest',
    verb: 'GET',
    path_template: '/a',
    destination: null,
  });
  c.eq('changeSummary reads clearly', summary, 'modified · rest GET /a · path_changed');

  /* ================================================================= *
   * 10. Command-id contract: package.json vs extension.ts
   * ----------------------------------------------------------------- *
   * Diffed mechanically rather than eyeballed — a contributed command
   * with no `registerCommand` is a palette entry that throws "command not
   * found", which is invisible until a user clicks it.
   * ================================================================= */
  c.section('command ids: package.json vs extension.ts');
  const pkg = JSON.parse(fs.readFileSync(path.join(REPO_ROOT, 'package.json'), 'utf8')) as {
    contributes: { commands: Array<{ command: string }> };
  };
  const declared = pkg.contributes.commands.map((x) => x.command).sort();
  const extensionSrc = fs.readFileSync(path.join(REPO_ROOT, 'src', 'extension.ts'), 'utf8');
  const registered = [...extensionSrc.matchAll(/\['(codeindex\.[A-Za-z]+)',/g)]
    .map((m) => m[1] as string)
    .sort();

  c.eq('package.json contributes exactly 10 commands', declared.length, 10);
  const missing = declared.filter((x) => !registered.includes(x));
  const extra = registered.filter((x) => !declared.includes(x));
  c.eq('every contributed command is registered', missing, []);
  c.eq(
    'the only unregistered-in-package.json id is the deliberate showOutput',
    extra,
    ['codeindex.showOutput'],
  );
  for (const id of declared) {
    c.check(`registered: ${id}`, registered.includes(id), '');
  }

  /* ================================================================= *
   * 11. Re-entrancy guard on bundle writers
   * ----------------------------------------------------------------- *
   * The status bar now launches runDemo on click, so a double-click must
   * not start two builds over the same .codeindex/ directory.
   * ================================================================= */
  c.section('single-writer re-entrancy guard');
  resetBusyForTests();
  c.eq('idle to begin with', isBusy(), false);

  let release: () => void = () => undefined;
  const held = new Promise<void>((resolve) => {
    release = resolve;
  });
  const first = runExclusive('Run End-to-End Demo', () => held, () => {
    c.check('the FIRST call must not be refused', false, '');
  });
  await Promise.resolve();
  c.eq('busy while the first command runs', isBusy(), true);
  c.eq('the holder is named', currentLabel(), 'Run End-to-End Demo');

  let refusedBy = '';
  const second = await runExclusive('Build Index for Current Workspace', async () => {
    c.check('the SECOND call must not run its body', false, '');
  }, (holder) => {
    refusedBy = holder;
  });
  c.eq('a concurrent bundle writer is refused', second, false);
  c.eq('the refusal names the command holding the lock', refusedBy, 'Run End-to-End Demo');

  release();
  c.eq('the first call reports that it ran', await first, true);
  c.eq('the lock is released on success', isBusy(), false);

  // The failure mode a naive boolean guard always has: a throw (or a
  // cancellation) that leaves the flag stuck true and the command dead forever.
  await runExclusive('Throwing command', async () => {
    throw new Error('boom');
  }, () => undefined).catch(() => undefined);
  c.eq('the lock is released after a THROW (command is not left dead)', isBusy(), false);
  c.eq('and the holder label is cleared', currentLabel(), '');

  await runExclusive('Cancelled command', async () => {
    throw new CancelledError();
  }, () => undefined).catch(() => undefined);
  c.eq('the lock is released after a CANCELLATION', isBusy(), false);

  const third = await runExclusive('Later command', async () => undefined, () => {
    c.check('a later command must not be refused', false, '');
  });
  c.eq('a later command runs normally', third, true);

  c.summary('ui-sanity');
}

void main().catch((err: unknown) => {
  console.error(err);
  process.exitCode = 1;
});
