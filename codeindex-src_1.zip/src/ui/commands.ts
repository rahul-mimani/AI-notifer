/**
 * Real implementations for every contributed command.
 *
 * House rules, applied uniformly:
 *  - FAIL OPEN. Every command body runs inside `guard`, which logs the failure
 *    under the right stage, sets the error status, shows a readable message with
 *    a "Show Log" affordance, and returns. Nothing throws into the VS Code host.
 *  - NEVER DEAD-END. With no chat model available the build coordinator degrades
 *    to deterministic-only extraction; commands say so plainly and carry on with
 *    whatever was computed rather than aborting.
 *  - The status bar always returns to a resting state, including on failure and
 *    on cancellation (`state.restStatus()` in the `finally` of `guard`).
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import * as vscode from 'vscode';

import type { BlastRadiusResult, ChangedEndpoint, Endpoint, Fingerprint } from '../types.js';
import { readConfig } from '../config.js';
import type { CodeIndexConfig } from '../config.js';
import { buildIndex } from '../coordinator/build.js';
import type { BuildIndexResult } from '../coordinator/build.js';
import { changedFromEndpoint } from '../daemon/blast.js';
import { detectChanges, isConsumed, loadFingerprints } from '../daemon/index.js';
import { VsCodeChatModelProvider, defaultConsentNotice } from '../lm/vscode-provider.js';
import type { ChatModelInfo } from '../lm/provider.js';
import { loadBundle } from '../store/reader.js';
import type { LoadedBundle } from '../store/reader.js';
import { bundlePaths, toRepoRelative } from '../store/paths.js';
import { log, outputChannelLogger, showLog } from '../util/log.js';
import { setStatus } from '../util/status.js';
import type { Stage } from '../util/logger.js';
import { FINGERPRINTS_PREV, hasBaseline, readBaseline, writeBaseline } from './baseline.js';
import { demoNotification, runDemoPipeline } from './demo.js';
import {
  changeListKey,
  openBlastRadiusPanel,
  postChangeList,
  postError,
  postResult,
} from './panel.js';
import { runExclusive } from './exclusive.js';
import { CancelledError, withCancellableProgress } from './progress.js';
import {
  changeSummary,
  endpointPickDetail,
  endpointPickLabel,
  formatLmCacheContent,
  lmCacheDirFor,
  lmCacheEntryPathFor,
  repoRootFromIndexPath,
  summarizeResult,
} from './pure.js';
import type { CodeIndexState } from './state.js';

/* ------------------------------------------------------------------ *
 * Re-entrancy guard
 * ------------------------------------------------------------------ */

/**
 * Bundle-writing commands take a single-writer lock (see `exclusive.ts` for why
 * and for the sanity assertions). This wrapper only supplies the user-facing
 * refusal message.
 */
async function exclusive(label: string, body: () => Promise<void>): Promise<boolean> {
  return runExclusive(label, body, (holder) => {
    log('DAEMON', `${label}: refused — '${holder}' is already running (one bundle writer at a time)`);
    void vscode.window.showInformationMessage(
      `CodeIndex is already running "${holder}". Wait for it to finish, or cancel it, before starting another build.`,
    );
  });
}

/* ------------------------------------------------------------------ *
 * Fail-open wrapper
 * ------------------------------------------------------------------ */

async function guard(
  state: CodeIndexState,
  stage: Stage,
  label: string,
  body: () => Promise<void>,
): Promise<void> {
  try {
    await body();
  } catch (err) {
    if (err instanceof CancelledError) {
      log(stage, `${label}: cancelled by the user`);
      void vscode.window.showInformationMessage(`CodeIndex: ${label} was cancelled.`);
      return;
    }
    const detail = err instanceof Error ? err.message : String(err);
    log(stage, `ERROR ${label}: ${detail}`);
    if (err instanceof Error && err.stack !== undefined) {
      log(stage, err.stack);
    }
    state.lastBuildHadErrors = true;
    setStatus({ kind: 'errors' });
    const choice = await vscode.window.showErrorMessage(`CodeIndex: ${label} failed — ${detail}`, 'Show Log');
    if (choice === 'Show Log') {
      showLog();
    }
  } finally {
    state.building = false;
    state.restStatus();
  }
}

/* ------------------------------------------------------------------ *
 * Pickers
 * ------------------------------------------------------------------ */

async function pickWorkspaceFolder(): Promise<vscode.WorkspaceFolder | null> {
  const folders = vscode.workspace.workspaceFolders ?? [];
  if (folders.length === 0) {
    void vscode.window.showWarningMessage(
      'CodeIndex: no workspace folder is open. Use "Build Index for Folder…" instead.',
    );
    return null;
  }
  if (folders.length === 1) {
    return folders[0] ?? null;
  }
  const picked = await vscode.window.showWorkspaceFolderPick({
    placeHolder: 'Which workspace folder should CodeIndex index?',
  });
  return picked ?? null;
}

async function pickFolder(title: string, defaultUri?: vscode.Uri): Promise<string | null> {
  const picked = await vscode.window.showOpenDialog({
    title,
    openLabel: 'Select',
    canSelectFiles: false,
    canSelectFolders: true,
    canSelectMany: false,
    defaultUri,
  });
  return picked?.[0]?.fsPath ?? null;
}

/** A `.codeindex` bundle directory, its repo root, or a `fingerprints.jsonl`. */
async function pickBundle(title: string, defaultUri?: vscode.Uri): Promise<string | null> {
  const picked = await vscode.window.showOpenDialog({
    title,
    openLabel: 'Select',
    canSelectFiles: true,
    canSelectFolders: true,
    canSelectMany: false,
    defaultUri,
  });
  return picked?.[0]?.fsPath ?? null;
}

async function pickBundles(title: string, defaultUri?: vscode.Uri): Promise<string[]> {
  const picked = await vscode.window.showOpenDialog({
    title,
    openLabel: 'Select',
    canSelectFiles: true,
    canSelectFolders: true,
    canSelectMany: true,
    defaultUri,
  });
  return (picked ?? []).map((u) => u.fsPath);
}

/* ------------------------------------------------------------------ *
 * LM provider + consent
 * ------------------------------------------------------------------ */

/**
 * The real `vscode.lm` provider, with the consent notice wired to fire once,
 * immediately before the first request of a session.
 *
 * The notice goes to the OUTPUT CHANNEL first and in full — it names exactly
 * what leaves the machine (the text of candidate Java files) — and only then to
 * a notification, so the record exists even if the toast is dismissed unread.
 */
function makeProvider(state: CodeIndexState): VsCodeChatModelProvider {
  return new VsCodeChatModelProvider({
    onFirstUse: (model: ChatModelInfo) => {
      log(
        'LM',
        'CONSENT — about to make the first language model request of this session.\n' +
          `  model: ${model.id} (maxInputTokens=${model.maxInputTokens})\n` +
          '  WHAT IS SENT: the full text of each candidate Java file in the repo being indexed,\n' +
          '                one file per request, chunked when a file exceeds the input budget.\n' +
          '  WHAT IS NOT SENT: config/property files, other repos, git history, or the bundle.\n' +
          '  Raw responses are cached under <repoRoot>/.codeindex/lm_cache/<sha256>.json;\n' +
          '  clear them with "CodeIndex: Clear LM Cache".',
      );
      defaultConsentNotice(model);
      state.lmUnavailable = false;
    },
  });
}

/* ------------------------------------------------------------------ *
 * Build
 * ------------------------------------------------------------------ */

/**
 * Index `repoRoot` behind a cancellable notification, load the bundle into the
 * registry, and report a summary.
 *
 * Returns null when the user cancelled. A build that ran but produced partial
 * results still returns its bundle — a partial index beats no index.
 */
async function runBuild(
  state: CodeIndexState,
  repoRoot: string,
  repoName: string,
  cfg: CodeIndexConfig,
): Promise<BuildIndexResult | null> {
  state.building = true;
  const started = Date.now();

  const result = await withCancellableProgress<BuildIndexResult | null>(
    `CodeIndex: indexing ${repoName}`,
    async (handle) => {
      log('DAEMON', `build start · repo='${repoName}' root=${repoRoot}`);
      setStatus({ kind: 'indexing', done: 0, total: 0 });

      const built = await buildIndex({
        repoRoot,
        repo: repoName,
        provider: makeProvider(state),
        model: cfg.lmModel,
        config: cfg,
        logger: outputChannelLogger,
        builtAt: new Date().toISOString(),
        signal: handle.signal,
        onProgress: (p) => handle.report(p),
      });

      if (handle.cancelled()) {
        // The coordinator is fail-open, so an aborted run still returns a
        // bundle; say so rather than pretending the index is complete.
        log('DAEMON', `build of '${repoName}' was cancelled — a partial bundle was written`);
      }
      return built;
    },
    () => {
      state.building = false;
    },
  );

  if (result === null) {
    return null;
  }

  state.lmUnavailable = result.deterministicOnly;
  const stats = result.meta.stats;
  const skipped = (stats['files_filtered_out'] ?? 0) as number;
  state.lastBuildHadErrors =
    result.write.totalBytes === 0 || (result.endpoints.length === 0 && !result.deterministicOnly);

  log(
    'DAEMON',
    `build done · repo='${repoName}' in ${Date.now() - started}ms — ` +
      `${stats['java_files_walked'] ?? 0} java files walked, ${skipped} filtered out, ` +
      `${stats['files_extracted'] ?? 0} extracted, ${result.endpoints.length} endpoint(s), ` +
      `${result.fingerprints.length} fingerprint(s), ${result.records.length} record(s), ` +
      `${result.callgraphStats.symbols} callgraph symbol(s) / ${result.callgraphStats.edges} edge(s), ` +
      `${result.write.totalBytes} bytes written to ${result.bundleRoot}` +
      (result.deterministicOnly ? ' [DETERMINISTIC-ONLY: no chat model was used]' : ''),
  );

  state.loadRepo(repoRoot, repoName);

  if (result.deterministicOnly) {
    void vscode.window
      .showWarningMessage(
        `CodeIndex indexed "${repoName}" in deterministic-only mode — no language model was available, ` +
          'so endpoints and invocations could not be extracted. Property, wiring and config data are complete.',
        'Show Log',
      )
      .then((choice) => {
        if (choice === 'Show Log') {
          showLog();
        }
      });
  }
  return result;
}

/* ------------------------------------------------------------------ *
 * Bundle helpers
 * ------------------------------------------------------------------ */

/** Load a bundle from a repo root, a `.codeindex` dir, or a file inside one. */
function loadBundleFrom(target: string): { bundle: LoadedBundle; repoRoot: string } {
  const repoRoot = repoRootFromIndexPath(target);
  return { bundle: loadBundle(repoRoot, outputChannelLogger), repoRoot };
}

function repoNameFor(bundle: LoadedBundle, repoRoot: string): string {
  return bundle.meta.repo !== '' ? bundle.meta.repo : path.basename(repoRoot);
}

/** Register a bundle from disk so blast radius can query it by repo name. */
function registerBundle(state: CodeIndexState, target: string): { repo: string; repoRoot: string } | null {
  const repoRoot = repoRootFromIndexPath(target);
  const entry = state.loadRepo(repoRoot);
  if (entry === null) {
    return null;
  }
  return { repo: entry.repo, repoRoot: entry.repoRoot };
}

/**
 * Load every repo named by `codeindex.consumerRepos` and return their names.
 * This is the setting that was previously read and never used.
 */
function loadConfiguredConsumers(state: CodeIndexState, cfg: CodeIndexConfig): string[] {
  const names: string[] = [];
  for (const setting of cfg.consumerRepos) {
    if (setting.indexPath === undefined || setting.indexPath === '') {
      log('DAEMON', `codeindex.consumerRepos entry '${setting.name}' has no indexPath — skipped`);
      continue;
    }
    const repoRoot = repoRootFromIndexPath(setting.indexPath);
    if (!fs.existsSync(bundlePaths(repoRoot).meta)) {
      log('DAEMON', `consumer repo '${setting.name}': no bundle at ${repoRoot}/.codeindex — skipped`);
      continue;
    }
    const entry = state.loadRepo(repoRoot, setting.name !== '' ? setting.name : undefined);
    if (entry !== null) {
      names.push(entry.repo);
    }
  }
  log('DAEMON', `codeindex.consumerRepos resolved to ${names.length} loaded repo(s): [${names.join(', ')}]`);
  return names;
}

async function pickEndpoint(endpoints: readonly Endpoint[], placeHolder: string): Promise<Endpoint | null> {
  if (endpoints.length === 0) {
    void vscode.window.showWarningMessage('CodeIndex: that bundle contains no endpoints.');
    return null;
  }
  const items = endpoints.map((ep) => ({
    label: endpointPickLabel(ep),
    detail: endpointPickDetail(ep),
    ep,
  }));
  const picked = await vscode.window.showQuickPick(items, { placeHolder, matchOnDetail: true });
  return picked?.ep ?? null;
}

/** Run the blast radius and drive the panel through loading -> result/error. */
function showBlastRadius(
  state: CodeIndexState,
  producerRepo: string,
  consumerRepos: readonly string[],
  endpointId: string,
  changed: ChangedEndpoint | null,
  maxDepth: number,
): BlastRadiusResult | null {
  openBlastRadiusPanel(state.extensionUri, endpointId);
  try {
    const result = state.registry.blastRadius(producerRepo, consumerRepos, endpointId, {
      changed,
      maxDepth,
      logger: outputChannelLogger,
    });
    log('QUERY', `blast radius ready — ${summarizeResult(result)}`);
    postResult(state.extensionUri, endpointId, result, state.roots());
    return result;
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    postError(endpointId, `Blast radius failed: ${detail}`);
    throw err;
  }
}

/* ------------------------------------------------------------------ *
 * 1. codeindex.buildIndex
 * ------------------------------------------------------------------ */

export function buildIndexCommand(state: CodeIndexState): () => Promise<void> {
  return () =>
    guard(state, 'DAEMON', 'Build Index for Current Workspace', async () => {
      await exclusive('Build Index for Current Workspace', async () => {
        const folder = await pickWorkspaceFolder();
        if (folder === null) {
          return;
        }
        const cfg = readConfig(folder.uri);
        showLog();
        await runBuild(state, folder.uri.fsPath, folder.name, cfg);
      });
    });
}

/* ------------------------------------------------------------------ *
 * 2. codeindex.buildIndexForFolder
 * ------------------------------------------------------------------ */

export function buildIndexForFolderCommand(state: CodeIndexState): () => Promise<void> {
  return () =>
    guard(state, 'DAEMON', 'Build Index for Folder', async () => {
      await exclusive('Build Index for Folder', async () => {
        const folder = await pickFolder('Select the repository to index');
        if (folder === null) {
          return;
        }
        const cfg = readConfig(vscode.Uri.file(folder));
        showLog();
        await runBuild(state, folder, path.basename(folder), cfg);
      });
    });
}

/* ------------------------------------------------------------------ *
 * 3. codeindex.detectChanges
 * ------------------------------------------------------------------ */

/**
 * PURE change detection — no blast radius is computed here.
 *
 * The webview opens in change-list mode showing only what changed. A blast
 * radius is computed lazily, for one endpoint, when the user clicks that row's
 * "Show blast radius" button (`onRequestBlastRadius` below).
 */
export function detectChangesCommand(state: CodeIndexState): () => Promise<void> {
  return () =>
    guard(state, 'QUERY', 'Detect API Changes', async () => {
      const source = await pickDiffSources(state);
      if (source === null) {
        return;
      }

      showLog();
      log('QUERY', `detectChanges: old=${source.oldLabel} new=${source.newLabel}`);

      const changes = detectChanges(source.oldSide.fingerprints, source.newSide.fingerprints, {
        oldBundle: source.oldSide.bundle,
        newBundle: source.newSide.bundle,
        logger: outputChannelLogger,
      });

      for (const c of changes) {
        log('QUERY', `  ${c.id} — ${changeSummary(c)}`);
      }

      if (changes.length === 0) {
        log('QUERY', 'detectChanges: no API changes between the two bundles');
        void vscode.window.showInformationMessage('CodeIndex: no API changes between those two bundles.');
        return;
      }

      // The NEW side is the producer; register it so a lazily requested blast
      // radius has something to query.
      const producer = source.newRepoRoot === null ? null : registerBundle(state, source.newRepoRoot);
      const cfg = readConfig();
      const key = changeListKey(producer?.repo ?? 'unknown');

      postChangeList(state.extensionUri, key, changes, state.roots(), (endpointId: string) => {
        void guard(state, 'QUERY', 'Show Blast Radius (from change list)', async () => {
          if (producer === null) {
            postError(
              key,
              'The new side is a bare fingerprint file, so there is no bundle to run a blast radius against.',
            );
            return;
          }
          const consumers = loadConfiguredConsumers(state, cfg);
          const changed = changes.find((c) => c.id === endpointId) ?? null;
          log('QUERY', `change list -> blast radius for ${endpointId} across [${consumers.join(', ')}]`);
          const result = state.registry.blastRadius(producer.repo, consumers, endpointId, {
            changed,
            maxDepth: cfg.maxCallerDepth,
            logger: outputChannelLogger,
          });
          postResult(state.extensionUri, key, result, state.roots());
        });
      });

      void vscode.window.showInformationMessage(
        `CodeIndex: ${changes.length} API change(s). Click "Show blast radius" on a row for its impact.`,
      );
    });
}

interface DiffSide {
  fingerprints: string | Fingerprint[];
  bundle: LoadedBundle | null;
}

interface DiffSources {
  oldSide: DiffSide;
  newSide: DiffSide;
  oldLabel: string;
  newLabel: string;
  /** Repo root of the NEW side, when it is a real bundle. */
  newRepoRoot: string | null;
}

/**
 * Choose what to diff.
 *
 * The overwhelmingly common case is "what changed since my last index of this
 * workspace?", which needs no path picking at all — so when the workspace
 * bundle carries a `fingerprints.prev.jsonl` baseline, that is offered as the
 * FIRST QuickPick option. The option is omitted entirely when no baseline
 * exists, rather than offered and then failing.
 */
async function pickDiffSources(state: CodeIndexState): Promise<DiffSources | null> {
  const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath ?? null;
  const baselineAvailable = workspaceRoot !== null && hasBaseline(workspaceRoot);

  if (baselineAvailable && workspaceRoot !== null) {
    const CURRENT_VS_PREV = 'current-vs-previous';
    const PICK_PATHS = 'pick-paths';
    const choice = await vscode.window.showQuickPick(
      [
        {
          label: '$(history) Current vs. previous',
          detail: `Diff ${path.basename(workspaceRoot)}'s current index against its saved baseline`,
          id: CURRENT_VS_PREV,
        },
        {
          label: '$(folder-opened) Pick two bundles…',
          detail: 'Choose the old and new .codeindex bundles by hand',
          id: PICK_PATHS,
        },
      ],
      { placeHolder: 'What should CodeIndex diff?' },
    );
    if (choice === undefined) {
      return null;
    }
    if (choice.id === CURRENT_VS_PREV) {
      const baseline = readBaseline(workspaceRoot, outputChannelLogger);
      if (baseline === null) {
        void vscode.window.showWarningMessage('CodeIndex: the baseline disappeared. Pick two bundles instead.');
        return null;
      }
      const current = loadBundle(workspaceRoot, outputChannelLogger);
      return {
        oldSide: { fingerprints: baseline.fingerprints, bundle: baseline.bundle },
        newSide: { fingerprints: current.fingerprints, bundle: current },
        oldLabel: `${workspaceRoot}/.codeindex/${FINGERPRINTS_PREV}`,
        newLabel: workspaceRoot,
        newRepoRoot: workspaceRoot,
      };
    }
  }

  const oldTarget = await pickBundle('Select the OLD bundle (.codeindex folder, repo root, or fingerprints.jsonl)');
  if (oldTarget === null) {
    return null;
  }
  const newTarget = await pickBundle('Select the NEW bundle (.codeindex folder, repo root, or fingerprints.jsonl)');
  if (newTarget === null) {
    return null;
  }
  void state;
  return {
    oldSide: sideFor(oldTarget),
    newSide: sideFor(newTarget),
    oldLabel: oldTarget,
    newLabel: newTarget,
    newRepoRoot: newTarget.endsWith('.jsonl') ? null : repoRootFromIndexPath(newTarget),
  };
}

/** A picked path becomes either a bundle (rich diff) or a bare fingerprint list. */
function sideFor(target: string): DiffSide {
  if (target.endsWith('.jsonl')) {
    return { fingerprints: loadFingerprints(target, outputChannelLogger), bundle: null };
  }
  const repoRoot = repoRootFromIndexPath(target);
  const bundle = loadBundle(repoRoot, outputChannelLogger);
  if (!bundle.present) {
    log('QUERY', `no bundle at ${repoRoot}/.codeindex — degrading to an id-only diff`);
    return { fingerprints: [], bundle: null };
  }
  return { fingerprints: bundle.fingerprints, bundle };
}

/* ------------------------------------------------------------------ *
 * 4. codeindex.checkConsumerImpact
 * ------------------------------------------------------------------ */

export function checkConsumerImpactCommand(state: CodeIndexState): () => Promise<void> {
  return () =>
    guard(state, 'QUERY', 'Check Consumer Impact', async () => {
      const producerTarget = await pickBundle('Select the PRODUCER bundle (.codeindex folder or repo root)');
      if (producerTarget === null) {
        return;
      }
      const consumerTargets = await pickBundles('Select one or more CONSUMER bundles');
      if (consumerTargets.length === 0) {
        void vscode.window.showWarningMessage('CodeIndex: no consumer bundles selected.');
        return;
      }

      showLog();
      const producer = loadBundleFrom(producerTarget);
      const producerRepo = repoNameFor(producer.bundle, producer.repoRoot);

      // No "before" snapshot was supplied, so every producer endpoint is treated
      // as a candidate change — the honest reading of "what would break".
      const changed: Array<{ changed: ChangedEndpoint; endpoint: Endpoint }> = producer.bundle.endpoints.map(
        (ep) => ({ changed: changedFromEndpoint(ep), endpoint: ep }),
      );
      log(
        'QUERY',
        `checkConsumerImpact: ${producerRepo} has ${changed.length} endpoint(s); ` +
          `checking ${consumerTargets.length} consumer bundle(s)`,
      );

      const consumers = consumerTargets.map((t) => {
        const loaded = loadBundleFrom(t);
        return { repo: repoNameFor(loaded.bundle, loaded.repoRoot), bundle: loaded.bundle };
      });

      const rows: Array<{ label: string; description: string; detail: string }> = [];
      let consumedCount = 0;

      for (const { changed: ch, endpoint } of changed) {
        const consumedBy: string[] = [];
        const reasons: string[] = [];
        for (const consumer of consumers) {
          const gate = isConsumed(ch, consumer.bundle.manifest, {
            producerEndpoint: endpoint,
            logger: outputChannelLogger,
          });
          if (gate.consumed) {
            consumedBy.push(consumer.repo);
            reasons.push(`${consumer.repo}: ${gate.signals.join(', ')}`);
          }
        }
        if (consumedBy.length > 0) {
          consumedCount += 1;
        }
        log(
          'QUERY',
          `  ${endpointPickLabel(endpoint)} -> ` +
            (consumedBy.length === 0 ? 'NOT consumed' : `consumed by ${consumedBy.join(', ')}`),
        );
        rows.push({
          label: `${consumedBy.length > 0 ? '$(check)' : '$(circle-slash)'} ${endpointPickLabel(endpoint)}`,
          description: consumedBy.length === 0 ? 'not consumed' : `consumed by ${consumedBy.join(', ')}`,
          detail: reasons.length === 0 ? 'no phase-1 signal fired against any selected consumer' : reasons.join(' · '),
        });
      }

      log(
        'QUERY',
        `checkConsumerImpact: ${consumedCount}/${changed.length} endpoint(s) are consumed by at least one selected consumer`,
      );
      await vscode.window.showQuickPick(rows, {
        placeHolder: `${consumedCount} of ${changed.length} ${producerRepo} endpoint(s) are consumed — Esc to close`,
        matchOnDetail: true,
      });
    });
}

/* ------------------------------------------------------------------ *
 * 5. codeindex.blastRadiusAtCursor
 * ------------------------------------------------------------------ */

/** Optional argument supplied by the code lens. */
export interface CursorLensArg {
  repo?: string;
  endpointId?: string;
  file?: string;
  line?: number;
}

export function blastRadiusAtCursorCommand(state: CodeIndexState): (arg?: CursorLensArg) => Promise<void> {
  return (arg?: CursorLensArg) =>
    guard(state, 'QUERY', 'Show Blast Radius for Endpoint at Cursor', async () => {
      const cfg = readConfig();

      let repo = arg?.repo ?? '';
      let endpointId = arg?.endpointId ?? '';
      let endpoint: Endpoint | null = null;

      if (repo === '' || endpointId === '') {
        const editor = vscode.window.activeTextEditor;
        if (editor === undefined || editor.document.languageId !== 'java') {
          void vscode.window.showWarningMessage(
            'CodeIndex: open a Java file and place the cursor on an endpoint handler first.',
          );
          return;
        }
        const entry = state.repoForFile(editor.document.uri.fsPath);
        if (entry === null) {
          void vscode.window.showWarningMessage(
            'CodeIndex: this file is not part of an indexed repo. Run "CodeIndex: Build Index for Current Workspace" first.',
          );
          return;
        }
        const relative = toRepoRelative(entry.repoRoot, editor.document.uri.fsPath);
        const line = editor.selection.active.line + 1;
        endpoint = state.registry.getEndpointAt(entry.repo, relative, line);
        if (endpoint === null) {
          void vscode.window.showInformationMessage(
            `CodeIndex: there is no indexed endpoint at ${path.basename(relative)}:${line}. ` +
              'Place the cursor on a handler method declaration (or its mapping annotation).',
          );
          return;
        }
        repo = entry.repo;
        endpointId = endpoint.id;
      } else {
        endpoint = state.registry.get(repo)?.bundle.endpointsById.get(endpointId) ?? null;
      }

      showLog();
      const consumers = loadConfiguredConsumers(state, cfg);
      if (consumers.length === 0) {
        void vscode.window
          .showWarningMessage(
            'CodeIndex: no consumer repos are configured, so the blast radius will only show the producer side.',
            'Configure',
          )
          .then((choice) => {
            if (choice === 'Configure') {
              void vscode.commands.executeCommand('codeindex.configureConsumerRepos');
            }
          });
      }

      log(
        'QUERY',
        `blastRadiusAtCursor: ${repo}:${endpointId} vs [${consumers.join(', ')}] (depth<=${cfg.maxCallerDepth})`,
      );
      showBlastRadius(
        state,
        repo,
        consumers,
        endpointId,
        endpoint === null ? null : changedFromEndpoint(endpoint),
        cfg.maxCallerDepth,
      );
    });
}

/* ------------------------------------------------------------------ *
 * 6. codeindex.blastRadiusAcrossConsumers
 * ------------------------------------------------------------------ */

export interface AcrossConsumersArg {
  producerRepo?: string;
  endpointId?: string;
}

export function blastRadiusAcrossConsumersCommand(
  state: CodeIndexState,
): (arg?: AcrossConsumersArg) => Promise<void> {
  return (arg?: AcrossConsumersArg) =>
    guard(state, 'QUERY', 'Show Blast Radius Across Consumers', async () => {
      const cfg = readConfig();
      showLog();

      // The lens hands us an already-resolved producer + endpoint; only prompt
      // when we are starting cold from the palette.
      if (arg?.producerRepo !== undefined && arg.endpointId !== undefined && state.registry.has(arg.producerRepo)) {
        const consumers = state.registry.list().filter((r) => r !== arg.producerRepo);
        const ep = state.registry.get(arg.producerRepo)?.bundle.endpointsById.get(arg.endpointId) ?? null;
        showBlastRadius(
          state,
          arg.producerRepo,
          consumers,
          arg.endpointId,
          ep === null ? null : changedFromEndpoint(ep),
          cfg.maxCallerDepth,
        );
        return;
      }

      const producerTarget = await pickBundle('Select the PRODUCER bundle (.codeindex folder or repo root)');
      if (producerTarget === null) {
        return;
      }
      const producer = registerBundle(state, producerTarget);
      if (producer === null) {
        void vscode.window.showWarningMessage(`CodeIndex: could not load a bundle from ${producerTarget}.`);
        return;
      }

      const consumerTargets = await pickBundles('Select one or more CONSUMER bundles');
      const consumerRepos: string[] = [];
      for (const target of consumerTargets) {
        const loaded = registerBundle(state, target);
        if (loaded !== null && loaded.repo !== producer.repo) {
          consumerRepos.push(loaded.repo);
        }
      }
      if (consumerRepos.length === 0) {
        log('QUERY', 'blastRadiusAcrossConsumers: no consumer bundles loaded — falling back to configured repos');
        consumerRepos.push(...loadConfiguredConsumers(state, cfg).filter((r) => r !== producer.repo));
      }

      const endpoints = state.registry.endpoints(producer.repo);
      const endpoint = await pickEndpoint(endpoints, `Which ${producer.repo} endpoint?`);
      if (endpoint === null) {
        return;
      }

      log(
        'QUERY',
        `blastRadiusAcrossConsumers: ${producer.repo}:${endpoint.id} vs [${consumerRepos.join(', ')}]`,
      );
      showBlastRadius(
        state,
        producer.repo,
        consumerRepos,
        endpoint.id,
        changedFromEndpoint(endpoint),
        cfg.maxCallerDepth,
      );
    });
}

/* ------------------------------------------------------------------ *
 * 7. codeindex.runDemo
 * ------------------------------------------------------------------ */

const DEMO_PRODUCER_KEY = 'codeindex.demo.producerRoot';
const DEMO_CONSUMER_KEY = 'codeindex.demo.consumerRoot';

/**
 * The headline command: two Enter presses to a full cross-repo blast radius.
 *
 * Prompts default to the LAST-USED paths (persisted in `globalState`), falling
 * back to the bundled `fixtures/cdu` and `fixtures/pou` on a first run — so a
 * repeat run really is two Enters. Everything after the prompts lives in
 * `runDemoPipeline` (vscode-free, verified headlessly by `demo-sanity.ts`).
 *
 * The baseline is advanced ONLY after the webview has opened. On any earlier
 * exit — cancellation, no endpoints, a thrown error — the previous baseline
 * survives, so a retry still diffs against the same "before" state.
 */
export function runDemoCommand(state: CodeIndexState): () => Promise<void> {
  return () =>
    guard(state, 'DAEMON', 'Run End-to-End Demo', async () => {
      await exclusive('Run End-to-End Demo', async () => {
        showLog();
        log('DAEMON', '===== DEMO: start =====');

        const fixtures = vscode.Uri.joinPath(state.extensionUri, 'fixtures');
        const lastProducer = state.memento.get<string>(DEMO_PRODUCER_KEY);
        const lastConsumer = state.memento.get<string>(DEMO_CONSUMER_KEY);

        const producerRoot = await pickFolder(
          'DEMO step 1 of 2 — PRODUCER repo (press Enter to accept the default)',
          defaultUriFor(lastProducer, vscode.Uri.joinPath(fixtures, 'cdu')),
        );
        if (producerRoot === null) {
          log('DAEMON', 'DEMO: cancelled at the producer prompt');
          return;
        }
        const consumerRoot = await pickFolder(
          'DEMO step 2 of 2 — CONSUMER repo (press Enter to accept the default)',
          defaultUriFor(lastConsumer, vscode.Uri.joinPath(fixtures, 'pou')),
        );
        if (consumerRoot === null) {
          log('DAEMON', 'DEMO: cancelled at the consumer prompt');
          return;
        }

        await state.memento.update(DEMO_PRODUCER_KEY, producerRoot);
        await state.memento.update(DEMO_CONSUMER_KEY, consumerRoot);

        const producerName = path.basename(producerRoot);
        const consumerName = path.basename(consumerRoot);
        const producerCfg = readConfig(vscode.Uri.file(producerRoot));
        const consumerCfg = readConfig(vscode.Uri.file(consumerRoot));
        log('DAEMON', `DEMO: producer='${producerName}' (${producerRoot})`);
        log('DAEMON', `DEMO: consumer='${consumerName}' (${consumerRoot})`);

        state.building = true;
        const outcome = await withCancellableProgress(
          'CodeIndex: running end-to-end demo',
          async (handle) =>
            runDemoPipeline({
              producer: {
                root: producerRoot,
                repo: producerName,
                config: producerCfg,
                provider: makeProvider(state),
              },
              consumer: {
                root: consumerRoot,
                repo: consumerName,
                config: consumerCfg,
                provider: makeProvider(state),
              },
              registry: state.registry,
              logger: outputChannelLogger,
              builtAt: new Date().toISOString(),
              maxDepth: producerCfg.maxCallerDepth,
              signal: handle.signal,
              onProgress: (p) => handle.report(p),
            }),
          () => {
            state.building = false;
          },
        );

        state.notifyChanged();

        if (outcome === null) {
          log('DAEMON', 'DEMO: stopped before a result was produced — baseline left untouched');
          void vscode.window.showWarningMessage(
            'CodeIndex demo did not produce a result (cancelled, or the producer has no endpoints). ' +
              'The change-detection baseline was left untouched. See the CodeIndex output channel.',
          );
          return;
        }

        state.lmUnavailable = outcome.deterministicOnly;
        if (outcome.deterministicOnly) {
          void vscode.window.showWarningMessage(
            'CodeIndex demo: no Copilot chat model is available, so both repos were indexed in ' +
              'deterministic-only mode. The webview opens with an empty-but-valid result — everything except ' +
              'LM extraction still ran for real. See the CodeIndex output channel.',
          );
        }

        // ---- open the webview ----------------------------------------
        postResult(state.extensionUri, outcome.selectedEndpointId, outcome.result, state.roots());
        log('DAEMON', `DEMO: result — ${summarizeResult(outcome.result)}`);

        // ---- ONLY NOW advance the baseline ---------------------------
        const written = writeBaseline(outcome.producerBundleRoot, outputChannelLogger);
        log(
          'DAEMON',
          `DEMO: baseline advanced — ${written.fingerprints} fingerprint(s), ` +
            `${written.endpoints} endpoint(s), ${written.dtos} dto(s). The next run diffs against this.`,
        );

        void vscode.window.showInformationMessage(demoNotification(outcome));
        log('DAEMON', `===== DEMO: done — ${demoNotification(outcome)} =====`);
      });
    });
}

function defaultUriFor(remembered: string | undefined, fallback: vscode.Uri): vscode.Uri {
  if (remembered !== undefined && remembered !== '' && fs.existsSync(remembered)) {
    return vscode.Uri.file(remembered);
  }
  return fallback;
}

/* ------------------------------------------------------------------ *
 * 8. codeindex.showRawLmExtraction
 * ------------------------------------------------------------------ */

export function showRawLmExtractionCommand(state: CodeIndexState): () => Promise<void> {
  return () =>
    guard(state, 'LM', 'Show Raw LM Extraction for Current File', async () => {
      const editor = vscode.window.activeTextEditor;
      if (editor === undefined) {
        void vscode.window.showWarningMessage('CodeIndex: open a file first.');
        return;
      }
      const filePath = editor.document.uri.fsPath;

      // The cache lives under the repo root the file was indexed from. Prefer a
      // resident repo; fall back to the workspace folder.
      const resident = state.repoForFile(filePath);
      const folder = vscode.workspace.getWorkspaceFolder(editor.document.uri);
      const repoRoot = resident?.repoRoot ?? folder?.uri.fsPath ?? path.dirname(filePath);

      const content = editor.document.getText();
      const entryPath = lmCacheEntryPathFor(repoRoot, content);
      log('LM', `showRawLmExtraction: ${filePath} -> ${entryPath}`);

      if (!fs.existsSync(entryPath)) {
        const cacheDir = lmCacheDirFor(repoRoot);
        const cacheExists = fs.existsSync(cacheDir);
        const entries = cacheExists ? fs.readdirSync(cacheDir).length : 0;
        const why = !cacheExists
          ? `there is no LM cache at ${cacheDir} — this repo has not been indexed yet`
          : `the cache holds ${entries} entr${entries === 1 ? 'y' : 'ies'}, but none for this file's CURRENT content — ` +
            'either the file was never extracted (filtered out as a non-candidate), or it has been edited since ' +
            'the last index (the cache key is a sha256 of the exact file text)';
        log('LM', `showRawLmExtraction: cache miss — ${why}`);
        const choice = await vscode.window.showInformationMessage(
          `CodeIndex: no cached LM extraction for this file. Reason: ${why}.`,
          'Build Index',
          'Show Log',
        );
        if (choice === 'Build Index') {
          await vscode.commands.executeCommand('codeindex.buildIndex');
        } else if (choice === 'Show Log') {
          showLog();
        }
        return;
      }

      const raw = fs.readFileSync(entryPath, 'utf8');
      const pretty = formatLmCacheContent(raw);
      const doc = await vscode.workspace.openTextDocument({ language: 'json', content: pretty });
      await vscode.window.showTextDocument(doc, { preview: false });
      log('LM', `showRawLmExtraction: opened ${pretty.length} chars from ${path.basename(entryPath)}`);
    });
}

/* ------------------------------------------------------------------ *
 * 9. codeindex.clearLmCache
 * ------------------------------------------------------------------ */

export function clearLmCacheCommand(state: CodeIndexState): () => Promise<void> {
  return () =>
    guard(state, 'LM', 'Clear LM Cache', async () => {
      const folder = await pickWorkspaceFolder();
      const repoRoot = folder?.uri.fsPath ?? (await pickFolder('Select the repo whose LM cache should be cleared'));
      if (repoRoot === null || repoRoot === undefined) {
        return;
      }
      const cacheDir = lmCacheDirFor(repoRoot);

      if (!fs.existsSync(cacheDir)) {
        log('LM', `clearLmCache: nothing at ${cacheDir}`);
        void vscode.window.showInformationMessage(`CodeIndex: there is no LM cache at ${cacheDir}.`);
        return;
      }
      const entries = fs.readdirSync(cacheDir).filter((f) => f.endsWith('.json'));

      const confirm = await vscode.window.showWarningMessage(
        `Delete ${entries.length} cached LM extraction${entries.length === 1 ? '' : 's'} from ${cacheDir}?`,
        {
          modal: true,
          detail:
            'This cannot be undone. The next index of this repo will re-send every candidate Java file to the ' +
            'language model, which costs time and quota.',
        },
        'Delete',
      );
      if (confirm !== 'Delete') {
        log('LM', 'clearLmCache: cancelled at the confirmation');
        return;
      }

      fs.rmSync(cacheDir, { recursive: true, force: true });
      log('LM', `clearLmCache: removed ${entries.length} entr${entries.length === 1 ? 'y' : 'ies'} from ${cacheDir}`);
      void vscode.window.showInformationMessage(
        `CodeIndex: removed ${entries.length} cached LM extraction${entries.length === 1 ? '' : 's'}.`,
      );
    });
}

/* ------------------------------------------------------------------ *
 * 10. codeindex.configureConsumerRepos
 * ------------------------------------------------------------------ */

export function configureConsumerReposCommand(): () => Promise<void> {
  return async () => {
    await vscode.commands.executeCommand('workbench.action.openSettings', 'codeindex.consumerRepos');
  };
}
