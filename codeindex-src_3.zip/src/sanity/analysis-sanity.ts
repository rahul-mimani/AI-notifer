/**
 * Sanity run for the AI impact analysis.
 *
 * Everything here runs against REAL bundles built from `fixtures/cdu` and
 * `fixtures/pou` through the real `buildIndex`, and against a real temporary git
 * repository for the worktree assertions. The only thing mocked is the chat
 * model itself, via `MockChatModelProvider`.
 *
 * Run:  npx tsc --outDir out && node out/sanity/analysis-sanity.js
 */

import { execFileSync } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';

import type { ChangedEndpoint, SymbolRecord } from '../types.js';
import { silentLogger } from '../util/logger.js';
import { buildIndex } from '../coordinator/build.js';
import { IndexRegistry } from '../daemon/daemon.js';
import { MockChatModelProvider } from '../lm/provider.js';
import {
  ANALYSIS_REQUIRED_SECTIONS,
  ANALYSIS_SYSTEM_PROMPT,
  buildAnalysisPrompt,
} from '../lm/analysis-prompt.js';
import {
  assembleEvidence,
  buildReport,
  computeImpact,
  generateNarrative,
  isUsableNarrative,
} from '../ui/analysis.js';
import type { AnalysedSymbol } from '../ui/analysis.js';
import { EVIDENCE_MAX_BYTES, evidenceBytes, evidenceJson } from '../ui/evidence.js';
import { findAffectedEndpoints } from '../ui/impact-graph.js';
import {
  ALL_ENDPOINTS,
  buildEndpointPickOptions,
  detectLocalChanges,
  summarizeChangedFiles,
  symbolsForChangedFiles,
  withHeadWorktree,
} from '../ui/local-changes.js';
import { renderEvidenceAppendix, sanitizeFragment, sectionsPresent } from '../ui/report-html.js';
import { symbolAtCursor } from '../ui/symbol-at.js';
import {
  BUILT_AT,
  Checks,
  REPO_ROOT,
  SCRATCH_ROOT,
  configFor,
  makeProvider,
  materialize,
} from './fixture-build.js';

const c = new Checks();
const SCRATCH = path.join(SCRATCH_ROOT, 'analysis-sanity');

const APPLY_UPDATE = 'cdu:com.acme.cdu.service.CustomerService#applyUpdate(Ljava/lang/String;Lcom/acme/cdu/dto/UpdateCustomerRequest;)Lcom/acme/cdu/dto/CustomerDto;';
const UPDATE_CUSTOMER = 'cdu:com.acme.cdu.controller.CustomerController#updateCustomer(Ljava/lang/String;Lcom/acme/cdu/dto/UpdateCustomerRequest;)Lcom/acme/cdu/dto/CustomerDto;';
const REPO_LOAD = 'cdu:com.acme.cdu.repository.CustomerRepository#load(Ljava/lang/String;)Lcom/acme/cdu/dto/CustomerDto;';
const CUSTOMER_SERVICE_FILE = 'src/main/java/com/acme/cdu/service/CustomerService.java';
const APPLICATION_FILE = 'src/main/java/com/acme/cdu/CduApplication.java';

/** A scripted, well-formed model response covering every required section. */
const GOOD_RESPONSE = `
<section data-part="verdict"><p><strong>Not safe to ship alone.</strong> The update flow behind <code>PUT /api/v1/customers/{id}</code> changed and <code>pou</code> calls it.</p></section>
<section data-part="what-changed"><p><code>CustomerService.applyUpdate</code> is the write path for a customer record. Every update request runs through it.</p></section>
<section data-part="producer-impact"><p>Inside <code>cdu</code>, the persistence call and the customer-updated event both sit behind this method.</p><ul><li>The saved record is what the response is built from.</li></ul></section>
<section data-part="consumer-impact"><p><strong>pou</strong> calls this endpoint from its enrichment path. A changed response shape would surface as a null field when the order flow reads the customer.</p></section>
<section data-part="risks"><ul><li><strong>Response shape drift</strong> silently nulls a field in <code>pou</code>.</li><li>The published event carries the display name from the saved record.</li></ul></section>
<section data-part="unknowns"><p>One consumer URL is built from a property that could not be resolved statically, so that call site may not be the only one.</p></section>
`;

/** Strip comments so a source scan sees only executable text. */
function stripComments(source: string): string {
  return source.split(/\/\*[\s\S]*?\*\//g).join(' ').split('\n')
    .map((line) => {
      const idx = line.indexOf('//');
      return idx < 0 ? line : line.slice(0, idx);
    })
    .join('\n');
}

async function main(): Promise<void> {
  fs.rmSync(SCRATCH, { recursive: true, force: true });
  fs.mkdirSync(SCRATCH, { recursive: true });

  /* ================================================================= *
   * 0. Build the fixture bundles
   * ================================================================= */
  c.section('fixture builds');
  const cdu = materialize(SCRATCH, 'cdu');
  const pou = materialize(SCRATCH, 'pou');

  await buildIndex({
    repoRoot: cdu.root,
    repo: 'cdu',
    provider: makeProvider(cdu.responseDir),
    model: 'mock-model',
    config: configFor('cdu'),
    logger: silentLogger,
    builtAt: BUILT_AT,
  });
  await buildIndex({
    repoRoot: pou.root,
    repo: 'pou',
    provider: makeProvider(pou.responseDir),
    model: 'mock-model',
    config: configFor('pou'),
    logger: silentLogger,
    builtAt: BUILT_AT,
  });

  const registry = new IndexRegistry(silentLogger);
  const cduRepo = registry.load(cdu.root, silentLogger, 'cdu');
  registry.load(pou.root, silentLogger, 'pou');
  const bundle = cduRepo.bundle;
  c.check('cdu bundle has endpoints', bundle.endpoints.length > 0, `${bundle.endpoints.length}`);

  const putEndpoint = bundle.endpoints.find((e) => e.verb === 'PUT');
  const getEndpoint = bundle.endpoints.find(
    (e) => e.verb === 'GET' && e.path_template === '/api/v1/customers/{id}',
  );
  c.check('cdu has PUT /api/v1/customers/{id}', putEndpoint !== undefined, putEndpoint?.path_template ?? 'none');
  c.check('cdu has GET /api/v1/customers/{id}', getEndpoint !== undefined, getEndpoint?.path_template ?? 'none');

  /* ================================================================= *
   * 1. symbolAtCursor
   * ================================================================= */
  c.section('symbolAtCursor');

  const applyUpdateSymbol = bundle.symbolsById.get(APPLY_UPDATE);
  c.check('applyUpdate is indexed', applyUpdateSymbol !== undefined, APPLY_UPDATE);
  const declLine = applyUpdateSymbol?.line_start ?? 0;

  const onDecl = symbolAtCursor(bundle, CUSTOMER_SERVICE_FILE, declLine);
  c.eq('cursor on the declaration line resolves the method', onDecl.symbol?.id, APPLY_UPDATE);

  const inBody = symbolAtCursor(bundle, CUSTOMER_SERVICE_FILE, declLine + 2);
  c.eq('cursor inside the method body resolves the same method', inBody.symbol?.id, APPLY_UPDATE);
  c.check('and explains how it was attributed', inBody.reason.length > 20, inBody.match ?? 'no match kind');

  // Adjacency: addressesFor is declared after applyUpdate, validate after that.
  const addressesFor = [...bundle.symbolsById.values()].find((s) => s.id.includes('#addressesFor('));
  const validate = [...bundle.symbolsById.values()].find((s) => s.id.includes('#validate('));
  if (addressesFor !== undefined && validate !== undefined) {
    c.eq(
      'the line just before an adjacent method still belongs to the earlier one',
      symbolAtCursor(bundle, CUSTOMER_SERVICE_FILE, addressesFor.line_start - 1).symbol?.id,
      APPLY_UPDATE,
    );
    c.eq(
      'the adjacent method claims its own declaration line',
      symbolAtCursor(bundle, CUSTOMER_SERVICE_FILE, addressesFor.line_start).symbol?.id,
      addressesFor.id,
    );
    c.eq(
      'the next adjacent method claims its own line too',
      symbolAtCursor(bundle, CUSTOMER_SERVICE_FILE, validate.line_start).symbol?.id,
      validate.id,
    );
  }

  const noFile = symbolAtCursor(bundle, 'src/main/java/com/acme/cdu/Nope.java', 10);
  c.eq('an unknown file resolves to null', noFile.symbol, null);
  c.check('and says why', noFile.reason.includes('no indexed symbols'), noFile.reason.slice(0, 60));

  const absolute = symbolAtCursor(bundle, path.join(cdu.root, CUSTOMER_SERVICE_FILE), declLine);
  c.eq('an absolute path resolves against the repo-relative index', absolute.symbol?.id, APPLY_UPDATE);

  /* ================================================================= *
   * 2. THE HEADLINE CASE — a helper finds the endpoint above it
   * ================================================================= */
  c.section('helper -> endpoint discovery (the headline case)');

  const fromHelper = findAffectedEndpoints(bundle, cduRepo.forward, APPLY_UPDATE, 4);
  c.eq('applyUpdate (a HELPER, not a handler) reaches exactly 1 endpoint', fromHelper.affected.length, 1);
  c.eq(
    'and it is PUT /api/v1/customers/{id}',
    fromHelper.affected[0]?.endpoint.path_template,
    '/api/v1/customers/{id}',
  );
  c.eq('reached by the PUT verb', fromHelper.affected[0]?.endpoint.verb, 'PUT');
  c.eq('at depth 1 (one hop up to the controller)', fromHelper.affected[0]?.depth, 1);
  c.eq(
    'with the call path helper -> handler',
    fromHelper.affected[0]?.call_path,
    [APPLY_UPDATE, UPDATE_CUSTOMER],
  );
  c.eq(
    'and the handler is recognised as a REST entry point',
    fromHelper.affected[0]?.entry_kind,
    'rest_controller',
  );

  /* ================================================================= *
   * 3. A helper reached by MULTIPLE endpoints reports all of them
   * ================================================================= */
  c.section('multi-endpoint helper');

  const fromRepo = findAffectedEndpoints(bundle, cduRepo.forward, REPO_LOAD, 4);
  const routes = fromRepo.affected
    .map((a) => `${a.endpoint.verb ?? ''} ${a.endpoint.path_template ?? ''}`)
    .sort();
  c.check(
    'CustomerRepository.load is reached by more than one endpoint',
    fromRepo.affected.length >= 2,
    `${fromRepo.affected.length}: ${routes.join(' | ')}`,
  );
  c.check(
    'both the GET and the PUT customer endpoints are reported',
    routes.includes('GET /api/v1/customers/{id}') && routes.includes('PUT /api/v1/customers/{id}'),
    routes.join(' | '),
  );
  for (const affected of fromRepo.affected) {
    c.eq(
      `call path for ${affected.endpoint.verb ?? '?'} starts at the analysed symbol`,
      affected.call_path[0],
      REPO_LOAD,
    );
    c.eq(
      `call path for ${affected.endpoint.verb ?? '?'} ends at its handler`,
      affected.call_path[affected.call_path.length - 1],
      affected.endpoint.handler_symbol,
    );
    c.eq(
      `call path for ${affected.endpoint.verb ?? '?'} has depth+1 entries`,
      affected.call_path.length,
      affected.depth + 1,
    );
  }

  // A method that feeds nothing.
  const mainSymbol = [...bundle.symbolsById.values()].find((s) => s.id.includes('#main('));
  if (mainSymbol !== undefined) {
    const fromMain = findAffectedEndpoints(bundle, cduRepo.forward, mainSymbol.id, 4);
    c.eq('the application main method feeds no endpoint', fromMain.affected.length, 0);
  }

  // Determinism + cycle safety.
  const again = findAffectedEndpoints(bundle, cduRepo.forward, REPO_LOAD, 4);
  c.eq(
    'the walk is deterministic across runs',
    again.affected.map((a) => a.endpoint.id),
    fromRepo.affected.map((a) => a.endpoint.id),
  );
  c.eq('depth 0 finds nothing above the seed', findAffectedEndpoints(bundle, cduRepo.forward, REPO_LOAD, 0).affected.length, 0);
  c.eq('an unknown symbol yields nothing rather than throwing', findAffectedEndpoints(bundle, cduRepo.forward, 'nope', 4).affected.length, 0);

  /* ================================================================= *
   * 4. Changed file -> symbols -> endpoints
   * ================================================================= */
  c.section('changed file -> symbol -> endpoint mapping');

  const changes = [
    { file: CUSTOMER_SERVICE_FILE, status: 'modified' as const },
    { file: APPLICATION_FILE, status: 'modified' as const },
  ];
  const symbolsByFile = symbolsForChangedFiles(bundle, changes);
  c.check(
    'the changed service file maps to its methods',
    (symbolsByFile.get(CUSTOMER_SERVICE_FILE) ?? []).some((s) => s.id === APPLY_UPDATE),
    `${(symbolsByFile.get(CUSTOMER_SERVICE_FILE) ?? []).length} method(s)`,
  );

  const changedSymbols: AnalysedSymbol[] = [];
  for (const change of changes) {
    for (const symbol of symbolsByFile.get(change.file) ?? []) {
      changedSymbols.push({ symbol, howResolved: `declared in ${change.file}` });
    }
  }

  const impactNoDiff = computeImpact({
    bundle,
    forward: cduRepo.forward,
    symbols: changedSymbols,
    changedEndpoints: [],
    maxDepth: 4,
  });
  const impactedRoutes = impactNoDiff.affected.map((a) => `${a.endpoint.verb ?? a.endpoint.transport} ${a.endpoint.path_template ?? a.endpoint.destination ?? ''}`);
  c.check(
    'editing CustomerService.java surfaces the endpoints above it',
    impactedRoutes.some((r) => r.includes('PUT /api/v1/customers/{id}')),
    impactedRoutes.join(' | '),
  );

  const fileSummary = summarizeChangedFiles(changes, symbolsByFile, impactNoDiff.affected);
  const serviceRow = fileSummary.find((f) => f.file === CUSTOMER_SERVICE_FILE);
  const appRow = fileSummary.find((f) => f.file === APPLICATION_FILE);
  c.check(
    'the service file records the endpoints it feeds',
    (serviceRow?.feeds_endpoints.length ?? 0) > 0,
    serviceRow?.feeds_endpoints.join(', ') ?? 'none',
  );
  c.check('a changed file that feeds NO endpoint is still reported', appRow !== undefined, appRow?.file ?? 'missing');
  c.eq('and its feeds list is explicitly empty, not omitted', appRow?.feeds_endpoints, []);

  /* ================================================================= *
   * 5. Contract-changed vs reachable-only
   * ================================================================= */
  c.section('contract change vs behaviour-only reachability');

  const syntheticDiff: ChangedEndpoint[] = putEndpoint === undefined ? [] : [
    {
      id: putEndpoint.id,
      change_kind: 'modified',
      diff_reason: ['response_dto_shape_changed'],
      diff_details: [{ field: 'CustomerDto.displayName', before: 'String', after: null }],
      handler_symbol: putEndpoint.handler_symbol,
      file: putEndpoint.file,
      line: putEndpoint.line,
      transport: putEndpoint.transport,
      verb: putEndpoint.verb,
      path_template: putEndpoint.path_template,
      destination: putEndpoint.destination,
    },
  ];

  const repoSymbol = bundle.symbolsById.get(REPO_LOAD);
  const mixed = computeImpact({
    bundle,
    forward: cduRepo.forward,
    symbols: repoSymbol === undefined ? [] : [{ symbol: repoSymbol, howResolved: 'edited' }],
    changedEndpoints: syntheticDiff,
    maxDepth: 4,
  });

  const contractChanged = mixed.affected.filter((a) => a.contractChanged);
  const reachableOnly = mixed.affected.filter((a) => !a.contractChanged);
  c.eq('exactly one endpoint has a changed contract', contractChanged.length, 1);
  c.eq('and it is the PUT endpoint', contractChanged[0]?.endpoint.verb, 'PUT');
  c.check(
    'the other reachable endpoints are marked contract-unchanged',
    reachableOnly.length >= 1 && reachableOnly.every((a) => a.changed === null),
    `${reachableOnly.length} reachable-only`,
  );
  c.check(
    'contract-changed endpoints sort first',
    mixed.affected[0]?.contractChanged === true,
    mixed.affected.map((a) => `${a.endpoint.verb ?? '?'}:${a.contractChanged}`).join(' '),
  );
  c.check(
    'the contract change carries its diff detail',
    (contractChanged[0]?.changed?.diff_details.length ?? 0) > 0,
    contractChanged[0]?.changed?.diff_reason.join(',') ?? 'none',
  );

  /* ================================================================= *
   * 6. The endpoint picker
   * ================================================================= */
  c.section('endpoint picker options');

  const options = buildEndpointPickOptions(mixed.affected, { defaultEndpointId: null });
  c.eq('the first option is "all affected endpoints"', options[0]?.id, ALL_ENDPOINTS);
  c.check('the all-option is preselected when there is no cursor default', options[0]?.picked === true, '');
  c.eq('there is one row per affected endpoint plus the all-option', options.length, mixed.affected.length + 1);
  c.check(
    'the all-option counts both populations',
    (options[0]?.detail ?? '').includes('with a changed contract') &&
      (options[0]?.detail ?? '').includes('reachable but contract-unchanged'),
    options[0]?.detail ?? '',
  );

  const contractRow = options.find((o) => o.id === putEndpoint?.id);
  const reachableRow = options.find((o) => o.id !== ALL_ENDPOINTS && o.id !== putEndpoint?.id);
  c.check(
    'a contract-changed row says so and names the reason',
    (contractRow?.detail ?? '').includes('CONTRACT CHANGED') &&
      (contractRow?.detail ?? '').includes('response_dto_shape_changed'),
    contractRow?.detail ?? 'missing',
  );
  c.check(
    'a reachable-only row says the contract is unchanged',
    (reachableRow?.detail ?? '').includes('Contract unchanged'),
    reachableRow?.detail ?? 'missing',
  );
  c.check(
    'the reachable-only row names the file that reaches it',
    (reachableRow?.detail ?? '').includes('CustomerRepository.java'),
    reachableRow?.detail ?? 'missing',
  );

  const withDefault = buildEndpointPickOptions(mixed.affected, {
    defaultEndpointId: putEndpoint?.id ?? null,
  });
  c.check(
    'a cursor-supplied default preselects that endpoint',
    withDefault.find((o) => o.id === putEndpoint?.id)?.picked === true,
    '',
  );
  c.check('and the all-option is no longer preselected', withDefault[0]?.picked === false, '');

  /* ================================================================= *
   * 7. Zero affected endpoints
   * ================================================================= */
  c.section('zero affected endpoints');

  const appOnly = computeImpact({
    bundle,
    forward: cduRepo.forward,
    symbols: (symbolsByFile.get(APPLICATION_FILE) ?? []).map((symbol) => ({
      symbol,
      howResolved: `declared in ${APPLICATION_FILE}`,
    })),
    changedEndpoints: [],
    maxDepth: 4,
  });
  c.eq('a change confined to the application class reaches no endpoint', appOnly.affected.length, 0);
  const emptySummary = summarizeChangedFiles(
    [{ file: APPLICATION_FILE, status: 'modified' }],
    symbolsByFile,
    appOnly.affected,
  );
  c.eq('the file is still listed', emptySummary.length, 1);
  c.eq('with an explicitly empty feeds list', emptySummary[0]?.feeds_endpoints, []);

  const emptyEvidence = assembleEvidence({
    mode: 'local_changes',
    registry,
    producerRepo: 'cdu',
    consumerRepos: ['pou'],
    selected: [],
    symbols: [],
    changedFiles: emptySummary,
    downstream: [],
    comparisonBasis: 'Comparing your working tree against git HEAD (abc1234)',
    baselineAvailable: true,
    baselineNote: 'HEAD worktree indexed',
    depthCapped: false,
    unreachedCallers: [],
    maxDepth: 4,
    analysedAt: BUILT_AT,
    logger: silentLogger,
  });
  c.eq(
    'the evidence names the file as feeding no endpoint',
    emptyEvidence.evidence.changed_files_feeding_no_endpoint,
    [APPLICATION_FILE],
  );
  const emptyAppendix = renderEvidenceAppendix(emptyEvidence.evidence);
  c.check(
    'and the appendix states it rather than rendering nothing',
    emptyAppendix.includes('feed no endpoint') && emptyAppendix.includes(APPLICATION_FILE),
    '',
  );
  c.check(
    'the appendix explains that no endpoint is reachable',
    emptyAppendix.includes('No indexed endpoint is reachable'),
    '',
  );

  /* ================================================================= *
   * 8. Evidence assembly, size cap and explicit truncation
   * ================================================================= */
  c.section('evidence assembly');

  const helperSymbols: AnalysedSymbol[] =
    applyUpdateSymbol === undefined ? [] : [{ symbol: applyUpdateSymbol, howResolved: onDecl.reason }];
  const headline = computeImpact({
    bundle,
    forward: cduRepo.forward,
    symbols: helperSymbols,
    changedEndpoints: syntheticDiff,
    maxDepth: 4,
  });

  const assembled = assembleEvidence({
    mode: 'local_changes',
    registry,
    producerRepo: 'cdu',
    consumerRepos: ['pou'],
    selected: headline.affected,
    symbols: helperSymbols,
    changedFiles: summarizeChangedFiles(
      [{ file: CUSTOMER_SERVICE_FILE, status: 'modified' }],
      symbolsByFile,
      headline.affected,
    ),
    downstream: headline.downstream,
    comparisonBasis: 'Comparing your working tree against git HEAD (abc1234)',
    baselineAvailable: true,
    baselineNote: 'a clean checkout of HEAD (abc1234) was indexed in a temporary git worktree',
    depthCapped: headline.depthCapped,
    unreachedCallers: headline.unreachedCallers,
    maxDepth: 4,
    analysedAt: BUILT_AT,
    logger: silentLogger,
  });
  const evidence = assembled.evidence;

  c.check('evidence fits the size cap', evidenceBytes(evidence) <= EVIDENCE_MAX_BYTES, `${evidenceBytes(evidence)} bytes`);
  c.eq('nothing was truncated at this size', evidence.truncation, []);
  c.eq('the changed symbol is carried', evidence.changed_symbols[0]?.id, APPLY_UPDATE);
  c.check(
    'the changed symbol records how it was resolved',
    (evidence.changed_symbols[0]?.how_resolved ?? '').length > 10,
    '',
  );
  c.eq('the changed symbol is not itself an entry point', evidence.changed_symbols[0]?.is_entry_point, false);
  c.eq('its declaring class is carried', evidence.changed_symbols[0]?.declaring_class, 'com.acme.cdu.service.CustomerService');
  c.eq('the affected endpoint is the PUT', evidence.affected_endpoints[0]?.endpoint.route, 'PUT /api/v1/customers/{id}');
  c.eq('marked as a contract change', evidence.affected_endpoints[0]?.contract_changed, true);
  c.check(
    'the call path is carried in readable form',
    (evidence.affected_endpoints[0]?.endpoint.reached_from[0]?.call_path ?? []).join(' -> ') ===
      'CustomerService.applyUpdate -> CustomerController.updateCustomer',
    (evidence.affected_endpoints[0]?.endpoint.reached_from[0]?.call_path ?? []).join(' -> '),
  );
  const pouConsumer = evidence.affected_endpoints[0]?.consumers.find((x) => x.repo === 'pou');
  c.check('pou is reported as a consumer', pouConsumer !== undefined, pouConsumer?.repo ?? 'none');
  c.check('with at least one call site', (pouConsumer?.call_sites.length ?? 0) > 0, `${pouConsumer?.call_sites.length ?? 0}`);
  c.check(
    'carrying matched_via and a match confidence',
    (pouConsumer?.call_sites[0]?.matched_via.length ?? 0) > 0 &&
      typeof pouConsumer?.call_sites[0]?.match_confidence === 'number',
    pouConsumer?.call_sites[0]?.matched_via.join(', ') ?? '',
  );
  c.check(
    'and the consumer entry points that would surface a failure',
    (pouConsumer?.entry_points.length ?? 0) > 0,
    pouConsumer?.entry_points.map((e) => e.symbol).join(', ') ?? 'none',
  );
  c.eq('the comparison basis is carried into the evidence', evidence.comparison_basis, 'Comparing your working tree against git HEAD (abc1234)');
  c.eq('the baseline is marked available', evidence.analysis_limits.baseline_available, true);

  // Truncation, forced with a small cap and an inflated input.
  c.section('evidence truncation is explicit');
  const inflated: AnalysedSymbol[] = [];
  for (let i = 0; i < 300; i++) {
    inflated.push({
      symbol: {
        ...(applyUpdateSymbol as SymbolRecord),
        id: `${APPLY_UPDATE}#copy${i}`,
      },
      howResolved: `synthetic copy ${i} used to force the size cap to bite`,
    });
  }
  const capped = assembleEvidence({
    mode: 'local_changes',
    registry,
    producerRepo: 'cdu',
    consumerRepos: ['pou'],
    selected: headline.affected,
    symbols: inflated,
    changedFiles: null,
    downstream: headline.downstream,
    comparisonBasis: 'Comparing your working tree against git HEAD (abc1234)',
    baselineAvailable: true,
    baselineNote: 'HEAD worktree indexed',
    depthCapped: false,
    unreachedCallers: [],
    maxDepth: 4,
    analysedAt: BUILT_AT,
    logger: silentLogger,
  });
  // `assembleEvidence` uses the default cap; assert the packet stays bounded and
  // that anything dropped left a marker.
  const cappedJson = evidenceJson(capped.evidence);
  c.check(
    'an oversized input is reduced to the byte cap',
    Buffer.byteLength(cappedJson, 'utf8') <= EVIDENCE_MAX_BYTES,
    `${Buffer.byteLength(cappedJson, 'utf8')} bytes`,
  );
  c.check(
    'truncation is recorded, not silent',
    capped.evidence.truncation.length > 0,
    capped.evidence.truncation[0] ?? 'none',
  );
  c.check(
    'and it uses the explicit "...N more" marker',
    capped.evidence.truncation.some((t) => /\.\.\.\d+ more/.test(t)),
    capped.evidence.truncation.join(' | ').slice(0, 120),
  );
  c.check(
    'the reduction itself is disclosed to the model',
    capped.evidence.truncation.some((t) => t.includes('samples, not complete inventories')),
    '',
  );

  /* ================================================================= *
   * 9. The prompt
   * ================================================================= */
  c.section('prompt construction');

  const prompt = buildAnalysisPrompt({ evidenceJson: evidenceJson(evidence) });
  c.check('the prompt embeds the evidence JSON', prompt.includes('"producer_repo": "cdu"'), '');
  c.check('the prompt names the real endpoint', prompt.includes('PUT /api/v1/customers/{id}'), '');
  c.check('no placeholder survives', !prompt.includes('{evidence}'), '');
  c.check(
    'the prompt asks for every required section',
    ANALYSIS_REQUIRED_SECTIONS.every((s) => prompt.includes(`data-part="${s}"`)),
    '',
  );
  c.check(
    'the prompt explains the contract-vs-behaviour distinction',
    prompt.includes('"contract_changed": true') && prompt.includes('"contract_changed": false'),
    '',
  );
  c.check(
    'the prompt frames the changeset as uncommitted local work',
    prompt.includes('UNCOMMITTED changes in the engineer\'s working tree'),
    '',
  );
  c.check(
    'the system prompt is the verbatim constant',
    ANALYSIS_SYSTEM_PROMPT.startsWith(
      'You are a senior engineer writing an impact analysis for a code change in a Spring Boot microservice estate.',
    ) &&
      ANALYSIS_SYSTEM_PROMPT.includes(
        'Confidence scores in the input describe how the static analysis MATCHED a call site, not how likely it is to break.',
      ) &&
      ANALYSIS_SYSTEM_PROMPT.includes('Output valid HTML fragments only'),
    `${ANALYSIS_SYSTEM_PROMPT.length} chars`,
  );

  /* ================================================================= *
   * 10. The sanitizer, against hostile input
   * ================================================================= */
  c.section('sanitizer: hostile input');

  const hostile = [
    '<section data-part="verdict"><p>Safe.</p></section>',
    '<script>alert(1)</script>',
    '<img src=x onerror=alert(1)>',
    '<a href="javascript:alert(1)">click me</a>',
    '<p onclick="alert(1)">clickable</p>',
    '<style>body{display:none}</style>',
    '<iframe src="https://evil.example"></iframe>',
    '<p>2 < 3 && 4 > 1</p>',
  ].join('\n');
  const clean = sanitizeFragment(hostile).html;

  c.check('<script> tags are gone', !/<script/i.test(clean), '');
  c.check('and so is the script CONTENT', !clean.includes('alert(1)</') && !clean.includes('alert(1)'), clean.slice(0, 80));
  c.check('<style> tags are gone', !/<style/i.test(clean), '');
  c.check('and so is the style content', !clean.includes('display:none'), '');
  c.check('<img> is dropped', !/<img/i.test(clean), '');
  c.check('onerror= does not survive', !/onerror/i.test(clean), '');
  c.check('onclick= does not survive', !/onclick/i.test(clean), '');
  c.check('javascript: URLs do not survive', !/javascript:/i.test(clean), '');
  c.check('<a href> is dropped', !/<a\b/i.test(clean) && !/href/i.test(clean), '');
  c.check('<iframe> is dropped', !/<iframe/i.test(clean), '');
  c.check('the anchor TEXT is preserved', clean.includes('click me'), '');
  c.check('the paragraph text is preserved', clean.includes('clickable'), '');
  c.check('allowed <p> survives', clean.includes('<p>'), '');
  c.check('allowed <section data-part> survives', clean.includes('<section data-part="verdict">'), '');
  c.check('stray < in text is escaped', clean.includes('2 &lt; 3'), '');
  c.check('stray & in text is escaped', clean.includes('&amp;&amp;'), '');

  const nested = sanitizeFragment('<p><strong>bold <em>and italic</em></strong> and <code>code</code></p>').html;
  c.eq(
    'nested allowed tags are preserved exactly',
    nested,
    '<p><strong>bold <em>and italic</em></strong> and <code>code</code></p>',
  );
  c.eq(
    'a list survives intact',
    sanitizeFragment('<ul><li>one</li><li>two</li></ul>').html,
    '<ul><li>one</li><li>two</li></ul>',
  );
  c.eq(
    'attributes are stripped from allowed tags',
    sanitizeFragment('<p class="x" style="color:red" id="y">text</p>').html,
    '<p>text</p>',
  );
  c.eq(
    'an unknown data-part value is dropped rather than echoed',
    sanitizeFragment('<section data-part="evil"><p>x</p></section>').html,
    '<section><p>x</p></section>',
  );
  c.eq(
    'an unclosed tag is closed for us',
    sanitizeFragment('<p>dangling').html,
    '<p>dangling</p>',
  );
  c.eq(
    'a stray closing tag cannot escape the container',
    sanitizeFragment('</section></div><p>x</p>').html,
    '<p>x</p>',
  );
  c.eq('an unterminated <script> truncates everything after it', sanitizeFragment('<p>ok</p><script>bad').html, '<p>ok</p>');
  c.eq('empty input is handled', sanitizeFragment('').html, '');
  c.check('sanitizer reports what it dropped', sanitizeFragment(hostile).droppedTags.includes('img'), sanitizeFragment(hostile).droppedTags.join(','));

  /* ================================================================= *
   * 11. Full flow with a scripted model
   * ================================================================= */
  c.section('full flow with a scripted model');

  const goodProvider = new MockChatModelProvider(() => GOOD_RESPONSE);
  const narrative = await generateNarrative({
    provider: goodProvider,
    model: 'mock-model',
    evidence,
    logger: silentLogger,
  });
  c.check('the narrative is accepted', narrative.html !== null, narrative.reason ?? 'accepted');
  c.eq('no fallback reason is recorded', narrative.reason, null);
  c.eq('the model id is reported', narrative.modelId, 'mock-model');
  c.eq('the provider was called exactly once', goodProvider.callCount, 1);
  c.check(
    'the request carried the verbatim system prompt',
    goodProvider.calls[0]?.system === ANALYSIS_SYSTEM_PROMPT,
    '',
  );
  c.check(
    'and the evidence in the user turn',
    (goodProvider.calls[0]?.messages[0] ?? '').includes('PUT /api/v1/customers/{id}'),
    '',
  );

  const html = buildReport({
    producerRepo: 'cdu',
    selected: headline.affected,
    evidence,
    blastByEndpoint: assembled.blastByEndpoint,
    narrative,
    comparisonBasis: 'Comparing your working tree against git HEAD (abc1234)',
    generatedAt: BUILT_AT,
  });

  c.check('the report is a complete HTML document', html.startsWith('<!DOCTYPE html>') && html.trimEnd().endsWith('</html>'), '');
  c.check('it has a <title>', html.includes('<title>CodeIndex impact report</title>'), '');
  c.check('it is self-contained (no external resources)', !/(src|href)\s*=\s*["']https?:/i.test(html), '');
  c.check('it carries inline CSS', html.includes('<style>') && html.includes('prefers-color-scheme'), '');
  c.check('it has print styles', html.includes('@media print'), '');
  for (const section of ANALYSIS_REQUIRED_SECTIONS) {
    c.check(`the report contains the ${section} section`, html.includes(`data-part="${section}"`), '');
  }
  c.eq('all six required sections are present', sectionsPresent(html).filter((s) => (ANALYSIS_REQUIRED_SECTIONS as readonly string[]).includes(s)).length, 6);
  c.check('headings are ours, not the model\'s', html.includes('data-heading="Verdict"'), '');
  c.check('the AI narrative is labelled as AI-written', html.includes('written by a language model'), '');

  /* ---- the header names the comparison basis --------------------- */
  c.section('report header');
  c.check(
    'the header states the comparison basis including the HEAD sha',
    html.includes('Comparing your working tree against git HEAD (abc1234)'),
    '',
  );
  c.check(
    'the appendix repeats the comparison basis',
    renderEvidenceAppendix(evidence).includes('git HEAD (abc1234)'),
    '',
  );

  /* ---- the evidence appendix ------------------------------------- */
  c.section('evidence appendix');
  c.check('the appendix is present', html.includes('<h2>Evidence</h2>'), '');
  c.check('labelled as machine-generated fact', html.includes('machine-generated fact'), '');
  c.check('and distinguished from the AI narrative', html.includes('not written by the'), '');
  c.check('it names the real endpoint', html.includes('PUT /api/v1/customers/{id}'), '');
  c.check('it names the real consumer repo', html.includes('<code>pou</code>'), '');
  c.check('it shows the call path', html.includes('CustomerService.applyUpdate'), '');
  c.check('it shows matched_via signals', html.includes('dto_shape_match') || html.includes('property_value:'), '');
  c.check('it shows a match confidence', html.includes('class="conf"'), '');
  c.check(
    'confidence is labelled as a match, not a risk',
    html.includes('not a probability of breakage') && html.includes('not how likely it is to break'),
    '',
  );
  c.check('the contract-changed badge is rendered', html.includes('badge-contract'), '');

  /* ================================================================= *
   * 12. Degradation paths
   * ================================================================= */
  c.section('fallback: no model available');

  const noModel = await generateNarrative({
    provider: new MockChatModelProvider(() => GOOD_RESPONSE, { unavailable: true }),
    model: 'mock-model',
    evidence,
    logger: silentLogger,
  });
  c.eq('no narrative is produced', noModel.html, null);
  c.check('and a reason is recorded', (noModel.reason ?? '').includes('no chat model is available'), noModel.reason ?? '');

  const fallbackHtml = buildReport({
    producerRepo: 'cdu',
    selected: headline.affected,
    evidence,
    blastByEndpoint: assembled.blastByEndpoint,
    narrative: noModel,
    comparisonBasis: 'Comparing your working tree against git HEAD (abc1234)',
    generatedAt: BUILT_AT,
  });
  c.check('the fallback is still a complete document', fallbackHtml.startsWith('<!DOCTYPE html>'), '');
  c.check(
    'it states plainly that this is the deterministic fallback',
    fallbackHtml.includes('This is the deterministic fallback report. The AI narrative was not available.'),
    '',
  );
  c.check('it explains WHY', fallbackHtml.includes('no chat model is available'), '');
  c.check(
    'it carries the deterministic template report',
    fallbackHtml.includes('Impact report') && fallbackHtml.includes('Impact on consumers'),
    '',
  );
  c.check('it still carries the evidence appendix', fallbackHtml.includes('<h2>Evidence</h2>'), '');
  c.check('and does not claim an AI wrote it', !fallbackHtml.includes('written by a language model'), '');

  c.section('fallback: unusable model output');

  for (const [label, response] of [
    ['prose instead of HTML', 'Sure! Here is my analysis: the change looks risky to me.'],
    ['empty response', '   '],
    ['JSON instead of HTML', '{"verdict":"safe"}'],
    ['HTML with no sections', '<p>Some analysis without any sections at all.</p>'],
    ['only a script tag', '<script>alert(1)</script>'],
    ['sections but no verdict', '<section data-part="risks"><p>x</p></section>'],
  ] as Array<[string, string]>) {
    const bad = await generateNarrative({
      provider: new MockChatModelProvider(() => response),
      model: 'mock-model',
      evidence,
      logger: silentLogger,
    });
    c.eq(`${label} -> falls back`, bad.html, null);
    c.check(`${label} -> records a reason`, (bad.reason ?? '').length > 20, (bad.reason ?? '').slice(0, 70));
  }

  const thrown = await generateNarrative({
    provider: new MockChatModelProvider(() => {
      throw new Error('network exploded');
    }),
    model: 'mock-model',
    evidence,
    logger: silentLogger,
  });
  c.eq('a thrown provider error falls back rather than propagating', thrown.html, null);
  c.check('and names the failure', (thrown.reason ?? '').includes('network exploded'), thrown.reason ?? '');

  const noProvider = await generateNarrative({
    provider: null,
    model: '',
    evidence,
    logger: silentLogger,
  });
  c.eq('a null provider falls back', noProvider.html, null);

  // A fenced-but-valid response should be RECOVERED, not discarded.
  const fenced = await generateNarrative({
    provider: new MockChatModelProvider(() => `\`\`\`html\n${GOOD_RESPONSE}\n\`\`\``),
    model: 'mock-model',
    evidence,
    logger: silentLogger,
  });
  c.check('a ```html fence is stripped rather than causing a fallback', fenced.html !== null, fenced.reason ?? 'recovered');

  c.check(
    'isUsableNarrative rejects a sectionless fragment',
    !isUsableNarrative('<p>hello</p>').ok,
    isUsableNarrative('<p>hello</p>').why.slice(0, 60),
  );
  c.check('isUsableNarrative accepts the scripted response', isUsableNarrative(sanitizeFragment(GOOD_RESPONSE).html).ok, '');

  /* ================================================================= *
   * 13. Local change detection + the HEAD worktree
   * ================================================================= */
  c.section('local changes: no git available');

  const nonGit = path.join(SCRATCH, 'not-a-repo');
  fs.mkdirSync(nonGit, { recursive: true });
  const noGit = detectLocalChanges(nonGit, ['src/main/java'], silentLogger);
  c.eq('a non-git directory reports unavailable', noGit.available, false);
  c.eq('with no changes', noGit.changes.length, 0);
  c.check('and an explanatory note', noGit.note.includes('git'), noGit.note);

  // The degradation that matters: impact WITHOUT a diff still works and says so.
  const noDiffEvidence = assembleEvidence({
    mode: 'local_changes',
    registry,
    producerRepo: 'cdu',
    consumerRepos: ['pou'],
    selected: impactNoDiff.affected,
    symbols: changedSymbols,
    changedFiles: fileSummary,
    downstream: impactNoDiff.downstream,
    comparisonBasis:
      'Analysing your working tree; the comparison against git HEAD was not possible (git is not available on PATH)',
    baselineAvailable: false,
    baselineNote:
      'git is not available on PATH. Endpoints below are shown as affected by reachability only; no contract diff was possible.',
    depthCapped: false,
    unreachedCallers: [],
    maxDepth: 4,
    analysedAt: BUILT_AT,
    logger: silentLogger,
  });
  c.check(
    'without git the analysis still produces affected endpoints',
    noDiffEvidence.evidence.affected_endpoints.length > 0,
    `${noDiffEvidence.evidence.affected_endpoints.length}`,
  );
  c.check(
    'every endpoint is contract-unchanged when there is no diff',
    noDiffEvidence.evidence.affected_endpoints.every((e) => !e.contract_changed),
    '',
  );
  c.eq('the evidence marks the baseline unavailable', noDiffEvidence.evidence.analysis_limits.baseline_available, false);
  c.check(
    'and explains why in the note',
    noDiffEvidence.evidence.analysis_limits.baseline_note.includes('no contract diff was possible'),
    '',
  );
  const noDiffHtml = renderEvidenceAppendix(noDiffEvidence.evidence);
  c.check(
    'the report says the baseline comparison was not available',
    noDiffHtml.includes('NOT available'),
    '',
  );

  c.section('local changes: a real git repo');

  const gitRepo = path.join(SCRATCH, 'git-repo');
  let gitUsable = true;
  try {
    fs.mkdirSync(path.join(gitRepo, 'src', 'main', 'java'), { recursive: true });
    fs.writeFileSync(path.join(gitRepo, 'src', 'main', 'java', 'A.java'), 'class A {}\n');
    fs.writeFileSync(path.join(gitRepo, 'README.md'), 'readme\n');
    const run = (...args: string[]): void => {
      execFileSync('git', args, { cwd: gitRepo, stdio: 'pipe', timeout: 20000 });
    };
    run('init', '-q');
    run('config', 'user.email', 'sanity@example.com');
    run('config', 'user.name', 'CodeIndex Sanity');
    run('add', '.');
    run('commit', '-q', '-m', 'initial');
  } catch (err) {
    gitUsable = false;
    console.log(`SKIP  git-backed assertions — could not create a test repo: ${String(err)}`);
  }

  if (gitUsable) {
    // Edit a tracked file and add an untracked one.
    fs.writeFileSync(path.join(gitRepo, 'src', 'main', 'java', 'A.java'), 'class A { void x() {} }\n');
    fs.writeFileSync(path.join(gitRepo, 'src', 'main', 'java', 'B.java'), 'class B {}\n');
    fs.writeFileSync(path.join(gitRepo, 'notes.txt'), 'ignore me\n');

    const detected = detectLocalChanges(gitRepo, ['src/main/java'], silentLogger);
    c.eq('git is detected as available', detected.available, true);
    c.check('a HEAD sha is read', (detected.headSha ?? '').length >= 7, detected.headSha ?? 'none');
    c.eq(
      'the modified tracked file is reported',
      detected.changes.find((x) => x.file.endsWith('A.java'))?.status,
      'modified',
    );
    c.eq(
      'the new untracked file is reported',
      detected.changes.find((x) => x.file.endsWith('B.java'))?.status,
      'untracked',
    );
    c.check(
      'a non-source file is filtered out of the relevant set',
      !detected.changes.some((x) => x.file.endsWith('notes.txt')),
      detected.changes.map((x) => x.file).join(', '),
    );
    c.check(
      'but it is still visible in the raw change list',
      detected.allChangedFiles.some((f) => f.endsWith('notes.txt')),
      '',
    );

    /* ---- the worktree is created and ALWAYS removed ---------------- */
    c.section('HEAD worktree lifecycle');

    let observedPath: string | null = null;
    let contentAtHead = '';
    await withHeadWorktree(gitRepo, silentLogger, async (worktree) => {
      observedPath = worktree.path;
      if (worktree.path !== null) {
        contentAtHead = fs.readFileSync(path.join(worktree.path, 'src', 'main', 'java', 'A.java'), 'utf8');
      }
    });
    c.check('a temporary HEAD worktree is created', observedPath !== null, observedPath ?? worktree_note());
    c.check(
      'it contains the HEAD version of the file, not the working-tree version',
      contentAtHead.trim() === 'class A {}',
      JSON.stringify(contentAtHead),
    );
    c.eq(
      'the temp directory is removed afterwards',
      observedPath === null ? false : fs.existsSync(observedPath),
      false,
    );

    let thrownPath: string | null = null;
    let propagated = false;
    try {
      await withHeadWorktree(gitRepo, silentLogger, async (worktree) => {
        thrownPath = worktree.path;
        throw new Error('body exploded');
      });
    } catch (err) {
      propagated = err instanceof Error && err.message === 'body exploded';
    }
    c.check('an error in the body propagates to the caller', propagated, '');
    c.eq(
      'and the temp directory is STILL removed after a throw',
      thrownPath === null ? false : fs.existsSync(thrownPath),
      false,
    );

    c.check(
      'the working tree was never mutated — the edit is still there',
      fs.readFileSync(path.join(gitRepo, 'src', 'main', 'java', 'A.java'), 'utf8').includes('void x()'),
      '',
    );
    c.check(
      'and the untracked file still exists',
      fs.existsSync(path.join(gitRepo, 'src', 'main', 'java', 'B.java')),
      '',
    );

    const stray = fs
      .readdirSync(path.dirname(observedPath ?? SCRATCH))
      .filter((n) => n.startsWith('codeindex-head-'));
    c.eq('no stray worktree directories are left behind', stray, []);
  }

  function worktree_note(): string {
    return 'worktree not created';
  }

  /* ================================================================= *
   * 14. THE SAFETY INVARIANT — no working-tree mutation, anywhere
   * ================================================================= */
  c.section('safety: no mutating git commands in our source');

  const OURS = [
    'src/ui/local-changes.ts',
    'src/ui/analysis.ts',
    'src/ui/impact-graph.ts',
    'src/ui/evidence.ts',
    'src/ui/report-html.ts',
    'src/ui/symbol-at.ts',
    'src/ui/commands.ts',
    'src/lm/analysis-prompt.ts',
  ];
  const FORBIDDEN = ['stash', 'checkout', 'reset', 'clean'];
  for (const relative of OURS) {
    const source = stripComments(fs.readFileSync(path.join(REPO_ROOT, relative), 'utf8'));
    for (const verb of FORBIDDEN) {
      const asArgument = new RegExp(`['"\`]${verb}['"\`]`).test(source);
      const asCommandLine = new RegExp(`git\\s+${verb}`).test(source);
      c.check(
        `${relative} never invokes git ${verb}`,
        !asArgument && !asCommandLine,
        '',
      );
    }
  }
  const localChangesSource = stripComments(
    fs.readFileSync(path.join(REPO_ROOT, 'src', 'ui', 'local-changes.ts'), 'utf8'),
  );
  // Only the argument arrays actually handed to `git(...)`, so the `stdio`
  // option arrays elsewhere in the file are not mistaken for subcommands.
  const gitCalls = [...localChangesSource.matchAll(/\bgit\(\s*\w+,\s*\[\s*'([a-z-]+)'/g)].map(
    (m) => m[1] as string,
  );
  c.check('the git argument arrays were actually found', gitCalls.length >= 4, `${gitCalls.length} call(s)`);
  c.check(
    'every git subcommand used is read-only or worktree-scoped',
    gitCalls.every((verb) =>
      ['rev-parse', 'diff', 'ls-files', 'worktree', 'add', 'remove', 'prune'].includes(verb),
    ),
    [...new Set(gitCalls)].join(', '),
  );

  c.summary('analysis-sanity');
}

void main().catch((err: unknown) => {
  console.error(err);
  process.exitCode = 1;
});
