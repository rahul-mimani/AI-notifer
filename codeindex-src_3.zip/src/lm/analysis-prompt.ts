/**
 * The impact-analysis prompt.
 *
 * Same house rules as `./prompts.ts`: every string a model ever sees is an
 * exported constant here, declared once. Nothing else in the codebase may
 * re-type a prompt fragment, or the docs and the runtime drift apart.
 *
 * No vscode import — this is drivable from plain Node against
 * `MockChatModelProvider`.
 */

/** Verbatim system prompt. Do not reword. */
export const ANALYSIS_SYSTEM_PROMPT =
  'You are a senior engineer writing an impact analysis for a code change in a Spring Boot microservice estate. You are given structured facts extracted from a static index: the changed method, the API endpoints that transitively depend on it, and the downstream consumer services that call those endpoints.\n' +
  '\n' +
  'Write for an engineer who must decide whether this change is safe to release. Explain consequences in terms of behaviour and flows, not code structure. Say what breaks, for whom, and under what circumstances.\n' +
  '\n' +
  'Rules you must follow:\n' +
  '- Ground every claim in the supplied facts. Never invent an endpoint, consumer, field, or call path that is not present in the input.\n' +
  '- Where the facts are incomplete or a value could not be resolved, say so explicitly and explain what it means for confidence in your analysis. Do not paper over gaps.\n' +
  '- Distinguish clearly between what IS broken, what MIGHT be broken and needs review, and what is unaffected.\n' +
  '- Confidence scores in the input describe how the static analysis MATCHED a call site, not how likely it is to break. Do not present a match confidence as a risk probability.\n' +
  '- Be concise and specific. No preamble, no restating the question, no generic advice about testing.\n' +
  '- Output valid HTML fragments only, using the exact section structure requested. No markdown, no code fences, no <html>/<head>/<body> wrapper.';

/**
 * The six sections, in order. `report-html.ts` renders against this list and the
 * sanity run asserts every one survives sanitization — so the section contract
 * lives in exactly one place.
 */
export const ANALYSIS_SECTIONS = [
  'changed-files',
  'verdict',
  'what-changed',
  'producer-impact',
  'consumer-impact',
  'risks',
  'unknowns',
] as const;

export type AnalysisSection = (typeof ANALYSIS_SECTIONS)[number];

/**
 * The six sections a usable narrative must always carry. `changed-files` is
 * conditional — there is no changeset in cursor mode — so it is deliberately
 * absent from this list and its omission is never treated as a failure.
 */
export const ANALYSIS_REQUIRED_SECTIONS: readonly AnalysisSection[] = [
  'verdict',
  'what-changed',
  'producer-impact',
  'consumer-impact',
  'risks',
  'unknowns',
];

/** Human-facing heading for each section, used by the HTML renderer. */
export const ANALYSIS_SECTION_TITLES: Record<AnalysisSection, string> = {
  'changed-files': 'What you changed',
  verdict: 'Verdict',
  'what-changed': 'What changed',
  'producer-impact': 'Impact inside the producer',
  'consumer-impact': 'Impact on consumers',
  risks: 'Risks, most severe first',
  unknowns: 'What this analysis could not determine',
};

/** The only tags the model may emit. Enforced by the sanitizer, not by hope. */
export const ANALYSIS_ALLOWED_TAGS = ['p', 'ul', 'li', 'strong', 'code'] as const;

/**
 * Raw user-prompt template. Placeholder: `{evidence}`.
 *
 * Kept verbatim and exported so PROMPTS.md can be generated from it.
 */
export const ANALYSIS_USER_PROMPT_TEMPLATE = `Here are the facts extracted from the static index. This is everything you know; there is no other source.

{evidence}

Read these facts carefully before writing.

WHAT THIS CHANGESET IS. When "mode" is "local_changes", these are UNCOMMITTED changes in the engineer's working tree, compared against the state described in "comparison_basis". Nothing here has been merged or released. When "mode" is "cursor_symbol", a single method was selected for analysis and there is no diff — say what that method affects, not what changed about it.

THE DISTINCTION YOU MUST NOT COLLAPSE. Every entry in "affected_endpoints" carries a "contract_changed" flag, and the two cases have completely different consequences:

- "contract_changed": true — the endpoint's wire contract moved. Its path, verb, destination or payload shape differs from the baseline. Consumers can break on the call ITSELF: a 404, a 405, a rejected request body, a deserialization failure, a field that is suddenly absent. The "diff" object says exactly what moved. These are the endpoints that force a coordinated release.
- "contract_changed": false — the endpoint is only REACHABLE from a changed internal method. Its contract is byte-identical, so no consumer's code breaks and nothing fails to parse. But the behaviour behind the contract changed: consumers can still observe different values, different side effects, different timing, or a different error rate through an interface that still looks the same. This is the class of change that ships quietly and surfaces in production as "the data looks wrong", so do not dismiss it as safe — describe what an observer of that endpoint would now see differently.

Treat those as two separate populations throughout. Never describe a behaviour-only change as breaking, and never describe a contract change as merely internal.

Write the impact analysis as HTML fragments. Emit each one wrapped in its own section element with the exact data-part value given, in this order, and emit nothing outside these sections:

<section data-part="changed-files">
Only when "changed_files" is not null. One short list: each changed file, what it declares that matters, and which endpoints it feeds. Name any file in "changed_files_feeding_no_endpoint" explicitly and say it feeds no indexed endpoint, so the reader knows it was analysed and not skipped. Omit this section entirely when "changed_files" is null.
</section>

<section data-part="verdict">
One paragraph. Is this change safe to ship? Lead with the answer, then the single most important reason.
</section>

<section data-part="what-changed">
What the changed methods are and the role they play in the flows above them. Describe behaviour, not signatures. State plainly how many endpoints had their contract change versus how many are reachable-but-unchanged.
</section>

<section data-part="producer-impact">
What else inside the producer service is affected, described as behaviour: which of its own flows run through these methods, and what changes for them.
</section>

<section data-part="consumer-impact">
One paragraph or list per consumer service. For each: what breaks for them, which user-facing or event-driven flows surface it, and how it would manifest at runtime — a 404, a deserialization failure, a null field, a silently dropped message. Separate the consequences of contract changes from the consequences of behaviour-only changes; for the latter, describe what the consumer would observe differently rather than what would fail. Name the consumer repos exactly as they appear in the facts. If a consumer is unaffected, say so and stop there.
</section>

<section data-part="risks">
A ranked list, most severe first. Each item states a specific risk, not a category. Order by blast radius and likelihood of a runtime failure.
</section>

<section data-part="unknowns">
What the analysis could not determine, drawn from the unresolved entries, truncation notes and analysis limits in the facts, and why each one matters for trusting the sections above. If nothing is unresolved, say that plainly in one sentence.
</section>

Use only these HTML tags: <p>, <ul>, <li>, <strong>, <code>. No attributes on any tag except the data-part on the six section elements. No markdown, no code fences, no headings.`;

export interface AnalysisPromptInput {
  /** The serialized evidence packet, exactly as it will be sent. */
  evidenceJson: string;
}

/** Build the user turn. The system prompt is sent separately. */
export function buildAnalysisPrompt(input: AnalysisPromptInput): string {
  return ANALYSIS_USER_PROMPT_TEMPLATE.replace('{evidence}', input.evidenceJson);
}

/** Everything PROMPTS.md needs, so the doc generator holds no literals. */
export const ANALYSIS_PROMPT_TEMPLATES = {
  system: ANALYSIS_SYSTEM_PROMPT,
  user: ANALYSIS_USER_PROMPT_TEMPLATE,
  sections: ANALYSIS_SECTIONS,
} as const;
