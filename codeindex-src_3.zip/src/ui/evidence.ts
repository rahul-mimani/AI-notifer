/**
 * The evidence packet — everything the model is allowed to know.
 *
 * The model may not read the repo, the bundle, or anything else. It sees exactly
 * this object, so the object IS the grounding: any endpoint, consumer, field or
 * call path in the narrative that is not in here is a hallucination, and the
 * deterministic appendix in `report-html.ts` is what lets a reader catch it.
 *
 * THE DISTINCTION THAT MATTERS MOST
 * ---------------------------------
 * `contract_changed` separates an endpoint whose WIRE CONTRACT moved (its
 * fingerprint differs from the baseline — consumers can 404 or fail to
 * deserialize) from an endpoint that is merely REACHABLE from a changed internal
 * method (identical contract, different behaviour behind it). Both are
 * "affected"; only one of them breaks a caller's code. The prompt leans on this
 * field heavily, so it is computed here rather than left for the model to infer.
 *
 * SIZE
 * ----
 * Capped at ~40KB. Truncation is EXPLICIT, never silent: every list that gets
 * cut records a `"...N more"` entry in `truncation`, so the model can see it was
 * given a partial view and say so, instead of confidently generalising from a
 * sample it thinks is complete. Shrinking happens in passes, cutting the
 * longest-tail lists first, and stops as soon as the packet fits.
 *
 * Pure and vscode-free.
 */

import type {
  BlastRadiusResult,
  ChainNode,
  SymbolRecord,
  UnresolvedRecord,
} from '../types.js';
import type { AggregatedEndpoint } from './impact-graph.js';
import { shortSymbolName } from './symbol-at.js';

/** Hard ceiling on the serialized packet. */
export const EVIDENCE_MAX_BYTES = 40_000;

/** The marker a truncated list leaves behind. Asserted in the sanity run. */
export function moreMarker(n: number): string {
  return `...${n} more`;
}

/** How the analysis was started. */
export type AnalysisMode = 'local_changes' | 'cursor_symbol';

/* ------------------------------------------------------------------ *
 * Shapes. Deliberately flat and prose-friendly — the model reads these
 * field names, so they are named the way a human would say them.
 * ------------------------------------------------------------------ */

export interface EvidenceSymbol {
  id: string;
  name: string;
  fqn: string;
  declaring_class: string | null;
  file: string;
  line_start: number;
  line_end: number;
  is_entry_point: boolean;
  entry_point_kind: string | null;
  how_resolved: string;
}

export interface EvidenceChangedFile {
  file: string;
  /** `modified` = tracked and edited; `untracked` = a brand-new file. */
  status: string;
  /** Methods and types declared in the file, as `Class.method`. */
  symbols: string[];
  /** Routes this file's symbols feed. Empty means it feeds no indexed endpoint. */
  feeds_endpoints: string[];
}

export interface EvidenceReachedFrom {
  from_symbol: string;
  from_file: string;
  depth: number;
  /** Changed method first, endpoint handler last. */
  call_path: string[];
}

export interface EvidenceEndpoint {
  id: string;
  route: string;
  transport: string;
  verb: string | null;
  path_template: string | null;
  destination: string | null;
  handler: string;
  file: string;
  line: number;
  request_dto: string | null;
  response_dto: string | null;
  /** Shallowest hop count from any changed method up to this handler. */
  depth: number;
  reached_from: EvidenceReachedFrom[];
}

export interface EvidenceConsumerHit {
  symbol: string;
  file: string;
  line: number;
  method_name: string;
  matched_via: string[];
  /** How the STATIC MATCH scored, not a probability of breakage. */
  match_confidence: number;
  transport: string;
  unresolved: string[];
}

export interface EvidenceConsumer {
  repo: string;
  consumed: boolean;
  why_matched: string[];
  call_sites: EvidenceConsumerHit[];
  /** Flows that would surface a failure. */
  entry_points: Array<{ symbol: string; kind: string }>;
  total_affected_symbols: number;
}

export interface EvidenceEndpointImpact {
  endpoint: EvidenceEndpoint;
  /**
   * TRUE  — the wire contract moved; consumers can break on the call itself.
   * FALSE — reachable from a changed internal method, contract identical.
   */
  contract_changed: boolean;
  consumers: EvidenceConsumer[];
  /** Present only when the fingerprint actually changed against the baseline. */
  diff: {
    change_kind: string;
    reasons: string[];
    details: Array<{ field: string; before: string | null; after: string | null }>;
  } | null;
}

export interface Evidence {
  mode: AnalysisMode;
  producer_repo: string;
  analysed_at: string;
  /** Exactly what "changed" means in this report, in one sentence. */
  comparison_basis: string;
  /** Null in cursor mode — there is no changeset, just a selected method. */
  changed_files: EvidenceChangedFile[] | null;
  changed_symbols: EvidenceSymbol[];
  /** True when a changed symbol is itself an endpoint handler. */
  includes_endpoint_handler: boolean;
  downstream_calls: Array<{ symbol: string; depth: number; file: string | null; line: number | null }>;
  affected_endpoints: EvidenceEndpointImpact[];
  /** Changed files that feed no indexed endpoint at all. Reported, never dropped. */
  changed_files_feeding_no_endpoint: string[];
  unresolved: Array<{ what: string; file: string; line: number; enclosing_symbol: string | null; reason: string }>;
  analysis_limits: {
    max_depth: number;
    depth_capped: boolean;
    /** Callers reached that lead to no endpoint at all. */
    callers_reaching_no_endpoint: string[];
    consumers_analysed: string[];
    /** False when the HEAD comparison could not be made — see `baseline_note`. */
    baseline_available: boolean;
    baseline_note: string;
  };
  /** Every list that was cut, and by how much. Empty when nothing was cut. */
  truncation: string[];
}

export interface BuildEvidenceInput {
  mode: AnalysisMode;
  producerRepo: string;
  comparisonBasis: string;
  changedFiles?: readonly EvidenceChangedFile[] | null;
  symbols: readonly { symbol: SymbolRecord; howResolved: string }[];
  affected: readonly AggregatedEndpoint[];
  downstream: readonly ChainNode[];
  /** One blast radius per affected endpoint, keyed by endpoint id. */
  blastByEndpoint: ReadonlyMap<string, BlastRadiusResult>;
  consumersAnalysed: readonly string[];
  maxDepth: number;
  depthCapped: boolean;
  unreachedCallers: readonly string[];
  baselineAvailable: boolean;
  baselineNote: string;
  analysedAt: string;
  maxBytes?: number;
}

/* ------------------------------------------------------------------ *
 * helpers
 * ------------------------------------------------------------------ */

/** How a route reads to a human. Shared with the HTML appendix and the picker. */
export function routeOf(ep: {
  transport: string;
  verb: string | null;
  path_template: string | null;
  destination: string | null;
}): string {
  if (ep.transport === 'rest') {
    return `${ep.verb ?? 'ANY'} ${ep.path_template ?? '(unknown path)'}`;
  }
  if (ep.destination !== null && ep.destination !== '') {
    return `${ep.transport} ${ep.destination}`;
  }
  return `${ep.transport} (no destination resolved)`;
}

interface Limits {
  endpoints: number;
  consumersPerEndpoint: number;
  hitsPerConsumer: number;
  entryPointsPerConsumer: number;
  reachedFrom: number;
  changedFiles: number;
  symbolsPerFile: number;
  changedSymbols: number;
  downstream: number;
  unresolved: number;
  unreached: number;
}

const FULL_LIMITS: Limits = {
  endpoints: 25,
  consumersPerEndpoint: 25,
  hitsPerConsumer: 25,
  entryPointsPerConsumer: 15,
  reachedFrom: 12,
  changedFiles: 60,
  symbolsPerFile: 25,
  changedSymbols: 60,
  downstream: 40,
  unresolved: 40,
  unreached: 40,
};

/** Successive shrink passes, applied in order until the packet fits. */
const SHRINK_PASSES: Limits[] = [
  { endpoints: 15, consumersPerEndpoint: 15, hitsPerConsumer: 12, entryPointsPerConsumer: 10, reachedFrom: 8, changedFiles: 40, symbolsPerFile: 15, changedSymbols: 40, downstream: 25, unresolved: 25, unreached: 20 },
  { endpoints: 10, consumersPerEndpoint: 10, hitsPerConsumer: 8, entryPointsPerConsumer: 6, reachedFrom: 5, changedFiles: 25, symbolsPerFile: 10, changedSymbols: 25, downstream: 15, unresolved: 15, unreached: 10 },
  { endpoints: 6, consumersPerEndpoint: 6, hitsPerConsumer: 5, entryPointsPerConsumer: 4, reachedFrom: 3, changedFiles: 15, symbolsPerFile: 6, changedSymbols: 15, downstream: 8, unresolved: 8, unreached: 5 },
  { endpoints: 3, consumersPerEndpoint: 4, hitsPerConsumer: 3, entryPointsPerConsumer: 2, reachedFrom: 2, changedFiles: 8, symbolsPerFile: 4, changedSymbols: 8, downstream: 4, unresolved: 4, unreached: 3 },
  { endpoints: 2, consumersPerEndpoint: 2, hitsPerConsumer: 2, entryPointsPerConsumer: 1, reachedFrom: 1, changedFiles: 4, symbolsPerFile: 2, changedSymbols: 4, downstream: 2, unresolved: 2, unreached: 2 },
];

/**
 * Take the first `limit` items, appending a `"...N more"` note to `notes` when
 * anything was dropped. Nothing is ever cut without leaving a trace.
 */
function cap<T>(items: readonly T[], limit: number, label: string, notes: string[]): T[] {
  if (items.length <= limit) {
    return [...items];
  }
  notes.push(`${label}: ${moreMarker(items.length - limit)} (showing ${limit} of ${items.length})`);
  return items.slice(0, limit);
}

function symbolEvidence(symbol: SymbolRecord, howResolved: string): EvidenceSymbol {
  return {
    id: symbol.id,
    name: shortSymbolName(symbol.id),
    fqn: symbol.fqn,
    declaring_class: symbol.enclosing_class,
    file: symbol.file,
    line_start: symbol.line_start,
    line_end: symbol.line_end,
    is_entry_point: symbol.is_entry_point,
    entry_point_kind: symbol.entry_point_kind,
    how_resolved: howResolved,
  };
}

function endpointEvidence(a: AggregatedEndpoint, limits: Limits, notes: string[]): EvidenceEndpoint {
  const ep = a.endpoint;
  const route = routeOf(ep);
  const reached = cap(a.reachedFrom, limits.reachedFrom, `${route} reached_from`, notes);
  return {
    id: ep.id,
    route,
    transport: ep.transport,
    verb: ep.verb,
    path_template: ep.path_template,
    destination: ep.destination,
    handler: shortSymbolName(ep.handler_symbol),
    file: ep.file,
    line: ep.line,
    request_dto: ep.request_dto_fqn,
    response_dto: ep.response_dto_fqn,
    depth: a.depth,
    reached_from: reached.map((r) => ({
      from_symbol: shortSymbolName(r.symbol),
      from_file: r.file,
      depth: r.depth,
      call_path: r.call_path.map(shortSymbolName),
    })),
  };
}

function consumerEvidence(
  consumer: BlastRadiusResult['consumer_blast_radius'][number],
  limits: Limits,
  label: string,
  notes: string[],
): EvidenceConsumer {
  const hits = cap(consumer.direct_invocations, limits.hitsPerConsumer, `${label} call_sites`, notes);
  const entryPoints = cap(
    consumer.entry_points,
    limits.entryPointsPerConsumer,
    `${label} entry_points`,
    notes,
  );
  return {
    repo: consumer.repo,
    consumed: consumer.consumed,
    why_matched: [...consumer.phase1_signals],
    call_sites: hits.map((h) => ({
      symbol: shortSymbolName(h.symbol),
      file: h.file,
      line: h.line_range[0],
      method_name: h.method_name,
      matched_via: [...h.matched_via],
      match_confidence: h.confidence,
      transport: h.transport,
      unresolved: (h.unresolved ?? []).map((u) => `${u.what}: ${u.reason}`),
    })),
    entry_points: entryPoints.map((e) => ({ symbol: shortSymbolName(e.symbol), kind: e.entry_kind })),
    total_affected_symbols: consumer.total_affected_symbols,
  };
}

function unresolvedEvidence(rec: UnresolvedRecord): Evidence['unresolved'][number] {
  return {
    what: rec.what,
    file: rec.context?.file ?? '',
    line: rec.context?.line ?? 0,
    enclosing_symbol:
      rec.context?.enclosing_symbol === null || rec.context?.enclosing_symbol === undefined
        ? null
        : shortSymbolName(rec.context.enclosing_symbol),
    reason: rec.reason,
  };
}

/** Assemble at one set of limits. Called repeatedly by `buildEvidence`. */
function assemble(input: BuildEvidenceInput, limits: Limits): Evidence {
  const notes: string[] = [];

  const affected = cap(input.affected, limits.endpoints, 'affected_endpoints', notes);

  const impacts: EvidenceEndpointImpact[] = affected.map((a) => {
    const blast = input.blastByEndpoint.get(a.endpoint.id);
    const route = routeOf(a.endpoint);
    const consumers = cap(
      blast?.consumer_blast_radius ?? [],
      limits.consumersPerEndpoint,
      `${route} consumers`,
      notes,
    );
    const changed = a.changed;
    return {
      endpoint: endpointEvidence(a, limits, notes),
      contract_changed: a.contractChanged,
      consumers: consumers.map((cbr) => consumerEvidence(cbr, limits, `${route} / ${cbr.repo}`, notes)),
      diff:
        changed === null
          ? null
          : {
              change_kind: changed.change_kind,
              reasons: [...changed.diff_reason],
              details: changed.diff_details.map((d) => ({
                field: d.field,
                before: d.before,
                after: d.after,
              })),
            },
    };
  });

  // Unresolved records are deduped across every endpoint's blast radius: the
  // same blind spot reported five times reads as five problems.
  const seenUnresolved = new Set<string>();
  const allUnresolved: UnresolvedRecord[] = [];
  for (const blast of input.blastByEndpoint.values()) {
    for (const rec of blast.unresolved_across_analysis ?? []) {
      const key = `${rec.what}|${rec.context?.file ?? ''}|${rec.context?.line ?? 0}|${rec.reason}`;
      if (!seenUnresolved.has(key)) {
        seenUnresolved.add(key);
        allUnresolved.push(rec);
      }
    }
  }

  const rawChangedFiles = input.changedFiles ?? null;
  const changedFiles =
    rawChangedFiles === null
      ? null
      : cap(rawChangedFiles, limits.changedFiles, 'changed_files', notes).map((f) => ({
          ...f,
          symbols: cap(f.symbols, limits.symbolsPerFile, `${f.file} symbols`, notes),
        }));

  const symbols = cap(input.symbols, limits.changedSymbols, 'changed_symbols', notes);
  const downstream = cap(input.downstream, limits.downstream, 'downstream_calls', notes);
  const unresolved = cap(allUnresolved, limits.unresolved, 'unresolved', notes);
  const unreached = cap(input.unreachedCallers, limits.unreached, 'callers_reaching_no_endpoint', notes);

  return {
    mode: input.mode,
    producer_repo: input.producerRepo,
    analysed_at: input.analysedAt,
    comparison_basis: input.comparisonBasis,
    changed_files: changedFiles,
    changed_symbols: symbols.map((s) => symbolEvidence(s.symbol, s.howResolved)),
    includes_endpoint_handler: input.affected.some((a) =>
      a.reachedFrom.some((r) => r.depth === 0),
    ),
    downstream_calls: downstream.map((n) => ({
      symbol: shortSymbolName(n.symbol),
      depth: n.depth,
      file: n.call_site?.file ?? null,
      line: n.call_site?.line ?? null,
    })),
    affected_endpoints: impacts,
    changed_files_feeding_no_endpoint: (rawChangedFiles ?? [])
      .filter((f) => f.feeds_endpoints.length === 0)
      .map((f) => f.file),
    unresolved: unresolved.map(unresolvedEvidence),
    analysis_limits: {
      max_depth: input.maxDepth,
      depth_capped: input.depthCapped,
      callers_reaching_no_endpoint: unreached.map(shortSymbolName),
      consumers_analysed: [...input.consumersAnalysed],
      baseline_available: input.baselineAvailable,
      baseline_note: input.baselineNote,
    },
    truncation: notes,
  };
}

/**
 * Build the packet, shrinking until it serializes under the byte cap.
 *
 * Never throws.
 */
export function buildEvidence(input: BuildEvidenceInput): Evidence {
  const maxBytes = input.maxBytes ?? EVIDENCE_MAX_BYTES;

  let evidence = assemble(input, FULL_LIMITS);
  if (evidenceBytes(evidence) <= maxBytes) {
    return evidence;
  }

  for (const limits of SHRINK_PASSES) {
    evidence = assemble(input, limits);
    if (evidenceBytes(evidence) <= maxBytes) {
      evidence.truncation.push(
        `evidence packet exceeded ${maxBytes} bytes at full detail and was reduced — ` +
          'the lists above are samples, not complete inventories',
      );
      return evidence;
    }
  }

  // Even the smallest pass did not fit: say so rather than shipping something
  // that will be silently cut by the model's context window.
  evidence.truncation.push(
    `evidence packet still exceeds ${maxBytes} bytes after maximum reduction — ` +
      'this analysis is necessarily partial',
  );
  return evidence;
}

/** Serialized size in bytes. */
export function evidenceBytes(evidence: Evidence): number {
  return Buffer.byteLength(evidenceJson(evidence), 'utf8');
}

/** The exact text handed to the model. */
export function evidenceJson(evidence: Evidence): string {
  return JSON.stringify(evidence, null, 2);
}
