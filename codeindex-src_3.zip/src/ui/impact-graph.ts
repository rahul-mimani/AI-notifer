/**
 * "Which API endpoints does this method feed?"
 *
 * THE PROBLEM THIS SOLVES
 * -----------------------
 * `blastRadius` starts from an ENDPOINT. But the method an engineer actually
 * edits is almost never a handler — it is a service or repository method three
 * frames down. Nothing in the daemon answers "given this helper, which endpoints
 * are above it?", because the daemon's walks either start at a handler and go
 * down (`walkFeeders`) or return a flat node list with no path information
 * (`walkCallers`).
 *
 * `findAffectedEndpoints` walks UPWARD from the helper and reconstructs, for
 * every endpoint handler it reaches, the ORDERED CALL PATH from the helper to
 * that handler. A helper reached by three endpoints reports all three, each with
 * its own path.
 *
 * WHY IT EXPANDS ONE LEVEL AT A TIME
 * `walkCallers` is the tested reverse-walk primitive, but it returns nodes, not
 * edges — a flat depth-tagged list cannot be reassembled into paths, because a
 * node at depth 2 gives no clue which depth-1 node reached it. So this walks the
 * graph itself, calling `walkCallers(..., maxDepth = 1)` per frontier node to
 * get that node's DIRECT callers, and records a predecessor link for each. The
 * expansion is therefore the same tested code path, one hop at a time, and the
 * predecessor map makes paths reconstructible.
 *
 * Endpoint handlers are TERMINALS, matching `walkCallers`' treatment of entry
 * points: reaching one records it and stops. Expanding past a controller
 * produces noise, not insight.
 *
 * Cycle-safe (a global visited set), depth-capped, and deterministic — callers
 * arrive from `walkCallers` already sorted, and the results are sorted again by
 * (depth, endpoint id).
 *
 * Pure and vscode-free.
 */

import type { ChainNode, Endpoint, EntryPointKind, EntryPointRecord } from '../types.js';
import type { LoadedBundle } from '../store/reader.js';
import type { ForwardIndex } from '../daemon/forward.js';
import { DEFAULT_MAX_DEPTH, walkCallers, walkFeeders } from '../daemon/walk.js';

/** One endpoint that transitively depends on the analysed symbol. */
export interface AffectedEndpoint {
  endpoint: Endpoint;
  /** The handler symbol id — always `endpoint.handler_symbol`. */
  handler_symbol: string;
  /** Hops from the analysed symbol up to the handler. 0 = it IS the handler. */
  depth: number;
  /**
   * Ordered symbol ids from the analysed symbol (index 0) up to the handler
   * (last index). Length is always `depth + 1`.
   */
  call_path: string[];
  /** Entry-point kind of the handler, when it is registered as one. */
  entry_kind: EntryPointKind | null;
}

export interface AffectedEndpointsResult {
  affected: AffectedEndpoint[];
  /** Every symbol visited on the way up, sorted. */
  visited: string[];
  /** True when the walk stopped because it hit `maxDepth`, not because it ran out. */
  depthCapped: boolean;
  /** Callers reached that are NOT below any endpoint — dead ends, in words. */
  unreachedCallers: string[];
}

interface EndpointsByHandler {
  get(symbolId: string): Endpoint[];
}

function indexEndpointsByHandler(bundle: LoadedBundle): EndpointsByHandler {
  const map = new Map<string, Endpoint[]>();
  for (const ep of bundle.endpoints) {
    if (ep.handler_symbol === '') {
      continue;
    }
    const list = map.get(ep.handler_symbol);
    if (list) {
      list.push(ep);
    } else {
      map.set(ep.handler_symbol, [ep]);
    }
  }
  return {
    get(symbolId: string): Endpoint[] {
      return map.get(symbolId) ?? [];
    },
  };
}

function entryPointMap(bundle: LoadedBundle): Map<string, EntryPointRecord> {
  const map = new Map<string, EntryPointRecord>();
  for (const rec of bundle.byKind.entry_point as EntryPointRecord[]) {
    map.set(rec.symbol, rec);
  }
  return map;
}

function clampDepth(maxDepth: number): number {
  if (!Number.isFinite(maxDepth) || maxDepth < 0) {
    return DEFAULT_MAX_DEPTH;
  }
  return Math.floor(maxDepth);
}

/**
 * Every endpoint whose handler transitively reaches `symbolId`, with the call
 * path from `symbolId` up to each handler.
 *
 * Never throws: an error mid-walk returns whatever was found so far.
 */
export function findAffectedEndpoints(
  bundle: LoadedBundle,
  forwardIndex: ForwardIndex,
  symbolId: string,
  maxDepth: number = DEFAULT_MAX_DEPTH,
): AffectedEndpointsResult {
  // `forwardIndex` is not needed to walk upward, but it is part of the module's
  // contract and callers pass the pair; referencing it keeps the signature
  // honest under noUnusedParameters.
  void forwardIndex;

  const affected: AffectedEndpoint[] = [];
  const visited = new Set<string>();
  let depthCapped = false;
  const unreached = new Set<string>();

  if (symbolId === '') {
    return { affected, visited: [], depthCapped: false, unreachedCallers: [] };
  }

  try {
    const cap = clampDepth(maxDepth);
    const byHandler = indexEndpointsByHandler(bundle);
    const entries = entryPointMap(bundle);

    /** callee -> the caller we first reached it from, for path reconstruction. */
    const cameFrom = new Map<string, string>();

    const pathTo = (symbol: string): string[] => {
      const path: string[] = [symbol];
      const guard = new Set<string>([symbol]);
      let cursor = symbol;
      while (cursor !== symbolId) {
        const parent = cameFrom.get(cursor);
        if (parent === undefined || guard.has(parent)) {
          break;
        }
        guard.add(parent);
        path.push(parent);
        cursor = parent;
      }
      // `path` was built handler -> ... -> seed; the contract is seed first.
      return path.reverse();
    };

    const record = (symbol: string, depth: number): boolean => {
      const endpoints = byHandler.get(symbol);
      if (endpoints.length === 0) {
        return false;
      }
      const entry = entries.get(symbol);
      // `pathTo` walks predecessors, which for the seed is just the seed.
      const call_path = symbol === symbolId ? [symbolId] : pathTo(symbol);
      for (const endpoint of endpoints) {
        affected.push({
          endpoint,
          handler_symbol: symbol,
          depth,
          call_path,
          entry_kind: entry?.entry_kind ?? null,
        });
      }
      return true;
    };

    visited.add(symbolId);
    // The cursor may itself sit on a handler — that is depth 0, not a failure.
    const seedIsHandler = record(symbolId, 0);

    let frontier: string[] = seedIsHandler ? [] : [symbolId];

    for (let depth = 1; depth <= cap && frontier.length > 0; depth++) {
      const nextFrontier: string[] = [];

      for (const callee of frontier) {
        // One hop, via the tested primitive. Depth 1 means "direct callers".
        const callers: ChainNode[] = walkCallers(bundle, callee, 1, { entryPoints: entries });
        for (const node of callers) {
          if (visited.has(node.symbol)) {
            continue;
          }
          visited.add(node.symbol);
          cameFrom.set(node.symbol, callee);

          // Endpoint handlers are terminals — record and stop climbing.
          if (record(node.symbol, depth)) {
            continue;
          }
          // So are entry points that expose no endpoint (a `main`, a scheduled
          // job): nothing above them, and climbing past is meaningless.
          if (node.is_entry_point) {
            unreached.add(node.symbol);
            continue;
          }
          nextFrontier.push(node.symbol);
        }
      }

      if (depth === cap && nextFrontier.length > 0) {
        depthCapped = true;
        for (const symbol of nextFrontier) {
          unreached.add(symbol);
        }
      }
      frontier = nextFrontier;
    }

    // Anything still on the frontier when the graph ran out reached no endpoint.
    for (const symbol of frontier) {
      unreached.add(symbol);
    }
  } catch {
    // Fail open: partial results beat none.
  }

  affected.sort(
    (a, b) =>
      a.depth - b.depth ||
      (a.endpoint.id < b.endpoint.id ? -1 : a.endpoint.id > b.endpoint.id ? 1 : 0),
  );

  return {
    affected,
    visited: [...visited].sort(),
    depthCapped,
    unreachedCallers: [...unreached].sort(),
  };
}

/**
 * What the analysed symbol itself calls, over the forward index — the other
 * half of "what does this change touch". The seed is excluded; the caller
 * already knows what it selected.
 *
 * Never throws.
 */
export function findDownstream(
  bundle: LoadedBundle,
  forwardIndex: ForwardIndex,
  symbolId: string,
  maxDepth: number = DEFAULT_MAX_DEPTH,
): ChainNode[] {
  try {
    if (symbolId === '') {
      return [];
    }
    const feeders = walkFeeders(bundle, symbolId, clampDepth(maxDepth), {
      forward: forwardIndex,
      entryPoints: entryPointMap(bundle),
    });
    return feeders.downstream.filter((n) => n.depth > 0);
  } catch {
    return [];
  }
}

/** Distinct endpoints in an affected list, preserving order. */
export function distinctEndpoints(affected: readonly AffectedEndpoint[]): Endpoint[] {
  const seen = new Set<string>();
  const out: Endpoint[] = [];
  for (const a of affected) {
    if (!seen.has(a.endpoint.id)) {
      seen.add(a.endpoint.id);
      out.push(a.endpoint);
    }
  }
  return out;
}

/* ------------------------------------------------------------------ *
 * Changeset aggregation
 * ------------------------------------------------------------------ */

/** One reason an endpoint is in scope: a changed symbol that reaches it. */
export interface ReachedFrom {
  /** The changed symbol id the walk started from. */
  symbol: string;
  /** Repo-relative file that symbol was declared in. */
  file: string;
  depth: number;
  call_path: string[];
}

/**
 * One endpoint in scope for a whole changeset, with every changed symbol that
 * reaches it.
 *
 * `contractChanged` is the distinction the reader cares about most:
 *   TRUE  — the endpoint's fingerprint differs from HEAD. Its wire contract
 *           moved, so consumers can break on the shape of the call itself.
 *   FALSE — the endpoint is merely REACHABLE from a changed internal method.
 *           The contract is identical, so nothing 404s or fails to deserialize,
 *           but the behaviour behind it changed and consumers can still observe
 *           different values, different timing, or different side effects.
 * Collapsing those two into "affected" would be the single most misleading
 * thing this report could do.
 */
export interface AggregatedEndpoint {
  endpoint: Endpoint;
  contractChanged: boolean;
  /** The diff record, when the fingerprint actually changed. */
  changed: import('../types.js').ChangedEndpoint | null;
  /** Every changed symbol that reaches this endpoint, sorted. */
  reachedFrom: ReachedFrom[];
  /** Shallowest depth across `reachedFrom`. */
  depth: number;
}

export interface ChangedSymbolWalk {
  symbolId: string;
  file: string;
  result: AffectedEndpointsResult;
}

/**
 * Union the upward walks of every changed symbol into one endpoint list, and
 * fold in the fingerprint diff so contract changes are distinguishable from
 * behaviour-only changes.
 *
 * Endpoints whose contract changed but which NO changed symbol reaches are
 * still included — an endpoint can change because its DTO changed in a file
 * that declares no method on the call path.
 */
export function aggregateAffected(
  walks: readonly ChangedSymbolWalk[],
  changedEndpoints: readonly import('../types.js').ChangedEndpoint[],
  endpointsById: ReadonlyMap<string, Endpoint>,
): AggregatedEndpoint[] {
  const byId = new Map<string, AggregatedEndpoint>();

  for (const walk of walks) {
    for (const a of walk.result.affected) {
      let entry = byId.get(a.endpoint.id);
      if (entry === undefined) {
        entry = {
          endpoint: a.endpoint,
          contractChanged: false,
          changed: null,
          reachedFrom: [],
          depth: a.depth,
        };
        byId.set(a.endpoint.id, entry);
      }
      entry.reachedFrom.push({
        symbol: walk.symbolId,
        file: walk.file,
        depth: a.depth,
        call_path: a.call_path,
      });
      entry.depth = Math.min(entry.depth, a.depth);
    }
  }

  for (const changed of changedEndpoints) {
    const endpoint = endpointsById.get(changed.id);
    let entry = byId.get(changed.id);
    if (entry === undefined) {
      if (endpoint === undefined) {
        // A REMOVED endpoint has no record on the new side. It cannot be walked
        // to, but it is unquestionably affected, so it must not be dropped.
        continue;
      }
      entry = {
        endpoint,
        contractChanged: true,
        changed,
        reachedFrom: [],
        depth: 0,
      };
      byId.set(changed.id, entry);
      continue;
    }
    entry.contractChanged = true;
    entry.changed = changed;
  }

  const out = [...byId.values()];
  for (const entry of out) {
    entry.reachedFrom.sort(
      (a, b) =>
        a.depth - b.depth ||
        (a.symbol < b.symbol ? -1 : a.symbol > b.symbol ? 1 : 0),
    );
  }
  // Contract changes first — they are what breaks callers — then by route.
  out.sort(
    (a, b) =>
      Number(b.contractChanged) - Number(a.contractChanged) ||
      a.depth - b.depth ||
      (a.endpoint.id < b.endpoint.id ? -1 : a.endpoint.id > b.endpoint.id ? 1 : 0),
  );
  return out;
}
