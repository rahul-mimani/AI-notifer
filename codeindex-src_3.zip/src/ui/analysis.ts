/**
 * The impact-analysis pipeline, with no vscode in it.
 *
 * Three stages, deliberately separated because the command has to stop between
 * the first and the second to ask the user which endpoint they want:
 *
 *   1. `computeImpact`     — changed symbols -> upward walks -> affected
 *                            endpoints, with contract changes distinguished
 *                            from behaviour-only reachability.
 *   2. `assembleEvidence`  — the selected subset -> blast radius per endpoint
 *                            -> the evidence packet handed to the model.
 *   3. `generateNarrative` — the model call, with every failure mode collapsing
 *                            to "use the deterministic report and say why".
 *
 * Stage 3 NEVER throws and never returns something unusable: a missing model, a
 * rate limit, a timeout, prose instead of HTML, or HTML missing its sections all
 * produce `{ html: null, reason }`, and the caller renders the template report
 * with that reason printed at the top. There is no path through this file that
 * dead-ends.
 */

import type {
  BlastRadiusResult,
  ChainNode,
  ChangedEndpoint,
  Endpoint,
  SymbolRecord,
} from '../types.js';
import type { Logger } from '../util/logger.js';
import { silentLogger } from '../util/logger.js';
import type { LoadedBundle } from '../store/reader.js';
import type { ForwardIndex } from '../daemon/forward.js';
import type { RegistryLike } from '../daemon/blast.js';
import { blastRadius, changedFromEndpoint } from '../daemon/blast.js';
import { DEFAULT_MAX_DEPTH } from '../daemon/walk.js';
import type { ChatModelProvider } from '../lm/provider.js';
import { LmError } from '../lm/provider.js';
import {
  ANALYSIS_REQUIRED_SECTIONS,
  ANALYSIS_SYSTEM_PROMPT,
  buildAnalysisPrompt,
} from '../lm/analysis-prompt.js';
import type { AggregatedEndpoint, ChangedSymbolWalk } from './impact-graph.js';
import { aggregateAffected, findAffectedEndpoints, findDownstream } from './impact-graph.js';
import type { AnalysisMode, Evidence, EvidenceChangedFile } from './evidence.js';
import { buildEvidence, evidenceJson, routeOf } from './evidence.js';
import { renderImpactReport } from './report.js';
import { renderAnalysisReport, sanitizeFragment, sectionsPresent } from './report-html.js';
import { shortSymbolName } from './symbol-at.js';

/* ================================================================== *
 * Stage 1 — compute impact
 * ================================================================== */

export interface AnalysedSymbol {
  symbol: SymbolRecord;
  howResolved: string;
}

export interface ComputeImpactInput {
  bundle: LoadedBundle;
  forward: ForwardIndex;
  symbols: readonly AnalysedSymbol[];
  /** Fingerprint diff against the baseline. Empty when there is no baseline. */
  changedEndpoints: readonly ChangedEndpoint[];
  maxDepth?: number;
}

export interface ComputeImpactResult {
  affected: AggregatedEndpoint[];
  walks: ChangedSymbolWalk[];
  downstream: ChainNode[];
  depthCapped: boolean;
  unreachedCallers: string[];
}

/**
 * Walk upward from every changed symbol and fold the results, plus the
 * fingerprint diff, into one endpoint list. Never throws.
 */
export function computeImpact(input: ComputeImpactInput): ComputeImpactResult {
  const maxDepth = input.maxDepth ?? DEFAULT_MAX_DEPTH;
  const walks: ChangedSymbolWalk[] = [];
  const downstream: ChainNode[] = [];
  const seenDownstream = new Set<string>();
  const unreached = new Set<string>();
  let depthCapped = false;

  for (const { symbol } of input.symbols) {
    const result = findAffectedEndpoints(input.bundle, input.forward, symbol.id, maxDepth);
    walks.push({ symbolId: symbol.id, file: symbol.file, result });
    depthCapped = depthCapped || result.depthCapped;
    for (const caller of result.unreachedCallers) {
      unreached.add(caller);
    }
    for (const node of findDownstream(input.bundle, input.forward, symbol.id, maxDepth)) {
      if (!seenDownstream.has(node.symbol)) {
        seenDownstream.add(node.symbol);
        downstream.push(node);
      }
    }
  }

  const affected = aggregateAffected(walks, input.changedEndpoints, input.bundle.endpointsById);

  return {
    affected,
    walks,
    downstream,
    depthCapped,
    unreachedCallers: [...unreached].sort(),
  };
}

/* ================================================================== *
 * Stage 2 — evidence
 * ================================================================== */

export interface AssembleEvidenceInput {
  mode: AnalysisMode;
  registry: RegistryLike;
  producerRepo: string;
  consumerRepos: readonly string[];
  /** The endpoints this report covers — already narrowed by the user's pick. */
  selected: readonly AggregatedEndpoint[];
  symbols: readonly AnalysedSymbol[];
  changedFiles: readonly EvidenceChangedFile[] | null;
  downstream: readonly ChainNode[];
  comparisonBasis: string;
  baselineAvailable: boolean;
  baselineNote: string;
  depthCapped: boolean;
  unreachedCallers: readonly string[];
  maxDepth: number;
  analysedAt: string;
  logger?: Logger;
}

export interface AssembledEvidence {
  evidence: Evidence;
  /** Kept for the deterministic fallback report. */
  blastByEndpoint: Map<string, BlastRadiusResult>;
}

/** Run the blast radius per selected endpoint and build the packet. */
export function assembleEvidence(input: AssembleEvidenceInput): AssembledEvidence {
  const logger = input.logger ?? silentLogger;
  const blastByEndpoint = new Map<string, BlastRadiusResult>();

  for (const entry of input.selected) {
    try {
      const changed = entry.changed ?? changedFromEndpoint(entry.endpoint);
      const result = blastRadius(
        input.registry,
        input.producerRepo,
        input.consumerRepos,
        entry.endpoint.id,
        { changed, maxDepth: input.maxDepth, logger },
      );
      blastByEndpoint.set(entry.endpoint.id, result);
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      logger.log(
        'QUERY',
        `blast radius for ${routeOf(entry.endpoint)} failed: ${detail} — endpoint reported without consumer detail`,
      );
    }
  }

  const evidence = buildEvidence({
    mode: input.mode,
    producerRepo: input.producerRepo,
    comparisonBasis: input.comparisonBasis,
    changedFiles: input.changedFiles,
    symbols: input.symbols,
    affected: input.selected,
    downstream: input.downstream,
    blastByEndpoint,
    consumersAnalysed: input.consumerRepos,
    maxDepth: input.maxDepth,
    depthCapped: input.depthCapped,
    unreachedCallers: input.unreachedCallers,
    baselineAvailable: input.baselineAvailable,
    baselineNote: input.baselineNote,
    analysedAt: input.analysedAt,
  });

  return { evidence, blastByEndpoint };
}

/* ================================================================== *
 * Stage 3 — the narrative
 * ================================================================== */

export interface NarrativeResult {
  /** Sanitized HTML, or null when the deterministic fallback must be used. */
  html: string | null;
  /** Populated whenever `html` is null. Printed at the top of the report. */
  reason: string | null;
  modelId: string | null;
  /** Sections the model actually produced. */
  sections: string[];
  /** Tags the sanitizer removed, if any. Logged for transparency. */
  droppedTags: string[];
}

export interface GenerateNarrativeInput {
  provider: ChatModelProvider | null;
  model: string;
  evidence: Evidence;
  logger?: Logger;
  signal?: AbortSignal;
}

/**
 * Minimum viable narrative: the verdict, plus at least three of the six required
 * sections.
 *
 * Not "all six", because a model that answers four sections well and skips two
 * still beats the template report, and the renderer shows a missing section as a
 * missing heading rather than pretending it was there. But a response with no
 * verdict has not answered the question that was asked, and prose with no
 * sections at all is not the requested format — both fall back.
 */
export const MIN_SECTIONS = 3;

export function isUsableNarrative(sanitizedHtml: string): { ok: boolean; sections: string[]; why: string } {
  const sections = sectionsPresent(sanitizedHtml);
  const required = sections.filter((s) => (ANALYSIS_REQUIRED_SECTIONS as readonly string[]).includes(s));
  if (!sections.includes('verdict')) {
    return {
      ok: false,
      sections,
      why: `the response contained no <section data-part="verdict">, so it did not answer whether the change is safe to ship (found: ${sections.length === 0 ? 'no sections at all' : sections.join(', ')})`,
    };
  }
  if (required.length < MIN_SECTIONS) {
    return {
      ok: false,
      sections,
      why: `the response contained only ${required.length} of the ${ANALYSIS_REQUIRED_SECTIONS.length} required sections (${required.join(', ')}), which is too incomplete to publish`,
    };
  }
  return { ok: true, sections, why: '' };
}

/**
 * Ask the model for the narrative. Never throws; every failure becomes a reason
 * string the report prints verbatim.
 */
export async function generateNarrative(input: GenerateNarrativeInput): Promise<NarrativeResult> {
  const logger = input.logger ?? silentLogger;
  const fail = (reason: string, modelId: string | null = null): NarrativeResult => {
    logger.log('LM', `impact narrative unavailable — ${reason}`);
    return { html: null, reason, modelId, sections: [], droppedTags: [] };
  };

  if (input.provider === null) {
    return fail('no language model provider was configured for this session.');
  }

  let modelId: string | null = null;
  try {
    const model = await input.provider.selectModel(input.model, logger);
    if (model === null) {
      return fail(
        'no chat model is available. In VS Code this usually means GitHub Copilot is not installed, ' +
          'not signed in, or has not been granted permission to this extension.',
      );
    }
    modelId = model.id;
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return fail(`selecting a chat model failed: ${detail}`);
  }

  let raw: string;
  try {
    const prompt = buildAnalysisPrompt({ evidenceJson: evidenceJson(input.evidence) });
    logger.log(
      'LM',
      `requesting impact narrative from ${modelId} — ` +
        `${Buffer.byteLength(prompt, 'utf8')} bytes of prompt, ` +
        `${input.evidence.affected_endpoints.length} endpoint(s) of evidence`,
    );
    raw = await input.provider.sendRequest(ANALYSIS_SYSTEM_PROMPT, [prompt], input.signal);
  } catch (err) {
    if (err instanceof LmError) {
      return fail(`the language model request failed (${err.name}): ${err.message}`, modelId);
    }
    const detail = err instanceof Error ? err.message : String(err);
    return fail(`the language model request failed: ${detail}`, modelId);
  }

  if (typeof raw !== 'string' || raw.trim() === '') {
    return fail('the language model returned an empty response.', modelId);
  }

  const sanitized = sanitizeFragment(stripFences(raw));
  if (sanitized.droppedTags.length > 0) {
    logger.log(
      'LM',
      `sanitizer removed disallowed tag(s) from the model response: ${sanitized.droppedTags.join(', ')}`,
    );
  }
  if (sanitized.strippedAttributes) {
    logger.log('LM', 'sanitizer stripped attributes from the model response');
  }

  const usable = isUsableNarrative(sanitized.html);
  if (!usable.ok) {
    return fail(
      `the language model responded, but ${usable.why}. The response was discarded rather than published.`,
      modelId,
    );
  }

  logger.log('LM', `impact narrative accepted — sections: ${usable.sections.join(', ')}`);
  return {
    html: sanitized.html,
    reason: null,
    modelId,
    sections: usable.sections,
    droppedTags: sanitized.droppedTags,
  };
}

/**
 * Remove a ```html fence the model may have added despite being told not to.
 * Cheap, and the difference between a usable answer and a fallback.
 */
export function stripFences(text: string): string {
  const trimmed = text.trim();
  if (!trimmed.startsWith('```')) {
    return trimmed;
  }
  const firstNewline = trimmed.indexOf('\n');
  if (firstNewline < 0) {
    return trimmed;
  }
  const withoutOpen = trimmed.slice(firstNewline + 1);
  const closing = withoutOpen.lastIndexOf('```');
  return (closing < 0 ? withoutOpen : withoutOpen.slice(0, closing)).trim();
}

/* ================================================================== *
 * Assembly
 * ================================================================== */

export interface BuildReportInput {
  producerRepo: string;
  selected: readonly AggregatedEndpoint[];
  evidence: Evidence;
  blastByEndpoint: ReadonlyMap<string, BlastRadiusResult>;
  narrative: NarrativeResult;
  comparisonBasis: string;
  generatedAt: string;
  cspMeta?: string;
  styleNonce?: string;
}

/** The report title and the one-line scope description. */
export function reportSubtitle(
  producerRepo: string,
  selected: readonly AggregatedEndpoint[],
  symbols: readonly AnalysedSymbol[],
): string {
  if (selected.length === 1) {
    const entry = selected[0]!;
    return `${routeOf(entry.endpoint)} in ${producerRepo} — ${
      entry.contractChanged ? 'contract changed' : 'contract unchanged, behaviour may differ'
    }`;
  }
  if (selected.length === 0) {
    const names = symbols.map((s) => shortSymbolName(s.symbol.id));
    return `${producerRepo} — no indexed endpoint is reachable from ${
      names.length === 0 ? 'the analysed change' : names.join(', ')
    }`;
  }
  const contract = selected.filter((s) => s.contractChanged).length;
  return `${selected.length} affected endpoint(s) in ${producerRepo} — ${contract} with a changed contract, ${
    selected.length - contract
  } reachable but contract-unchanged`;
}

/** Deterministic markdown for the fallback path, across every selected endpoint. */
export function fallbackReportText(
  producerRepo: string,
  selected: readonly AggregatedEndpoint[],
  blastByEndpoint: ReadonlyMap<string, BlastRadiusResult>,
): string {
  if (selected.length === 0) {
    return 'No indexed endpoint is reachable from the analysed change, so there is no blast radius to report.';
  }
  const parts: string[] = [];
  for (const entry of selected) {
    const result = blastByEndpoint.get(entry.endpoint.id);
    if (result === undefined) {
      parts.push(`# ${routeOf(entry.endpoint)}\n\nThe blast radius for this endpoint could not be computed.`);
      continue;
    }
    parts.push(renderImpactReport(result, { producerRepo }));
  }
  return parts.join('\n\n---\n\n');
}

/** Render the finished HTML document. */
export function buildReport(input: BuildReportInput): string {
  const usingFallback = input.narrative.html === null;
  return renderAnalysisReport({
    title: 'CodeIndex impact report',
    subtitle: reportSubtitle(
      input.producerRepo,
      input.selected,
      input.evidence.changed_symbols.map((s) => ({
        symbol: { id: s.id, file: s.file } as SymbolRecord,
        howResolved: s.how_resolved,
      })),
    ),
    comparisonBasis: input.comparisonBasis,
    generatedAt: input.generatedAt,
    narrativeHtml: input.narrative.html,
    fallbackText: usingFallback
      ? fallbackReportText(input.producerRepo, input.selected, input.blastByEndpoint)
      : null,
    fallbackReason: input.narrative.reason,
    evidence: input.evidence,
    modelId: input.narrative.modelId,
    cspMeta: input.cspMeta,
    styleNonce: input.styleNonce,
  });
}

/** Endpoints matching a selection: a single id, or all of them. */
export function selectEndpoints(
  affected: readonly AggregatedEndpoint[],
  endpointId: string | null,
): AggregatedEndpoint[] {
  if (endpointId === null) {
    return [...affected];
  }
  return affected.filter((a) => a.endpoint.id === endpointId);
}

/** Endpoints in the bundle, for the picker default lookup. */
export function endpointsOf(bundle: LoadedBundle): Endpoint[] {
  return [...bundle.endpoints];
}
