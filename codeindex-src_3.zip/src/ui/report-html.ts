/**
 * The standalone HTML impact report, and the sanitizer that makes it safe.
 *
 * THE MODEL'S OUTPUT IS UNTRUSTED INPUT.
 * --------------------------------------
 * It is rendered inside a VS Code webview, which is a real browser context with
 * a message channel back to the extension host, and it is also written to a file
 * the user may open in their normal browser. A model can be talked into emitting
 * a <script> tag by anything it read on the way here — including, in principle,
 * a comment in the user's own source. So the narrative goes through
 * `sanitizeFragment` before it is ever concatenated into a document:
 *
 *   - an ALLOWLIST of tags; everything else is dropped, keeping its text
 *   - every attribute is stripped except `data-part` on <section>
 *   - <script> and <style> are removed WITH THEIR CONTENT, not just untagged —
 *     dropping only the tags would paste executable text straight into the page
 *   - stray `<` and `&` in text are escaped, so nothing reassembles into markup
 *   - unbalanced tags are closed, so the model cannot leak markup into the
 *     deterministic appendix below it by opening an element and never closing it
 *
 * There is no dependency here and no regex-driven "remove the bad bits" pass —
 * the parser emits a NEW document from tokens it recognised, so anything it did
 * not recognise cannot survive by construction.
 *
 * THE APPENDIX IS THE AUDIT TRAIL.
 * The narrative above it is a language model's prose and may be wrong. The
 * appendix below it is rendered by this file from the same evidence the model
 * was given, and is labelled as machine-generated fact. A reader who distrusts a
 * sentence can check it against the table underneath.
 *
 * Pure and vscode-free: it takes strings and an `Evidence` object and returns a
 * string. The webview CSP is supplied by the caller.
 */

import type { AnalysisSection } from '../lm/analysis-prompt.js';
import { ANALYSIS_SECTIONS, ANALYSIS_SECTION_TITLES } from '../lm/analysis-prompt.js';
import type { Evidence } from './evidence.js';

/* ================================================================== *
 * 1. Sanitizer
 * ================================================================== */

/** The only elements the model may produce. Everything else loses its tags. */
export const ALLOWED_TAGS: ReadonlySet<string> = new Set([
  'p',
  'ul',
  'ol',
  'li',
  'strong',
  'em',
  'code',
  'h3',
  'h4',
  'section',
  'br',
]);

/** Tags whose CONTENT is dropped as well as the tag itself. */
const DROP_CONTENT_TAGS: ReadonlySet<string> = new Set(['script', 'style']);

/** Elements with no closing tag. */
const VOID_TAGS: ReadonlySet<string> = new Set(['br']);

/** The single attribute that survives, and only on <section>. */
const ALLOWED_ATTRIBUTE = 'data-part';

/** Entities we leave alone when escaping `&`, so text is not double-escaped. */
const ENTITY = /^&(#\d{1,7}|#[xX][0-9a-fA-F]{1,6}|[a-zA-Z][a-zA-Z0-9]{1,31});/;

/** Escape text for insertion into an element body. */
export function escapeText(text: string): string {
  let out = '';
  for (let i = 0; i < text.length; i++) {
    const ch = text[i]!;
    if (ch === '&') {
      const rest = text.slice(i);
      const match = ENTITY.exec(rest);
      if (match !== null) {
        out += match[0];
        i += match[0].length - 1;
        continue;
      }
      out += '&amp;';
    } else if (ch === '<') {
      out += '&lt;';
    } else if (ch === '>') {
      out += '&gt;';
    } else {
      out += ch;
    }
  }
  return out;
}

/** Escape a value for a double-quoted attribute. */
export function escapeAttribute(value: string): string {
  return escapeText(value).split('"').join('&quot;').split("'").join('&#39;');
}

/**
 * A `data-part` value is only ever one of our own section names. Anything else
 * is dropped rather than escaped — there is no legitimate reason for the model
 * to invent one, and an unrecognised value would just be noise in the DOM.
 */
function safeDataPart(raw: string): string | null {
  const value = raw.trim().toLowerCase();
  return (ANALYSIS_SECTIONS as readonly string[]).includes(value) ? value : null;
}

/** Extract `data-part="..."` from a raw attribute string, if present and valid. */
function readDataPart(rawAttributes: string): string | null {
  const match = /\bdata-part\s*=\s*("([^"]*)"|'([^']*)'|([^\s"'`=<>]+))/i.exec(rawAttributes);
  if (match === null) {
    return null;
  }
  return safeDataPart(match[2] ?? match[3] ?? match[4] ?? '');
}

interface Token {
  kind: 'text' | 'open' | 'close';
  /** Raw text, for `text`. Lowercased tag name otherwise. */
  value: string;
  attributes: string;
  selfClosing: boolean;
}

/**
 * Remove comments, and <script>/<style> elements INCLUDING their content.
 *
 * An unclosed `<script>` drops everything to the end of the input: a model that
 * emits `<script>` without a matching close has produced something we will not
 * render under any circumstances, and truncating is the safe reading.
 */
function stripDangerousBlocks(input: string): string {
  let out = input.split(/<!--[\s\S]*?-->/g).join('');
  // Also drop an unterminated comment.
  const commentStart = out.indexOf('<!--');
  if (commentStart >= 0) {
    out = out.slice(0, commentStart);
  }
  for (const tag of DROP_CONTENT_TAGS) {
    const open = new RegExp(`<${tag}\\b[^>]*>`, 'i');
    for (;;) {
      const start = open.exec(out);
      if (start === null) {
        break;
      }
      const closeIndex = out.toLowerCase().indexOf(`</${tag}`, start.index);
      if (closeIndex < 0) {
        out = out.slice(0, start.index);
        break;
      }
      const closeEnd = out.indexOf('>', closeIndex);
      out = out.slice(0, start.index) + (closeEnd < 0 ? '' : out.slice(closeEnd + 1));
    }
  }
  return out;
}

/** Split into text and tag tokens. Anything unparseable stays text. */
function tokenize(input: string): Token[] {
  const tokens: Token[] = [];
  const tagPattern = /<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9-]*)((?:"[^"]*"|'[^']*'|[^>"'])*)>/g;
  let cursor = 0;
  let match: RegExpExecArray | null;

  while ((match = tagPattern.exec(input)) !== null) {
    if (match.index > cursor) {
      tokens.push({
        kind: 'text',
        value: input.slice(cursor, match.index),
        attributes: '',
        selfClosing: false,
      });
    }
    const closing = match[1] === '/';
    const name = (match[2] ?? '').toLowerCase();
    const attributes = match[3] ?? '';
    tokens.push({
      kind: closing ? 'close' : 'open',
      value: name,
      attributes,
      selfClosing: attributes.trimEnd().endsWith('/'),
    });
    cursor = match.index + match[0].length;
  }

  if (cursor < input.length) {
    tokens.push({ kind: 'text', value: input.slice(cursor), attributes: '', selfClosing: false });
  }
  return tokens;
}

export interface SanitizeResult {
  html: string;
  /** Tag names that were dropped, sorted. Logged, and useful in tests. */
  droppedTags: string[];
  /** True when at least one attribute was stripped. */
  strippedAttributes: boolean;
}

/**
 * Sanitize one untrusted HTML fragment against the allowlist.
 *
 * Never throws — a fragment it cannot make sense of degrades to escaped text,
 * which is ugly but harmless, and the caller's usability check will reject it.
 */
export function sanitizeFragment(input: string): SanitizeResult {
  const dropped = new Set<string>();
  let strippedAttributes = false;

  if (typeof input !== 'string' || input === '') {
    return { html: '', droppedTags: [], strippedAttributes: false };
  }

  let out = '';
  const openStack: string[] = [];

  try {
    for (const token of tokenize(stripDangerousBlocks(input))) {
      if (token.kind === 'text') {
        out += escapeText(token.value);
        continue;
      }

      if (!ALLOWED_TAGS.has(token.value)) {
        // Keep the text inside a disallowed element; drop only the markup.
        dropped.add(token.value);
        continue;
      }

      if (token.kind === 'open') {
        if (token.attributes.trim() !== '') {
          const dataPart = token.value === 'section' ? readDataPart(token.attributes) : null;
          // Anything that is not an accepted data-part is discarded, including
          // every event handler, style, href and src.
          const onlyAttribute =
            dataPart !== null &&
            token.attributes.replace(/\s+/g, '').replace(/\/$/, '').toLowerCase() ===
              `data-part=${JSON.stringify(dataPart)}`.replace(/\s+/g, '').toLowerCase();
          if (!onlyAttribute) {
            strippedAttributes = true;
          }
          out += dataPart === null
            ? `<${token.value}>`
            : `<${token.value} ${ALLOWED_ATTRIBUTE}="${escapeAttribute(dataPart)}">`;
        } else {
          out += `<${token.value}>`;
        }
        if (!VOID_TAGS.has(token.value) && !token.selfClosing) {
          openStack.push(token.value);
        }
        continue;
      }

      // Closing tag. A close with no matching open would let the model escape
      // its own container, so it is dropped.
      if (VOID_TAGS.has(token.value)) {
        continue;
      }
      const last = openStack.lastIndexOf(token.value);
      if (last < 0) {
        continue;
      }
      // Close anything opened inside it that was never closed.
      while (openStack.length > last) {
        out += `</${openStack.pop()!}>`;
      }
    }

    // Close whatever the model left open.
    while (openStack.length > 0) {
      out += `</${openStack.pop()!}>`;
    }
  } catch {
    return {
      html: escapeText(input),
      droppedTags: [...dropped].sort(),
      strippedAttributes: true,
    };
  }

  return { html: out, droppedTags: [...dropped].sort(), strippedAttributes };
}

/** The `data-part` values present in a sanitized fragment. */
export function sectionsPresent(sanitizedHtml: string): AnalysisSection[] {
  const out: AnalysisSection[] = [];
  // Tolerates the `data-heading` the renderer stamps on afterwards, so this
  // works on both a raw sanitized fragment and a finished document.
  const pattern = /<section\s+data-part="([a-z-]+)"/g;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(sanitizedHtml)) !== null) {
    const name = match[1] as AnalysisSection;
    if ((ANALYSIS_SECTIONS as readonly string[]).includes(name) && !out.includes(name)) {
      out.push(name);
    }
  }
  return out;
}

/* ================================================================== *
 * 2. Document rendering
 * ================================================================== */

export interface ReportRenderOptions {
  title: string;
  /** The endpoint or changeset the report is scoped to. */
  subtitle: string;
  /** "comparing your working tree against git HEAD (abc1234)". */
  comparisonBasis: string;
  generatedAt: string;
  /** Sanitized model narrative. Null triggers the fallback banner. */
  narrativeHtml: string | null;
  /** The deterministic `renderImpactReport` markdown, for the fallback path. */
  fallbackText: string | null;
  /** Why the AI narrative is missing. Required whenever `narrativeHtml` is null. */
  fallbackReason: string | null;
  evidence: Evidence;
  modelId: string | null;
  /** A `<meta http-equiv="Content-Security-Policy">` line, for the webview. */
  cspMeta?: string;
  /** Nonce applied to the inline <style>, so a strict CSP can allow just it. */
  styleNonce?: string;
}

function h(text: string): string {
  return escapeText(text);
}

function list(items: readonly string[], empty: string): string {
  if (items.length === 0) {
    return `<p class="muted">${h(empty)}</p>`;
  }
  return `<ul>${items.map((i) => `<li>${h(i)}</li>`).join('')}</ul>`;
}

function callPath(path: readonly string[]): string {
  return path.map((s) => `<code>${h(s)}</code>`).join('<span class="arrow"> &rarr; </span>');
}

function confidenceCell(value: number): string {
  const pretty = Number.isFinite(value) ? value.toFixed(2) : '0.00';
  return `<span class="conf" title="How the static analysis matched this call site — not a probability of breakage">${h(pretty)}</span>`;
}

/* ---- the deterministic appendix ---------------------------------- */

function changedFilesTable(evidence: Evidence): string {
  const files = evidence.changed_files;
  if (files === null || files.length === 0) {
    return '';
  }
  const rows = files
    .map(
      (f) => `<tr>
      <td><code>${h(f.file)}</code></td>
      <td>${h(f.status)}</td>
      <td>${f.symbols.length === 0 ? '<span class="muted">no indexed symbols</span>' : f.symbols.map((s) => `<code>${h(s)}</code>`).join(', ')}</td>
      <td>${
        f.feeds_endpoints.length === 0
          ? '<span class="warn">feeds no indexed endpoint</span>'
          : f.feeds_endpoints.map((e) => `<code>${h(e)}</code>`).join('<br>')
      }</td>
    </tr>`,
    )
    .join('');
  return `<h3>Changed files</h3>
  <div class="scroll"><table>
    <thead><tr><th>File</th><th>Status</th><th>Symbols</th><th>Feeds</th></tr></thead>
    <tbody>${rows}</tbody>
  </table></div>`;
}

function endpointsSection(evidence: Evidence): string {
  if (evidence.affected_endpoints.length === 0) {
    return '<h3>Affected endpoints</h3><p class="muted">No indexed endpoint is reachable from the analysed change.</p>';
  }

  const blocks = evidence.affected_endpoints
    .map((impact) => {
      const ep = impact.endpoint;
      const badge = impact.contract_changed
        ? '<span class="badge badge-contract">contract changed</span>'
        : '<span class="badge badge-behaviour">reachable &mdash; contract unchanged</span>';

      const paths =
        ep.reached_from.length === 0
          ? '<p class="muted">Reached through the fingerprint diff rather than a call path.</p>'
          : `<ul class="paths">${ep.reached_from
              .map(
                (r) =>
                  `<li><span class="muted">depth ${r.depth}, from <code>${h(r.from_file)}</code>:</span><br>${callPath(r.call_path)}</li>`,
              )
              .join('')}</ul>`;

      const diff =
        impact.diff === null
          ? ''
          : `<p><strong>Contract diff</strong> (${h(impact.diff.change_kind)}): ${
              impact.diff.reasons.length === 0
                ? '<span class="muted">no field-level reason was derivable</span>'
                : impact.diff.reasons.map((r) => `<code>${h(r)}</code>`).join(', ')
            }</p>${
              impact.diff.details.length === 0
                ? ''
                : `<div class="scroll"><table><thead><tr><th>Field</th><th>Before</th><th>After</th></tr></thead><tbody>${impact.diff.details
                    .map(
                      (d) =>
                        `<tr><td><code>${h(d.field)}</code></td><td>${d.before === null ? '<span class="muted">absent</span>' : `<code>${h(d.before)}</code>`}</td><td>${d.after === null ? '<span class="muted">absent</span>' : `<code>${h(d.after)}</code>`}</td></tr>`,
                    )
                    .join('')}</tbody></table></div>`
            }`;

      const consumers = impact.consumers
        .map((c) => {
          if (!c.consumed) {
            return `<div class="consumer"><h5><code>${h(c.repo)}</code> <span class="badge badge-clear">not consumed</span></h5>
            <p class="muted">No phase-1 signal fired against this consumer's manifest${
              c.why_matched.length === 0 ? '' : ` (checked: ${h(c.why_matched.join(', '))})`
            }.</p></div>`;
          }
          const hits =
            c.call_sites.length === 0
              ? '<p class="muted">Consumed by signal, but no individual call site resolved.</p>'
              : `<div class="scroll"><table>
                <thead><tr><th>Call site</th><th>Location</th><th>Method</th><th>Matched via</th><th>Match confidence</th></tr></thead>
                <tbody>${c.call_sites
                  .map(
                    (hit) => `<tr>
                    <td><code>${h(hit.symbol)}</code></td>
                    <td><code>${h(hit.file)}:${hit.line}</code></td>
                    <td><code>${h(hit.method_name)}</code></td>
                    <td>${hit.matched_via.map((m) => `<code>${h(m)}</code>`).join('<br>')}</td>
                    <td>${confidenceCell(hit.match_confidence)}</td>
                  </tr>${
                    hit.unresolved.length === 0
                      ? ''
                      : `<tr class="sub"><td colspan="5"><span class="warn">unresolved:</span> ${hit.unresolved.map((u) => h(u)).join('; ')}</td></tr>`
                  }`,
                  )
                  .join('')}</tbody></table></div>`;
          const entries =
            c.entry_points.length === 0
              ? '<p class="muted">No entry point was reached within the depth limit.</p>'
              : `<p><strong>Surfaced by:</strong> ${c.entry_points
                  .map((e) => `<code>${h(e.symbol)}</code> <span class="muted">(${h(e.kind)})</span>`)
                  .join(', ')}</p>`;
          return `<div class="consumer"><h5><code>${h(c.repo)}</code> <span class="badge badge-hit">${c.call_sites.length} call site(s)</span></h5>${hits}${entries}</div>`;
        })
        .join('');

      return `<div class="endpoint">
      <h4><code>${h(ep.route)}</code> ${badge}</h4>
      <p class="muted">Handled by <code>${h(ep.handler)}</code> at <code>${h(ep.file)}:${ep.line}</code>${
        ep.request_dto === null ? '' : ` &middot; request <code>${h(ep.request_dto)}</code>`
      }${ep.response_dto === null ? '' : ` &middot; response <code>${h(ep.response_dto)}</code>`}</p>
      ${diff}
      <h5>Call paths from the change</h5>
      ${paths}
      <h5>Consumers</h5>
      ${impact.consumers.length === 0 ? '<p class="muted">No consumer repos were analysed.</p>' : consumers}
    </div>`;
    })
    .join('');

  return `<h3>Affected endpoints</h3>${blocks}`;
}

function limitsSection(evidence: Evidence): string {
  const l = evidence.analysis_limits;
  const items = [
    `Caller walk depth limit: ${l.max_depth}${l.depth_capped ? ' — REACHED, so callers beyond it were not explored' : ''}`,
    `Consumer repos analysed: ${l.consumers_analysed.length === 0 ? 'none configured' : l.consumers_analysed.join(', ')}`,
    `Baseline comparison: ${l.baseline_available ? 'available' : 'NOT available'} — ${l.baseline_note}`,
  ];
  return `<h3>Analysis limits</h3>${list(items, '')}
  ${
    l.callers_reaching_no_endpoint.length === 0
      ? ''
      : `<p><strong>Callers that reach no endpoint</strong> (internal-only paths):</p>${list(l.callers_reaching_no_endpoint, '')}`
  }`;
}

function unresolvedSection(evidence: Evidence): string {
  if (evidence.unresolved.length === 0) {
    return '<h3>Unresolved</h3><p class="muted">Everything in this analysis resolved cleanly.</p>';
  }
  const rows = evidence.unresolved
    .map(
      (u) => `<tr>
      <td><code>${h(u.what)}</code></td>
      <td><code>${h(u.file)}:${u.line}</code></td>
      <td>${u.enclosing_symbol === null ? '<span class="muted">—</span>' : `<code>${h(u.enclosing_symbol)}</code>`}</td>
      <td>${h(u.reason)}</td>
    </tr>`,
    )
    .join('');
  return `<h3>Unresolved</h3>
  <p>These are the blind spots. Anything above that depends on them is less certain than it reads.</p>
  <div class="scroll"><table>
    <thead><tr><th>What</th><th>Where</th><th>In</th><th>Reason</th></tr></thead>
    <tbody>${rows}</tbody>
  </table></div>`;
}

function truncationSection(evidence: Evidence): string {
  if (evidence.truncation.length === 0) {
    return '';
  }
  return `<h3>Truncated for size</h3>
  <p>The evidence given to the model was capped. These lists were shortened, so both the narrative and this appendix are samples rather than complete inventories:</p>
  ${list(evidence.truncation, '')}`;
}

/** The whole deterministic appendix. Exported so the sanity run can assert it. */
export function renderEvidenceAppendix(evidence: Evidence): string {
  return `<section class="appendix">
  <div class="appendix-banner">
    <strong>Evidence &mdash; machine-generated fact.</strong>
    Everything below is rendered directly from the static index by CodeIndex, not written by the
    language model. The narrative above is an AI interpretation of exactly these facts; where the two
    disagree, this section is the record.
  </div>
  <h2>Evidence</h2>
  <p class="muted">Producer <code>${h(evidence.producer_repo)}</code> &middot; ${h(evidence.comparison_basis)} &middot; generated ${h(evidence.analysed_at)}</p>
  ${changedFilesTable(evidence)}
  ${
    evidence.changed_files_feeding_no_endpoint.length === 0
      ? ''
      : `<h3>Changed files that feed no endpoint</h3>
         <p>These files were analysed and reach no indexed endpoint. They are not omissions.</p>
         ${list(evidence.changed_files_feeding_no_endpoint, '')}`
  }
  <h3>Changed symbols</h3>
  ${
    evidence.changed_symbols.length === 0
      ? '<p class="muted">No symbols were resolved.</p>'
      : `<div class="scroll"><table>
        <thead><tr><th>Symbol</th><th>Location</th><th>Entry point</th><th>How it was resolved</th></tr></thead>
        <tbody>${evidence.changed_symbols
          .map(
            (s) => `<tr>
            <td><code>${h(s.name)}</code></td>
            <td><code>${h(s.file)}:${s.line_start}${s.line_end !== s.line_start ? `-${s.line_end}` : ''}</code></td>
            <td>${s.is_entry_point ? `yes <span class="muted">(${h(s.entry_point_kind ?? '')})</span>` : 'no'}</td>
            <td class="reason">${h(s.how_resolved)}</td>
          </tr>`,
          )
          .join('')}</tbody>
      </table></div>`
  }
  ${endpointsSection(evidence)}
  ${
    evidence.downstream_calls.length === 0
      ? ''
      : `<h3>What the change calls downstream</h3>${list(
          evidence.downstream_calls.map(
            (d) => `${d.symbol} (depth ${d.depth}${d.file === null ? '' : `, ${d.file}:${d.line ?? 0}`})`,
          ),
          '',
        )}`
  }
  ${unresolvedSection(evidence)}
  ${limitsSection(evidence)}
  ${truncationSection(evidence)}
</section>`;
}

/* ---- styles ------------------------------------------------------- */

/**
 * Theme-neutral: light and dark are both defined against
 * `prefers-color-scheme`, and print gets its own high-contrast override so a
 * dark-mode reader does not print a black page.
 */
const STYLES = `
:root {
  --bg: #ffffff; --fg: #1b1f23; --muted: #5a6570; --rule: #d8dee4;
  --card: #f6f8fa; --accent: #0b62c4; --warn: #9a5b00; --danger: #b3261e;
  --code-bg: #eef1f4; --badge-fg: #ffffff;
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #14171a; --fg: #e6e9ec; --muted: #98a2ad; --rule: #2c3238;
    --card: #1c2126; --accent: #6cb0ff; --warn: #e0a458; --danger: #ff8a80;
    --code-bg: #23292f; --badge-fg: #10141a;
  }
}
* { box-sizing: border-box; }
body {
  margin: 0; padding: 2rem 1.25rem 4rem;
  background: var(--bg); color: var(--fg);
  font: 16px/1.65 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}
main { max-width: 60rem; margin: 0 auto; }
h1 { font-size: 1.6rem; line-height: 1.25; margin: 0 0 .35rem; }
h2 { font-size: 1.25rem; margin: 2.5rem 0 .75rem; padding-bottom: .3rem; border-bottom: 1px solid var(--rule); }
h3 { font-size: 1.05rem; margin: 1.75rem 0 .5rem; }
h4 { font-size: .98rem; margin: 1.25rem 0 .4rem; }
h5 { font-size: .88rem; margin: 1rem 0 .35rem; text-transform: uppercase; letter-spacing: .04em; color: var(--muted); }
p { margin: .6rem 0; }
ul, ol { margin: .6rem 0; padding-left: 1.4rem; }
li { margin: .3rem 0; }
code {
  font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  font-size: .875em; background: var(--code-bg); padding: .1em .35em; border-radius: 3px;
  overflow-wrap: anywhere;
}
.muted { color: var(--muted); }
.warn { color: var(--warn); font-weight: 600; }
.arrow { color: var(--muted); }
.subtitle { font-size: 1.02rem; color: var(--muted); margin: 0 0 .2rem; }
.basis { font-size: .9rem; color: var(--muted); margin: 0 0 1.5rem; }
.banner {
  border-left: 4px solid var(--warn); background: var(--card);
  padding: .85rem 1rem; margin: 1.25rem 0; border-radius: 0 4px 4px 0;
}
.banner.ok { border-left-color: var(--accent); }
.appendix-banner {
  border-left: 4px solid var(--accent); background: var(--card);
  padding: .85rem 1rem; margin: 2rem 0 1rem; border-radius: 0 4px 4px 0; font-size: .93rem;
}
.narrative section { margin: 0 0 1.5rem; }
.narrative section::before {
  content: attr(data-heading); display: block;
  font-size: 1.25rem; font-weight: 600; margin: 2.5rem 0 .75rem;
  padding-bottom: .3rem; border-bottom: 1px solid var(--rule);
}
.endpoint { border: 1px solid var(--rule); border-radius: 6px; padding: .5rem 1rem 1rem; margin: 1rem 0; }
.consumer { border-top: 1px dashed var(--rule); padding-top: .5rem; margin-top: .75rem; }
.badge {
  display: inline-block; font-size: .7rem; font-weight: 700; letter-spacing: .03em;
  text-transform: uppercase; padding: .15em .5em; border-radius: 10px; vertical-align: middle;
  color: var(--badge-fg); background: var(--muted);
}
.badge-contract { background: var(--danger); color: #fff; }
.badge-behaviour { background: var(--warn); color: #fff; }
.badge-hit { background: var(--accent); color: #fff; }
.badge-clear { background: var(--muted); }
.scroll { overflow-x: auto; max-width: 100%; margin: .6rem 0; }
table { border-collapse: collapse; width: 100%; font-size: .86rem; }
th, td { border: 1px solid var(--rule); padding: .35rem .55rem; text-align: left; vertical-align: top; }
th { background: var(--card); font-weight: 600; }
tr.sub td { background: var(--card); font-size: .82rem; }
td.reason { font-size: .82rem; color: var(--muted); }
.paths li { margin: .5rem 0; }
pre.fallback {
  background: var(--card); border: 1px solid var(--rule); border-radius: 4px;
  padding: 1rem; overflow-x: auto; font-size: .85rem; line-height: 1.55;
  white-space: pre-wrap; overflow-wrap: anywhere;
}
footer { margin-top: 3rem; padding-top: 1rem; border-top: 1px solid var(--rule); font-size: .82rem; color: var(--muted); }
@media print {
  :root {
    --bg: #fff; --fg: #000; --muted: #444; --rule: #999; --card: #f2f2f2;
    --accent: #003a75; --warn: #6b3f00; --danger: #8a0f0a; --code-bg: #f0f0f0;
  }
  body { padding: 0; font-size: 11pt; }
  .endpoint, .appendix-banner, .banner { break-inside: avoid; }
  h2, h3, h4 { break-after: avoid; }
  .scroll { overflow: visible; }
}
`;

/**
 * Wrap the narrative (or the fallback) plus the evidence appendix in a complete,
 * self-contained HTML document.
 *
 * Never throws.
 */
export function renderAnalysisReport(options: ReportRenderOptions): string {
  const {
    title,
    subtitle,
    comparisonBasis,
    generatedAt,
    narrativeHtml,
    fallbackText,
    fallbackReason,
    evidence,
    modelId,
    cspMeta,
    styleNonce,
  } = options;

  const usingFallback = narrativeHtml === null || narrativeHtml.trim() === '';

  const banner = usingFallback
    ? `<div class="banner">
        <p><strong>This is the deterministic fallback report. The AI narrative was not available.</strong></p>
        <p>${h(fallbackReason ?? 'No reason was recorded.')}</p>
        <p>Everything below was computed by CodeIndex's static analysis and is complete and accurate on its
        own terms &mdash; it is the same analysis the AI narrative would have been written from. What is
        missing is only the prose interpretation.</p>
      </div>`
    : `<div class="banner ok">
        <p><strong>The narrative below was written by a language model</strong>${
          modelId === null ? '' : ` (<code>${h(modelId)}</code>)`
        } from the evidence in the appendix, and may contain errors. The Evidence section is machine-generated
        and is the authoritative record.</p>
      </div>`;

  // Give each narrative section its heading via a data attribute, so headings
  // are OURS rather than the model's — it cannot retitle a section to hide
  // something, and a missing section is visible as a missing heading.
  const narrativeBody = usingFallback
    ? `<h2>Deterministic impact report</h2><pre class="fallback">${h(fallbackText ?? '(no fallback content was produced)')}</pre>`
    : withHeadings(narrativeHtml);

  const styleTag = styleNonce === undefined ? '<style>' : `<style nonce="${escapeAttribute(styleNonce)}">`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
${cspMeta ?? ''}
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${h(title)}</title>
${styleTag}${STYLES}</style>
</head>
<body>
<main>
  <h1>${h(title)}</h1>
  <p class="subtitle">${h(subtitle)}</p>
  <p class="basis">${h(comparisonBasis)} &middot; generated ${h(generatedAt)}</p>
  ${banner}
  <div class="narrative">${narrativeBody}</div>
  ${renderEvidenceAppendix(evidence)}
  <footer>
    Generated by CodeIndex. Match confidence describes how a call site was matched by static analysis,
    not how likely it is to break.
  </footer>
</main>
</body>
</html>`;
}

/**
 * Stamp our own heading onto each `<section data-part>` the model produced, and
 * note any required section it omitted rather than letting it vanish silently.
 */
function withHeadings(sanitizedHtml: string): string {
  let out = sanitizedHtml;
  for (const section of ANALYSIS_SECTIONS) {
    const title = ANALYSIS_SECTION_TITLES[section];
    out = out
      .split(`<section data-part="${section}">`)
      .join(`<section data-part="${section}" data-heading="${escapeAttribute(title)}">`);
  }
  return out;
}
