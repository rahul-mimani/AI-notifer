/**
 * "What have I changed, and what does it reach?"
 *
 * SAFETY CONSTRAINT — THE WHOLE REASON THIS FILE IS SHAPED LIKE THIS
 * ------------------------------------------------------------------
 * The user's uncommitted work is the most valuable thing on their disk and it
 * exists in exactly one place. This module therefore NEVER runs a command that
 * mutates the working tree or the index. No `git stash`, no `git checkout`, no
 * `git reset`, no `git clean` — not even transiently, not even wrapped in a
 * try/finally. A crash, a SIGKILL, or a laptop lid closing between the two
 * halves of a stash/pop would leave a stranger's uncommitted code stashed under
 * a name they never chose, and no report is worth that risk.
 *
 * To get a clean "before" tree we use `git worktree add --detach <tmp> HEAD`,
 * which materialises HEAD into a SEPARATE temporary directory and touches
 * nothing in the user's checkout. It is removed in a `finally`, and a leftover
 * directory from a previous crash is harmless — `git worktree prune` reaps it.
 *
 * Every git call is fail-open: unavailable git, a non-repo directory, a shallow
 * clone, a worktree that refuses to materialise — all of them return null or an
 * empty result with a `note` explaining the degradation, and the caller reports
 * impact without the HEAD comparison rather than aborting.
 *
 * vscode-free, so the sanity run drives it directly.
 */

import { execFileSync } from 'node:child_process';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';

import type { Endpoint, SymbolRecord } from '../types.js';
import type { Logger } from '../util/logger.js';
import { silentLogger } from '../util/logger.js';
import type { LoadedBundle } from '../store/reader.js';
import { haveGit } from '../coordinator/git.js';
import { routeOf } from './evidence.js';
import type { EvidenceChangedFile } from './evidence.js';
import type { AggregatedEndpoint } from './impact-graph.js';
import { symbolsInFile, shortSymbolName } from './symbol-at.js';

/** Prefix for the temporary HEAD checkouts, so a stray one is identifiable. */
export const WORKTREE_PREFIX = 'codeindex-head-';

const GIT_TIMEOUT_MS = 20_000;

export type ChangeStatus = 'modified' | 'untracked';

export interface LocalChange {
  /** Repo-relative, forward-slashed. */
  file: string;
  status: ChangeStatus;
}

export interface LocalChangesResult {
  /** False when git could not be used at all. */
  available: boolean;
  /** Short HEAD sha, when it could be read. */
  headSha: string | null;
  /** Relevant changed files, sorted. Empty is a valid, meaningful answer. */
  changes: LocalChange[];
  /** Every changed file git reported, before source-root filtering. */
  allChangedFiles: string[];
  /** Human-readable explanation, always populated. */
  note: string;
}

/* ------------------------------------------------------------------ *
 * git plumbing — read-only
 * ------------------------------------------------------------------ */

/**
 * Run a read-only git command. Returns null on any failure.
 *
 * The command allowlist is enforced by the call sites in this file, all of
 * which are `rev-parse`, `diff --name-only`, `ls-files`, or `worktree`.
 */
function git(repoRoot: string, args: readonly string[], logger: Logger): string | null {
  try {
    return execFileSync('git', [...args], {
      cwd: repoRoot,
      stdio: ['pipe', 'pipe', 'pipe'],
      encoding: 'utf8',
      timeout: GIT_TIMEOUT_MS,
      maxBuffer: 16 * 1024 * 1024,
    });
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('QUERY', `git ${args.join(' ')} failed in ${repoRoot}: ${detail}`);
    return null;
  }
}

/** Is `repoRoot` inside a git work tree? */
export function isGitRepo(repoRoot: string, logger: Logger = silentLogger): boolean {
  if (!haveGit(logger)) {
    return false;
  }
  return git(repoRoot, ['rev-parse', '--is-inside-work-tree'], logger)?.trim() === 'true';
}

/** Short HEAD sha, or null. */
export function headSha(repoRoot: string, logger: Logger = silentLogger): string | null {
  const out = git(repoRoot, ['rev-parse', '--short', 'HEAD'], logger);
  const sha = out?.trim() ?? '';
  return sha === '' ? null : sha;
}

function splitLines(output: string | null): string[] {
  if (output === null) {
    return [];
  }
  return output
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l !== '');
}

/* ------------------------------------------------------------------ *
 * relevance filter
 * ------------------------------------------------------------------ */

const CONFIG_EXTENSIONS = ['.properties', '.yml', '.yaml'];

/**
 * Is this changed file one the index could possibly care about?
 *
 * Java sources under a configured source root, plus property/YAML files
 * anywhere under a `resources` directory — those feed the property table, which
 * is how consumer URL matching resolves.
 */
export function isRelevantChange(file: string, sourceRoots: readonly string[]): boolean {
  const normalized = file.split('\\').join('/');
  if (normalized.endsWith('.java')) {
    if (sourceRoots.length === 0) {
      return true;
    }
    return sourceRoots.some((root) => {
      const clean = root.split('\\').join('/').replace(/\/+$/, '');
      return clean === '' || normalized === clean || normalized.startsWith(`${clean}/`);
    });
  }
  if (CONFIG_EXTENSIONS.some((ext) => normalized.endsWith(ext))) {
    return normalized.includes('/resources/') || normalized.startsWith('resources/');
  }
  return false;
}

/**
 * Changed files in the working tree, relative to HEAD.
 *
 * `git diff --name-only HEAD` covers tracked edits (staged and unstaged);
 * `git ls-files --others --exclude-standard` adds brand-new untracked files,
 * which the diff alone would miss. Both are read-only.
 *
 * Never throws.
 */
export function detectLocalChanges(
  repoRoot: string,
  sourceRoots: readonly string[],
  logger: Logger = silentLogger,
): LocalChangesResult {
  const empty = (note: string): LocalChangesResult => ({
    available: false,
    headSha: null,
    changes: [],
    allChangedFiles: [],
    note,
  });

  try {
    if (!haveGit(logger)) {
      return empty('git is not available on PATH, so local changes could not be determined.');
    }
    if (!isGitRepo(repoRoot, logger)) {
      return empty(`${repoRoot} is not inside a git work tree, so local changes could not be determined.`);
    }

    const sha = headSha(repoRoot, logger);
    const tracked = splitLines(git(repoRoot, ['diff', '--name-only', 'HEAD'], logger));
    const untracked = splitLines(git(repoRoot, ['ls-files', '--others', '--exclude-standard'], logger));

    const seen = new Set<string>();
    const changes: LocalChange[] = [];
    const all: string[] = [];

    for (const [files, status] of [
      [tracked, 'modified'],
      [untracked, 'untracked'],
    ] as Array<[string[], ChangeStatus]>) {
      for (const raw of files) {
        const file = raw.split('\\').join('/');
        if (seen.has(file)) {
          continue;
        }
        seen.add(file);
        all.push(file);
        if (isRelevantChange(file, sourceRoots)) {
          changes.push({ file, status });
        }
      }
    }

    changes.sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : 0));
    all.sort();

    const note =
      changes.length === 0
        ? all.length === 0
          ? `No uncommitted changes against HEAD${sha === null ? '' : ` (${sha})`}.`
          : `${all.length} file(s) changed against HEAD${sha === null ? '' : ` (${sha})`}, but none of them is an indexed Java source or resource file.`
        : `${changes.length} indexable file(s) changed against HEAD${sha === null ? '' : ` (${sha})`}.`;

    logger.log('QUERY', `detectLocalChanges(${repoRoot}): ${note}`);
    return { available: true, headSha: sha, changes, allChangedFiles: all, note };
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return empty(`Local change detection failed: ${detail}`);
  }
}

/* ------------------------------------------------------------------ *
 * the HEAD worktree
 * ------------------------------------------------------------------ */

export interface HeadWorktree {
  /** Absolute path of the clean HEAD checkout, or null when unavailable. */
  path: string | null;
  /** Why it is null, when it is. */
  note: string;
}

/**
 * Materialise HEAD into a temporary directory, run `body` against it, and remove
 * it — ALWAYS, including when `body` throws.
 *
 * `body` receives null when the worktree could not be created, and must degrade
 * to an analysis without the HEAD comparison rather than failing.
 *
 * NOTE ON WHAT IS NOT HERE: there is no stash, no checkout, no reset and no
 * clean, by design. See the header of this file.
 */
export async function withHeadWorktree<T>(
  repoRoot: string,
  logger: Logger,
  body: (worktree: HeadWorktree) => Promise<T>,
): Promise<T> {
  let created: string | null = null;
  let note = '';

  try {
    if (!haveGit(logger)) {
      note = 'git is not available on PATH, so a clean HEAD checkout could not be created.';
    } else if (!isGitRepo(repoRoot, logger)) {
      note = `${repoRoot} is not a git work tree, so a clean HEAD checkout could not be created.`;
    } else {
      const dir = fs.mkdtempSync(path.join(os.tmpdir(), WORKTREE_PREFIX));
      // `git worktree add` accepts an existing EMPTY directory, which is what
      // mkdtemp just produced. --detach avoids creating or moving any branch.
      const added = git(repoRoot, ['worktree', 'add', '--detach', dir, 'HEAD'], logger);
      if (added === null) {
        note =
          'git refused to create a temporary HEAD worktree (a shallow clone, a bare repo, or an ' +
          'unborn HEAD will all do this), so this report has no "before" state to compare against.';
        try {
          fs.rmSync(dir, { recursive: true, force: true });
        } catch {
          /* the directory is empty and in the OS temp dir; leaking it is harmless */
        }
      } else {
        created = dir;
        logger.log('QUERY', `created temporary HEAD worktree at ${dir}`);
      }
    }

    return await body({ path: created, note });
  } finally {
    if (created !== null) {
      // `worktree remove` deletes the temp checkout and its admin entry. It
      // operates only on the temp directory — the user's tree is untouched.
      const removed = git(repoRoot, ['worktree', 'remove', '--force', created], logger);
      if (removed === null) {
        logger.log('QUERY', `git worktree remove failed for ${created} — removing the directory directly`);
      }
      try {
        fs.rmSync(created, { recursive: true, force: true });
      } catch (err) {
        const detail = err instanceof Error ? err.message : String(err);
        logger.log('QUERY', `could not delete ${created}: ${detail}`);
      }
      // Reap the admin entry if `remove` did not.
      git(repoRoot, ['worktree', 'prune'], logger);
      logger.log('QUERY', `removed temporary HEAD worktree ${created}`);
    }
  }
}

/* ------------------------------------------------------------------ *
 * changed file -> symbols -> endpoints
 * ------------------------------------------------------------------ */

/**
 * Symbols declared in each changed file.
 *
 * A file with no entry in the map declares nothing the index knows about —
 * a new file that has not been indexed yet, a test, or a class filtered out by
 * the package prefixes. The caller reports those explicitly.
 */
export function symbolsForChangedFiles(
  bundle: LoadedBundle,
  changes: readonly LocalChange[],
): Map<string, SymbolRecord[]> {
  const out = new Map<string, SymbolRecord[]>();
  for (const change of changes) {
    const symbols = symbolsInFile(bundle, change.file);
    out.set(
      change.file,
      symbols.filter((s) => s.symbol_kind === 'method'),
    );
  }
  return out;
}

/**
 * The deterministic changed-file summary that goes into the evidence packet and
 * the HTML appendix.
 *
 * A file that feeds nothing gets an empty `feeds_endpoints`, which the renderer
 * shows as an explicit "feeds no indexed endpoint" — never a silent omission.
 */
export function summarizeChangedFiles(
  changes: readonly LocalChange[],
  symbolsByFile: ReadonlyMap<string, SymbolRecord[]>,
  affected: readonly AggregatedEndpoint[],
): EvidenceChangedFile[] {
  const routesByFile = new Map<string, Set<string>>();
  for (const entry of affected) {
    for (const reached of entry.reachedFrom) {
      const set = routesByFile.get(reached.file) ?? new Set<string>();
      set.add(routeOf(entry.endpoint));
      routesByFile.set(reached.file, set);
    }
  }

  return changes.map((change) => ({
    file: change.file,
    status: change.status,
    symbols: (symbolsByFile.get(change.file) ?? []).map((s) => shortSymbolName(s.id)),
    feeds_endpoints: [...(routesByFile.get(change.file) ?? new Set<string>())].sort(),
  }));
}

/* ------------------------------------------------------------------ *
 * the endpoint picker
 * ------------------------------------------------------------------ */

/** Sentinel id for the "every affected endpoint" option. */
export const ALL_ENDPOINTS = '__codeindex_all_endpoints__';

export interface EndpointPickOption {
  /** `ALL_ENDPOINTS`, or a real endpoint id. */
  id: string;
  label: string;
  detail: string;
  contractChanged: boolean;
  /** True when this option should be pre-selected. */
  picked: boolean;
}

/**
 * Build the QuickPick rows.
 *
 * The detail line answers the one question that decides what the reader does
 * next: did the CONTRACT move (consumers break), or is this endpoint merely
 * reachable from something you edited (consumers see different behaviour
 * through an unchanged interface)?
 */
export function buildEndpointPickOptions(
  affected: readonly AggregatedEndpoint[],
  opts: { defaultEndpointId?: string | null } = {},
): EndpointPickOption[] {
  const contractCount = affected.filter((a) => a.contractChanged).length;
  const reachableCount = affected.length - contractCount;
  const defaultId = opts.defaultEndpointId ?? null;

  const all: EndpointPickOption = {
    id: ALL_ENDPOINTS,
    label: '$(list-tree) All affected endpoints',
    detail:
      `One report covering all ${affected.length} endpoint(s) — ` +
      `${contractCount} with a changed contract, ${reachableCount} reachable but contract-unchanged`,
    contractChanged: contractCount > 0,
    picked: defaultId === null,
  };

  const rows = affected.map((entry) => {
    const files = [...new Set(entry.reachedFrom.map((r) => r.file))].sort();
    const from =
      files.length === 0
        ? 'reached via the fingerprint diff'
        : `reached from ${files.map((f) => f.split('/').pop() ?? f).join(', ')}`;
    const reasons =
      entry.changed === null || entry.changed.diff_reason.length === 0
        ? ''
        : ` (${entry.changed.diff_reason.join(', ')})`;
    return {
      id: entry.endpoint.id,
      label: `${entry.contractChanged ? '$(warning)' : '$(circle-outline)'} ${routeOf(entry.endpoint)}`,
      detail: `${
        entry.contractChanged
          ? `CONTRACT CHANGED${reasons} — consumers can break on the call itself`
          : 'Contract unchanged — reachable from a changed internal method, so behaviour may differ'
      } · ${from}`,
      contractChanged: entry.contractChanged,
      picked: defaultId !== null && entry.endpoint.id === defaultId,
    };
  });

  return [all, ...rows];
}

/** Endpoints reachable from a set of walks, as a lookup for the picker default. */
export function endpointIdAt(
  bundle: LoadedBundle,
  file: string,
  line: number,
  endpoints: readonly Endpoint[],
): string | null {
  void bundle;
  const normalized = file.split('\\').join('/');
  let best: Endpoint | null = null;
  for (const ep of endpoints) {
    const epFile = ep.file.split('\\').join('/');
    if (!(normalized.endsWith(epFile) || epFile.endsWith(normalized))) {
      continue;
    }
    if (ep.line <= line && (best === null || ep.line > best.line)) {
      best = ep;
    }
  }
  return best?.id ?? null;
}
