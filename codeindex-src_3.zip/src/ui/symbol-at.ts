/**
 * "What method is the cursor in?"
 *
 * The blast-radius commands resolve an ENDPOINT at the cursor (`getEndpointAt`).
 * This resolves a SYMBOL — any method, including a private helper five frames
 * below a controller — which is what `analyzeImpact` starts from.
 *
 * RESOLUTION ORDER, and why it is not just "line_start <= line <= line_end":
 * the LM extractor reports a method's DECLARATION line, so in practice most
 * symbol records carry `line_start === line_end`. A cursor parked on line 36 of
 * a method declared on line 34 would match nothing under a strict containment
 * test. So:
 *
 *   1. `enclosing_method`  — the innermost method whose range contains the line.
 *                            "Innermost" = the latest `line_start`, which is the
 *                            deepest declaration at that point.
 *   2. `preceding_method`  — the nearest method declared AT OR BEFORE the line,
 *                            bounded by the enclosing class so the cursor cannot
 *                            fall through into the previous class's last method.
 *   3. `enclosing_class`   — the class/interface itself, when the cursor is in a
 *                            field block, an import, or the type declaration.
 *
 * Every failure returns a `reason` a human can act on, never a bare null.
 *
 * Pure and vscode-free.
 */

import type { IndexRecord, SymbolRecord } from '../types.js';
import type { LoadedBundle } from '../store/reader.js';

export type SymbolMatchKind = 'enclosing_method' | 'preceding_method' | 'enclosing_class';

export interface SymbolAtCursor {
  /** The resolved symbol, or null when nothing could be attributed. */
  symbol: SymbolRecord | null;
  /** How it was resolved. Null when `symbol` is null. */
  match: SymbolMatchKind | null;
  /** Always populated — the explanation, whether it succeeded or not. */
  reason: string;
  /** The class record enclosing `symbol`, when one is indexed. */
  enclosingClass: SymbolRecord | null;
}

/**
 * How to name a symbol in a `reason` string.
 *
 * A method record's `fqn` is its DECLARING CLASS, not the method — so using
 * `fqn` alone produces "attributed to com.acme.Foo", which reads as though the
 * class was selected. Methods are named `Class.method`; types keep their fqn.
 */
function describeSymbol(symbol: SymbolRecord): string {
  return symbol.symbol_kind === 'method' ? shortSymbolName(symbol.id) : symbol.fqn;
}

/** Normalize a path for comparison: forward slashes, no leading separators. */
function normalizePath(file: string): string {
  return file.split('\\').join('/').replace(/^\/+/, '');
}

/**
 * Symbol records declared in `file`.
 *
 * Tolerates an absolute path being handed to a repo-relative index (and the
 * reverse) via a suffix match, the same way `getEndpointAt` does — the caller is
 * an editor, and editors deal in absolute paths.
 */
export function symbolsInFile(bundle: LoadedBundle, file: string): SymbolRecord[] {
  const wanted = normalizePath(file);
  const direct = bundle.recordsByFile.get(file) ?? bundle.recordsByFile.get(wanted);
  if (direct !== undefined) {
    return onlySymbols(direct);
  }
  for (const [key, records] of bundle.recordsByFile) {
    const candidate = normalizePath(key);
    if (wanted.endsWith(`/${candidate}`) || candidate.endsWith(`/${wanted}`) || candidate === wanted) {
      return onlySymbols(records);
    }
  }
  return [];
}

function onlySymbols(records: readonly IndexRecord[]): SymbolRecord[] {
  const out: SymbolRecord[] = [];
  for (const rec of records) {
    if (rec.kind === 'symbol') {
      out.push(rec);
    }
  }
  return out;
}

/** The class/interface record whose fqn matches `symbol.enclosing_class`. */
export function enclosingClassOf(
  bundle: LoadedBundle,
  symbol: SymbolRecord | null,
): SymbolRecord | null {
  if (symbol === null || symbol.enclosing_class === null || symbol.enclosing_class === '') {
    return null;
  }
  for (const rec of bundle.byKind.symbol as SymbolRecord[]) {
    if (
      (rec.symbol_kind === 'class' || rec.symbol_kind === 'interface') &&
      rec.fqn === symbol.enclosing_class
    ) {
      return rec;
    }
  }
  return null;
}

/**
 * Resolve the method (or failing that, the type) at `file:line`.
 *
 * `line` is 1-BASED, matching the store's convention and `getEndpointAt`.
 * Never throws.
 */
export function symbolAtCursor(
  bundle: LoadedBundle,
  file: string,
  line: number,
): SymbolAtCursor {
  const miss = (reason: string): SymbolAtCursor => ({
    symbol: null,
    match: null,
    reason,
    enclosingClass: null,
  });

  try {
    if (!Number.isFinite(line) || line < 1) {
      return miss(`line ${String(line)} is not a valid 1-based source line`);
    }

    const symbols = symbolsInFile(bundle, file);
    if (symbols.length === 0) {
      return miss(
        `no indexed symbols in "${file}" — the file may be outside the configured source roots, ` +
          'or the index may predate it. Rebuild the index for this repo.',
      );
    }

    const methods = symbols.filter((s) => s.symbol_kind === 'method');
    const types = symbols.filter((s) => s.symbol_kind === 'class' || s.symbol_kind === 'interface');

    /* ---- 1. innermost enclosing method ------------------------------- */
    let enclosing: SymbolRecord | null = null;
    for (const m of methods) {
      if (m.line_start <= line && line <= m.line_end) {
        if (enclosing === null || m.line_start > enclosing.line_start) {
          enclosing = m;
        }
      }
    }
    if (enclosing !== null) {
      return {
        symbol: enclosing,
        match: 'enclosing_method',
        reason: `line ${line} is inside ${describeSymbol(enclosing)} (lines ${enclosing.line_start}-${enclosing.line_end})`,
        enclosingClass: enclosingClassOf(bundle, enclosing),
      };
    }

    /* ---- 2. nearest preceding method, bounded by its class ----------- */
    // The index usually records only the declaration line, so a cursor in a
    // method BODY lands here rather than in branch 1. Bounding by the enclosing
    // class stops a cursor in whitespace after a type from attaching to the
    // previous type's last method.
    let preceding: SymbolRecord | null = null;
    for (const m of methods) {
      if (m.line_start <= line && (preceding === null || m.line_start > preceding.line_start)) {
        preceding = m;
      }
    }
    if (preceding !== null) {
      const owner = enclosingClassOf(bundle, preceding);
      // The class bound only applies when the class record carries a REAL range.
      // The LM extractor commonly reports `line_start === line_end` (the
      // declaration line only), and treating that as the class's extent would
      // reject every cursor position below the `class` keyword — which is to
      // say, all of them.
      const ownerBounded = owner !== null && owner.line_end > owner.line_start;
      const withinOwner = !ownerBounded || line <= owner.line_end;
      if (withinOwner) {
        return {
          symbol: preceding,
          match: 'preceding_method',
          reason:
            `line ${line} has no method whose recorded range covers it; attributed to the nearest ` +
            `preceding declaration ${describeSymbol(preceding)} at line ${preceding.line_start}. The index records ` +
            'declaration lines rather than full bodies, so this is the normal case for a cursor inside a method.',
          enclosingClass: owner,
        };
      }
    }

    /* ---- 3. enclosing type ------------------------------------------- */
    let type: SymbolRecord | null = null;
    for (const t of types) {
      // Same reasoning as above: a degenerate range means "unknown extent",
      // not "one line long".
      const bounded = t.line_end > t.line_start;
      if (t.line_start <= line && (!bounded || line <= t.line_end)) {
        if (type === null || t.line_start > type.line_start) {
          type = t;
        }
      }
    }
    if (type !== null) {
      return {
        symbol: type,
        match: 'enclosing_class',
        reason:
          `line ${line} is not inside or after any indexed method; attributed to the enclosing ` +
          `${type.symbol_kind} ${describeSymbol(type)}. Place the cursor on a method to analyse a specific change.`,
        enclosingClass: type,
      };
    }

    return miss(
      `"${file}" has ${methods.length} indexed method(s) and ${types.length} indexed type(s), ` +
        `but none of them covers or precedes line ${line}.`,
    );
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return miss(`symbol resolution failed: ${detail}`);
  }
}

/** `Class.method` — full symbol ids are unreadable in prose. */
export function shortSymbolName(id: string): string {
  const afterRepo = id.includes(':') ? id.slice(id.indexOf(':') + 1) : id;
  const hash = afterRepo.indexOf('#');
  const type = hash < 0 ? afterRepo : afterRepo.slice(0, hash);
  const cls = type.split('.').pop() ?? type;
  if (hash < 0) {
    return cls;
  }
  const method = afterRepo.slice(hash + 1);
  const paren = method.indexOf('(');
  return `${cls}.${paren < 0 ? method : method.slice(0, paren)}`;
}
