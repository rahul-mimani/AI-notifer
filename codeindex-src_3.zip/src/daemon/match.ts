/**
 * Cross-repo matching: the two-phase consumer join.
 *
 * PHASE 1 — `isConsumed`: a cheap gate answered purely from the consumer's
 * `consumption_manifest.json`. Pure set membership, no scanning of records. Its
 * job is to let the daemon skip Phase 2 entirely for repos that provably cannot
 * be talking to this endpoint.
 *
 * PHASE 2 — `findInvocations`: the real join, scanning only the surviving
 * consumers' invocation records and attaching a weighted confidence per signal.
 *
 * THE UNRESOLVED-PLACEHOLDER RULE (load-bearing)
 * ---------------------------------------------
 * An unresolved placeholder string such as `${services.cdu.base-url}` or
 * `${vault:secret/pou#cdu-api-key}` is ITSELF a valid join token. Two things
 * wired to the same unresolved placeholder must match each other, so unresolved
 * values are never skipped or blanked anywhere in this module.
 *
 * STRUCTURAL PATH MATCHING
 * ------------------------
 * Path fragments are compared through `collapsePathParams`, never by raw string
 * equality, so `/api/v1/customers/{id}` matches `/api/v1/customers/{customerId}`.
 *
 * Fail-open: every exported function catches, logs and returns a partial result.
 */
import type {
  ChangedEndpoint,
  ConsumptionManifest,
  DtoRecord,
  Endpoint,
  EntryPointRecord,
  InvocationHit,
  InvocationRecord,
  MatchSignal,
  PropertyRecord,
  UnresolvedRecord,
  WiringRecord,
} from '../types.js';
import type { Logger } from '../util/logger.js';
import { silentLogger } from '../util/logger.js';
import { collapsePathParams, normalizePathTemplate } from '../extractor/paths.js';
import type { LoadedBundle } from '../store/reader.js';
import type { ForwardIndex } from './forward.js';

/* ------------------------------------------------------------------ *
 * Signal weights — EXACTLY per spec.
 * ------------------------------------------------------------------ */

export const SIGNAL_WEIGHTS = {
  dto_shape: 0.95,
  dto_fqn: 0.95,
  destination: 0.9,
  logical_name: 0.85,
  property_value: 0.8,
  wired_bean: 0.75,
} as const;

/* ------------------------------------------------------------------ *
 * Pre-built per-bundle lookup maps
 * ------------------------------------------------------------------ */

/**
 * Every map a query needs, built ONCE when a bundle is loaded so that queries
 * are map lookups rather than scans. Built by `buildBundleIndex`; the daemon
 * registry holds one per repo.
 */
export interface BundleIndex {
  dtosByShape: Map<string, DtoRecord[]>;
  dtosByFqn: Map<string, DtoRecord>;
  invocations: InvocationRecord[];
  invocationsById: Map<string, InvocationRecord>;
  invocationsByFile: Map<string, InvocationRecord[]>;
  endpointsByFile: Map<string, Endpoint[]>;
  endpointsByDestination: Map<string, Endpoint[]>;
  endpointsByHandler: Map<string, Endpoint[]>;
  entryPointsBySymbol: Map<string, EntryPointRecord>;
  wirings: WiringRecord[];
  wiringsByPropertyKey: Map<string, WiringRecord[]>;
  wiringsByBean: Map<string, WiringRecord[]>;
  properties: PropertyRecord[];
  unresolved: UnresolvedRecord[];
  /** unresolved records keyed by `partial_info.invocation_id`. */
  unresolvedByInvocation: Map<string, UnresolvedRecord[]>;
  /** unresolved property_value records keyed by `partial_info.key`. */
  unresolvedByPropertyKey: Map<string, UnresolvedRecord[]>;
  manifest: ManifestIndex;
}

/** Set-based view of a `ConsumptionManifest`. Phase 1 reads only this. */
export interface ManifestIndex {
  dtoShapes: Set<string>;
  dtoFqns: Set<string>;
  pathFragments: Set<string>;
  /** `path_fragments`, each passed through `collapsePathParams`. */
  collapsedFragments: Set<string>;
  destinations: Set<string>;
  logicalNames: Set<string>;
  propertyKeys: Set<string>;
  unresolvedPlaceholders: Set<string>;
  /** Raw inverted index, verbatim from the manifest. */
  fragmentToPropertyKeys: Map<string, string[]>;
  /** The same index keyed by the COLLAPSED fragment (structural matching). */
  collapsedFragmentToPropertyKeys: Map<string, string[]>;
}

/**
 * Memoized manifest indexes. `isConsumed` takes a plain `ConsumptionManifest`
 * per its contract, so the set-building cost is paid once per manifest object
 * rather than once per call — which is what keeps Phase 1 O(1)-ish even when a
 * caller does not go through the registry.
 */
const MANIFEST_CACHE = new WeakMap<ConsumptionManifest, ManifestIndex>();

function addKeys(map: Map<string, string[]>, key: string, keys: readonly string[]): void {
  const existing = map.get(key);
  if (existing) {
    const merged = new Set([...existing, ...keys]);
    map.set(key, [...merged].sort());
  } else {
    map.set(key, [...new Set(keys)].sort());
  }
}

/** Build (or return the cached) set view of a manifest. Never throws. */
export function manifestIndex(manifest: ConsumptionManifest): ManifestIndex {
  const cached = MANIFEST_CACHE.get(manifest);
  if (cached) {
    return cached;
  }

  const fragments: string[] = Array.isArray(manifest?.path_fragments) ? manifest.path_fragments : [];
  const rawIndex: Record<string, string[]> =
    manifest?.path_fragment_to_property_keys !== null &&
    typeof manifest?.path_fragment_to_property_keys === 'object'
      ? manifest.path_fragment_to_property_keys
      : {};

  const fragmentToPropertyKeys = new Map<string, string[]>();
  const collapsedFragmentToPropertyKeys = new Map<string, string[]>();
  for (const frag of Object.keys(rawIndex).sort()) {
    const keys = Array.isArray(rawIndex[frag]) ? rawIndex[frag]! : [];
    addKeys(fragmentToPropertyKeys, frag, keys);
    // An UNRESOLVED placeholder is a join token in its own right: index it under
    // its verbatim text as well as its collapsed form.
    addKeys(collapsedFragmentToPropertyKeys, collapseToken(frag), keys);
    addKeys(collapsedFragmentToPropertyKeys, frag, keys);
  }

  // NOTE: the fragment set is stored as-is. Suffix handling is a DIRECTED test
  // (`pathTargetsEndpoint`) applied at match time, not a widening of this set —
  // widening it made unrelated endpoints share tokens and produced false
  // "consumed" verdicts.
  const index: ManifestIndex = {
    dtoShapes: new Set(manifest?.dto_shapes ?? []),
    dtoFqns: new Set(manifest?.dto_fqns ?? []),
    pathFragments: new Set(fragments),
    collapsedFragments: new Set(fragments.map(collapseToken)),
    destinations: new Set(manifest?.destinations ?? []),
    logicalNames: new Set(manifest?.logical_names ?? []),
    propertyKeys: new Set(manifest?.property_keys ?? []),
    unresolvedPlaceholders: new Set(manifest?.unresolved_placeholders ?? []),
    fragmentToPropertyKeys,
    collapsedFragmentToPropertyKeys,
  };
  MANIFEST_CACHE.set(manifest, index);
  return index;
}

/**
 * Structural form of a join token.
 *
 * Path-like tokens collapse their parameters (`/x/{id}` -> `/x/{}`); anything
 * that is not path-like — notably a bare `${...}` placeholder — is returned
 * verbatim so unresolved placeholders stay joinable.
 */
export function collapseToken(token: string): string {
  if (typeof token !== 'string' || token === '') {
    return '';
  }
  if (!token.includes('/')) {
    return token;
  }
  if (token.startsWith('${')) {
    return token;
  }
  try {
    return collapsePathParams(token);
  } catch {
    return token;
  }
}

/**
 * Does a consumer-side path fragment actually target this endpoint?
 *
 * DIRECTED, and deliberately strict. The consumer's URL is
 * `<host><context-path><endpoint-path>`, so the endpoint path must appear as a
 * SUFFIX of the consumer fragment — `/cdu/tag` targets `/tag`.
 *
 * What this rules out is the previous behaviour: both sides used to be expanded
 * into cumulative PREFIXES and any overlap counted as a match, so `/api/health`
 * and `/api/v1/orders` "matched" every consumer that called anything under
 * `/api`. A shared prefix is not evidence of consumption; only the full
 * endpoint path is.
 *
 * The endpoint path must contain at least one literal segment — a collapsed
 * `/{}` would otherwise match nearly everything.
 */
function pathTargetsEndpoint(endpointPath: string, consumerFragment: string): boolean {
  if (endpointPath === '' || consumerFragment === '') {
    return false;
  }
  if (endpointPath.startsWith('${') || consumerFragment.startsWith('${')) {
    // Unresolved placeholders join by exact identity, handled by the caller.
    return endpointPath === consumerFragment;
  }
  const e = collapsePathParams(normalizePathTemplate(endpointPath));
  const c = collapsePathParams(normalizePathTemplate(consumerFragment));
  if (e === '' || e === '/') {
    return false;
  }
  const literal = e.split('/').filter((s) => s !== '' && s !== '{}' && s !== '*' && s !== '**');
  if (literal.length === 0) {
    return false;
  }
  if (c === e) {
    return true;
  }
  // `e` begins with '/', so endsWith already implies a segment boundary:
  // '/mytag'.endsWith('/tag') is false, '/cdu/tag'.endsWith('/tag') is true.
  return c.endsWith(e);
}

/** The endpoint's full path forms — NOT prefixes. Used with the directed test. */
function endpointPathForms(
  changed: ChangedEndpoint,
  endpoint: Endpoint | null | undefined,
): string[] {
  const out = new Set<string>();
  for (const t of [
    changed.path_template,
    endpoint?.path_template ?? null,
    endpoint?.path_template_normalized ?? null,
  ]) {
    if (t !== null && t !== undefined && t !== '') {
      out.add(t);
      out.add(collapsePathParams(normalizePathTemplate(t)));
    }
  }
  return [...out].filter((f) => f !== '').sort();
}

/** Cumulative literal prefixes plus the whole token, all collapsed. */
function fragmentForms(token: string | null | undefined): string[] {
  if (token === null || token === undefined || token === '') {
    return [];
  }
  const out = new Set<string>([token, collapseToken(token)]);
  if (token.includes('/') && !token.startsWith('${')) {
    const normalized = normalizePathTemplate(token);
    out.add(normalized);
    out.add(collapsePathParams(normalized));
    let cur = '';
    for (const seg of collapsePathParams(normalized).split('/')) {
      if (seg === '') {
        continue;
      }
      cur = `${cur}/${seg}`;
      out.add(cur);
    }
  }
  return [...out].filter((f) => f !== '').sort();
}

function pushMap<T>(map: Map<string, T[]>, key: string, value: T): void {
  if (key === '') {
    return;
  }
  const list = map.get(key);
  if (list) {
    list.push(value);
  } else {
    map.set(key, [value]);
  }
}

function byLine(a: { line: number }, b: { line: number }): number {
  return a.line - b.line;
}

/** Build every per-bundle lookup map. Pure, deterministic, never throws. */
export function buildBundleIndex(bundle: LoadedBundle, logger: Logger = silentLogger): BundleIndex {
  const dtosByShape = new Map<string, DtoRecord[]>();
  const dtosByFqn = new Map<string, DtoRecord>();
  const invocations: InvocationRecord[] = [];
  const invocationsById = new Map<string, InvocationRecord>();
  const invocationsByFile = new Map<string, InvocationRecord[]>();
  const endpointsByFile = new Map<string, Endpoint[]>();
  const endpointsByDestination = new Map<string, Endpoint[]>();
  const endpointsByHandler = new Map<string, Endpoint[]>();
  const entryPointsBySymbol = new Map<string, EntryPointRecord>();
  const wirings: WiringRecord[] = [];
  const wiringsByPropertyKey = new Map<string, WiringRecord[]>();
  const wiringsByBean = new Map<string, WiringRecord[]>();
  const properties: PropertyRecord[] = [];
  const unresolved: UnresolvedRecord[] = [];
  const unresolvedByInvocation = new Map<string, UnresolvedRecord[]>();
  const unresolvedByPropertyKey = new Map<string, UnresolvedRecord[]>();

  try {
    for (const rec of bundle.byKind.dto as DtoRecord[]) {
      pushMap(dtosByShape, rec.shape, rec);
      if (!dtosByFqn.has(rec.fqn)) {
        dtosByFqn.set(rec.fqn, rec);
      }
    }
    for (const rec of bundle.byKind.invocation as InvocationRecord[]) {
      invocations.push(rec);
      invocationsById.set(rec.id, rec);
      pushMap(invocationsByFile, rec.file, rec);
    }
    for (const rec of bundle.byKind.entry_point as EntryPointRecord[]) {
      entryPointsBySymbol.set(rec.symbol, rec);
    }
    for (const rec of bundle.byKind.wiring as WiringRecord[]) {
      wirings.push(rec);
      pushMap(wiringsByPropertyKey, rec.property_key, rec);
      pushMap(wiringsByBean, rec.bean, rec);
    }
    for (const rec of bundle.byKind.property as PropertyRecord[]) {
      properties.push(rec);
    }
    for (const rec of bundle.byKind.unresolved as UnresolvedRecord[]) {
      unresolved.push(rec);
      const invId = rec.partial_info?.['invocation_id'];
      if (typeof invId === 'string') {
        pushMap(unresolvedByInvocation, invId, rec);
      }
      const key = rec.partial_info?.['key'];
      if (rec.what === 'property_value' && typeof key === 'string') {
        pushMap(unresolvedByPropertyKey, key, rec);
      }
    }
    for (const ep of bundle.endpoints) {
      pushMap(endpointsByFile, ep.file, ep);
      pushMap(endpointsByHandler, ep.handler_symbol, ep);
      if (ep.destination !== null) {
        pushMap(endpointsByDestination, ep.destination, ep);
      }
    }

    for (const list of invocationsByFile.values()) {
      list.sort(byLine);
    }
    for (const list of endpointsByFile.values()) {
      list.sort(byLine);
    }
    invocations.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('DAEMON', `ERROR building bundle index: ${detail} — continuing with partial maps`);
  }

  return {
    dtosByShape,
    dtosByFqn,
    invocations,
    invocationsById,
    invocationsByFile,
    endpointsByFile,
    endpointsByDestination,
    endpointsByHandler,
    entryPointsBySymbol,
    wirings,
    wiringsByPropertyKey,
    wiringsByBean,
    properties,
    unresolved,
    unresolvedByInvocation,
    unresolvedByPropertyKey,
    manifest: manifestIndex(bundle.manifest),
  };
}

/**
 * One loaded repo, as the query functions see it. `IndexRegistry` entries are
 * structurally assignable to this, which keeps `blast.ts` free of any import
 * from `daemon.ts` (and therefore free of an import cycle).
 */
export interface QueryRepo {
  repo: string;
  repoRoot: string;
  bundle: LoadedBundle;
  index: BundleIndex;
  forward: ForwardIndex;
}

/* ------------------------------------------------------------------ *
 * PHASE 1 — isConsumed
 * ------------------------------------------------------------------ */

/** Extra producer-side facts a `ChangedEndpoint` does not carry. */
export interface MatchContext {
  /**
   * The producer `Endpoint` the change refers to. `ChangedEndpoint` has no DTO
   * shape / FQN / logical-name fields, so without this only the destination and
   * path-fragment signals can fire.
   */
  producerEndpoint?: Endpoint | null;
  logger?: Logger;
}

export interface ConsumedResult {
  consumed: boolean;
  signals: string[];
}

/** Every join token the changed endpoint contributes on the path axis. */
function endpointFragments(
  changed: ChangedEndpoint,
  endpoint: Endpoint | null | undefined,
): string[] {
  const out = new Set<string>();
  for (const token of [
    changed.path_template,
    endpoint?.path_template ?? null,
    endpoint?.path_template_normalized ?? null,
  ]) {
    for (const form of fragmentForms(token)) {
      out.add(form);
    }
  }
  return [...out].sort();
}

/**
 * Phase-1 consumption gate. Pure set lookups against the manifest — no record
 * scanning, no callgraph, no I/O.
 *
 * Signals are reported with the value that fired so a "why did this repo
 * survive?" question is answerable from the result alone:
 *   `dto_shape:request` / `dto_shape:response`, `dto_fqn:<fqn>`,
 *   `destination:<dest>`, `logical_name:<name>`, `path_fragment:<fragment>`.
 */
export function isConsumed(
  changed: ChangedEndpoint,
  manifest: ConsumptionManifest,
  ctx: MatchContext = {},
): ConsumedResult {
  const logger = ctx.logger ?? silentLogger;
  const signals: string[] = [];

  try {
    const mi = manifestIndex(manifest);
    const ep = ctx.producerEndpoint ?? null;

    // --- dto_shape (request AND response) ---
    if (ep?.request_dto_shape && mi.dtoShapes.has(ep.request_dto_shape)) {
      signals.push('dto_shape:request');
    }
    if (ep?.response_dto_shape && mi.dtoShapes.has(ep.response_dto_shape)) {
      signals.push('dto_shape:response');
    }

    // --- dto_fqn ---
    for (const fqn of [ep?.request_dto_fqn, ep?.response_dto_fqn]) {
      if (fqn && mi.dtoFqns.has(fqn)) {
        signals.push(`dto_fqn:${fqn}`);
      }
    }

    // --- destination ---
    const destination = changed.destination ?? ep?.destination ?? null;
    if (destination && mi.destinations.has(destination)) {
      signals.push(`destination:${destination}`);
    }

    // --- logical_name ---
    if (ep?.logical_name && mi.logicalNames.has(ep.logical_name)) {
      signals.push(`logical_name:${ep.logical_name}`);
    }

    // --- path_fragment: the FULL endpoint path must target a consumer fragment.
    // Directed suffix test, not prefix overlap — see `pathTargetsEndpoint`. ---
    const consumerFragments = new Set<string>([
      ...mi.pathFragments,
      ...mi.fragmentToPropertyKeys.keys(),
      ...mi.collapsedFragmentToPropertyKeys.keys(),
    ]);
    for (const epPath of endpointPathForms(changed, ep)) {
      let matched: string | null = null;
      for (const frag of [...consumerFragments].sort()) {
        if (pathTargetsEndpoint(epPath, frag)) {
          matched = frag;
          break;
        }
      }
      if (matched !== null) {
        signals.push(`path_fragment:${collapsePathParams(normalizePathTemplate(epPath))}`);
        break;
      }
    }
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('QUERY', `ERROR isConsumed(${changed.id}): ${detail} — reporting the signals found so far`);
  }

  const unique = [...new Set(signals)].sort();
  return { consumed: unique.length > 0, signals: unique };
}

/* ------------------------------------------------------------------ *
 * PHASE 2 — findInvocations
 * ------------------------------------------------------------------ */

export interface FindInvocationsOptions extends MatchContext {
  /** Pre-built index for `consumerBundle`. Built on demand when absent. */
  index?: BundleIndex;
  /** Minimum confidence to report. Default 0. */
  minConfidence?: number;
}

interface Accumulator {
  invocation: InvocationRecord;
  signals: Map<MatchSignal, number>;
}

function shapeOf(index: BundleIndex, fqn: string | null): string | null {
  if (fqn === null || fqn === '') {
    return null;
  }
  const direct = index.dtosByFqn.get(fqn);
  if (direct) {
    return direct.shape;
  }
  // Container types: `java.util.List<com.acme.Foo>` carries Foo on the wire.
  const open = fqn.indexOf('<');
  if (open >= 0 && fqn.endsWith('>')) {
    const inner = fqn.slice(open + 1, -1).split(',')[0]!.trim();
    const nested = index.dtosByFqn.get(inner);
    if (nested) {
      return nested.shape;
    }
  }
  return null;
}

/** Property-derived join tokens recorded on an invocation by normalize.ts. */
function propertyFragmentsOf(inv: InvocationRecord): string[] {
  const raw = inv.annotations?.['property_fragments'];
  return Array.isArray(raw) ? raw.filter((f): f is string => typeof f === 'string') : [];
}

/**
 * Phase-2 join. Scans only the consumer's invocation records and attaches every
 * signal that fires, at the spec's exact weights:
 *
 *   dto_shape                     0.95  `dto_shape_match`
 *   dto_fqn                       0.95  `dto_fqn_match`
 *   destination                   0.90  `destination_match`
 *   logical_name                  0.85  `logical_name_match`
 *   path fragment via property    0.80  `property_value:<key>`
 *   property key wired to a bean  0.75  `wired_bean:<name>`
 *
 * Results are deduped by invocation id keeping the MAX confidence, with every
 * `matched_via` reason concatenated, deduped and sorted.
 */
export function findInvocations(
  consumerBundle: LoadedBundle,
  changed: ChangedEndpoint,
  opts: FindInvocationsOptions = {},
): InvocationHit[] {
  const logger = opts.logger ?? silentLogger;
  const hits = new Map<string, Accumulator>();

  try {
    const index = opts.index ?? buildBundleIndex(consumerBundle, logger);
    const mi = index.manifest;
    const ep = opts.producerEndpoint ?? null;

    const record = (inv: InvocationRecord, signal: MatchSignal, weight: number): void => {
      const acc = hits.get(inv.id) ?? { invocation: inv, signals: new Map<MatchSignal, number>() };
      const prior = acc.signals.get(signal);
      acc.signals.set(signal, prior === undefined ? weight : Math.max(prior, weight));
      hits.set(inv.id, acc);
    };

    /* --- which property keys does this endpoint's path reach? ------------- */
    // The consumer's `path_fragment_to_property_keys` is the inverted index the
    // property pass built exactly for this join. Fragments are matched
    // STRUCTURALLY (collapsed), and unresolved `${...}` tokens verbatim.
    const matchedPropertyKeys = new Set<string>();
    const matchedFragments = new Set<string>();
    for (const frag of endpointFragments(changed, ep)) {
      for (const keys of [
        mi.collapsedFragmentToPropertyKeys.get(frag),
        mi.fragmentToPropertyKeys.get(frag),
      ]) {
        if (keys) {
          matchedFragments.add(frag);
          for (const k of keys) {
            matchedPropertyKeys.add(k);
          }
        }
      }
    }

    const endpointPathList = endpointPathForms(changed, ep);
    const destination = changed.destination ?? ep?.destination ?? null;

    /* --- per-invocation signals ------------------------------------------ */
    for (const inv of index.invocations) {
      // dto_shape — direction-aware: request against request, response against
      // response. The invocation's DTO lives in the CONSUMER's package, so the
      // join must run through the shape hash, never the FQN.
      if (ep !== null) {
        const invRequest = shapeOf(index, inv.request_dto_fqn);
        const invResponse = shapeOf(index, inv.response_dto_fqn);
        if (
          (ep.request_dto_shape !== null && invRequest === ep.request_dto_shape) ||
          (ep.response_dto_shape !== null && invResponse === ep.response_dto_shape)
        ) {
          record(inv, 'dto_shape_match', SIGNAL_WEIGHTS.dto_shape);
        }
        // dto_fqn — only fires when the two repos genuinely share a type.
        if (
          (ep.request_dto_fqn !== null && inv.request_dto_fqn === ep.request_dto_fqn) ||
          (ep.response_dto_fqn !== null && inv.response_dto_fqn === ep.response_dto_fqn)
        ) {
          record(inv, 'dto_fqn_match', SIGNAL_WEIGHTS.dto_fqn);
        }
      }

      // destination (kafka/jms/solace topics and queues)
      if (destination !== null && destination !== '' && inv.destination === destination) {
        record(inv, 'destination_match', SIGNAL_WEIGHTS.destination);
      }

      // logical_name (feign client / service-discovery id / operation id)
      const logicalName = ep?.logical_name ?? null;
      if (logicalName !== null && logicalName !== '' && inv.logical_name === logicalName) {
        record(inv, 'logical_name_match', SIGNAL_WEIGHTS.logical_name);
      }

      // path fragment via property value.
      //
      // Two independent routes, both valid:
      //   a) the invocation's own property_key_ref is one of the keys the
      //      endpoint's path resolves through;
      //   b) one of the invocation's fragments (its literal path fragment, or a
      //      property-derived one — INCLUDING an unresolved `${...}` token)
      //      structurally equals one of the endpoint's fragments.
      const keyRef = inv.property_key_ref;
      if (keyRef !== null && keyRef !== '' && matchedPropertyKeys.has(keyRef)) {
        record(inv, `property_value:${keyRef}`, SIGNAL_WEIGHTS.property_value);
      } else {
        // The invocation's own path tokens, NOT expanded into prefixes — the
        // directed test below handles the context-path case.
        const invFragments = new Set<string>(
          [
            inv.path_fragment,
            inv.literal_url,
            ...propertyFragmentsOf(inv),
          ].filter((f): f is string => typeof f === 'string' && f !== ''),
        );
        let joined: string | null = null;
        for (const frag of [...invFragments].sort()) {
          for (const epPath of endpointPathList) {
            if (pathTargetsEndpoint(epPath, frag)) {
              joined = frag;
              break;
            }
          }
          if (joined !== null) {
            break;
          }
        }
        if (joined !== null) {
          const keys = mi.collapsedFragmentToPropertyKeys.get(joined) ??
            mi.fragmentToPropertyKeys.get(joined) ?? [];
          const key = keyRef ?? keys[0] ?? joined;
          record(inv, `property_value:${key}`, SIGNAL_WEIGHTS.property_value);
        }
      }

      // property key wired to a bean: the invocation's client bean is
      // constructed in a class that also binds one of the matched property keys.
      const bean = inv.client_bean;
      if (bean !== null && bean !== '') {
        let wired = false;
        for (const key of matchedPropertyKeys) {
          for (const w of index.wiringsByPropertyKey.get(key) ?? []) {
            if (w.bean === bean || w.defining_class === enclosingClassOf(inv.enclosing_symbol)) {
              wired = true;
              break;
            }
          }
          if (wired) {
            break;
          }
        }
        if (wired) {
          record(inv, `wired_bean:${bean}`, SIGNAL_WEIGHTS.wired_bean);
        }
      }
    }

    /* --- materialize ------------------------------------------------------ */
    const minConfidence = opts.minConfidence ?? 0;
    const out: InvocationHit[] = [];
    for (const acc of hits.values()) {
      const reasons = [...acc.signals.keys()].sort();
      const confidence = Math.max(...acc.signals.values());
      if (confidence < minConfidence) {
        continue;
      }
      const inv = acc.invocation;
      out.push({
        invocation_id: inv.id,
        symbol: inv.enclosing_symbol,
        file: inv.file,
        // Only the call line is known, so it is both ends of the range.
        line_range: [inv.line, inv.line],
        matched_via: reasons,
        confidence,
        transport: inv.transport,
        method_name: inv.method_name,
        unresolved: inv.unresolved.map((u) => ({ ...u })),
      });
    }

    // Deterministic: strongest first, then by id.
    out.sort(
      (a, b) =>
        b.confidence - a.confidence ||
        (a.invocation_id < b.invocation_id ? -1 : a.invocation_id > b.invocation_id ? 1 : 0),
    );
    return out;
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log(
      'QUERY',
      `ERROR findInvocations(${changed.id}): ${detail} — returning ${hits.size} partial hit(s)`,
    );
    return [];
  }
}

/** `<repo>:<class fqn>#<signature>` -> `<class fqn>`. */
export function enclosingClassOf(symbolId: string): string {
  const hash = symbolId.indexOf('#');
  const noSig = hash < 0 ? symbolId : symbolId.slice(0, hash);
  const colon = noSig.indexOf(':');
  return colon < 0 ? noSig : noSig.slice(colon + 1);
}
