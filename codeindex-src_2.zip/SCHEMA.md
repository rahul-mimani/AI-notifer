# CodeIndex store reference

The complete on-disk contract for `.codeindex/`. Field names in this document are the literal
on-disk names — they are written verbatim by `src/store/writer.ts` from the interfaces in
`src/types.ts`.

`INDEXER_VERSION` and `SCHEMA_VERSION` are both `"0.1.0"` (`src/coordinator/build.ts`; duplicated in
`src/config.ts`).

---

## Contents

- [Bundle layout](#bundle-layout)
- [`meta.json`](#metajson)
- [`endpoints.jsonl`](#endpointsjsonl)
- [`fingerprints.jsonl`](#fingerprintsjsonl)
- [`consumption_manifest.json`](#consumption_manifestjson)
- [`index.jsonl.gz`](#indexjsonlgz) — all ten record kinds
- [`callgraph.bin`](#callgraphbin) — byte-exact format
- [`callgraph.idx.json`](#callgraphidxjson)
- [`callgraph.fwd.json`](#callgraphfwdjson)
- [`source_map.json`](#source_mapjson)
- [`lm_cache/`](#lm_cache)
- [Cross-cutting rules](#cross-cutting-rules)
- [Interface/impl reconciliation](#interfaceimpl-reconciliation)
- [The property resolution pass](#the-property-resolution-pass)
- [**Deviations from the original spec**](#deviations-from-the-original-spec)

---

## Bundle layout

Every path is derived in `src/store/paths.ts` (`bundlePaths`); no other module hardcodes a filename.
The bundle root is `<repoRoot>/.codeindex`.

| File | Format | Written by |
|---|---|---|
| `meta.json` | JSON, 2-space indent, trailing `\n` | `writeBundle` |
| `endpoints.jsonl` | JSONL | `writeBundle` |
| `fingerprints.jsonl` | JSONL | `writeBundle` |
| `consumption_manifest.json` | JSON | `writeBundle` |
| `index.jsonl.gz` | gzipped JSONL | `writeBundle` |
| `callgraph.bin` | CGRF binary | `writeBundle` |
| `callgraph.idx.json` | JSON | `writeBundle` |
| `source_map.json` | JSON array | `writeBundle` |
| `callgraph.fwd.json` | JSON | **`buildIndex`, not `writeBundle`** — see [deviations](#1-callgraphfwdjson--an-additional-bundle-file) |
| `lm_cache/<hash>.json` | JSON | `writeLmCache` |

`lm_cache/` is created (empty) by `writeBundle` even when nothing is cached.

**JSONL** — one `JSON.stringify` per record, `\n`-joined, with a trailing newline when non-empty. An
empty collection produces a **zero-byte file**, not a file containing a blank line. Readers skip blank
and malformed lines, logging each.

**JSON** — `JSON.stringify(value, null, 2)` plus a trailing `\n`.

**Gzip** — level 9 with `mtime: 0`, and the header's MTIME/XFL/OS bytes explicitly zeroed (OS set to
`0xFF`, "unknown") so archives are byte-identical across platforms and across rebuilds.

---

## `meta.json`

One `Meta` object.

| Field | Type | Meaning |
|---|---|---|
| `repo` | `string` | Repo identifier. Prefixes every symbol id. |
| `repo_url` | `string` | From `BuildIndexOptions.repoUrl`; `""` when not supplied. |
| `commit` | `string` | From `BuildIndexOptions.commit`; `""` when not supplied. |
| `branch` | `string` | From `BuildIndexOptions.branch`; `""` when not supplied. |
| `built_at` | `string` | ISO timestamp, **injected by the caller**. `buildIndex` never generates it — this is the only clock in the bundle, and injecting it is what makes rebuilds byte-identical. |
| `indexer_version` | `string` | `"0.1.0"`. |
| `schema_version` | `string` | `"0.1.0"`. Bump when any on-disk field name changes. |
| `source_roots` | `string[]` | Configured roots, sorted. |
| `package_prefixes` | `string[]` | Configured prefixes, sorted. |
| `config_sources` | `object[]` | One entry per discovered config source, contents stripped: `{source, source_type, env, branch, format}`. `format` is `"yaml"` or `"properties"`. |
| `transports_supported` | `Transport[]` | Always the full literal list `["rest","kafka","solace","jms","message_router","grpc"]`. |
| `stats` | `Record<string, number>` | See below. |

### `meta.stats`

Fixed keys, plus one `records_<kind>` key per record kind actually present.

| Key | Meaning |
|---|---|
| `java_files_walked` | Files returned by the walk. |
| `files_filtered_out` | Files the pre-filter rejected (`stats.skipped`). |
| `lm_candidates` | Wave-1 marker hits only — **not** the total sent to the LM. |
| `files_extracted` | Files with an extraction result, across all closure waves. Normally exceeds `lm_candidates`. |
| `endpoints` | Post-reconciliation endpoint count. |
| `fingerprints` | Always equals `endpoints` (one fingerprint per endpoint). |
| `records_total` | Total records in `index.jsonl.gz`. |
| `records_<kind>` | Per-kind counts, e.g. `records_symbol`, `records_dto`, `records_property`. Absent kinds are omitted. |
| `callgraph_symbols` | Symbol string-table size. |
| `callgraph_edges` | Edges written. |
| `callgraph_interface_edges` | Edges emitted through interface fan-out. |
| `callgraph_unresolved_callees` | Call sites whose callee resolved to nothing (mostly framework noise). |
| `callgraph_excluded_by_prefix` | Call sites dropped because either endpoint failed the package-prefix test. |
| `source_map_files` | Entries in `source_map.json`. |
| `deterministic_only` | `1` when no LM was used, `0` otherwise. |

Example from a real fixture build:

```json
"stats": {
  "java_files_walked": 9, "files_filtered_out": 5, "lm_candidates": 4,
  "files_extracted": 9, "endpoints": 4, "fingerprints": 4, "records_total": 51,
  "records_logical_name_ref": 4, "records_symbol": 24, "records_dto": 3,
  "records_invocation": 1, "records_property": 9, "records_wiring": 5,
  "records_entry_point": 4, "records_unresolved": 1,
  "callgraph_symbols": 15, "callgraph_edges": 10, "callgraph_interface_edges": 0,
  "callgraph_unresolved_callees": 0, "callgraph_excluded_by_prefix": 6,
  "source_map_files": 9, "deterministic_only": 0
}
```

---

## `endpoints.jsonl`

One `Endpoint` per line — a single inbound contract this repo serves. Sorted by
`transport|verb|path_template|destination|handler_symbol`.

| Field | Type | Meaning |
|---|---|---|
| `id` | `string` | `endpointId(transport, verb, path_template, handler_symbol)` — SHA-256 hex. Uses the **display** path, so renaming `{id}`→`{userId}` yields a different id (it is a different declaration). |
| `fingerprint` | `string` | `endpointFingerprint(...)` — SHA-256 hex over the **matching** path. See [fingerprints](#fingerprintsjsonl). |
| `transport` | `"rest"\|"kafka"\|"solace"\|"jms"\|"message_router"\|"grpc"` | |
| `verb` | `"GET"\|"POST"\|"PUT"\|"DELETE"\|"PATCH"\|null` | `null` for non-REST transports. |
| `path_template` | `string\|null` | Display form: normalized, param names kept (`/api/v1/customers/{id}`). |
| `path_template_normalized` | `string\|null` | Matching form: params collapsed (`/api/v1/customers/{}`). |
| `destination` | `string\|null` | Topic/queue. May be an unresolved `${...}` placeholder — deliberately retained as a join key. |
| `request_dto_fqn` | `string\|null` | Verbatim from the model. |
| `response_dto_fqn` | `string\|null` | Verbatim from the model; may carry generics, e.g. `java.util.List<com.acme.cdu.dto.AddressDto>`. |
| `request_dto_shape` | `string\|null` | Shape hash. Resolved directly, else from the first generic argument. `null` if the type is not a known DTO. |
| `response_dto_shape` | `string\|null` | As above. |
| `path_params` | `ParamSpec[]` | `required` is forced to `true`. |
| `query_params` | `ParamSpec[]` | `required` defaults to `true` when the model omits it. |
| `headers` | `ParamSpec[]` | As above. |
| `status_codes` | `number[]` | **Always `[]`.** Nothing populates it. |
| `logical_name` | `string\|null` | Feign name, OpenAPI `operationId`, service-discovery id. |
| `handler_symbol` | `string` | Symbol id of the canonical handler method. |
| `file` | `string` | Repo-relative path of the **canonical** candidate's file. |
| `line` | `number` | Canonical candidate's `handler_line`. |
| `annotations` | `Record<string, Record<string, unknown>>` | Merged across the whole reconciliation group, plus the synthetic `declaring_type` key. |
| `visibility` | `"public"\|"internal"\|"deprecated"` | `"deprecated"` iff `Deprecated` is a merged annotation key; otherwise `"public"`. **`"internal"` is never emitted.** |
| `extractor` | `string` | `lm:<model id>`, or `deterministic`. |
| `extraction_confidence` | `number` | The canonical candidate's `confidence`. |

`ParamSpec` is `{ name: string, type: string, required: boolean }`.

### Reserved synthetic annotation key: `declaring_type`

Present only when reconciliation identified a distinct declaring type. `Endpoint` has no dedicated
field for it and adding one would break the schema, so it is recorded as a synthetic annotation
entry. **This key is reserved — a real Java annotation named `declaring_type` would collide.**

```json
"annotations": {
  "RestController": {},
  "GetMapping": { "value": "/api/v1/customers/{id}", "inherited_from": "com.acme.cdu.api.CustomerApi" },
  "declaring_type": {
    "fqn": "com.acme.cdu.api.CustomerApi",
    "reconciliation_rule": "restcontroller_annotation",
    "merged_candidates": 2
  }
}
```

| Attribute | Type | Meaning |
|---|---|---|
| `fqn` | `string` | The declaring interface's FQN. When several were found, the **first after sorting**. Consumers read `endpoint.annotations.declaring_type.fqn`. |
| `reconciliation_rule` | `string` | Which rule picked the canonical handler. One of `single_candidate`, `restcontroller_annotation`, `concrete_impl_marker`, `not_declared_as_interface`, `higher_confidence`, `not_api_package`, `first_by_symbol`. |
| `merged_candidates` | `number` | Group size (`others.length + 1`). |

---

## `fingerprints.jsonl`

One `Fingerprint` per endpoint — the projection a change detector diffs. Sorted by `id`.

| Field | Type | Meaning |
|---|---|---|
| `id` | `string` | Same value as the endpoint's `id`. |
| `fingerprint` | `string` | Same value as the endpoint's `fingerprint`. |
| `transport` | `Transport` | |
| `path_template` | `string\|null` | Display form (matching the `Endpoint`, not the hashed form). |
| `destination` | `string\|null` | |
| `request_dto_shape` | `string\|null` | |
| `response_dto_shape` | `string\|null` | |

**What the fingerprint is sensitive to.** It hashes `[transport, verb, collapsePathParams(path),
request_dto_shape, response_dto_shape, destination]` joined by a single space. It therefore
**ignores** path-variable renames, regex constraints on variables (`{id:[0-9]+}`), and trailing
slashes — none of which break a caller. It **reacts to** path structure changes
(`/users/{id}` → `/users/{id}/profile`), literal-versus-parameter changes
(`/users/{id}` → `/users/all`), verb changes, destination changes, and any change to either DTO
shape. Collapsing is idempotent, so callers may pass either form safely.

---

## `consumption_manifest.json`

One `ConsumptionManifest` object — the compact broadcast used for cheap phase-1 "could this repo
possibly consume that?" matching. Every array is deduped, empty strings removed, and sorted.

| Field | Type | Contents |
|---|---|---|
| `dto_shapes` | `string[]` | Every DTO shape hash in this repo. |
| `dto_fqns` | `string[]` | Every DTO FQN. |
| `path_fragments` | `string[]` | Endpoint display paths, their normalized forms, cumulative literal prefixes of both endpoints and invocations (`/api`, `/api/v1`, `/api/v1/customers`), invocation `path_fragment`s and their collapsed forms, and every property-derived fragment from `annotations.property_fragments`. |
| `destinations` | `string[]` | Endpoint and invocation destinations, plus each per-env resolution of any `${...}` destination. |
| `logical_names` | `string[]` | From endpoints and invocations. |
| `property_keys` | `string[]` | Every resolved property key. |
| `unresolved_placeholders` | `string[]` | Verbatim `${...}` tokens that survived resolution — from destinations, property values, and invocation enrichment. These are join keys, not errors. |
| `path_fragment_to_property_keys` | `Record<string, string[]>` | Inverted index: fragment → the property key(s) whose resolved value produced it. Merges the property pass's `pathFragmentIndex` with the invocation-derived index. Keys sorted; arrays sorted and deduped. |

A `[NORMALIZE] WARN` fires when the serialized manifest exceeds 50,000 bytes. It is still written.
(The CDU fixture manifest is 979 bytes.)

---

## `index.jsonl.gz`

Gzipped JSONL of every `IndexRecord`. Records are appended in this order, each group internally
sorted: **symbols → dtos → invocations → properties → wirings → property_bindings → entry_points →
unresolved**. `logical_name_ref` records are pushed during endpoint processing and therefore appear
*first* in the file.

Ten `kind` values are recognized by the reader. Nine are produced.

### `kind: "symbol"` — `SymbolRecord`

Emitted for every in-prefix class/interface and every in-prefix method. Sorted by `id`.

| Field | Type | Meaning |
|---|---|---|
| `kind` | `"symbol"` | |
| `id` | `string` | `<repo>:<fqn>` for types, `<repo>:<fqn>#<signature>` for methods. |
| `fqn` | `string` | For a method record this is the **declaring class** FQN, not the method. |
| `symbol_kind` | `"class"\|"interface"\|"method"\|"field"\|"annotation"` | Only `class`, `interface` and `method` are emitted. |
| `file` | `string` | Repo-relative. |
| `line_start` | `number` | For classes, the minimum line seen across all mentions. |
| `line_end` | `number` | **Always equals `line_start`.** True end lines are not extracted. |
| `modifiers` | `string[]` | **Always `[]`.** |
| `is_entry_point` | `boolean` | |
| `entry_point_kind` | `EntryPointKind\|null` | `rest_controller`, `kafka_listener`, `jms_listener`, `scheduled`, `main`, `message_router_handler`, `grpc_handler`. `grpc_handler` is declared but never assigned. |
| `entry_point_details` | `object\|null` | `{class_fqn, method, signature}` when an entry point, else `null`. |
| `annotations` | `Array<{name: string}>` | Names only, sorted. A method inherits its class's annotation names plus its own merged handler annotations. |
| `enclosing_class` | `string\|null` | The class FQN for methods; `null` for types. |
| `extractor` | `string` | |
| `extraction_confidence` | `number` | **Always `1.0`** for symbol records. |

Entry-point classification (`entryPointKindOf`) tests, in order: `KafkaListener` → `kafka_listener`;
`JmsListener`/`RabbitListener` → `jms_listener`; `Scheduled` → `scheduled`; any configured message
router marker (leading `@` stripped) → `message_router_handler`; `RestController`/`Controller` →
`rest_controller`; method named `main` with a signature starting `main([Ljava/lang/String;)` →
`main`. A class-level `@RestController` marks only its **mapped** methods as entry points — a
`rest_controller` classification on a method that is not a reconciled handler is discarded.

### `kind: "dto"` — `DtoRecord`

Sorted by `fqn`.

| Field | Type | Meaning |
|---|---|---|
| `kind` | `"dto"` | |
| `fqn` | `string` | |
| `shape` | `string` | SHA-256 hex of the canonical shape serialization. |
| `fields` | `DtoField[]` | `{name, type, nullable, annotations}` — as reported, `annotations` sorted. **The full field list, including fields excluded from the hash.** |
| `nested_shapes` | `Record<string, string>` | Field name → shape hash of the DTO that field resolves to. One entry per field at most; a field naming several DTOs (`Map<Foo,Bar>`) records the first. |
| `file` | `string` | |
| `line` | `number` | |
| `is_generated` | `boolean` | |
| `extractor` | `string` | |
| `extraction_confidence` | `number` | |

### `kind: "invocation"` — `InvocationRecord`

One outbound call site. Sorted by `id`.

| Field | Type | Meaning |
|---|---|---|
| `kind` | `"invocation"` | |
| `id` | `string` | `invocationId(file, line, enclosing_symbol, transport)`. |
| `transport` | `Transport` | |
| `enclosing_symbol` | `string` | Symbol id of the containing method. |
| `file`, `line` | `string`, `number` | |
| `literal_url` | `string\|null` | |
| `path_fragment` | `string\|null` | The model's value if it supplied one; otherwise filled from the property table (see below). |
| `destination` | `string\|null` | |
| `request_dto_fqn` / `response_dto_fqn` | `string\|null` | |
| `client_bean` | `string\|null` | e.g. `cduRestTemplate`. |
| `property_key_ref` | `string\|null` | The key the URL/destination came from. |
| `logical_name` | `string\|null` | |
| `method_name` | `string` | e.g. `getForObject`. |
| `confidence_hints` | `string[]` | Model hints plus pipeline-added hints, deduped and sorted. |
| `unresolved` | `UnresolvedNote[]` | `{what, reason, expression}`. Each is *also* emitted as a standalone `unresolved` record. |
| `annotations` | `Record<string, unknown>` | Two reserved keys — see below. |
| `extractor`, `extraction_confidence` | | |

**Reserved keys in `invocation.annotations`.** This field is not Java annotations; it is a pipeline
side-channel with exactly two keys:

| Key | Type | Meaning |
|---|---|---|
| `enclosing_method_name` | `string` | Carried through from the model. |
| `property_fragments` | `string[]` | Sorted, deduped fragments derived from resolving `property_key_ref` across **every** materialized env. Feeds `manifest.path_fragments`. |

Two pipeline-added `confidence_hints` values:

| Hint | Added when |
|---|---|
| `path_fragment_from_property` | `path_fragment` was `null`/empty and was filled from the property table. The chosen value is the first derived fragment starting with `/`, else the first overall. |
| `property_fragments_recorded` | `path_fragment` was already set and property-derived fragments were recorded alongside it. |

Example (POU consumer, no literal URL anywhere in the source):

```json
{
  "kind": "invocation",
  "path_fragment": "/api/v1/customers/{id}",
  "property_key_ref": "services.cdu.base-url",
  "client_bean": "cduRestTemplate",
  "confidence_hints": ["base_url_from_value_annotation", "dto_type_resolved",
                       "path_fragment_is_literal", "property_fragments_recorded",
                       "url_is_concatenated", "verb_from_resttemplate_method"],
  "annotations": {
    "enclosing_method_name": "fetchCustomer",
    "property_fragments": ["/cdu-service",
                           "https://cdu.default.internal/cdu-service",
                           "https://cdu.dev.internal/cdu-service",
                           "https://cdu.prod.internal/cdu-service",
                           "https://cdu.uat.internal/cdu-service"]
  }
}
```

### `kind: "property"` — `PropertyRecord`

**One record per (key, env, source) — including shadowed declarations.** Sorted by
`key env source line`.

| Field | Type | Meaning |
|---|---|---|
| `kind` | `"property"` | |
| `key` | `string` | Dotted key. YAML sequences flatten to `key[0]`, `key[1]`. |
| `value` | `string` | Fully resolved. **Retains verbatim `${...}` when unresolvable.** |
| `raw_value` | `string` | Exactly as written. |
| `env` | `"dev"\|"uat"\|"prod"\|"default"\|"shared"` | The env of the **declaration**, not the env it was resolved for. |
| `source` | `string` | Repo-relative path of the config file (absolute if outside the repo). |
| `source_type` | `"application_yml"\|"config_server"\|"configmap"\|"env_var"\|"vault_ref"` | `env_var` and `vault_ref` are declared but never assigned by the parsers. |
| `line` | `number` | True 1-based line. For a continued `.properties` line, the **first** physical line. |
| `branch` | `string\|null` | Config Server branch label; `null` otherwise. |
| `is_secret` | `boolean` | True when the key's final segment matches `password\|secret\|token\|api-?key\|credential`, or when either the raw or resolved value contains a `vault:` scheme. |
| `extractor` | `"deterministic"` | Always. |
| `extraction_confidence` | `1.0` | Always. |

### `kind: "wiring"` — `WiringRecord`

Bean-to-property wiring, from the model's `wirings`. Sorted by `file|line|bean`.

| Field | Type | Meaning |
|---|---|---|
| `kind` | `"wiring"` | |
| `bean` | `string` | Bean name. |
| `bean_class` | `string` | `""` when the model reported `null` — **not** `null`. |
| `property_key` | `string` | `""` when the model reported `null` — **not** `null`. |
| `injection` | `"@Value"\|"@ConfigurationProperties"\|"constructor"\|"setter"\|"field"` | |
| `file`, `line` | | |
| `defining_class` | `string\|null` | Stays `null` (unlike the two fields above). |
| `extractor`, `extraction_confidence` | | |

### `kind: "property_binding"` — `PropertyBindingRecord`

`@ConfigurationProperties` classes. Sorted by `class_fqn|prefix`.

| Field | Type | Meaning |
|---|---|---|
| `kind` | `"property_binding"` | |
| `prefix` | `string` | e.g. `services.cdu`. |
| `class_fqn` | `string` | |
| `fields` | `Array<{name, type, property_subkey}>` | |
| `file`, `line`, `extractor`, `extraction_confidence` | | |

### `kind: "entry_point"` — `EntryPointRecord`

A denormalized projection of every symbol with `is_entry_point: true`. Sorted by `symbol`.

| Field | Type | Meaning |
|---|---|---|
| `kind` | `"entry_point"` | |
| `symbol` | `string` | Method symbol id. |
| `entry_kind` | `EntryPointKind` | |
| `details` | `object\|null` | `{class_fqn, method, signature}`. |
| `file`, `line` | | |

No `extractor` or `extraction_confidence` on this kind.

### `kind: "logical_name_ref"` — `LogicalNameRefRecord`

Emitted for every endpoint with a non-empty `logical_name`.

| Field | Type | Meaning |
|---|---|---|
| `kind` | `"logical_name_ref"` | |
| `logical_name` | `string` | |
| `context` | `"feign"\|"service_discovery"\|"openapi_operation_id"\|"custom_annotation"` | **Always `"openapi_operation_id"`** — the only value ever assigned. |
| `symbol` | `string` | Handler symbol id. |
| `file`, `line`, `extractor`, `extraction_confidence` | | |

### `kind: "alias"` — `AliasRecord`

| Field | Type |
|---|---|
| `kind` | `"alias"` |
| `canonical_key` | `string` |
| `aliases` | `string[]` |
| `confidence` | `number` |

**Never produced.** The type is declared, and `loadBundle` buckets the kind, but nothing constructs
one. Relaxed-binding aliases from ConfigMaps are instead emitted as ordinary `property` records
flagged internally with `is_alias` (see below) — that flag is a `RawProperty` field consumed by the
resolver's precedence rule and is **not** written to disk.

### `kind: "unresolved"` — `UnresolvedRecord`

Everything the pipeline refused to guess. Sorted by `what|file|line|reason`.

| Field | Type | Meaning |
|---|---|---|
| `kind` | `"unresolved"` | |
| `what` | `"url"\|"destination"\|"dto_type"\|"bean_wiring"\|"property_value"\|"method_body"\|"extraction_failed"\|"other"` | |
| `context` | `{file, line, enclosing_symbol}` | File-level model notes use `line: 1` and `enclosing_symbol: null`; property failures use the config file and its line. |
| `reason` | `string` | Human-readable. |
| `partial_info` | `Record<string, unknown>` | Varies by origin. From an invocation: `{invocation_id, method_name, expression, client_bean, property_key_ref}`. From a file-level model note: `{expression, source: "lm_file_level"}`. From the property pass: `{key, env, raw_value, value, expression, is_secret}`. |

---

## `callgraph.bin`

Binary **reverse** adjacency: indexed **by callee**, yielding **callers**. The blast-radius walk only
ever asks "who calls this?", so the reverse direction makes that one offset-table lookup plus a
contiguous slice. Downstream walks are served by [`callgraph.fwd.json`](#callgraphfwdjson) instead.

**All integers are little-endian.** Magic `CGRF`, version `1`.

### Header — 17 bytes

| Offset | Size | Type | Field |
|---|---|---|---|
| 0 | 4 | ASCII | magic, `"CGRF"` |
| 4 | 1 | uint8 | version, `1` |
| 5 | 4 | uint32 | `symbol_count` |
| 9 | 4 | uint32 | `edge_count` |
| 13 | 4 | uint32 | `string_table_offset` — **absolute byte offset** |

### Offset table — `(symbol_count + 1) × uint32`, starting at byte 17

Values are **edge indices, not byte offsets**. Callee `i` owns edges `[offset[i], offset[i+1])`.
The final entry, `offset[symbol_count]`, is a sentinel equal to `edge_count`.

A callee with no callers has `offset[i] == offset[i+1]`.

### Edge array — `edge_count × 13` bytes

Starts at `17 + (symbol_count + 1) * 4`. The record carries the **caller** — the callee is implied by
which offset-table slot the record falls into.

| Offset | Size | Type | Field |
|---|---|---|---|
| 0 | 4 | uint32 | `caller_symbol_index` |
| 4 | 4 | uint32 | `file_id` — index into `source_map.json` |
| 8 | 4 | uint32 | `line` |
| 12 | 1 | uint8 | `call_kind`: `0` direct, `1` interface, `2` lambda, `3` reflective |

### String table

Starts at `string_table_offset`, which always equals
`17 + (symbol_count + 1) * 4 + edge_count * 13`. Symbol ids in index order, each encoded as a
**uint16 byte length followed by that many UTF-8 bytes**.

Note the uint16 length: a symbol id longer than 65,535 bytes would be truncated. Not guarded.

### Determinism

Edges are sorted by `(callee_index, caller_index, line, file_id, call_kind)` before writing, so the
same logical graph always packs to identical bytes regardless of input order — asserted by
`store-sanity` with shuffled input.

### Validation and fail-open

`CallgraphReader.fromBuffer` degrades to an empty reader (logging at `[CALLGRAPH]`, never throwing)
when the buffer is shorter than the header, the magic is wrong, the version is not `1`, or
`string_table_offset` does not equal the computed expected value / exceeds the buffer length. Edges
referencing an index outside the symbol table are **dropped at pack time** rather than corrupting the
file.

---

## `callgraph.idx.json`

`Record<string, number>` — symbol id → its index in the binary string table. Redundant with the
string table itself; it exists so a consumer can resolve ids without decoding the binary. First
occurrence wins if ids repeat.

```json
{
  "cdu:com.acme.cdu.CduApplication#main([Ljava/lang/String;)V": 0,
  "cdu:com.acme.cdu.api.CustomerApi#getCustomer(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;": 1
}
```

---

## `callgraph.fwd.json`

**Forward** adjacency: caller symbol id → its call sites. See
[deviations](#1-callgraphfwdjson--an-additional-bundle-file) for why it exists and what does not read
it.

Type `ForwardAdjacency = Record<string, ForwardCallSite[]>`. Object keys are sorted; each array is
sorted by `(callee, line, file_id)`.

| Field | Type | Meaning |
|---|---|---|
| `callee` | `string` | Callee symbol id (a full id, not an index — unlike the binary). |
| `file_id` | `number` | Index into `source_map.json`. |
| `line` | `number` | |
| `call_kind` | `"direct"\|"interface"\|"lambda"\|"reflective"` | Spelled out, not the numeric code. |

```json
{
  "cdu:com.acme.cdu.controller.CustomerController#getCustomer(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;": [
    {
      "callee": "cdu:com.acme.cdu.service.CustomerService#findById(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;",
      "file_id": 2,
      "line": 30,
      "call_kind": "direct"
    }
  ]
}
```

It holds exactly the same edge set as `callgraph.bin`, transposed.

---

## `source_map.json`

A JSON array of strings — **positional**: the array index *is* the `file_id` referenced by callgraph
edges (binary and forward alike).

```json
[
  "src/main/java/com/acme/cdu/api/CustomerApi.java",
  "src/main/java/com/acme/cdu/CduApplication.java",
  "src/main/java/com/acme/cdu/controller/CustomerController.java"
]
```

Seeded from the full walked-file list (so `file_id`s are stable against the walk order), and extended
by `buildCallgraph` if a call site names a file not already present.

---

## `lm_cache/`

One file per extracted source file: `.codeindex/lm_cache/<sanitized-content-hash>.json`.

- **Key** — SHA-256 hex of the file's UTF-8 content. Editing a file therefore invalidates its entry
  automatically. `sanitizeHash` replaces every character outside `[A-Za-z0-9_-]` with `_` before it
  becomes a filename, so a hostile key cannot escape the directory.
- **Value** — the raw model response text. `FileLmCache` unwraps the multi-chunk envelope into real
  JSON on write (so the file stays human-readable rather than a doubly-escaped string) and
  re-serializes it on read. **The chunk strings themselves are preserved byte-for-byte** either way.
- **Multi-chunk envelope** — `{"__codeindex_lm_chunks__": ["<raw chunk 0>", "<raw chunk 1>", …]}`.
  A single-chunk file stores the bare response.
- **Fail-open** — a missing, unreadable or corrupt entry is a cache **miss**, never an error. A hit
  that no longer passes schema validation is logged and re-extracted.

---

## Cross-cutting rules

### Symbol id format

```
<repo>:<fqn>                          class or interface
<repo>:<fqn>#<normalized signature>   method
```

`normalizeMethodSignature` produces `name(<param descriptors>)<return descriptor>`, where `name` and
the return descriptor are omitted when the input did not carry them. It accepts both real JVM
descriptors (`getUser(Ljava/lang/String;)V`) and source-ish text (`getUser(List<Foo> foos)`).
Generics are erased. Primitives map to `V Z B C S I J F D`; a fixed `WELL_KNOWN` table expands common
JDK simple names (`String` → `java/lang/String`, `List` → `java/util/List`, …); anything else is kept
verbatim with dots turned into slashes, which is lossy-but-reversible and, critically, *consistent*.
Unparseable input is returned with whitespace normalized rather than throwing.

Both sides of every callgraph join pass through this function before comparison — a mismatch silently
drops an edge, which is the worst failure mode available here.

### DTO shape hashing

`computeDtoShapes` (`src/extractor/shapes.ts`) hashes the **whole DTO universe at once**, because
both inheritance and nested substitution need the complete set. Algorithm:

1. **Collect fields including inherited.** Superclass fields first, then the subclass's own fields
   override same-named ones. An inheritance cycle is guarded by a `seen` set.
2. **Exclude** fields carrying a `transient` or `static` modifier (case-insensitive), and synthetic
   names — anything starting with or containing `$`, or named `serialVersionUID`.
   A subclass field that is itself excluded **also removes the inherited field of that name**: the
   concrete class genuinely does not serialize it.
   *Note:* the LM reports Java modifiers inside each field's `annotations` array, so `normalize.ts`
   maps `annotations` → `modifiers` before hashing. This is exactly what makes CDU's and POU's
   `CustomerDto` — both carrying a `transient cacheKey` — hash identically.
3. **Substitute nested DTO types** with their shape hash, preserving the container:
   `List<Foo>` → `List<{hash}>`, `Map<String,Foo>` → `Map<String,{hash}>`, `Foo[]` → `{hash}[]`.
   Unknown types (`String`, `com.external.Thing`) pass through literally.
4. **Sort** the resulting `{name, nullable, type}` tuples by field name.
5. **Serialize** as canonical JSON (object keys sorted recursively; array order preserved) and
   **SHA-256** it, lowercase hex.

**Reference cycles — the subtle part.** `A { B b }` and `B { A a }` would recurse forever. When the
DFS re-enters an FQN already on the current stack, that back-edge is replaced with the stable
placeholder `#cycle:<fqn>` instead of recursing.

The placeholder alone is not sufficient for determinism, because *which* node the back-edge names
depends on where the DFS started: rooted at `A`, `B`'s field reads `#cycle:A`; rooted at `B`, `A`'s
field reads `#cycle:B`. The rule is therefore:

> Every DTO's shape is **defined** as "computed with a fresh stack rooted at itself", and any result
> that consumed a cycle placeholder is **never memoized** for reuse under a different root. Acyclic
> results are context-independent and are memoized freely.

The outcome depends only on the subgraph reachable from each DTO, making the whole set independent of
input order — asserted directly in `hash-sanity`.

### Path template normalization

Two forms, both in `src/extractor/paths.ts`:

- **Display** (`normalizePathTemplate`) — drops `scheme://host[:port]`, drops query string and
  fragment, collapses runs of `/`, ensures exactly one leading `/`, strips trailing slashes except at
  the root, and **preserves param names**. Empty/null input normalizes to `/`.
- **Matching** (`collapsePathParams`) — additionally collapses every path variable to `{}`.
  Handles `{id}`, `{id:[0-9]+}`, `{*spring}`, and regex quantifiers like `{code:[a-z]{2,4}}` via
  depth counting. Ant wildcards `*` and `**` are left as-is, being structural.

`joinPathTemplates(classLevel, methodLevel)` joins a class-level `@RequestMapping` with a method-level
mapping; a method-level value carrying a scheme+host wins outright. `pathFragments` returns the
fully-literal segments in order — segments containing a `{` or equal to `*`/`**` are dropped.

`derivePathTemplate` prefers the class+method join over the model's own `path_template`, logging at
`[NORMALIZE]` when they disagree. It falls back to the model's value verbatim when no method-level
mapping annotation was reported at all.

### Property value resolution order

Detailed in [the property resolution pass](#the-property-resolution-pass). In brief:

1. **Source precedence** when two sources set the same `(key, env)`:
   `application_yml`(0) < `config_server`(1) < `configmap`(2) < `env_var`/`vault_ref`(3). Within a
   tier, a canonical key beats a relaxed-binding alias; on a full tie the **later** declaration wins.
   Shadowed declarations are logged and **still emitted as records**.
2. **Env inheritance** when materializing a view: same-env → `shared` → `default`
   (for `shared` itself: `shared` → `default`).
3. **Placeholder expansion** within the chosen view, depth-capped at 10.

### Repo-relative path convention

Every `file` and `source` field is repo-relative, forward-slashed, with no leading slash —
`toRepoRelative` in both `src/store/paths.ts` and `src/coordinator/walk.ts`. A config source that
resolves outside the repo root keeps its absolute path (also forward-slashed).

### Determinism guarantees

Writing the same logical bundle twice produces **byte-identical files**. This is asserted directly by
`store-sanity` (including a shuffled-edge-input case) and `indexer-sanity` (full rebuild
comparison). It rests on:

- `meta.built_at` is injected, never generated. It is the only clock in the bundle.
- No module in the pipeline reads `process.env`, `Date.now()` (outside timing logs) or any random
  source. `getNonce` in `src/ui/webview-html.ts` uses `Math.random`, but is not part of the pipeline
  and its output never reaches disk.
- The directory walk sorts entries; every emitted collection is sorted by an explicit total order.
- Callgraph edges are sorted before packing; the symbol string table is sorted.
- Property keys are resolved in sorted order, which keeps the order-sensitive recursion-cap outcomes
  stable.
- Gzip uses `level: 9, mtime: 0` with the MTIME/XFL/OS header bytes explicitly zeroed.
- LM extraction results are re-sorted by `relativePath` after the concurrent schedule completes, so
  concurrency cannot leak into output ordering.

---

## Interface/impl reconciliation

Spring registers a handler when a `@RestController` class implements an interface whose methods carry
the mapping annotations. The annotations physically live on the interface while traffic is served by
the concrete class, so the LM legitimately reports the same endpoint twice: once from the interface
file (attributes tagged `declared_on`) and once from the controller file (attributes tagged
`inherited_from`, typically lower confidence).

**Grouping key:** `(transport, verb, path_template_normalized, destination)`.

Within a group, candidates are first sorted by `handlerSymbol` for a stable base order. A rule fires
only if it selects **exactly one** candidate; rules are tried in order and the one that fired is
recorded in `annotations.declaring_type.reconciliation_rule` and logged at `[NORMALIZE]`.

| # | Rule | Predicate | Note |
|---|---|---|---|
| — | `single_candidate` | group size is 1 | No rule evaluation occurs. |
| 1 | `restcontroller_annotation` | candidate's annotations include `RestController` or `Controller` | Strongest and fixture-independent. |
| 2 | `concrete_impl_marker` | any of the candidate's mapping attributes carry `inherited_from` | It is the inheriting (concrete) side. |
| 3 | `not_declared_as_interface` | candidate's class FQN is **not** in the known interface set | The other candidate is an interface. |
| 4 | `higher_confidence` | candidate's `confidence` equals the group max | Ties select nothing and fall through. |
| 5 | `not_api_package` | candidate's file path does not match `(^\|/)api/` | **Deliberately weak** — a naming convention only, reached only when nothing structural distinguishes the candidates. |
| 6 | `first_by_symbol` | — | Total-order fallback. Guarantees determinism. |

**After selection:**

- `others` = every non-canonical candidate.
- Annotations are **merged across the whole group** (others first, canonical last, so the canonical
  side wins on attribute collision), preserving the interface's `declared_on` evidence even though
  the controller is canonical.
- `declaringType` = sorted unique of the canonical's declaring types plus every other candidate's own
  class FQN and declaring types, minus the canonical class FQN itself. The **first** entry becomes
  `annotations.declaring_type.fqn`.

**Interface knowledge is derived, not declared.** The LM schema carries no `implements`/`extends`
array. The only structural evidence available is the `declared_on`/`inherited_from` markers: a class
whose mapping annotations name another type is taken to implement that type. That populates
`symbolTable.implementations` (interface FQN → concrete FQNs) and flips `ClassSymbolEntry.isInterface`.
A class known to implement an interface is by construction marked concrete. **Consequence:** an
interface never involved in an endpoint declaration is invisible to the callgraph's interface
fan-out, which then resolves only by unambiguous name match. This limitation is logged at
`[CALLGRAPH]` when no interface information was derivable at all.

**Callgraph interface handling.** When a callee class is a known interface, one edge is emitted per
resolved target *plus* one per method of every known implementation, all tagged `call_kind:
"interface"`. If that fan-out emits nothing, the call site is counted as an unresolved callee.

**Callee resolution is layered** (`resolveCallee`): exact `class#normalized-signature` → `class#method
name` across all overloads (logged when the signature guess was wrong) → interface fan-out → give up
and count it. Unresolvable callees are overwhelmingly framework noise (`RestTemplate`,
`KafkaTemplate`, `java.util.Map`) and are skipped rather than synthesized, but always reported in the
`[CALLGRAPH]` summary.

---

## The property resolution pass

`src/extractor/properties/resolve.ts`. Format-agnostic — YAML, `.properties` and ConfigMap sources
all arrive as a flat `RawProperty[]` from `parse.ts`.

### Placeholder syntax

Three forms are accepted:

| Form | Meaning |
|---|---|
| `${var}` | Bare reference. |
| `${var:default}` | Spring's actual default syntax. |
| `${var:-default}` | The shell-style form the project spec text used. |

Both default forms are supported because the spec says one and real Spring Boot uses the other, and
both appear in the wild (notably in Helm-templated configs). Defaults may themselves contain
placeholders: `${a:${b}}` resolves `b` when `a` is absent. The default separator is the first
**top-level** `:` — nested `${}` is skipped when scanning.

### Per-env materialized views

Views are built for every declared env plus `default`. For each env, each key is resolved through the
chain **same-env → `shared` → `default`** (for `shared`: `shared` → `default`), taking the first hit.

Materializing inherited keys per env is what makes a key declared only in `default` —
`services.cdu.base-url: ${cdu.host}/cdu-service` — resolve to the *dev* host under env `dev`, which
is how Spring actually behaves. The `PropertyRecord` for that declaration still carries
`env: "default"`; the per-env effective values live in the resolution table and are what
`lookupResolved` returns.

### Cycles and the depth cap

- **Cycle detection** — `resolveKey` maintains a stack; re-entering a key already on it yields
  `placeholder dependency cycle: a -> b -> a` and leaves the value verbatim.
- **Depth cap** — `MAX_RESOLUTION_DEPTH = 10`. Exceeding it yields a note naming the chain and leaves
  the placeholder verbatim.
- **Memoization is success-only.** Failures are depth- and stack-sensitive (recursion cap, cycle
  participation), so caching them would let the order of the first visit leak into later results.
  Keys are additionally resolved in sorted order for the same reason.
- Winning declarations reuse their authoritative table entry rather than being re-resolved, so
  records and table agree exactly even for depth-sensitive outcomes.

### Unresolved placeholders are retained deliberately

When a placeholder cannot be resolved — missing key, absent env var, Vault ref, cycle, recursion cap
— the **original placeholder text is left verbatim in `value`**. It is never blanked and never
replaced with a marker.

This is load-bearing. `${services.cdu.base-url}` is itself a stable join token: two beans wired to the
same unresolved placeholder still match each other across repos. The same reasoning drives
`normalize.ts`'s enrichment loop — when a `property_key_ref` is absent from the resolved table
entirely, the synthesized token `${<key>}` is used as the join key and logged.

### `process.env` is never read

Deliberate, for build determinism. A key matching `^[A-Z][A-Z0-9]*(_[A-Z0-9]+)*$` is recognized as an
OS environment variable and reported unresolved with reason `env var not present at index time (NAME)`
unless an inline default was supplied — in which case the default resolves. Reading the real
environment would make the index depend on the machine that built it.

### Vault references

Anything matching `(^|[^A-Za-z0-9_-])vault:` is never resolvable at index time; the value is left
verbatim, an unresolved note is emitted, and `is_secret` is set. `valueFragments` indexes **only the
placeholder token** for a vault value, never its path segments — a vault "path" is a secret address,
not a service path, so the join key survives without leaking structure.

### `valueFragments` — what a property value contributes

- Every `${...}` token, verbatim.
- For a URL or bare path, **cumulative** segments: `https://h/cdu-service/v1` yields `/cdu-service`
  and `/cdu-service/v1`.
- A segment that is itself a placeholder **resets** the accumulator, so `${cdu.host}/cdu-service`
  still yields `/cdu-service`.
- Pure numbers, booleanish values (`true|false|yes|no|on|off|null`), vault refs, and values with no
  `/` contribute only their placeholder tokens.

### Relaxed binding (ConfigMaps)

Only the top-level `data:` block is read. Each key is emitted verbatim (canonical, `is_alias: false`)
plus every relaxed-binding alias (`is_alias: true`). `SERVICES_CDU_TIMEOUT_MS` →
`services.cdu.timeout-ms`, using a fixed unit-suffix list (`ms`, `ns`, `s`, `sec`, `seconds`,
`millis`, `min`, `minutes`, `hours`, `days`, `bytes`, `kb`, `mb`, `gb`, …) to decide when a trailing
token hyphenates onto the previous one rather than becoming its own segment. Because SCREAMING_SNAKE →
dotted is genuinely ambiguous — nothing distinguishes `SERVICES_CDU_TIMEOUT_MS` from
`SPRING_PROFILES_ACTIVE` — the plain all-dots candidate is *also* emitted so joins work either way.

`is_alias` is a `RawProperty` field used only by the resolver's precedence rule. **It is not written
to disk.**

### Env from filename

`application.yml` → `default`; `application-dev.properties` → `dev`; `application-shared.yml` →
`shared`. Synonyms are folded: `develop`/`development`/`local` → `dev`; `qa`/`staging`/`stage` →
`uat`; `production`/`prd` → `prod`; `common` → `shared`. Unknown profiles fall back to `default`. A
Config Server `application.yml` applies to every app, so with `{isConfigServer: true}` a
dash-less basename maps to `shared` rather than `default`.

---

## Deviations from the original spec

Three implemented behaviours differ from the original specification. Each is documented as
implemented, with rationale.

### 1. `callgraph.fwd.json` — an additional bundle file

**Not in the original store spec.** The packed `callgraph.bin` is reverse-only (callee → callers),
which cannot serve producer-side *downstream* walks — handler → service → repository — without a full
scan of the entire edge array. The forward adjacency is therefore written alongside it as plain JSON.

Its exact shape is documented [above](#callgraphfwdjson).

**Three implementation details worth knowing:**

- It is written by `buildIndex` (`src/coordinator/build.ts`), **not** by `writeBundle`. The store
  layer has no knowledge of it: `bundlePaths` does not expose a path for it, and the filename lives in
  the exported constant `FORWARD_CALLGRAPH_FILE` in the coordinator.
- The write is wrapped in its own `try`/`failOpen`, so a failure to write it does not fail the build.
  Its byte count is folded into `WriteResult.bytes` under the key `callgraph.fwd.json` after the fact.
- **`loadBundle` does not read it.** `LoadedBundle` has no field for it. A consumer needing forward
  adjacency must read and parse the file itself. The design intent was for the daemon to load it
  separately — and since [no daemon exists in this tree](README.md#implementation-status--read-this-first),
  nothing currently reads it at all.

### 2. Candidate-set expansion in the build

**The spec's pre-filter matches only transport markers.** `BASE_MARKERS` in
`src/coordinator/filter.ts` is a fixed list: `@RestController`, `@Controller`, `@RequestMapping`, the
five verb mappings, `@KafkaListener`, `@JmsListener`, `@RabbitListener`, `RestTemplate`, `WebClient`,
`FeignClient`, `KafkaTemplate`, `JmsTemplate`, `RabbitTemplate`, `UriComponentsBuilder`, `UriBuilder`,
`@Value`, `@ConfigurationProperties`, `@Bean` — plus any configured message-router markers.

**Why a strict pre-filter is wrong here.** Plain POJO DTOs, services and repositories carry none of
those markers. A strict filter therefore yields **zero DTO records**, which silently destroys the
cross-repo DTO-shape join — the product's headline feature — and truncates every call chain at the
first unextracted service.

**What the build actually does.** `src/coordinator/build.ts` treats marker hits as **wave 1** and then
closes the candidate set over the in-repo types that wave actually referenced, iterating until no new
files appear or the cap is hit.

- **Structural markers.** `STRUCTURAL_MARKERS = ['@SpringBootApplication']` is appended to the
  configured message-router markers before pre-filtering. Rationale, verbatim from the code: it pulls
  in the boot class so its `main` is registered as an entry point — without it nothing in the repo
  references that file and the reference closure cannot reach it either.
- **Cap.** `MAX_EXPANSION_WAVES = 6`. On reaching it with work still pending, a
  `[LM] WARN reference-closure cap of 6 waves reached; N referenced file(s) were not extracted —
  partial index` is logged.
- **What counts as a reference** (`referencedFiles`). Every dotted identifier is scraped from these
  fields of the wave's extractions:

  | Source | Fields scraped |
  |---|---|
  | `endpoints` | `handler_class_fqn`, `request_dto_fqn`, `response_dto_fqn`, and the `declared_on` / `inherited_from` attributes of every annotation |
  | `invocations` | `enclosing_class_fqn`, `request_dto_fqn`, `response_dto_fqn` |
  | `dtos` | `fqn`, and every field's `type` |
  | `wirings` | `bean_class_fqn`, `defining_class_fqn` |
  | `property_bindings` | `class_fqn`, and every field's `type` |
  | `method_calls` | `caller_class_fqn`, `callee_class_fqn` |

  Generic type expressions are handled by scraping *every* dotted token, so `List<com.acme.Foo>`
  contributes `com.acme.Foo`.
- **Filtering and mapping.** Each collected FQN must pass `matchesPrefix` against
  `codeindex.packagePrefixes` (an empty prefix list matches everything). It is then mapped to a file
  by **suffix match** against the already-walked set — `com.acme.cdu.dto.CustomerDto` →
  `/com/acme/cdu/dto/CustomerDto.java` — which is robust to any source-root layout. Nested types
  (`Outer$Inner`) map to the outer type's file. Files already extracted are skipped, and the result is
  sorted for determinism.

**Effect.** In the CDU fixture the pre-filter keeps `lm_candidates: 4`, but `files_extracted: 9` —
the closure pulls in the DTOs, the service and the repository, which is what makes the DTO shapes and
the full handler → service → repository chain exist at all.

### 3. `endpoint.annotations.declaring_type` — a reserved synthetic annotation key

`Endpoint` has no field for the declaring interface FQN, and adding one would be a schema break, so
reconciliation records it as a synthetic entry in the `annotations` map under the reserved key
`declaring_type`, carrying `fqn`, `reconciliation_rule` and `merged_candidates`. Full field
documentation is [above](#reserved-synthetic-annotation-key-declaring_type); the ordered rule list is
[here](#interfaceimpl-reconciliation).

The key is **reserved**: a Java annotation genuinely named `declaring_type` would collide. Nothing
guards against that.

### Further synthetic / reserved keys

Checked across `normalize.ts` and `properties/resolve.ts`. Two more exist, both on
`InvocationRecord.annotations` — which, despite the field name, is a pipeline side-channel rather
than Java annotations:

| Key | Type | Set by | Purpose |
|---|---|---|---|
| `enclosing_method_name` | `string` | `normalize.ts` | Carried through from the model's `enclosing_method_name`. |
| `property_fragments` | `string[]` | `normalize.ts` enrichment loop | Sorted, deduped fragments derived by resolving `property_key_ref` across every materialized env. Feeds `manifest.path_fragments`; read back by name in the manifest-assembly loop. |

Two pipeline-added values also appear in `confidence_hints` alongside the model's own hints:
`path_fragment_from_property` and `property_fragments_recorded` (documented
[above](#kind-invocation--invocationrecord)).

**`is_alias` is not a store field.** It is a `RawProperty` field in
`src/extractor/properties/parse.ts`, set on relaxed-binding aliases synthesized from ConfigMap keys,
and consumed only by `winnerOf` in the resolver's precedence rule. It never reaches disk — neither on
`PropertyRecord` nor anywhere else.

---

## Known gaps

Stated plainly rather than papered over:

- `Endpoint.status_codes` is always `[]`.
- `Endpoint.visibility` never takes the value `"internal"`.
- `SymbolRecord.line_end` always equals `line_start`; `SymbolRecord.modifiers` is always `[]`.
- `LogicalNameRefRecord.context` is always `"openapi_operation_id"`.
- `AliasRecord` (`kind: "alias"`) is declared and bucketed but never produced.
- `SourceType` values `env_var` and `vault_ref` are declared but never assigned by any parser.
- `EntryPointKind` value `grpc_handler` is declared but never assigned.
- `WiringRecord.bean_class` and `property_key` coerce `null` to `""`, while `defining_class` stays
  `null` — inconsistent, but that is what is written.
- Config Server branch enumeration requires a `readBranch` hook that `buildIndex` does not supply;
  only the first configured branch is labelled. See the caveat in
  [README](README.md#configuration).
- The `QUERY` log stage is declared in the `Stage` union and never emitted.
