/**
 * The blast-radius orchestrator, plus the two hover/lens point lookups.
 *
 * THREE PHASES
 * ------------
 *  1. CONSUMPTION GATE — `isConsumed` per consumer, from its manifest alone. A
 *     consumer with no signal is still EMITTED, with `consumed: false` and the
 *     signals that were checked, and phases 2-3 are skipped for it. Silently
 *     omitting it would be wrong: the webview renders an explicit
 *     "not consumed" state and needs the row.
 *  2. JOIN — `findInvocations` per surviving consumer.
 *  3. BIDIRECTIONAL WALK —
 *       consumer side: upward from every matched invocation to its entry points;
 *       producer side: `walkFeeders` from the changed handler, populating BOTH
 *       `feeder_chains` (downstream) and `caller_chains` (upstream).
 *
 * `ConsumerBlastRadius.caller_chains` is a FLAT EDGE LIST, not a node list: the
 * webview walks it upward from each invocation symbol, so every edge on every
 * path from an invocation to an entry point has to be present. It is therefore
 * produced by an edge-recording BFS rather than derived from the node walk.
 *
 * Fail-open: a consumer that blows up is reported with whatever was computed for
 * it and the remaining consumers still run. Nothing here throws.
 */
import type {
  BlastRadiusResult,
  ChainNode,
  ChangedEndpoint,
  ConsumerBlastRadius,
  Endpoint,
  EntryPointRecord,
  InvocationHit,
  InvocationRecord,
  ProducerBlastRadius,
  UnresolvedRecord,
} from '../types.js';
import type { Logger } from '../util/logger.js';
import { silentLogger } from '../util/logger.js';
import type { LoadedBundle } from '../store/reader.js';
import type { QueryRepo } from './match.js';
import { findInvocations, isConsumed } from './match.js';
import { DEFAULT_MAX_DEPTH, entryPointsIn, walkCallers, walkFeeders } from './walk.js';

/** Structural view of the registry, so this module never imports `daemon.ts`. */
export interface RegistryLike {
  get(repo: string): QueryRepo | undefined;
}

export interface BlastRadiusOptions {
  maxDepth?: number;
  /**
   * The `ChangedEndpoint` under analysis. Synthesized from the producer endpoint
   * (as a no-reason `modified`) when omitted, so the query is usable for
   * "what would break if I touched this?" as well as for a real diff.
   */
  changed?: ChangedEndpoint | null;
  logger?: Logger;
}

type CallerEdge = ConsumerBlastRadius['caller_chains'][number];

function cmp(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** Synthesize a `ChangedEndpoint` from an `Endpoint`. */
export function changedFromEndpoint(ep: Endpoint): ChangedEndpoint {
  return {
    id: ep.id,
    change_kind: 'modified',
    diff_reason: [],
    diff_details: [],
    handler_symbol: ep.handler_symbol,
    file: ep.file,
    line: ep.line,
    transport: ep.transport,
    verb: ep.verb,
    path_template: ep.path_template,
    destination: ep.destination,
  };
}

function emptyChanged(id: string): ChangedEndpoint {
  return {
    id,
    change_kind: 'modified',
    diff_reason: [],
    diff_details: [],
    handler_symbol: null,
    file: null,
    line: null,
    transport: 'rest',
    verb: null,
    path_template: null,
    destination: null,
  };
}

function emptyProducer(repo: string): ProducerBlastRadius {
  return { repo, feeder_chains: [], caller_chains: [], total_affected_symbols: 0 };
}

function notConsumed(repo: string, signals: string[]): ConsumerBlastRadius {
  return {
    repo,
    consumed: false,
    phase1_signals: signals,
    direct_invocations: [],
    caller_chains: [],
    entry_points: [],
    total_affected_symbols: 0,
  };
}

/**
 * Edge-recording upward BFS. Emits every caller->callee edge on every path from
 * the seeds up to (and including the edge into) an entry point. Entry points are
 * terminals; the visited set makes it cycle-safe.
 *
 * `depth` is 0 for the edge whose callee is a seed, and increases upward — the
 * webview uses it purely for indentation.
 */
function callerEdges(
  bundle: LoadedBundle,
  seeds: readonly string[],
  maxDepth: number,
  entries: Map<string, EntryPointRecord>,
): { edges: CallerEdge[]; symbols: Set<string> } {
  const cg = bundle.callgraph;
  const edges: CallerEdge[] = [];
  const seen = new Set<string>();
  const symbols = new Set<string>(seeds.filter((s) => s !== ''));
  const visited = new Set<string>(symbols);
  let frontier = [...symbols].sort();

  for (let depth = 0; depth < maxDepth && frontier.length > 0; depth++) {
    const nextFrontier = new Set<string>();
    for (const callee of frontier) {
      for (const ref of cg.callersOfSymbol(callee)) {
        const caller = cg.symbolAt(ref.caller_index);
        if (caller === null || caller === '') {
          continue;
        }
        const file =
          ref.file_id >= 0 && ref.file_id < bundle.sourceMap.length
            ? bundle.sourceMap[ref.file_id] ?? ''
            : '';
        const edge: CallerEdge = { caller, callee, file, line: ref.line, depth };
        const key = `${caller}|${callee}|${file}|${edge.line}|${depth}`;
        if (!seen.has(key)) {
          seen.add(key);
          edges.push(edge);
        }
        symbols.add(caller);
        // Entry points are terminals — record the edge into them, stop there.
        if (!visited.has(caller) && !entries.has(caller)) {
          nextFrontier.add(caller);
        }
        visited.add(caller);
      }
    }
    frontier = [...nextFrontier].sort();
  }

  edges.sort(
    (a, b) => a.depth - b.depth || cmp(a.callee, b.callee) || cmp(a.caller, b.caller) || a.line - b.line,
  );
  return { edges, symbols };
}

function unresolvedKey(rec: UnresolvedRecord): string {
  return [
    rec.what,
    rec.context?.file ?? '',
    String(rec.context?.line ?? 0),
    rec.context?.enclosing_symbol ?? '',
    rec.reason,
  ].join('|');
}

class UnresolvedCollector {
  private readonly seen = new Set<string>();
  private readonly out: UnresolvedRecord[] = [];

  add(rec: UnresolvedRecord | undefined | null): void {
    if (!rec || rec.kind !== 'unresolved') {
      return;
    }
    const key = unresolvedKey(rec);
    if (this.seen.has(key)) {
      return;
    }
    this.seen.add(key);
    this.out.push(rec);
  }

  addAll(recs: Iterable<UnresolvedRecord>): void {
    for (const r of recs) {
      this.add(r);
    }
  }

  result(): UnresolvedRecord[] {
    return this.out
      .slice()
      .sort((a, b) =>
        cmp(
          `${a.what}|${a.context?.file ?? ''}|${String(a.context?.line ?? 0).padStart(8, '0')}|${a.reason}`,
          `${b.what}|${b.context?.file ?? ''}|${String(b.context?.line ?? 0).padStart(8, '0')}|${b.reason}`,
        ),
      );
  }
}

/** Property keys named by the `property_value:<key>` signals on a hit set. */
function propertyKeysOf(hits: readonly InvocationHit[]): string[] {
  const keys = new Set<string>();
  for (const hit of hits) {
    for (const signal of hit.matched_via) {
      if (signal.startsWith('property_value:')) {
        keys.add(signal.slice('property_value:'.length));
      }
    }
  }
  return [...keys].sort();
}

/**
 * Full cross-repo blast radius for one changed endpoint.
 *
 * A missing producer repo or endpoint yields an empty-but-well-formed result
 * rather than an exception: every field the webview reads is always present.
 */
export function blastRadius(
  registry: RegistryLike,
  producerRepo: string,
  consumerRepos: readonly string[],
  changedEndpointId: string,
  opts: BlastRadiusOptions = {},
): BlastRadiusResult {
  const logger = opts.logger ?? silentLogger;
  const maxDepth = opts.maxDepth ?? DEFAULT_MAX_DEPTH;
  const unresolvedAll = new UnresolvedCollector();

  let changed: ChangedEndpoint = opts.changed ?? emptyChanged(changedEndpointId);
  let producer: ProducerBlastRadius = emptyProducer(producerRepo);
  const consumers: ConsumerBlastRadius[] = [];

  let producerEndpoint: Endpoint | null = null;
  let producerRepoEntry: QueryRepo | undefined;

  /* ---------------- producer side -------------------------------------- */
  try {
    producerRepoEntry = registry.get(producerRepo);
    if (!producerRepoEntry) {
      logger.log('QUERY', `blastRadius: producer repo '${producerRepo}' is not loaded — empty producer radius`);
    } else {
      producerEndpoint = producerRepoEntry.bundle.endpointsById.get(changedEndpointId) ?? null;
      if (producerEndpoint === null) {
        logger.log(
          'QUERY',
          `blastRadius: endpoint ${changedEndpointId} not found in '${producerRepo}' — ` +
            'continuing with the change record alone',
        );
      } else if (opts.changed === undefined || opts.changed === null) {
        changed = changedFromEndpoint(producerEndpoint);
      }

      const handler = changed.handler_symbol ?? producerEndpoint?.handler_symbol ?? null;
      if (handler !== null && handler !== '') {
        const entries = producerRepoEntry.index.entryPointsBySymbol;
        const feeders = walkFeeders(producerRepoEntry.bundle, handler, maxDepth, {
          forward: producerRepoEntry.forward,
          entryPoints: entries,
          logger,
        });
        const affected = new Set<string>();
        for (const node of [...feeders.downstream, ...feeders.upstream]) {
          affected.add(node.symbol);
        }
        producer = {
          repo: producerRepo,
          feeder_chains: feeders.downstream,
          caller_chains: feeders.upstream,
          total_affected_symbols: affected.size,
        };

        // Producer-side unresolved: anything recorded against a symbol or file
        // the change actually touches.
        const files = new Set<string>();
        if (producerEndpoint !== null) {
          files.add(producerEndpoint.file);
        }
        for (const node of feeders.downstream) {
          if (node.call_site !== null) {
            files.add(node.call_site.file);
          }
        }
        for (const rec of producerRepoEntry.index.unresolved) {
          const sym = rec.context?.enclosing_symbol ?? null;
          if ((sym !== null && affected.has(sym)) || files.has(rec.context?.file ?? '')) {
            unresolvedAll.add(rec);
          }
        }
      }
    }
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('QUERY', `ERROR blastRadius producer side: ${detail} — empty producer radius`);
  }

  /* ---------------- consumer side --------------------------------------- */
  for (const consumerRepo of [...new Set(consumerRepos)].sort()) {
    try {
      const entry = registry.get(consumerRepo);
      if (!entry) {
        logger.log('QUERY', `blastRadius: consumer repo '${consumerRepo}' is not loaded — reported as not consumed`);
        consumers.push(notConsumed(consumerRepo, []));
        continue;
      }

      /* --- phase 1 ------------------------------------------------------ */
      const gate = isConsumed(changed, entry.bundle.manifest, { producerEndpoint, logger });
      if (!gate.consumed) {
        logger.log(
          'QUERY',
          `blastRadius: '${consumerRepo}' did not pass the phase-1 gate for ${changed.id} — ` +
            'phases 2-3 skipped',
        );
        consumers.push(notConsumed(consumerRepo, gate.signals));
        continue;
      }

      /* --- phase 2 ------------------------------------------------------ */
      const hits = findInvocations(entry.bundle, changed, {
        producerEndpoint,
        index: entry.index,
        logger,
      });

      /* --- phase 3 ------------------------------------------------------ */
      const entries = entry.index.entryPointsBySymbol;
      const seeds = [...new Set(hits.map((h) => h.symbol))].sort();
      const { edges, symbols } = callerEdges(entry.bundle, seeds, maxDepth, entries);

      const nodes: ChainNode[] = [];
      for (const seed of seeds) {
        nodes.push(
          ...walkCallers(entry.bundle, seed, maxDepth, { entryPoints: entries, logger }),
        );
      }
      for (const node of nodes) {
        symbols.add(node.symbol);
      }
      const reachedEntries = entryPointsIn(
        [...nodes, ...seeds.map((symbol) => ({ symbol }))],
        entries,
      );

      consumers.push({
        repo: consumerRepo,
        consumed: true,
        phase1_signals: gate.signals,
        direct_invocations: hits,
        caller_chains: edges,
        entry_points: reachedEntries,
        total_affected_symbols: symbols.size,
      });

      /* --- unresolved aggregation --------------------------------------- */
      for (const hit of hits) {
        unresolvedAll.addAll(entry.index.unresolvedByInvocation.get(hit.invocation_id) ?? []);
      }
      // Anything recorded against a symbol on a path from an invocation to an
      // entry point — e.g. the dynamically-resolved URL in EnrichmentService.
      for (const rec of entry.index.unresolved) {
        const sym = rec.context?.enclosing_symbol ?? null;
        if (sym !== null && symbols.has(sym)) {
          unresolvedAll.add(rec);
        }
      }
      // The property resolution itself: the property table is what carried the
      // join, so its unresolved entries (Vault refs, absent env vars) are part
      // of this analysis even though no single invocation owns them.
      const keys = new Set(propertyKeysOf(hits));
      for (const rec of entry.index.unresolved) {
        if (rec.what !== 'property_value') {
          continue;
        }
        const key = rec.partial_info?.['key'];
        if (typeof key === 'string' && (keys.has(key) || entry.index.manifest.propertyKeys.has(key))) {
          unresolvedAll.add(rec);
        }
      }
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      logger.log('QUERY', `ERROR blastRadius consumer '${consumerRepo}': ${detail} — reported as not consumed`);
      consumers.push(notConsumed(consumerRepo, []));
    }
  }

  consumers.sort((a, b) => cmp(a.repo, b.repo));

  return {
    changed_endpoint: changed,
    producer_blast_radius: producer,
    consumer_blast_radius: consumers,
    unresolved_across_analysis: unresolvedAll.result(),
  };
}

/* ------------------------------------------------------------------ *
 * Hover / code-lens point lookups
 * ------------------------------------------------------------------ */

/** How many lines away from the declaration/call line still counts as a hit. */
export const DEFAULT_LINE_TOLERANCE = 2;

export interface PointLookupOptions {
  tolerance?: number;
  /** Pre-indexed file -> records maps. Falls back to scanning when absent. */
  endpointsByFile?: Map<string, Endpoint[]>;
  invocationsByFile?: Map<string, InvocationRecord[]>;
  logger?: Logger;
}

/**
 * Records for `file`, tolerating an absolute path against a repo-relative index
 * (and vice versa) by falling back to a suffix match.
 */
function forFile<T extends { file: string }>(
  byFile: Map<string, T[]>,
  file: string,
): readonly T[] {
  const direct = byFile.get(file);
  if (direct) {
    return direct;
  }
  const normalized = file.split('\\').join('/');
  const hit = byFile.get(normalized);
  if (hit) {
    return hit;
  }
  for (const [key, list] of byFile) {
    if (normalized.endsWith(`/${key}`) || key.endsWith(`/${normalized}`)) {
      return list;
    }
  }
  return [];
}

/**
 * Closest record at or before `line`, else the closest one just after, within
 * `tolerance`. Ties break toward the later declaration, which is the innermost
 * one at that point.
 */
function closest<T extends { line: number }>(records: readonly T[], line: number, tolerance: number): T | null {
  let before: T | null = null;
  let after: T | null = null;
  for (const rec of records) {
    if (rec.line <= line) {
      if (before === null || rec.line >= before.line) {
        before = rec;
      }
    } else if (after === null || rec.line < after.line) {
      after = rec;
    }
  }
  if (before !== null && line - before.line <= tolerance) {
    return before;
  }
  if (after !== null && after.line - line <= tolerance) {
    return after;
  }
  return null;
}

/** The endpoint declared at (or just above) `file:line`, or null. */
export function getEndpointAt(
  bundle: LoadedBundle,
  file: string,
  line: number,
  opts: PointLookupOptions = {},
): Endpoint | null {
  const logger = opts.logger ?? silentLogger;
  try {
    let byFile = opts.endpointsByFile;
    if (!byFile) {
      byFile = new Map<string, Endpoint[]>();
      for (const ep of bundle.endpoints) {
        const list = byFile.get(ep.file);
        if (list) {
          list.push(ep);
        } else {
          byFile.set(ep.file, [ep]);
        }
      }
    }
    return closest(forFile(byFile, file), line, opts.tolerance ?? DEFAULT_LINE_TOLERANCE);
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('QUERY', `ERROR getEndpointAt(${file}:${line}): ${detail} — no endpoint reported`);
    return null;
  }
}

/** The outbound invocation at (or just above) `file:line`, or null. */
export function getInvocationAt(
  bundle: LoadedBundle,
  file: string,
  line: number,
  opts: PointLookupOptions = {},
): InvocationRecord | null {
  const logger = opts.logger ?? silentLogger;
  try {
    let byFile = opts.invocationsByFile;
    if (!byFile) {
      byFile = new Map<string, InvocationRecord[]>();
      for (const rec of bundle.byKind.invocation as InvocationRecord[]) {
        const list = byFile.get(rec.file);
        if (list) {
          list.push(rec);
        } else {
          byFile.set(rec.file, [rec]);
        }
      }
    }
    return closest(forFile(byFile, file), line, opts.tolerance ?? DEFAULT_LINE_TOLERANCE);
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('QUERY', `ERROR getInvocationAt(${file}:${line}): ${detail} — no invocation reported`);
    return null;
  }
}
