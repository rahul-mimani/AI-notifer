/** Daemon query layer barrel: registry, diffing, matching, walks, blast radius. */

export {
  FORWARD_CALLGRAPH_FILE,
  emptyForwardIndex,
  forwardIndexFrom,
  loadForwardCallgraph,
} from './forward.js';
export type { ForwardAdjacency, ForwardCallSite, ForwardIndex } from './forward.js';

export { detectChanges, loadFingerprints } from './changes.js';
export type { DetectChangesOptions, FingerprintSource } from './changes.js';

export {
  SIGNAL_WEIGHTS,
  buildBundleIndex,
  collapseToken,
  enclosingClassOf,
  findInvocations,
  isConsumed,
  manifestIndex,
} from './match.js';
export type {
  BundleIndex,
  ConsumedResult,
  FindInvocationsOptions,
  ManifestIndex,
  MatchContext,
  QueryRepo,
} from './match.js';

export { DEFAULT_MAX_DEPTH, entryPointsIn, walkCallers, walkFeeders } from './walk.js';
export type { FeederResult, WalkOptions } from './walk.js';

export {
  DEFAULT_LINE_TOLERANCE,
  blastRadius,
  changedFromEndpoint,
  getEndpointAt,
  getInvocationAt,
} from './blast.js';
export type { BlastRadiusOptions, PointLookupOptions, RegistryLike } from './blast.js';

export { IndexRegistry } from './daemon.js';
export type { LoadedRepo } from './daemon.js';
