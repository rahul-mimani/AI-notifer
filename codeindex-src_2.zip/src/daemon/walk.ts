/**
 * Callgraph walks.
 *
 * `walkCallers`  — UPWARD (who calls this?) over the packed reverse adjacency in
 *                  `callgraph.bin`. Entry points are TERMINALS: reaching one
 *                  records it and stops, because an entry point is by definition
 *                  the top of a chain and expanding past it produces noise.
 *
 * `walkFeeders`  — BOTH directions from a producer handler:
 *                  `downstream` (handler -> service -> repository) over the
 *                  forward map, which is the primary producer-side view, and
 *                  `upstream`, the same reverse walk as `walkCallers`. Upstream
 *                  is normally EMPTY for a controller handler — nothing in the
 *                  repo calls it, the framework does — and that empty result is
 *                  correct, not a failure.
 *
 * Both walks are breadth-first, depth-capped, cycle-safe (visited set) and emit
 * nodes in deterministic BFS order (siblings sorted by symbol id).
 *
 * DEPTH CONVENTION
 *   walkCallers   depth 1 = a direct caller. The seed is NOT included — the
 *                 result answers "who is upstream of this", not "what is this".
 *   walkFeeders   downstream depth 0 = the handler itself, 1 = what it calls.
 *                 The seed is included so the producer view renders as a tree
 *                 rooted at the changed handler.
 */
import type { ChainNode, EntryPointKind, EntryPointRecord, SymbolRecord } from '../types.js';
import type { Logger } from '../util/logger.js';
import { silentLogger } from '../util/logger.js';
import type { LoadedBundle } from '../store/reader.js';
import type { ForwardIndex } from './forward.js';
import { emptyForwardIndex } from './forward.js';

export const DEFAULT_MAX_DEPTH = 4;

export interface WalkOptions {
  /** Forward adjacency. Required for `walkFeeders().downstream`. */
  forward?: ForwardIndex;
  /** Pre-built symbol -> entry-point map. Derived from the bundle when absent. */
  entryPoints?: Map<string, EntryPointRecord>;
  logger?: Logger;
}

export interface FeederResult {
  /** Forward walk: what the handler calls. Includes the handler at depth 0. */
  downstream: ChainNode[];
  /** Reverse walk: in-repo callers of the handler. Often legitimately empty. */
  upstream: ChainNode[];
}

function entryPointMap(
  bundle: LoadedBundle,
  provided?: Map<string, EntryPointRecord>,
): Map<string, EntryPointRecord> {
  if (provided) {
    return provided;
  }
  const map = new Map<string, EntryPointRecord>();
  for (const rec of bundle.byKind.entry_point as EntryPointRecord[]) {
    map.set(rec.symbol, rec);
  }
  return map;
}

/** `file_id` -> repo-relative path, via the bundle's source map. */
function fileOf(bundle: LoadedBundle, fileId: number): string | null {
  if (!Number.isInteger(fileId) || fileId < 0 || fileId >= bundle.sourceMap.length) {
    return null;
  }
  return bundle.sourceMap[fileId] ?? null;
}

function makeNode(
  symbol: string,
  depth: number,
  callSite: { file: string; line: number } | null,
  entry: EntryPointRecord | undefined,
): ChainNode {
  return {
    symbol,
    depth,
    call_site: callSite,
    is_entry_point: entry !== undefined,
    entry_kind: entry?.entry_kind ?? null,
  };
}

function clampDepth(maxDepth: number): number {
  if (!Number.isFinite(maxDepth) || maxDepth < 0) {
    return DEFAULT_MAX_DEPTH;
  }
  return Math.floor(maxDepth);
}

/**
 * BFS upward over the reverse adjacency. Cycle-safe, depth-capped, entry points
 * terminal. Returns callers only (the seed is not included).
 */
export function walkCallers(
  bundle: LoadedBundle,
  symbolId: string,
  maxDepth: number = DEFAULT_MAX_DEPTH,
  opts: WalkOptions = {},
): ChainNode[] {
  const logger = opts.logger ?? silentLogger;
  const out: ChainNode[] = [];

  try {
    const cap = clampDepth(maxDepth);
    if (cap === 0 || symbolId === '') {
      return out;
    }
    const entries = entryPointMap(bundle, opts.entryPoints);
    const cg = bundle.callgraph;

    const visited = new Set<string>([symbolId]);
    let frontier: string[] = [symbolId];

    for (let depth = 1; depth <= cap && frontier.length > 0; depth++) {
      // (symbol -> best call site) so a node reached twice at the same depth is
      // emitted once, with the lowest-line call site for stability.
      const next = new Map<string, { file: string; line: number } | null>();

      for (const callee of frontier) {
        for (const ref of cg.callersOfSymbol(callee)) {
          const caller = cg.symbolAt(ref.caller_index);
          if (caller === null || caller === '' || visited.has(caller)) {
            continue;
          }
          const file = fileOf(bundle, ref.file_id);
          const site = file === null ? null : { file, line: ref.line };
          const existing = next.get(caller);
          if (existing === undefined || (site !== null && existing !== null && site.line < existing.line)) {
            next.set(caller, site);
          }
        }
      }

      const nextFrontier: string[] = [];
      for (const caller of [...next.keys()].sort()) {
        visited.add(caller);
        const entry = entries.get(caller);
        out.push(makeNode(caller, depth, next.get(caller) ?? null, entry));
        // Entry points are TERMINALS — never expanded past.
        if (entry === undefined) {
          nextFrontier.push(caller);
        }
      }
      frontier = nextFrontier;
    }
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('QUERY', `ERROR walkCallers(${symbolId}): ${detail} — returning ${out.length} partial node(s)`);
  }

  return out;
}

/**
 * BFS downward over the forward adjacency. Cycle-safe, depth-capped. Includes
 * the seed at depth 0, whose call site is its own declaration line.
 */
function walkDownstream(
  bundle: LoadedBundle,
  symbolId: string,
  cap: number,
  forward: ForwardIndex,
  entries: Map<string, EntryPointRecord>,
): ChainNode[] {
  const out: ChainNode[] = [];
  if (symbolId === '') {
    return out;
  }

  const seedSymbol = bundle.symbolsById.get(symbolId) as SymbolRecord | undefined;
  const seedEntry = entries.get(symbolId);
  out.push(
    makeNode(
      symbolId,
      0,
      seedSymbol ? { file: seedSymbol.file, line: seedSymbol.line_start } : null,
      seedEntry,
    ),
  );

  const visited = new Set<string>([symbolId]);
  let frontier: string[] = [symbolId];

  for (let depth = 1; depth <= cap && frontier.length > 0; depth++) {
    const next = new Map<string, { file: string; line: number } | null>();
    for (const caller of frontier) {
      for (const site of forward.calleesOf(caller)) {
        if (site.callee === '' || visited.has(site.callee)) {
          continue;
        }
        const file = fileOf(bundle, site.file_id);
        const callSite = file === null ? null : { file, line: site.line };
        const existing = next.get(site.callee);
        if (
          existing === undefined ||
          (callSite !== null && existing !== null && callSite.line < existing.line)
        ) {
          next.set(site.callee, callSite);
        }
      }
    }

    const nextFrontier: string[] = [];
    for (const callee of [...next.keys()].sort()) {
      visited.add(callee);
      out.push(makeNode(callee, depth, next.get(callee) ?? null, entries.get(callee)));
      nextFrontier.push(callee);
    }
    frontier = nextFrontier;
  }

  return out;
}

/**
 * Both directions from a producer handler. `downstream` needs the forward map;
 * without one it degrades to just the seed node and logs why.
 */
export function walkFeeders(
  bundle: LoadedBundle,
  handlerSymbolId: string,
  maxDepth: number = DEFAULT_MAX_DEPTH,
  opts: WalkOptions = {},
): FeederResult {
  const logger = opts.logger ?? silentLogger;
  let downstream: ChainNode[] = [];
  let upstream: ChainNode[] = [];

  try {
    const cap = clampDepth(maxDepth);
    const entries = entryPointMap(bundle, opts.entryPoints);
    const forward = opts.forward ?? emptyForwardIndex();
    if (!forward.present) {
      logger.log(
        'QUERY',
        `walkFeeders(${handlerSymbolId}): no forward callgraph available — ` +
          'downstream chain will contain the handler only',
      );
    }
    downstream = walkDownstream(bundle, handlerSymbolId, cap, forward, entries);
    upstream = walkCallers(bundle, handlerSymbolId, cap, { ...opts, entryPoints: entries });
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('QUERY', `ERROR walkFeeders(${handlerSymbolId}): ${detail} — returning partial chains`);
  }

  return { downstream, upstream };
}

/** Entry-point nodes reached by a walk, sorted by symbol. */
export function entryPointsIn(
  nodes: readonly { symbol: string }[],
  entries: Map<string, EntryPointRecord>,
): Array<{ symbol: string; entry_kind: EntryPointKind; details: Record<string, unknown> | null }> {
  const seen = new Map<string, EntryPointRecord>();
  for (const node of nodes) {
    const rec = entries.get(node.symbol);
    if (rec && !seen.has(node.symbol)) {
      seen.set(node.symbol, rec);
    }
  }
  return [...seen.keys()]
    .sort()
    .map((symbol) => {
      const rec = seen.get(symbol)!;
      return { symbol, entry_kind: rec.entry_kind, details: rec.details ?? null };
    });
}
