/**
 * Fingerprint diffing: two bundles in, `ChangedEndpoint[]` out.
 *
 * IDENTITY, AND WHY RENAME PAIRING EXISTS
 * ---------------------------------------
 * `endpointId` hashes (transport, verb, DISPLAY path template, handler symbol),
 * so an endpoint whose path template changes gets a NEW id — a pure id join
 * would report that as one `removed` plus one `added` and `path_changed` could
 * never be emitted at all. That is a worse answer than the truth: the handler is
 * the same method, its route moved.
 *
 * So the diff runs in two passes:
 *   1. join on `id` — added / removed / modified;
 *   2. pair leftover added/removed endpoints that share a handler symbol and
 *      transport, and re-classify them as `modified` with `path_changed`.
 * Pass 2 needs the handler symbols, which live on `Endpoint`, not `Fingerprint`,
 * so it only runs when the bundles are supplied. Without them the diff degrades
 * to id-only add/remove, which is still correct, just less specific.
 *
 * DTO FIELD DETAIL
 * ----------------
 * A shape-hash change says THAT the payload changed, not WHAT changed. When both
 * bundles are available the DTO records behind the shapes are diffed field by
 * field to emit `dto_field_added` / `dto_field_removed` / `dto_field_type_changed`
 * plus per-field before/after. Without the bundles the reason set degrades
 * gracefully to the shape-hash reasons alone.
 *
 * Deterministic: output is sorted by id; `diff_reason` is emitted in a fixed
 * canonical order; `diff_details` is sorted by field name.
 */
import * as fs from 'node:fs';

import type {
  ChangedEndpoint,
  DiffReason,
  DtoRecord,
  Endpoint,
  FieldDiff,
  Fingerprint,
  Transport,
} from '../types.js';
import type { Logger } from '../util/logger.js';
import { silentLogger } from '../util/logger.js';
import { bundlePaths } from '../store/paths.js';
import { readJsonl } from '../store/jsonl.js';
import type { LoadedBundle } from '../store/reader.js';

/** Canonical emission order for `diff_reason`. */
const REASON_ORDER: readonly DiffReason[] = [
  'path_changed',
  'verb_changed',
  'destination_changed',
  'request_dto_shape_changed',
  'response_dto_shape_changed',
  'dto_field_added',
  'dto_field_removed',
  'dto_field_type_changed',
];

export interface DetectChangesOptions {
  /** Enables verb detail, DTO field diffs and rename pairing. */
  oldBundle?: LoadedBundle | null;
  newBundle?: LoadedBundle | null;
  logger?: Logger;
  /** Pair leftover add/remove by handler symbol. Default true when both bundles are given. */
  detectRenames?: boolean;
}

/** Either an already-loaded array or a path to read one from. */
export type FingerprintSource = string | readonly Fingerprint[];

function cmp(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/**
 * Accept a `fingerprints.jsonl` path, a `.codeindex` directory or a repo root.
 * Anything unreadable degrades to an empty list rather than throwing.
 */
export function loadFingerprints(source: FingerprintSource, logger: Logger): Fingerprint[] {
  if (typeof source !== 'string') {
    return [...source];
  }
  let file = source;
  try {
    if (!file.endsWith('.jsonl')) {
      file = bundlePaths(file.endsWith('.codeindex') ? `${file}/..` : file).fingerprints;
    }
    if (!fs.existsSync(file)) {
      logger.log('QUERY', `no fingerprints at ${file} — treating as an empty set`);
      return [];
    }
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('QUERY', `ERROR resolving fingerprints path ${source}: ${detail} — empty set`);
    return [];
  }
  return readJsonl<Fingerprint>(file, logger, 'QUERY');
}

function dtoIndex(bundle: LoadedBundle | null | undefined): Map<string, DtoRecord> {
  const out = new Map<string, DtoRecord>();
  if (!bundle) {
    return out;
  }
  for (const rec of bundle.byKind.dto as DtoRecord[]) {
    if (!out.has(rec.fqn)) {
      out.set(rec.fqn, rec);
    }
  }
  return out;
}

function simpleName(fqn: string): string {
  const bare = fqn.split('<')[0]!;
  const dot = bare.lastIndexOf('.');
  return dot < 0 ? bare : bare.slice(dot + 1);
}

/** Resolve a DTO record, tolerating `List<Foo>`-style container declarations. */
function resolveDto(index: Map<string, DtoRecord>, fqn: string | null): DtoRecord | undefined {
  if (fqn === null || fqn === '') {
    return undefined;
  }
  const direct = index.get(fqn);
  if (direct) {
    return direct;
  }
  const open = fqn.indexOf('<');
  if (open >= 0 && fqn.endsWith('>')) {
    return index.get(fqn.slice(open + 1, -1).split(',')[0]!.trim());
  }
  return undefined;
}

/**
 * Field-level diff of one DTO pair. Emits one `FieldDiff` per changed field
 * (added -> before null, removed -> after null) plus the reasons that fired.
 */
function diffDto(
  before: DtoRecord | undefined,
  after: DtoRecord | undefined,
): { reasons: DiffReason[]; details: FieldDiff[] } {
  const reasons = new Set<DiffReason>();
  const details: FieldDiff[] = [];
  if (!before && !after) {
    return { reasons: [], details: [] };
  }

  const label = simpleName(after?.fqn ?? before?.fqn ?? '');
  const beforeFields = new Map((before?.fields ?? []).map((f) => [f.name, f.type] as const));
  const afterFields = new Map((after?.fields ?? []).map((f) => [f.name, f.type] as const));

  for (const name of [...new Set([...beforeFields.keys(), ...afterFields.keys()])].sort()) {
    const b = beforeFields.get(name) ?? null;
    const a = afterFields.get(name) ?? null;
    if (b === a) {
      continue;
    }
    if (b === null) {
      reasons.add('dto_field_added');
    } else if (a === null) {
      reasons.add('dto_field_removed');
    } else {
      reasons.add('dto_field_type_changed');
    }
    details.push({ field: `${label}.${name}`, before: b, after: a });
  }

  return { reasons: [...reasons], details };
}

interface Sides {
  oldFp: Fingerprint | null;
  newFp: Fingerprint | null;
  oldEp: Endpoint | null;
  newEp: Endpoint | null;
}

function buildChanged(
  id: string,
  kind: ChangedEndpoint['change_kind'],
  sides: Sides,
  reasons: Iterable<DiffReason>,
  details: FieldDiff[],
): ChangedEndpoint {
  const fp = sides.newFp ?? sides.oldFp;
  const ep = sides.newEp ?? sides.oldEp;
  const reasonSet = new Set(reasons);
  return {
    id,
    change_kind: kind,
    diff_reason: REASON_ORDER.filter((r) => reasonSet.has(r)),
    diff_details: details
      .slice()
      .sort((a, b) => cmp(a.field, b.field)),
    handler_symbol: ep?.handler_symbol ?? null,
    file: ep?.file ?? null,
    line: ep?.line ?? null,
    transport: (ep?.transport ?? fp?.transport ?? 'rest') as Transport,
    verb: ep?.verb ?? null,
    path_template: ep?.path_template ?? fp?.path_template ?? null,
    destination: ep?.destination ?? fp?.destination ?? null,
  };
}

/** Everything that differs between two fingerprints of the same endpoint. */
function diffPair(
  sides: Sides,
  oldDtos: Map<string, DtoRecord>,
  newDtos: Map<string, DtoRecord>,
): { reasons: Set<DiffReason>; details: FieldDiff[] } {
  const reasons = new Set<DiffReason>();
  const details: FieldDiff[] = [];
  const { oldFp, newFp, oldEp, newEp } = sides;

  const oldPath = oldEp?.path_template ?? oldFp?.path_template ?? null;
  const newPath = newEp?.path_template ?? newFp?.path_template ?? null;
  if (oldPath !== newPath) {
    reasons.add('path_changed');
    details.push({ field: 'path_template', before: oldPath, after: newPath });
  }

  // `Fingerprint` carries no verb, so this only fires with both bundles.
  if (oldEp && newEp && oldEp.verb !== newEp.verb) {
    reasons.add('verb_changed');
    details.push({ field: 'verb', before: oldEp.verb, after: newEp.verb });
  }

  const oldDest = oldEp?.destination ?? oldFp?.destination ?? null;
  const newDest = newEp?.destination ?? newFp?.destination ?? null;
  if (oldDest !== newDest) {
    reasons.add('destination_changed');
    details.push({ field: 'destination', before: oldDest, after: newDest });
  }

  for (const side of ['request', 'response'] as const) {
    const oldShape =
      side === 'request'
        ? oldEp?.request_dto_shape ?? oldFp?.request_dto_shape ?? null
        : oldEp?.response_dto_shape ?? oldFp?.response_dto_shape ?? null;
    const newShape =
      side === 'request'
        ? newEp?.request_dto_shape ?? newFp?.request_dto_shape ?? null
        : newEp?.response_dto_shape ?? newFp?.response_dto_shape ?? null;
    if (oldShape === newShape) {
      continue;
    }
    reasons.add(side === 'request' ? 'request_dto_shape_changed' : 'response_dto_shape_changed');
    details.push({ field: `${side}_dto_shape`, before: oldShape, after: newShape });

    // DTO-level detail, when both sides' records are available.
    const oldFqn = side === 'request' ? oldEp?.request_dto_fqn ?? null : oldEp?.response_dto_fqn ?? null;
    const newFqn = side === 'request' ? newEp?.request_dto_fqn ?? null : newEp?.response_dto_fqn ?? null;
    const beforeDto = resolveDto(oldDtos, oldFqn);
    const afterDto = resolveDto(newDtos, newFqn);
    if (beforeDto || afterDto) {
      const fieldDiff = diffDto(beforeDto, afterDto);
      for (const r of fieldDiff.reasons) {
        reasons.add(r);
      }
      details.push(...fieldDiff.details);
    }
  }

  return { reasons, details };
}

/**
 * Diff two fingerprint sets.
 *
 * Both arguments accept either a path (to `fingerprints.jsonl`, a `.codeindex`
 * directory or a repo root) or an already-loaded `Fingerprint[]`.
 *
 * Never throws: a failure anywhere logs and returns whatever was computed.
 */
export function detectChanges(
  oldFingerprints: FingerprintSource,
  newFingerprints: FingerprintSource,
  opts: DetectChangesOptions = {},
): ChangedEndpoint[] {
  const logger = opts.logger ?? silentLogger;
  const out: ChangedEndpoint[] = [];

  try {
    const oldList = loadFingerprints(oldFingerprints, logger);
    const newList = loadFingerprints(newFingerprints, logger);
    const oldBundle = opts.oldBundle ?? null;
    const newBundle = opts.newBundle ?? null;
    const oldDtos = dtoIndex(oldBundle);
    const newDtos = dtoIndex(newBundle);

    const oldById = new Map(oldList.map((f) => [f.id, f] as const));
    const newById = new Map(newList.map((f) => [f.id, f] as const));
    const sidesOf = (id: string): Sides => ({
      oldFp: oldById.get(id) ?? null,
      newFp: newById.get(id) ?? null,
      oldEp: oldBundle?.endpointsById.get(id) ?? null,
      newEp: newBundle?.endpointsById.get(id) ?? null,
    });

    /* --- pass 1: join on id -------------------------------------------- */
    const removedIds: string[] = [];
    const addedIds: string[] = [];

    for (const id of [...oldById.keys()].sort()) {
      if (!newById.has(id)) {
        removedIds.push(id);
      }
    }
    for (const id of [...newById.keys()].sort()) {
      if (!oldById.has(id)) {
        addedIds.push(id);
      }
    }

    for (const id of [...newById.keys()].sort()) {
      const oldFp = oldById.get(id);
      const newFp = newById.get(id)!;
      if (!oldFp) {
        continue;
      }
      const sides = sidesOf(id);
      // The fingerprint hash is the fast path; a matching hash cannot hide a
      // wire-visible change, so nothing further needs comparing.
      if (oldFp.fingerprint === newFp.fingerprint) {
        continue;
      }
      const { reasons, details } = diffPair(sides, oldDtos, newDtos);
      if (reasons.size === 0) {
        logger.log(
          'QUERY',
          `endpoint ${id} fingerprint changed but no field-level reason was derivable — ` +
            'reporting it as modified with an empty reason set',
        );
      }
      out.push(buildChanged(id, 'modified', sides, reasons, details));
    }

    /* --- pass 2: rename pairing ----------------------------------------- */
    const detectRenames = opts.detectRenames ?? (oldBundle !== null && newBundle !== null);
    const pairedRemoved = new Set<string>();
    const pairedAdded = new Set<string>();

    if (detectRenames && oldBundle && newBundle) {
      // handler symbol + transport is stable across a route change.
      const removedByHandler = new Map<string, string[]>();
      for (const id of removedIds) {
        const ep = oldBundle.endpointsById.get(id);
        if (!ep) {
          continue;
        }
        const key = `${ep.transport}|${ep.handler_symbol}`;
        const list = removedByHandler.get(key);
        if (list) {
          list.push(id);
        } else {
          removedByHandler.set(key, [id]);
        }
      }
      for (const newId of addedIds) {
        const newEp = newBundle.endpointsById.get(newId);
        if (!newEp) {
          continue;
        }
        const key = `${newEp.transport}|${newEp.handler_symbol}`;
        const candidates = (removedByHandler.get(key) ?? []).filter((id) => !pairedRemoved.has(id));
        if (candidates.length !== 1) {
          continue;
        }
        const oldId = candidates[0]!;
        pairedRemoved.add(oldId);
        pairedAdded.add(newId);

        const sides: Sides = {
          oldFp: oldById.get(oldId) ?? null,
          newFp: newById.get(newId) ?? null,
          oldEp: oldBundle.endpointsById.get(oldId) ?? null,
          newEp,
        };
        const { reasons, details } = diffPair(sides, oldDtos, newDtos);
        logger.log(
          'QUERY',
          `endpoint ${oldId} -> ${newId} paired by handler symbol ${newEp.handler_symbol}: ` +
            `reported as modified (${[...reasons].sort().join(', ') || 'no reason derivable'}) ` +
            'rather than a remove + add',
        );
        out.push(buildChanged(newId, 'modified', sides, reasons, details));
      }
    }

    /* --- leftovers ------------------------------------------------------ */
    for (const id of removedIds) {
      if (pairedRemoved.has(id)) {
        continue;
      }
      out.push(buildChanged(id, 'removed', sidesOf(id), [], []));
    }
    for (const id of addedIds) {
      if (pairedAdded.has(id)) {
        continue;
      }
      out.push(buildChanged(id, 'added', sidesOf(id), [], []));
    }

    out.sort((a, b) => cmp(a.id, b.id));
    logger.log(
      'QUERY',
      `detectChanges: ${oldList.length} -> ${newList.length} fingerprints, ${out.length} change(s) ` +
        `(${out.filter((c) => c.change_kind === 'added').length} added, ` +
        `${out.filter((c) => c.change_kind === 'removed').length} removed, ` +
        `${out.filter((c) => c.change_kind === 'modified').length} modified)`,
    );
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('QUERY', `ERROR detectChanges: ${detail} — returning ${out.length} partial change(s)`);
  }

  return out;
}
