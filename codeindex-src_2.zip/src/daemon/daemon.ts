/**
 * The memory-resident index registry and the public query API.
 *
 * A bundle is loaded ONCE per repo and kept in memory with every lookup map it
 * needs already built (`buildBundleIndex`), so a query is a sequence of map
 * lookups rather than a scan over records. `[DAEMON]` logs cover bundle sizes
 * and load times; `[QUERY]` logs cover every public query's kind, latency and
 * result counts.
 *
 * No `vscode` import: the whole layer is drivable from plain Node, which is what
 * makes `sanity/daemon-sanity.ts` possible.
 *
 * Fail-open everywhere. A query against a repo that is not loaded returns an
 * empty-but-well-formed result and logs; nothing here throws.
 */
import * as path from 'node:path';

import type {
  BlastRadiusResult,
  ChainNode,
  ChangedEndpoint,
  Endpoint,
  Fingerprint,
  InvocationHit,
  InvocationRecord,
} from '../types.js';
import type { Logger } from '../util/logger.js';
import { silentLogger } from '../util/logger.js';
import { loadBundle } from '../store/reader.js';
import type { LoadedBundle } from '../store/reader.js';
import type { BlastRadiusOptions, RegistryLike } from './blast.js';
import { blastRadius, getEndpointAt, getInvocationAt } from './blast.js';
import type { DetectChangesOptions, FingerprintSource } from './changes.js';
import { detectChanges } from './changes.js';
import type { ForwardIndex } from './forward.js';
import { loadForwardCallgraph } from './forward.js';
import type { BundleIndex, ConsumedResult, FindInvocationsOptions, QueryRepo } from './match.js';
import { buildBundleIndex, findInvocations, isConsumed } from './match.js';
import type { FeederResult, WalkOptions } from './walk.js';
import { DEFAULT_MAX_DEPTH, walkCallers, walkFeeders } from './walk.js';

/** One repo held in memory. Structurally a `QueryRepo`. */
export interface LoadedRepo extends QueryRepo {
  repo: string;
  repoRoot: string;
  bundle: LoadedBundle;
  index: BundleIndex;
  forward: ForwardIndex;
  loadedAt: number;
  loadMs: number;
}

function fmtMs(started: number): number {
  return Date.now() - started;
}

/**
 * Memory-resident bundle registry.
 *
 * Repos are keyed by name — `meta.repo` when the bundle declares one, otherwise
 * the basename of the repo root — so queries address repos the way the rest of
 * the system talks about them.
 */
export class IndexRegistry implements RegistryLike {
  private readonly repos = new Map<string, LoadedRepo>();
  private readonly logger: Logger;

  constructor(logger: Logger = silentLogger) {
    this.logger = logger;
  }

  /** Repo names currently held, sorted. */
  list(): string[] {
    return [...this.repos.keys()].sort();
  }

  get(repo: string): LoadedRepo | undefined {
    return this.repos.get(repo);
  }

  has(repo: string): boolean {
    return this.repos.has(repo);
  }

  /**
   * Load `<repoRoot>/.codeindex` (bundle + forward callgraph + lookup maps) and
   * cache it. A repo already loaded from the same root is returned as-is; use
   * `reload` to force a re-read.
   */
  load(repoRoot: string, logger: Logger = this.logger, repoName?: string): LoadedRepo {
    const started = Date.now();
    const absRoot = path.resolve(repoRoot);

    for (const existing of this.repos.values()) {
      if (existing.repoRoot === absRoot && (repoName === undefined || existing.repo === repoName)) {
        logger.log('DAEMON', `bundle for '${existing.repo}' already resident — reusing (loaded ${existing.loadMs}ms ago)`);
        return existing;
      }
    }

    const bundle = loadBundle(absRoot, logger);
    const forward = loadForwardCallgraph(absRoot, logger);
    const index = buildBundleIndex(bundle, logger);
    const repo = repoName ?? (bundle.meta.repo !== '' ? bundle.meta.repo : path.basename(absRoot));
    const loadMs = fmtMs(started);

    const entry: LoadedRepo = {
      repo,
      repoRoot: absRoot,
      bundle,
      index,
      forward,
      loadedAt: Date.now(),
      loadMs,
    };
    this.repos.set(repo, entry);

    logger.log(
      'DAEMON',
      `registry: '${repo}' resident after ${loadMs}ms — ` +
        `${bundle.records.length} records, ${bundle.endpoints.length} endpoints, ` +
        `${bundle.fingerprints.length} fingerprints, ${index.invocations.length} invocations, ` +
        `${index.dtosByShape.size} dto shapes, ${index.entryPointsBySymbol.size} entry points, ` +
        `callgraph ${bundle.callgraph.symbolCountValue} symbols / ${bundle.callgraph.edgeCountValue} reverse edges, ` +
        `forward ${forward.callerCount} callers / ${forward.edgeCount} edges, ` +
        `manifest ${index.manifest.dtoShapes.size} shapes / ${index.manifest.pathFragments.size} fragments`,
    );
    return entry;
  }

  /** Drop and re-read a repo from disk. Loads it if it was not resident. */
  reload(repo: string, logger: Logger = this.logger): LoadedRepo | undefined {
    const existing = this.repos.get(repo);
    if (!existing) {
      logger.log('DAEMON', `reload('${repo}'): not resident — nothing to reload`);
      return undefined;
    }
    const root = existing.repoRoot;
    this.repos.delete(repo);
    logger.log('DAEMON', `reload('${repo}') from ${root}`);
    return this.load(root, logger, repo);
  }

  /** Evict a repo. Returns true when something was evicted. */
  unload(repo: string, logger: Logger = this.logger): boolean {
    const had = this.repos.delete(repo);
    logger.log('DAEMON', had ? `unloaded '${repo}'` : `unload('${repo}'): not resident`);
    return had;
  }

  unloadAll(logger: Logger = this.logger): void {
    const n = this.repos.size;
    this.repos.clear();
    logger.log('DAEMON', `unloaded all ${n} repo(s)`);
  }

  /* ---------------------------------------------------------------- *
   * Public query API. Every method logs [QUERY] kind, latency, counts.
   * ---------------------------------------------------------------- */

  private query<T>(kind: string, detail: string, run: () => T, count: (result: T) => string): T {
    const started = Date.now();
    let result: T;
    try {
      result = run();
    } catch (err) {
      const err_ = err instanceof Error ? err.message : String(err);
      this.logger.log('QUERY', `${kind}(${detail}) ERROR after ${fmtMs(started)}ms: ${err_}`);
      throw err;
    }
    this.logger.log('QUERY', `${kind}(${detail}) ${fmtMs(started)}ms -> ${count(result)}`);
    return result;
  }

  /** Endpoints of a resident repo, in bundle order. */
  endpoints(repo: string): Endpoint[] {
    return this.get(repo)?.bundle.endpoints ?? [];
  }

  fingerprints(repo: string): Fingerprint[] {
    return this.get(repo)?.bundle.fingerprints ?? [];
  }

  /** Diff two fingerprint sets (paths or arrays). */
  detectChanges(
    oldFingerprints: FingerprintSource,
    newFingerprints: FingerprintSource,
    opts: DetectChangesOptions = {},
  ): ChangedEndpoint[] {
    return this.query(
      'detectChanges',
      typeof oldFingerprints === 'string' ? oldFingerprints : `${oldFingerprints.length} fingerprints`,
      () => detectChanges(oldFingerprints, newFingerprints, { logger: this.logger, ...opts }),
      (r) => `${r.length} change(s)`,
    );
  }

  /** Phase-1 gate against one resident consumer. */
  isConsumed(consumerRepo: string, changed: ChangedEndpoint, producerEndpoint?: Endpoint | null): ConsumedResult {
    return this.query(
      'isConsumed',
      `${consumerRepo}, ${changed.id}`,
      () => {
        const entry = this.get(consumerRepo);
        if (!entry) {
          this.logger.log('QUERY', `isConsumed: '${consumerRepo}' is not resident — reporting not consumed`);
          return { consumed: false, signals: [] };
        }
        return isConsumed(changed, entry.bundle.manifest, {
          producerEndpoint: producerEndpoint ?? null,
          logger: this.logger,
        });
      },
      (r) => `consumed=${r.consumed}, ${r.signals.length} signal(s)`,
    );
  }

  /** Phase-2 join against one resident consumer. */
  findInvocations(
    consumerRepo: string,
    changed: ChangedEndpoint,
    opts: FindInvocationsOptions = {},
  ): InvocationHit[] {
    return this.query(
      'findInvocations',
      `${consumerRepo}, ${changed.id}`,
      () => {
        const entry = this.get(consumerRepo);
        if (!entry) {
          this.logger.log('QUERY', `findInvocations: '${consumerRepo}' is not resident — no hits`);
          return [];
        }
        return findInvocations(entry.bundle, changed, {
          index: entry.index,
          logger: this.logger,
          ...opts,
        });
      },
      (r) => `${r.length} hit(s)`,
    );
  }

  walkCallers(repo: string, symbolId: string, maxDepth = DEFAULT_MAX_DEPTH, opts: WalkOptions = {}): ChainNode[] {
    return this.query(
      'walkCallers',
      `${repo}, ${symbolId}, depth<=${maxDepth}`,
      () => {
        const entry = this.get(repo);
        if (!entry) {
          this.logger.log('QUERY', `walkCallers: '${repo}' is not resident — empty chain`);
          return [];
        }
        return walkCallers(entry.bundle, symbolId, maxDepth, {
          entryPoints: entry.index.entryPointsBySymbol,
          logger: this.logger,
          ...opts,
        });
      },
      (r) => `${r.length} node(s)`,
    );
  }

  walkFeeders(repo: string, handlerSymbolId: string, maxDepth = DEFAULT_MAX_DEPTH, opts: WalkOptions = {}): FeederResult {
    return this.query(
      'walkFeeders',
      `${repo}, ${handlerSymbolId}, depth<=${maxDepth}`,
      () => {
        const entry = this.get(repo);
        if (!entry) {
          this.logger.log('QUERY', `walkFeeders: '${repo}' is not resident — empty chains`);
          return { downstream: [], upstream: [] };
        }
        return walkFeeders(entry.bundle, handlerSymbolId, maxDepth, {
          forward: entry.forward,
          entryPoints: entry.index.entryPointsBySymbol,
          logger: this.logger,
          ...opts,
        });
      },
      (r) => `${r.downstream.length} downstream / ${r.upstream.length} upstream node(s)`,
    );
  }

  /** Full three-phase blast radius. */
  blastRadius(
    producerRepo: string,
    consumerRepos: readonly string[],
    changedEndpointId: string,
    opts: BlastRadiusOptions = {},
  ): BlastRadiusResult {
    return this.query(
      'blastRadius',
      `${producerRepo} -> [${[...consumerRepos].sort().join(', ')}], ${changedEndpointId}`,
      () => blastRadius(this, producerRepo, consumerRepos, changedEndpointId, { logger: this.logger, ...opts }),
      (r) =>
        `${r.producer_blast_radius.feeder_chains.length} feeder + ` +
        `${r.producer_blast_radius.caller_chains.length} caller node(s), ` +
        `${r.consumer_blast_radius.filter((c) => c.consumed).length}/${r.consumer_blast_radius.length} consumer(s) consumed, ` +
        `${r.consumer_blast_radius.reduce((n, c) => n + c.direct_invocations.length, 0)} invocation(s), ` +
        `${r.unresolved_across_analysis.length} unresolved`,
    );
  }

  /** Hover/lens: the endpoint declared at `file:line`. */
  getEndpointAt(repo: string, file: string, line: number, tolerance?: number): Endpoint | null {
    return this.query(
      'getEndpointAt',
      `${repo}, ${file}:${line}`,
      () => {
        const entry = this.get(repo);
        if (!entry) {
          return null;
        }
        return getEndpointAt(entry.bundle, file, line, {
          endpointsByFile: entry.index.endpointsByFile,
          tolerance,
          logger: this.logger,
        });
      },
      (r) => (r === null ? 'no endpoint' : r.id),
    );
  }

  /** Hover/lens: the outbound invocation at `file:line`. */
  getInvocationAt(repo: string, file: string, line: number, tolerance?: number): InvocationRecord | null {
    return this.query(
      'getInvocationAt',
      `${repo}, ${file}:${line}`,
      () => {
        const entry = this.get(repo);
        if (!entry) {
          return null;
        }
        return getInvocationAt(entry.bundle, file, line, {
          invocationsByFile: entry.index.invocationsByFile,
          tolerance,
          logger: this.logger,
        });
      },
      (r) => (r === null ? 'no invocation' : r.id),
    );
  }
}
