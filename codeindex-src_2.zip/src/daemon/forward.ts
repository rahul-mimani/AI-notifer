/**
 * Forward-adjacency callgraph loader.
 *
 * `callgraph.bin` is REVERSE adjacency only (indexed by callee, yields callers),
 * because the blast-radius walk's primary question is "who calls this?". The
 * producer-side view needs the opposite direction (handler -> service ->
 * repository), which a reverse index cannot serve without a full scan, so the
 * build coordinator additionally writes `.codeindex/callgraph.fwd.json`:
 *
 *   { "<caller symbol id>": [ { callee, file_id, line, call_kind }, ... ] }
 *
 * `loadBundle` does not read that file (the store layer is owned elsewhere), so
 * the daemon loads it here.
 *
 * Fail-open: a missing, unreadable or malformed file yields an EMPTY index and
 * is logged. Nothing in this module throws.
 */
import * as fs from 'node:fs';
import * as path from 'node:path';

import type { CallKind } from '../types.js';
import type { Logger } from '../util/logger.js';
import { bundlePaths } from '../store/paths.js';

/** Must stay in sync with `FORWARD_CALLGRAPH_FILE` in coordinator/build.ts. */
export const FORWARD_CALLGRAPH_FILE = 'callgraph.fwd.json';

const CALL_KINDS: readonly CallKind[] = ['direct', 'interface', 'lambda', 'reflective'];

/** One outgoing call site. Mirrors `ForwardCallSite` in extractor/callgraph.ts. */
export interface ForwardCallSite {
  callee: string;
  file_id: number;
  line: number;
  call_kind: CallKind;
}

/** caller symbol id -> its call sites. */
export type ForwardAdjacency = Record<string, ForwardCallSite[]>;

/**
 * Random-access forward index. `calleesOf` is a single map lookup and always
 * returns a (possibly empty) array in deterministic order.
 */
export interface ForwardIndex {
  /** False when the file was absent or unusable. */
  present: boolean;
  /** Absolute path the index was loaded from ('' for synthetic indexes). */
  file: string;
  callerCount: number;
  edgeCount: number;
  calleesOf(symbolId: string): readonly ForwardCallSite[];
  /** Every caller symbol id, sorted. */
  callers(): string[];
  loadMs: number;
}

const NO_SITES: readonly ForwardCallSite[] = Object.freeze([]);

function compareSites(a: ForwardCallSite, b: ForwardCallSite): number {
  return (
    (a.callee < b.callee ? -1 : a.callee > b.callee ? 1 : 0) ||
    a.line - b.line ||
    a.file_id - b.file_id ||
    (a.call_kind < b.call_kind ? -1 : a.call_kind > b.call_kind ? 1 : 0)
  );
}

/** Coerce one raw JSON entry into a `ForwardCallSite`, or null if unusable. */
function toSite(raw: unknown): ForwardCallSite | null {
  if (raw === null || typeof raw !== 'object') {
    return null;
  }
  const o = raw as Record<string, unknown>;
  const callee = typeof o['callee'] === 'string' ? o['callee'] : '';
  if (callee === '') {
    return null;
  }
  const fileId = typeof o['file_id'] === 'number' && Number.isFinite(o['file_id']) ? o['file_id'] : -1;
  const line = typeof o['line'] === 'number' && Number.isFinite(o['line']) ? o['line'] : 0;
  const kindRaw = o['call_kind'];
  const call_kind: CallKind =
    typeof kindRaw === 'string' && (CALL_KINDS as readonly string[]).includes(kindRaw)
      ? (kindRaw as CallKind)
      : 'direct';
  return { callee, file_id: fileId, line, call_kind };
}

/**
 * Build an index over an in-memory adjacency object. Used for synthetic graphs
 * (cycle tests) and by `loadForwardCallgraph` after parsing.
 */
export function forwardIndexFrom(
  adjacency: Readonly<Record<string, readonly unknown[]>>,
  meta: { present?: boolean; file?: string; loadMs?: number } = {},
): ForwardIndex {
  const map = new Map<string, ForwardCallSite[]>();
  let edgeCount = 0;

  for (const caller of Object.keys(adjacency).sort()) {
    const rawSites = adjacency[caller];
    if (!Array.isArray(rawSites) || caller === '') {
      continue;
    }
    const sites: ForwardCallSite[] = [];
    const seen = new Set<string>();
    for (const raw of rawSites) {
      const site = toSite(raw);
      if (site === null) {
        continue;
      }
      // Dedupe identical edges so repeated entries cannot inflate the walk.
      const key = `${site.callee}|${site.line}|${site.file_id}|${site.call_kind}`;
      if (seen.has(key)) {
        continue;
      }
      seen.add(key);
      sites.push(site);
    }
    if (sites.length === 0) {
      continue;
    }
    sites.sort(compareSites);
    edgeCount += sites.length;
    map.set(caller, sites);
  }

  const sortedCallers = [...map.keys()].sort();

  return {
    present: meta.present ?? true,
    file: meta.file ?? '',
    callerCount: map.size,
    edgeCount,
    loadMs: meta.loadMs ?? 0,
    calleesOf(symbolId: string): readonly ForwardCallSite[] {
      return map.get(symbolId) ?? NO_SITES;
    },
    callers(): string[] {
      return sortedCallers.slice();
    },
  };
}

/** An always-safe empty index. */
export function emptyForwardIndex(file = ''): ForwardIndex {
  return forwardIndexFrom({}, { present: false, file });
}

/**
 * Load `<repoRoot>/.codeindex/callgraph.fwd.json`. Never throws.
 *
 * `repoRoot` is the bundle's OUTPUT root — the same value `loadBundle` is given.
 */
export function loadForwardCallgraph(repoRoot: string, logger: Logger): ForwardIndex {
  const started = Date.now();
  const file = path.join(bundlePaths(repoRoot).root, FORWARD_CALLGRAPH_FILE);

  let text: string;
  try {
    if (!fs.existsSync(file)) {
      logger.log('DAEMON', `missing ${file} — empty forward callgraph (downstream walks will be empty)`);
      return emptyForwardIndex(file);
    }
    text = fs.readFileSync(file, 'utf8');
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('DAEMON', `ERROR reading ${file}: ${detail} — empty forward callgraph`);
    return emptyForwardIndex(file);
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('DAEMON', `ERROR parsing ${file}: ${detail} — empty forward callgraph`);
    return emptyForwardIndex(file);
  }

  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    logger.log('DAEMON', `${file} is not a JSON object — empty forward callgraph`);
    return emptyForwardIndex(file);
  }

  const index = forwardIndexFrom(parsed as Record<string, readonly unknown[]>, {
    present: true,
    file,
    loadMs: Date.now() - started,
  });
  logger.log(
    'DAEMON',
    `loaded ${FORWARD_CALLGRAPH_FILE} in ${index.loadMs}ms: ` +
      `${index.callerCount} callers / ${index.edgeCount} forward edges (${text.length} bytes)`,
  );
  return index;
}
