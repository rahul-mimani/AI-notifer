/**
 * Bundle reader. Loads a `.codeindex/` directory into memory for the daemon.
 *
 * Fail-open throughout: any missing, unreadable or corrupt artifact degrades to
 * an empty section and is logged. `loadBundle` never throws.
 */
import * as fs from 'node:fs';
import {
  ConsumptionManifest,
  Endpoint,
  Fingerprint,
  IndexRecord,
  Meta,
  SymbolRecord,
} from '../types.js';
import { Logger } from '../util/logger.js';
import { CallgraphReader } from './callgraph-codec.js';
import { readJson, readJsonl, readJsonlGz } from './jsonl.js';
import { bundlePaths } from './paths.js';
import { CallgraphIndex, SourceMap } from './writer.js';

export type RecordKind = IndexRecord['kind'];

export interface LoadedBundle {
  /** Absolute path of the `.codeindex` directory this was loaded from. */
  bundleRoot: string;
  /** False when `.codeindex` did not exist at all. */
  present: boolean;

  meta: Meta;
  endpoints: Endpoint[];
  fingerprints: Fingerprint[];
  manifest: ConsumptionManifest;

  /** Every index record, in file order. */
  records: IndexRecord[];
  /** Records bucketed by `kind`. Every kind is present, possibly empty. */
  byKind: Record<RecordKind, IndexRecord[]>;

  /** Symbol id → SymbolRecord. */
  symbolsById: Map<string, SymbolRecord>;
  /** Repo-relative file → every record declaring that file. */
  recordsByFile: Map<string, IndexRecord[]>;
  /** Endpoint id → Endpoint. */
  endpointsById: Map<string, Endpoint>;

  callgraph: CallgraphReader;
  /** symbol id → callgraph symbol index (from callgraph.idx.json). */
  callgraphIndex: CallgraphIndex;
  /** file_id → repo-relative path. */
  sourceMap: SourceMap;

  loadMs: number;
}

const ALL_KINDS: RecordKind[] = [
  'symbol',
  'dto',
  'invocation',
  'property',
  'wiring',
  'property_binding',
  'entry_point',
  'logical_name_ref',
  'alias',
  'unresolved',
];

export function emptyMeta(): Meta {
  return {
    repo: '',
    repo_url: '',
    commit: '',
    branch: '',
    built_at: '',
    indexer_version: '',
    schema_version: '',
    source_roots: [],
    package_prefixes: [],
    config_sources: [],
    transports_supported: [],
    stats: {},
  };
}

export function emptyManifest(): ConsumptionManifest {
  return {
    dto_shapes: [],
    dto_fqns: [],
    path_fragments: [],
    destinations: [],
    logical_names: [],
    property_keys: [],
    unresolved_placeholders: [],
    path_fragment_to_property_keys: {},
  };
}

function emptyByKind(): Record<RecordKind, IndexRecord[]> {
  const out = {} as Record<RecordKind, IndexRecord[]>;
  for (const k of ALL_KINDS) {
    out[k] = [];
  }
  return out;
}

/** The file a record refers to, if it has one. Property records use `source`. */
function recordFile(rec: IndexRecord): string | null {
  switch (rec.kind) {
    case 'property':
      return rec.source || null;
    case 'unresolved':
      return rec.context?.file ?? null;
    case 'alias':
      return null;
    default:
      return (rec as { file?: string }).file ?? null;
  }
}

/** Load a bundle from `<repoRoot>/.codeindex`. Never throws. */
export function loadBundle(repoRoot: string, logger: Logger): LoadedBundle {
  const started = Date.now();
  const p = bundlePaths(repoRoot);

  let present = false;
  try {
    present = fs.existsSync(p.root);
  } catch {
    present = false;
  }
  if (!present) {
    logger.log('DAEMON', `no bundle at ${p.root} — loading empty bundle`);
  }

  const meta = readJson<Meta>(p.meta, emptyMeta(), logger, 'DAEMON');
  const endpoints = readJsonl<Endpoint>(p.endpoints, logger, 'DAEMON');
  const fingerprints = readJsonl<Fingerprint>(p.fingerprints, logger, 'DAEMON');
  const manifest = readJson<ConsumptionManifest>(
    p.consumptionManifest,
    emptyManifest(),
    logger,
    'DAEMON',
  );
  const records = readJsonlGz<IndexRecord>(p.index, logger, 'DAEMON');
  const callgraphIndex = readJson<CallgraphIndex>(p.callgraphIdx, {}, logger, 'DAEMON');
  const sourceMap = readJson<SourceMap>(p.sourceMap, [], logger, 'DAEMON');

  let callgraph = CallgraphReader.empty();
  let callgraphBytes = 0;
  try {
    if (fs.existsSync(p.callgraphBin)) {
      const buf = fs.readFileSync(p.callgraphBin);
      callgraphBytes = buf.byteLength;
      callgraph = CallgraphReader.fromBuffer(buf, logger);
    } else {
      logger.log('DAEMON', `missing ${p.callgraphBin} — empty callgraph`);
    }
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log('DAEMON', `ERROR reading callgraph.bin: ${detail} — empty callgraph`);
    callgraph = CallgraphReader.empty();
  }

  const byKind = emptyByKind();
  const symbolsById = new Map<string, SymbolRecord>();
  const recordsByFile = new Map<string, IndexRecord[]>();

  for (const rec of records) {
    if (!rec || typeof rec !== 'object' || typeof rec.kind !== 'string') {
      continue;
    }
    const bucket = byKind[rec.kind as RecordKind];
    if (bucket) {
      bucket.push(rec);
    } else {
      logger.log('DAEMON', `unknown record kind ${JSON.stringify(rec.kind)} — ignored`);
      continue;
    }
    if (rec.kind === 'symbol') {
      symbolsById.set(rec.id, rec);
    }
    const file = recordFile(rec);
    if (file) {
      const list = recordsByFile.get(file);
      if (list) {
        list.push(rec);
      } else {
        recordsByFile.set(file, [rec]);
      }
    }
  }

  const endpointsById = new Map<string, Endpoint>();
  for (const ep of endpoints) {
    endpointsById.set(ep.id, ep);
  }

  const loadMs = Date.now() - started;
  logger.log(
    'DAEMON',
    `loaded bundle ${p.root} in ${loadMs}ms: ${records.length} records, ` +
      `${endpoints.length} endpoints, ${fingerprints.length} fingerprints, ` +
      `callgraph ${callgraph.symbolCountValue} symbols / ${callgraph.edgeCountValue} edges ` +
      `(${callgraphBytes} bytes), source_map ${sourceMap.length} files`,
  );

  return {
    bundleRoot: p.root,
    present,
    meta,
    endpoints,
    fingerprints,
    manifest,
    records,
    byKind,
    symbolsById,
    recordsByFile,
    endpointsById,
    callgraph,
    callgraphIndex,
    sourceMap,
    loadMs,
  };
}
