/** Store layer barrel. The `.codeindex/` bundle format: paths, codecs, IO. */
export { BUNDLE_DIR, LM_CACHE_DIR, bundlePaths, sanitizeHash, toRepoRelative } from './paths.js';
export type { BundlePaths } from './paths.js';

export {
  ensureDir,
  gzipDeterministic,
  parseJsonl,
  readJson,
  readJsonl,
  readJsonlGz,
  toJsonlText,
  writeJson,
  writeJsonl,
  writeJsonlGz,
} from './jsonl.js';

export {
  CALLGRAPH_MAGIC,
  CALLGRAPH_VERSION,
  CallgraphReader,
  EDGE_BYTES,
  HEADER_BYTES,
  packCallgraph,
} from './callgraph-codec.js';
export type { CallerRef } from './callgraph-codec.js';

export { buildCallgraphIndex, readLmCache, writeBundle, writeLmCache } from './writer.js';
export type { CallgraphIndex, SourceMap, StoreBundle, WriteResult } from './writer.js';

export { emptyManifest, emptyMeta, loadBundle } from './reader.js';
export type { LoadedBundle, RecordKind } from './reader.js';
