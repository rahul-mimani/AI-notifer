/**
 * Bundle writer. Emits the complete `.codeindex/` directory.
 *
 * Determinism: nothing here reads the clock or a random source. `meta.built_at`
 * is whatever the caller put in the Meta record — the store layer never
 * generates it. Writing the same StoreBundle twice yields byte-identical files.
 */
import * as fs from 'node:fs';
import { CallEdge, ConsumptionManifest, Endpoint, Fingerprint, IndexRecord, Meta } from '../types.js';
import { Logger } from '../util/logger.js';
import { packCallgraph } from './callgraph-codec.js';
import { ensureDir, writeJson, writeJsonl, writeJsonlGz } from './jsonl.js';
import { bundlePaths } from './paths.js';

/**
 * `source_map.json`: file_id → repo-relative path, stored positionally.
 * The array index IS the file_id referenced by callgraph edges.
 */
export type SourceMap = string[];

/** `callgraph.idx.json`: symbol id → symbol index into the callgraph string table. */
export type CallgraphIndex = Record<string, number>;

/** Everything needed to write a bundle. */
export interface StoreBundle {
  meta: Meta;
  endpoints: Endpoint[];
  fingerprints: Fingerprint[];
  manifest: ConsumptionManifest;
  records: IndexRecord[];
  /** Symbol ids in callgraph index order — becomes the binary string table. */
  callgraphSymbols: string[];
  callgraphEdges: CallEdge[];
  sourceMap: SourceMap;
}

export interface WriteResult {
  /** Bytes written per bundle file, keyed by bundle-relative filename. */
  bytes: Record<string, number>;
  totalBytes: number;
}

/** Write every bundle artifact under `<repoRoot>/.codeindex`. */
export function writeBundle(repoRoot: string, bundle: StoreBundle, logger: Logger): WriteResult {
  const p = bundlePaths(repoRoot);
  ensureDir(p.root);
  ensureDir(p.lmCacheDir);

  const bytes: Record<string, number> = {};

  bytes['meta.json'] = writeJson(p.meta, bundle.meta);
  bytes['endpoints.jsonl'] = writeJsonl(p.endpoints, bundle.endpoints);
  bytes['fingerprints.jsonl'] = writeJsonl(p.fingerprints, bundle.fingerprints);
  bytes['consumption_manifest.json'] = writeJson(p.consumptionManifest, bundle.manifest);
  bytes['index.jsonl.gz'] = writeJsonlGz(p.index, bundle.records);

  const cg = packCallgraph(bundle.callgraphSymbols, bundle.callgraphEdges);
  fs.writeFileSync(p.callgraphBin, cg);
  bytes['callgraph.bin'] = cg.byteLength;

  bytes['callgraph.idx.json'] = writeJson(p.callgraphIdx, buildCallgraphIndex(bundle.callgraphSymbols));
  bytes['source_map.json'] = writeJson(p.sourceMap, bundle.sourceMap);

  let totalBytes = 0;
  for (const name of Object.keys(bytes)) {
    const n = bytes[name]!;
    totalBytes += n;
    logger.log('STORE', `wrote ${name} (${n} bytes)`);
  }
  logger.log(
    'STORE',
    `bundle complete at ${p.root}: ${Object.keys(bytes).length} files, ${totalBytes} bytes, ` +
      `${bundle.records.length} records, ${bundle.endpoints.length} endpoints, ` +
      `${bundle.callgraphSymbols.length} symbols, ${bundle.callgraphEdges.length} edges`,
  );

  return { bytes, totalBytes };
}

/** symbol id → index. First occurrence wins if ids repeat. */
export function buildCallgraphIndex(symbols: readonly string[]): CallgraphIndex {
  const idx: CallgraphIndex = {};
  for (let i = 0; i < symbols.length; i++) {
    const id = symbols[i]!;
    if (!(id in idx)) {
      idx[id] = i;
    }
  }
  return idx;
}

/** Persist one raw LM response keyed by the hash of the content it was derived from. */
export function writeLmCache(
  repoRoot: string,
  contentHash: string,
  raw: unknown,
  logger?: Logger,
): boolean {
  const p = bundlePaths(repoRoot);
  try {
    ensureDir(p.lmCacheDir);
    const file = p.lmCacheEntry(contentHash);
    const n = writeJson(file, raw);
    logger?.log('STORE', `lm_cache write ${contentHash} (${n} bytes)`);
    return true;
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger?.log('STORE', `ERROR writing lm_cache ${contentHash}: ${detail} — skipping`);
    return false;
  }
}

/** Read a cached raw LM response. Missing or corrupt → null (fail-open). */
export function readLmCache<T = unknown>(
  repoRoot: string,
  contentHash: string,
  logger?: Logger,
): T | null {
  const p = bundlePaths(repoRoot);
  const file = p.lmCacheEntry(contentHash);
  try {
    if (!fs.existsSync(file)) {
      return null;
    }
    return JSON.parse(fs.readFileSync(file, 'utf8')) as T;
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger?.log('STORE', `ERROR reading lm_cache ${contentHash}: ${detail} — treating as miss`);
    return null;
  }
}
