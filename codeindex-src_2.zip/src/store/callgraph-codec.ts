/**
 * Binary reverse-adjacency callgraph.
 *
 * The graph is indexed BY CALLEE and yields CALLERS — the blast-radius walk only
 * ever asks "who calls this?", so storing the reverse direction makes that a
 * single offset-table lookup plus a contiguous slice.
 *
 * Layout (all little-endian):
 *
 *   Header (17 bytes)
 *     0  4  magic "CGRF"
 *     4  1  version = 1
 *     5  4  symbol_count            uint32
 *     9  4  edge_count              uint32
 *    13  4  string_table_offset     uint32  (absolute byte offset)
 *
 *   Offset table: (symbol_count + 1) x uint32 — EDGE INDICES, not byte offsets.
 *     Callee i owns edges [offset[i], offset[i + 1]). offset[symbol_count] ===
 *     edge_count is the sentinel.
 *
 *   Edge array: edge_count x 13 bytes
 *     0  4  caller_symbol_index     uint32
 *     4  4  file_id                 uint32
 *     8  4  line                    uint32
 *    12  1  call_kind               uint8 (0 direct, 1 interface, 2 lambda, 3 reflective)
 *
 *   String table: symbol ids in index order, each = uint16 byte length + UTF-8.
 *
 * Determinism: edges are sorted by (callee_index, caller_index, line, file_id,
 * call_kind) before writing, so the same logical graph always packs to the same
 * bytes.
 */
import { CallEdge, CallKind, CALL_KIND_CODE } from '../types.js';
import { Logger } from '../util/logger.js';

export const CALLGRAPH_MAGIC = 'CGRF';
export const CALLGRAPH_VERSION = 1;

export const HEADER_BYTES = 17;
export const EDGE_BYTES = 13;

const OFF_MAGIC = 0;
const OFF_VERSION = 4;
const OFF_SYMBOL_COUNT = 5;
const OFF_EDGE_COUNT = 9;
const OFF_STRING_TABLE = 13;

const CODE_TO_CALL_KIND: readonly CallKind[] = ['direct', 'interface', 'lambda', 'reflective'];

export interface CallerRef {
  caller_index: number;
  file_id: number;
  line: number;
  call_kind: CallKind;
}

function compareEdges(a: CallEdge, b: CallEdge): number {
  return (
    a.callee_index - b.callee_index ||
    a.caller_index - b.caller_index ||
    a.line - b.line ||
    a.file_id - b.file_id ||
    CALL_KIND_CODE[a.call_kind] - CALL_KIND_CODE[b.call_kind]
  );
}

/** Pack a symbol table plus edge list into the CGRF binary format. */
export function packCallgraph(symbols: readonly string[], edges: readonly CallEdge[]): Buffer {
  const symbolCount = symbols.length;

  // Drop edges pointing outside the symbol table rather than corrupting the file.
  const valid = edges.filter(
    (e) =>
      Number.isInteger(e.callee_index) &&
      e.callee_index >= 0 &&
      e.callee_index < symbolCount &&
      Number.isInteger(e.caller_index) &&
      e.caller_index >= 0 &&
      e.caller_index < symbolCount,
  );
  const sorted = valid.slice().sort(compareEdges);
  const edgeCount = sorted.length;

  const stringBufs = symbols.map((s) => Buffer.from(s, 'utf8'));
  const stringBytes = stringBufs.reduce((n, b) => n + 2 + b.byteLength, 0);

  const offsetTableBytes = (symbolCount + 1) * 4;
  const edgeArrayBytes = edgeCount * EDGE_BYTES;
  const stringTableOffset = HEADER_BYTES + offsetTableBytes + edgeArrayBytes;
  const total = stringTableOffset + stringBytes;

  const buf = Buffer.alloc(total);

  buf.write(CALLGRAPH_MAGIC, OFF_MAGIC, 4, 'ascii');
  buf.writeUInt8(CALLGRAPH_VERSION, OFF_VERSION);
  buf.writeUInt32LE(symbolCount, OFF_SYMBOL_COUNT);
  buf.writeUInt32LE(edgeCount, OFF_EDGE_COUNT);
  buf.writeUInt32LE(stringTableOffset, OFF_STRING_TABLE);

  // Offset table: start edge index per callee, sentinel at the end.
  const offsetBase = HEADER_BYTES;
  let cursor = 0;
  for (let sym = 0; sym < symbolCount; sym++) {
    buf.writeUInt32LE(cursor, offsetBase + sym * 4);
    while (cursor < edgeCount && sorted[cursor]!.callee_index === sym) {
      cursor++;
    }
  }
  buf.writeUInt32LE(edgeCount, offsetBase + symbolCount * 4);

  // Edge array.
  const edgeBase = offsetBase + offsetTableBytes;
  for (let i = 0; i < edgeCount; i++) {
    const e = sorted[i]!;
    const at = edgeBase + i * EDGE_BYTES;
    buf.writeUInt32LE(e.caller_index, at);
    buf.writeUInt32LE(e.file_id, at + 4);
    buf.writeUInt32LE(e.line, at + 8);
    buf.writeUInt8(CALL_KIND_CODE[e.call_kind] ?? 0, at + 12);
  }

  // String table.
  let at = stringTableOffset;
  for (const sb of stringBufs) {
    buf.writeUInt16LE(sb.byteLength, at);
    sb.copy(buf, at + 2);
    at += 2 + sb.byteLength;
  }

  return buf;
}

/**
 * Random-access reader over a packed callgraph. Nothing is materialized up front
 * except the symbol table (needed for id ↔ index lookups); edges are decoded
 * lazily straight out of the backing Buffer.
 */
export class CallgraphReader {
  private readonly buf: Buffer;
  private readonly symbolCount: number;
  private readonly edgeCount: number;
  private readonly offsetBase: number;
  private readonly edgeBase: number;
  private readonly stringTableOffset: number;
  private symbolCache: string[] | null = null;
  private indexCache: Map<string, number> | null = null;

  private constructor(
    buf: Buffer,
    symbolCount: number,
    edgeCount: number,
    stringTableOffset: number,
  ) {
    this.buf = buf;
    this.symbolCount = symbolCount;
    this.edgeCount = edgeCount;
    this.stringTableOffset = stringTableOffset;
    this.offsetBase = HEADER_BYTES;
    this.edgeBase = this.offsetBase + (symbolCount + 1) * 4;
  }

  /** An empty, always-safe reader. Used as the fail-open fallback. */
  static empty(): CallgraphReader {
    return CallgraphReader.emptyRaw();
  }

  /**
   * Validate and wrap a buffer. Bad magic, bad version or a truncated/inconsistent
   * file logs and degrades to an empty reader — never throws.
   */
  static fromBuffer(buf: Buffer, logger: Logger): CallgraphReader {
    try {
      if (buf.byteLength < HEADER_BYTES) {
        logger.log('CALLGRAPH', `callgraph too small (${buf.byteLength}b) — empty reader`);
        return CallgraphReader.emptyRaw();
      }
      const magic = buf.toString('ascii', OFF_MAGIC, OFF_MAGIC + 4);
      if (magic !== CALLGRAPH_MAGIC) {
        logger.log(
          'CALLGRAPH',
          `bad callgraph magic ${JSON.stringify(magic)} (expected ${CALLGRAPH_MAGIC}) — empty reader`,
        );
        return CallgraphReader.emptyRaw();
      }
      const version = buf.readUInt8(OFF_VERSION);
      if (version !== CALLGRAPH_VERSION) {
        logger.log(
          'CALLGRAPH',
          `unsupported callgraph version ${version} (expected ${CALLGRAPH_VERSION}) — empty reader`,
        );
        return CallgraphReader.emptyRaw();
      }
      const symbolCount = buf.readUInt32LE(OFF_SYMBOL_COUNT);
      const edgeCount = buf.readUInt32LE(OFF_EDGE_COUNT);
      const stringTableOffset = buf.readUInt32LE(OFF_STRING_TABLE);

      const expectedMin = HEADER_BYTES + (symbolCount + 1) * 4 + edgeCount * EDGE_BYTES;
      if (stringTableOffset !== expectedMin || buf.byteLength < stringTableOffset) {
        logger.log(
          'CALLGRAPH',
          `inconsistent callgraph header (string_table_offset=${stringTableOffset}, expected ${expectedMin}, size=${buf.byteLength}) — empty reader`,
        );
        return CallgraphReader.emptyRaw();
      }
      return new CallgraphReader(buf, symbolCount, edgeCount, stringTableOffset);
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      logger.log('CALLGRAPH', `ERROR parsing callgraph: ${detail} — empty reader`);
      return CallgraphReader.emptyRaw();
    }
  }

  /** Construct the empty graph without recursing through validation. */
  private static emptyRaw(): CallgraphReader {
    const buf = packCallgraph([], []);
    return new CallgraphReader(buf, 0, 0, buf.readUInt32LE(OFF_STRING_TABLE));
  }

  get symbolCountValue(): number {
    return this.symbolCount;
  }

  get edgeCountValue(): number {
    return this.edgeCount;
  }

  /** All callers of `calleeIndex`, in packed (deterministic) order. */
  callersOf(calleeIndex: number): CallerRef[] {
    if (!Number.isInteger(calleeIndex) || calleeIndex < 0 || calleeIndex >= this.symbolCount) {
      return [];
    }
    const start = this.buf.readUInt32LE(this.offsetBase + calleeIndex * 4);
    const end = this.buf.readUInt32LE(this.offsetBase + (calleeIndex + 1) * 4);
    if (end <= start || end > this.edgeCount) {
      return [];
    }
    const out: CallerRef[] = [];
    for (let i = start; i < end; i++) {
      const at = this.edgeBase + i * EDGE_BYTES;
      out.push({
        caller_index: this.buf.readUInt32LE(at),
        file_id: this.buf.readUInt32LE(at + 4),
        line: this.buf.readUInt32LE(at + 8),
        call_kind: CODE_TO_CALL_KIND[this.buf.readUInt8(at + 12)] ?? 'direct',
      });
    }
    return out;
  }

  /** Symbol ids in index order, decoded from the string table on first use. */
  symbols(): string[] {
    if (this.symbolCache) {
      return this.symbolCache;
    }
    const out: string[] = [];
    let at = this.stringTableOffset;
    for (let i = 0; i < this.symbolCount; i++) {
      if (at + 2 > this.buf.byteLength) {
        break;
      }
      const len = this.buf.readUInt16LE(at);
      if (at + 2 + len > this.buf.byteLength) {
        break;
      }
      out.push(this.buf.toString('utf8', at + 2, at + 2 + len));
      at += 2 + len;
    }
    this.symbolCache = out;
    return out;
  }

  symbolAt(index: number): string | null {
    return this.symbols()[index] ?? null;
  }

  /** Index of a symbol id, or -1. Built lazily from the string table. */
  indexOf(symbolId: string): number {
    if (!this.indexCache) {
      this.indexCache = new Map();
      const syms = this.symbols();
      for (let i = 0; i < syms.length; i++) {
        if (!this.indexCache.has(syms[i]!)) {
          this.indexCache.set(syms[i]!, i);
        }
      }
    }
    return this.indexCache.get(symbolId) ?? -1;
  }

  /** Convenience: callers of a symbol id. */
  callersOfSymbol(symbolId: string): CallerRef[] {
    const idx = this.indexOf(symbolId);
    return idx < 0 ? [] : this.callersOf(idx);
  }
}
