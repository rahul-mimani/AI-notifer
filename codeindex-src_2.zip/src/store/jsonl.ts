/**
 * JSONL and gzipped-JSONL IO.
 *
 * Determinism: gzip is written with `{ level: 9, mtime: 0 }` so identical input
 * bytes always produce an identical archive. Without `mtime: 0` zlib stamps the
 * current time into the gzip header and cached rebuilds stop being byte-identical.
 *
 * Fail-open: readers never throw. A malformed line is logged and skipped; a
 * missing or unreadable file yields an empty array.
 */
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as zlib from 'node:zlib';
import { Logger, Stage } from '../util/logger.js';

/**
 * `mtime` is not in @types/node's ZlibOptions (Node's zlib writes MTIME=0 itself),
 * so it is declared here and passed anyway — belt and braces with the explicit
 * header zeroing in `gzipDeterministic`.
 */
type DeterministicGzipOptions = zlib.ZlibOptions & { mtime?: number };

const GZIP_OPTS: DeterministicGzipOptions = { level: 9, mtime: 0 };

export function ensureDir(dir: string): void {
  fs.mkdirSync(dir, { recursive: true });
}

/** Serialize records to JSONL text (trailing newline when non-empty). */
export function toJsonlText(records: readonly unknown[]): string {
  if (records.length === 0) {
    return '';
  }
  return records.map((r) => JSON.stringify(r)).join('\n') + '\n';
}

/** Write JSONL. Returns the byte count written. */
export function writeJsonl(file: string, records: readonly unknown[]): number {
  ensureDir(path.dirname(file));
  const buf = Buffer.from(toJsonlText(records), 'utf8');
  fs.writeFileSync(file, buf);
  return buf.byteLength;
}

/** Write gzipped JSONL deterministically. Returns the compressed byte count. */
export function writeJsonlGz(file: string, records: readonly unknown[]): number {
  ensureDir(path.dirname(file));
  const buf = gzipDeterministic(Buffer.from(toJsonlText(records), 'utf8'));
  fs.writeFileSync(file, buf);
  return buf.byteLength;
}

/**
 * Deterministic gzip. `mtime: 0` zeroes the MTIME field of the gzip header; the
 * OS byte is normalized to 0xFF (unknown) so archives match across platforms.
 */
export function gzipDeterministic(input: Buffer): Buffer {
  const out = zlib.gzipSync(input, GZIP_OPTS as zlib.ZlibOptions);
  if (out.byteLength >= 10) {
    out.writeUInt32LE(0, 4); // MTIME
    out.writeUInt8(0, 8); // XFL
    out.writeUInt8(0xff, 9); // OS = unknown
  }
  return out;
}

/** Parse JSONL text, skipping blank and malformed lines. */
export function parseJsonl<T>(text: string, logger: Logger, stage: Stage, what: string): T[] {
  const out: T[] = [];
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!.trim();
    if (line.length === 0) {
      continue;
    }
    try {
      out.push(JSON.parse(line) as T);
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      logger.log(stage, `skipping malformed line ${i + 1} in ${what}: ${detail}`);
    }
  }
  return out;
}

/** Read JSONL. Missing/unreadable file → []. */
export function readJsonl<T>(file: string, logger: Logger, stage: Stage = 'STORE'): T[] {
  try {
    if (!fs.existsSync(file)) {
      logger.log(stage, `missing ${file} — using empty list`);
      return [];
    }
    return parseJsonl<T>(fs.readFileSync(file, 'utf8'), logger, stage, file);
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log(stage, `ERROR reading ${file}: ${detail} — using empty list`);
    return [];
  }
}

/** Read gzipped JSONL. Missing/unreadable/corrupt file → []. */
export function readJsonlGz<T>(file: string, logger: Logger, stage: Stage = 'STORE'): T[] {
  try {
    if (!fs.existsSync(file)) {
      logger.log(stage, `missing ${file} — using empty list`);
      return [];
    }
    const text = zlib.gunzipSync(fs.readFileSync(file)).toString('utf8');
    return parseJsonl<T>(text, logger, stage, file);
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log(stage, `ERROR reading ${file}: ${detail} — using empty list`);
    return [];
  }
}

/** Write a JSON document with stable 2-space formatting. Returns byte count. */
export function writeJson(file: string, value: unknown): number {
  ensureDir(path.dirname(file));
  const buf = Buffer.from(JSON.stringify(value, null, 2) + '\n', 'utf8');
  fs.writeFileSync(file, buf);
  return buf.byteLength;
}

/** Read a JSON document. Missing/unreadable/malformed → `fallback`. */
export function readJson<T>(file: string, fallback: T, logger: Logger, stage: Stage = 'STORE'): T {
  try {
    if (!fs.existsSync(file)) {
      logger.log(stage, `missing ${file} — using fallback`);
      return fallback;
    }
    return JSON.parse(fs.readFileSync(file, 'utf8')) as T;
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger.log(stage, `ERROR reading ${file}: ${detail} — using fallback`);
    return fallback;
  }
}
