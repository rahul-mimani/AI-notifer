/**
 * Bundle path resolution. Every `.codeindex/` artifact path is derived here so
 * no other module hardcodes a filename.
 */
import * as path from 'node:path';

export const BUNDLE_DIR = '.codeindex';
export const LM_CACHE_DIR = 'lm_cache';

export interface BundlePaths {
  /** Absolute path to the repo root the bundle belongs to. */
  repoRoot: string;
  /** Absolute path to `<repoRoot>/.codeindex`. */
  root: string;
  meta: string;
  endpoints: string;
  fingerprints: string;
  consumptionManifest: string;
  /** Gzipped JSONL of every IndexRecord. */
  index: string;
  callgraphBin: string;
  callgraphIdx: string;
  sourceMap: string;
  lmCacheDir: string;
  /** Path of one cached raw LM response, keyed by content hash. */
  lmCacheEntry(contentHash: string): string;
}

export function bundlePaths(repoRoot: string): BundlePaths {
  const absRepoRoot = path.resolve(repoRoot);
  const root = path.join(absRepoRoot, BUNDLE_DIR);
  const lmCacheDir = path.join(root, LM_CACHE_DIR);
  return {
    repoRoot: absRepoRoot,
    root,
    meta: path.join(root, 'meta.json'),
    endpoints: path.join(root, 'endpoints.jsonl'),
    fingerprints: path.join(root, 'fingerprints.jsonl'),
    consumptionManifest: path.join(root, 'consumption_manifest.json'),
    index: path.join(root, 'index.jsonl.gz'),
    callgraphBin: path.join(root, 'callgraph.bin'),
    callgraphIdx: path.join(root, 'callgraph.idx.json'),
    sourceMap: path.join(root, 'source_map.json'),
    lmCacheDir,
    lmCacheEntry(contentHash: string): string {
      return path.join(lmCacheDir, `${sanitizeHash(contentHash)}.json`);
    },
  };
}

/**
 * LM cache keys are content hashes, but they arrive from callers we do not
 * control — strip anything that could escape the cache directory.
 */
export function sanitizeHash(contentHash: string): string {
  return contentHash.replace(/[^A-Za-z0-9_-]/g, '_');
}

/** Normalize an absolute path to a repo-relative, forward-slashed, unrooted path. */
export function toRepoRelative(repoRoot: string, absPath: string): string {
  const rel = path.relative(path.resolve(repoRoot), path.resolve(absPath));
  return rel.split(path.sep).join('/').replace(/^\/+/, '');
}
