/**
 * Barrel for the language-model layer.
 *
 * NOTE: `./vscode-provider.js` is intentionally NOT re-exported — importing it
 * pulls in `vscode`, which would break every plain-Node consumer. Import it
 * directly from the extension host instead.
 */

export * from './provider.js';
export * from './prompts.js';
export * from './schema.js';
export * from './chunker.js';
export * from './extractor.js';
