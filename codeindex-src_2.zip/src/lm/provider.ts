/**
 * The language-model boundary.
 *
 * NOTHING in this file (or anything it imports) may touch `vscode`. The only
 * vscode-aware implementation lives in `./vscode-provider.ts`. Everything else
 * in src/lm is drivable from plain Node against `MockChatModelProvider`.
 */

import type { Logger } from '../util/logger.js';

export interface ChatModelInfo {
  id: string;
  maxInputTokens: number;
}

export interface ChatModelProvider {
  /**
   * Resolve a chat model. Returns null when no model is available at all —
   * callers must then fall back to deterministic-only extraction rather than
   * failing the build.
   */
  selectModel(preferredId: string, logger: Logger): Promise<ChatModelInfo | null>;
  /**
   * Send one request. `messages` are user turns, in order. Implementations must
   * return the fully concatenated response text.
   */
  sendRequest(system: string, messages: string[], token?: AbortSignal): Promise<string>;
}

/** Base class for all typed LM failures so callers can `instanceof` one thing. */
export class LmError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'LmError';
  }
}

/** The model refused because of quota/throttling. Retryable with backoff. */
export class LmRateLimitError extends LmError {
  /** Optional server-suggested delay, milliseconds. */
  readonly retryAfterMs: number | null;
  constructor(message: string, retryAfterMs: number | null = null) {
    super(message);
    this.name = 'LmRateLimitError';
    this.retryAfterMs = retryAfterMs;
  }
}

/**
 * No model, no consent, or the model went away mid-run. NOT retryable — the
 * caller should degrade to deterministic-only extraction.
 */
export class LmUnavailableError extends LmError {
  constructor(message: string) {
    super(message);
    this.name = 'LmUnavailableError';
  }
}

/** The per-request deadline elapsed (or the caller aborted). Retryable. */
export class LmTimeoutError extends LmError {
  constructor(message: string) {
    super(message);
    this.name = 'LmTimeoutError';
  }
}

export type MockHandler = (system: string, messages: string[]) => string | Promise<string>;

export interface MockChatModelProviderOptions {
  /** Reported model id. */
  id?: string;
  /** Reported input budget; drives the chunker in tests. */
  maxInputTokens?: number;
  /** When true, `selectModel` resolves to null (simulates "Copilot missing"). */
  unavailable?: boolean;
}

/**
 * Scriptable in-memory provider. The handler decides every response, so sanity
 * runs can produce valid JSON, fenced JSON, malformed JSON, schema-violating
 * JSON, or throw {@link LmRateLimitError} / {@link LmTimeoutError} on demand.
 */
export class MockChatModelProvider implements ChatModelProvider {
  /** Total `sendRequest` invocations. Cache-hit tests assert this stays at 0. */
  callCount = 0;
  /** Currently executing requests. */
  inFlight = 0;
  /** High-water mark of `inFlight`; concurrency-cap tests assert against it. */
  maxInFlight = 0;
  /** Every (system, messages) pair seen, in call order. */
  readonly calls: Array<{ system: string; messages: string[] }> = [];

  private readonly handler: MockHandler;
  private readonly opts: MockChatModelProviderOptions;

  constructor(handler: MockHandler, opts: MockChatModelProviderOptions = {}) {
    this.handler = handler;
    this.opts = opts;
  }

  async selectModel(preferredId: string, logger: Logger): Promise<ChatModelInfo | null> {
    if (this.opts.unavailable) {
      logger.log('LM', 'mock provider: no chat model available');
      return null;
    }
    const id = this.opts.id ?? (preferredId || 'mock-model');
    const maxInputTokens = this.opts.maxInputTokens ?? 64000;
    logger.log('LM', `mock provider: selected ${id} (maxInputTokens=${maxInputTokens})`);
    return { id, maxInputTokens };
  }

  async sendRequest(system: string, messages: string[], token?: AbortSignal): Promise<string> {
    if (token?.aborted) {
      throw new LmTimeoutError('mock provider: aborted before dispatch');
    }
    this.callCount += 1;
    this.calls.push({ system, messages: [...messages] });
    this.inFlight += 1;
    if (this.inFlight > this.maxInFlight) {
      this.maxInFlight = this.inFlight;
    }
    try {
      return await this.handler(system, messages);
    } finally {
      this.inFlight -= 1;
    }
  }

  reset(): void {
    this.callCount = 0;
    this.inFlight = 0;
    this.maxInFlight = 0;
    this.calls.length = 0;
  }
}
