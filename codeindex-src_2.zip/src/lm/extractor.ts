/**
 * Orchestration: cache-first extraction, one repair round-trip, line-range
 * verification, bounded concurrency, wall-clock budget and rate-limit backoff.
 *
 * Fail-open is absolute here: nothing in this module may throw at the caller.
 * Every failure path logs and returns partial results.
 */

import { createHash } from 'node:crypto';

import type { Logger } from '../util/logger.js';
import { chunkJavaSource, estimateTokens, mergeExtractions } from './chunker.js';
import type { JavaChunk } from './chunker.js';
import { REPAIR_MESSAGE, SYSTEM_PROMPT, buildUserPrompt } from './prompts.js';
import type { ChatModelInfo, ChatModelProvider } from './provider.js';
import { LmRateLimitError, LmTimeoutError, LmUnavailableError } from './provider.js';
import type { LmExtraction, LmUnresolved } from './schema.js';
import { emptyExtraction, parseLmJson, validateExtraction } from './schema.js';

/**
 * Raw-output cache. The file-backed implementation lives in the store layer
 * (owned by another agent) and writes `.codeindex/lm_cache/<hash>.json`; this
 * layer only ever sees the interface, so sanity runs can inject a Map.
 */
export interface LmCache {
  read(hash: string): Promise<string | null>;
  write(hash: string, raw: string): Promise<void>;
}

/** Trivial in-memory cache, used by sanity runs and by `--no-store` paths. */
export class MemoryLmCache implements LmCache {
  readonly entries = new Map<string, string>();
  reads = 0;
  writes = 0;
  async read(hash: string): Promise<string | null> {
    this.reads += 1;
    return this.entries.get(hash) ?? null;
  }
  async write(hash: string, raw: string): Promise<void> {
    this.writes += 1;
    this.entries.set(hash, raw);
  }
}

export interface ExtractFileOptions {
  repoRoot: string;
  relativePath: string;
  content: string;
  provider: ChatModelProvider;
  model: ChatModelInfo;
  cache: LmCache;
  logger: Logger;
  markers: string[];
  timeoutSeconds?: number;
  signal?: AbortSignal;
}

export type FileFailure = 'none' | 'parse' | 'schema' | 'rate_limit' | 'unavailable' | 'error';

export interface FileExtraction {
  relativePath: string;
  hash: string;
  extraction: LmExtraction;
  fromCache: boolean;
  /** Number of repair round-trips actually issued (0 or 1 per chunk). */
  repairAttempts: number;
  /** Records dropped because their line number was outside the file. */
  discarded: number;
  chunks: number;
  failure: FileFailure;
}

export const DEFAULT_MAX_CONCURRENT = 4;
export const DEFAULT_TOTAL_BUDGET_MINUTES = 10;
export const DEFAULT_TIMEOUT_SECONDS = 60;
export const MAX_BACKOFF_MS = 30_000;

const CACHE_ENVELOPE_MARKER = '__codeindex_lm_chunks__';
/** Headroom left for the system prompt, schema text, markers and the reply. */
const PROMPT_OVERHEAD_MARGIN_TOKENS = 1024;

export function hashContent(content: string): string {
  return createHash('sha256').update(content, 'utf8').digest('hex');
}

// ---------------------------------------------------------------------------
// Single file
// ---------------------------------------------------------------------------

/**
 * Extract one file. Fail-open for every content-level problem (bad JSON, bad
 * schema, bad line numbers, cache I/O). The ONE exception: transport-level
 * `LmRateLimitError` / `LmUnavailableError` are rethrown so `extractFiles` can
 * apply backoff or skip — callers invoking this directly should catch them.
 *
 * REPAIR BUDGET: parse failures and schema-validation failures share exactly
 * ONE repair round-trip per chunk. They are not budgeted separately, because a
 * repair is a single "you got the format wrong, try again" turn — the model
 * cannot distinguish "your JSON did not parse" from "your JSON parsed but broke
 * the schema" in any way that would make a second attempt more likely to
 * succeed, and a second retry doubles cost and latency on exactly the files
 * that are already the slowest. So a response that parses but fails validation
 * spends the budget; if the repair then comes back unparseable, that is the end
 * of it — no further attempt.
 *
 * Neither failure mode silently drops the file: both emit an `extraction_failed`
 * unresolved record so the miss is visible in the index.
 */
export async function extractFile(opts: ExtractFileOptions): Promise<FileExtraction> {
  const { logger, relativePath } = opts;
  const hash = hashContent(opts.content);
  const lineCount = opts.content.split('\n').length;

  const base: FileExtraction = {
    relativePath,
    hash,
    extraction: emptyExtraction(),
    fromCache: false,
    repairAttempts: 0,
    discarded: 0,
    chunks: 0,
    failure: 'none',
  };

  // --- cache first: a hit must cost ZERO provider calls -------------------
  let cached: string | null = null;
  try {
    cached = await opts.cache.read(hash);
  } catch (err) {
    logger.log('LM', `cache read failed for ${relativePath}: ${message(err)} — re-extracting`);
  }
  if (cached !== null) {
    const parts = decodeCacheEnvelope(cached);
    const validated = parts.map((raw) => validateRaw(raw));
    if (validated.every((v) => v.ok)) {
      const merged = mergeExtractions(validated.map((v) => (v.ok ? v.value : emptyExtraction())));
      const { extraction, discarded } = enforceLineRange(merged, lineCount, relativePath, logger);
      logger.log('LM', `cache hit ${relativePath} (${hash.slice(0, 12)})`);
      return { ...base, extraction, fromCache: true, chunks: parts.length, discarded };
    }
    logger.log('LM', `cache entry for ${relativePath} no longer validates — re-extracting`);
  }

  // --- chunk --------------------------------------------------------------
  const budget = sourceBudgetTokens(opts.model, opts.markers, relativePath);
  let chunks: JavaChunk[];
  try {
    chunks = chunkJavaSource(opts.content, budget);
  } catch (err) {
    logger.log('LM', `chunking failed for ${relativePath}: ${message(err)} — sending whole file`);
    chunks = chunkJavaSource(opts.content, Number.MAX_SAFE_INTEGER);
  }
  if (chunks.length > 1) {
    logger.log('LM', `${relativePath}: split into ${chunks.length} chunks (budget ${budget}t)`);
  }

  // --- request ------------------------------------------------------------
  const rawParts: string[] = [];
  const extractions: LmExtraction[] = [];
  let repairAttempts = 0;
  let failure: FileFailure = 'none';

  for (const chunk of chunks) {
    const userPrompt = buildUserPrompt({
      relativePath,
      numberedSource: chunk.numberedSource,
      messageRouterMarkers: opts.markers,
    });
    const outcome = await requestWithRepair(opts, userPrompt);
    repairAttempts += outcome.repairAttempts;
    if (outcome.raw !== null) {
      rawParts.push(outcome.raw);
    }
    if (outcome.kind === 'ok') {
      extractions.push(outcome.value);
      continue;
    }
    if (outcome.kind === 'rate_limit' || outcome.kind === 'unavailable') {
      // Not recoverable here — surface it so extractFiles can back off/skip.
      throw outcome.error;
    }
    failure = outcome.kind;
    // Never silently drop a chunk: parse, schema and transport failures all
    // leave an `extraction_failed` trace in the index.
    if (outcome.kind === 'schema') {
      const reason = `schema validation failed after one repair attempt: ${truncate(outcome.detail, 400)}`;
      logger.log('LM', `${relativePath} chunk ${chunk.index}: ${reason}`);
      extractions.push(withUnresolved(reason, 'extraction_failed'));
    } else if (outcome.kind === 'parse' || outcome.kind === 'error') {
      logger.log(
        'LM',
        `${relativePath} chunk ${chunk.index}: extraction failed (${outcome.detail})`,
      );
      extractions.push(withUnresolved(outcome.detail, 'extraction_failed'));
    }
  }

  const merged = mergeExtractions(extractions);
  const { extraction, discarded } = enforceLineRange(merged, lineCount, relativePath, logger);

  if (rawParts.length > 0) {
    try {
      await opts.cache.write(hash, encodeCacheEnvelope(rawParts));
    } catch (err) {
      logger.log('LM', `cache write failed for ${relativePath}: ${message(err)} — continuing`);
    }
  }

  return { ...base, extraction, repairAttempts, discarded, chunks: chunks.length, failure };
}

type RequestOutcome =
  | { kind: 'ok'; value: LmExtraction; raw: string; repairAttempts: number }
  | { kind: 'parse' | 'schema' | 'error'; detail: string; raw: string | null; repairAttempts: number }
  | { kind: 'rate_limit' | 'unavailable'; error: Error; raw: null; repairAttempts: number };

/**
 * Send once; on parse OR schema failure send exactly ONE repair. Stripping a
 * markdown fence is handled inside parseLmJson and never costs a repair.
 */
async function requestWithRepair(
  opts: ExtractFileOptions,
  userPrompt: string,
): Promise<RequestOutcome> {
  let first: string;
  try {
    first = await sendWithTimeout(opts, [userPrompt]);
  } catch (err) {
    return classifyThrow(err);
  }

  const firstResult = validateRaw(first);
  if (firstResult.ok) {
    return { kind: 'ok', value: firstResult.value, raw: first, repairAttempts: 0 };
  }

  opts.logger.log(
    'LM',
    `${opts.relativePath}: ${firstResult.stage} failure (${firstResult.detail}) — one repair attempt`,
  );

  let second: string;
  try {
    second = await sendWithTimeout(opts, [userPrompt, first, REPAIR_MESSAGE]);
  } catch (err) {
    return classifyThrow(err, 1);
  }

  const secondResult = validateRaw(second);
  if (secondResult.ok) {
    return { kind: 'ok', value: secondResult.value, raw: second, repairAttempts: 1 };
  }
  return {
    kind: secondResult.stage === 'parse' ? 'parse' : 'schema',
    detail: secondResult.detail,
    raw: null,
    repairAttempts: 1,
  };
}

function classifyThrow(err: unknown, repairAttempts = 0): RequestOutcome {
  if (err instanceof LmRateLimitError) {
    return { kind: 'rate_limit', error: err, raw: null, repairAttempts };
  }
  if (err instanceof LmUnavailableError) {
    return { kind: 'unavailable', error: err, raw: null, repairAttempts };
  }
  return { kind: 'error', detail: message(err), raw: null, repairAttempts };
}

async function sendWithTimeout(opts: ExtractFileOptions, messages: string[]): Promise<string> {
  const seconds = opts.timeoutSeconds ?? DEFAULT_TIMEOUT_SECONDS;
  const controller = new AbortController();
  const onOuterAbort = (): void => controller.abort();
  opts.signal?.addEventListener('abort', onOuterAbort);
  let timer: NodeJS.Timeout | undefined;
  const timeout = new Promise<never>((_resolve, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      reject(new LmTimeoutError(`request exceeded ${seconds}s`));
    }, seconds * 1000);
    timer.unref?.();
  });
  try {
    return await Promise.race([
      opts.provider.sendRequest(SYSTEM_PROMPT, messages, controller.signal),
      timeout,
    ]);
  } finally {
    if (timer) {
      clearTimeout(timer);
    }
    opts.signal?.removeEventListener('abort', onOuterAbort);
  }
}

type RawResult =
  | { ok: true; value: LmExtraction }
  | { ok: false; stage: 'parse' | 'schema'; detail: string };

function validateRaw(raw: string): RawResult {
  const parsed = parseLmJson(raw);
  if (!parsed.ok) {
    return { ok: false, stage: 'parse', detail: parsed.error };
  }
  const validated = validateExtraction(parsed.value);
  if (!validated.ok) {
    return { ok: false, stage: 'schema', detail: validated.errors.slice(0, 3).join('; ') };
  }
  return { ok: true, value: validated.value };
}

function withUnresolved(reason: string, what: LmUnresolved['what']): LmExtraction {
  const e = emptyExtraction();
  e.unresolved.push({ what, reason, expression: null });
  return e;
}

/** Drop every record whose reported line falls outside the real file. */
function enforceLineRange(
  extraction: LmExtraction,
  lineCount: number,
  relativePath: string,
  logger: Logger,
): { extraction: LmExtraction; discarded: number } {
  let discarded = 0;
  const inRange = (line: number): boolean => line >= 1 && line <= lineCount;
  const keep = <T>(kind: string, items: T[], get: (t: T) => number): T[] =>
    items.filter((item) => {
      const line = get(item);
      if (inRange(line)) {
        return true;
      }
      discarded += 1;
      logger.log(
        'LM',
        `discarded ${kind} in ${relativePath}: line ${line} outside 1..${lineCount}`,
      );
      return false;
    });

  const out: LmExtraction = {
    endpoints: keep('endpoint', extraction.endpoints, (e) => e.handler_line),
    invocations: keep('invocation', extraction.invocations, (i) => i.line),
    dtos: keep('dto', extraction.dtos, (d) => d.line),
    wirings: keep('wiring', extraction.wirings, (w) => w.line),
    property_bindings: keep('property_binding', extraction.property_bindings, (b) => b.line),
    method_calls: keep('method_call', extraction.method_calls, (m) => m.line),
    unresolved: extraction.unresolved,
  };
  return { extraction: out, discarded };
}

function sourceBudgetTokens(
  model: ChatModelInfo,
  markers: string[],
  relativePath: string,
): number {
  const skeleton = buildUserPrompt({
    relativePath,
    numberedSource: '',
    messageRouterMarkers: markers,
  });
  const overhead =
    estimateTokens(SYSTEM_PROMPT) + estimateTokens(skeleton) + PROMPT_OVERHEAD_MARGIN_TOKENS;
  return Math.max(1000, model.maxInputTokens - overhead);
}

function encodeCacheEnvelope(parts: string[]): string {
  if (parts.length === 1) {
    return parts[0]!;
  }
  return JSON.stringify({ [CACHE_ENVELOPE_MARKER]: parts });
}

function decodeCacheEnvelope(raw: string): string[] {
  try {
    const parsed: unknown = JSON.parse(raw);
    if (
      parsed !== null &&
      typeof parsed === 'object' &&
      !Array.isArray(parsed) &&
      Array.isArray((parsed as Record<string, unknown>)[CACHE_ENVELOPE_MARKER])
    ) {
      return ((parsed as Record<string, unknown>)[CACHE_ENVELOPE_MARKER] as unknown[]).map((p) =>
        String(p),
      );
    }
  } catch {
    /* not an envelope; treat as a single raw response */
  }
  return [raw];
}

function message(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

function truncate(text: string, max: number): string {
  return text.length <= max ? text : `${text.slice(0, max)}…`;
}

// ---------------------------------------------------------------------------
// Many files
// ---------------------------------------------------------------------------

export interface LmFileInput {
  relativePath: string;
  content: string;
}

export interface ExtractProgress {
  done: number;
  total: number;
  cacheHits: number;
}

export interface ExtractFilesOptions {
  repoRoot: string;
  files: LmFileInput[];
  provider: ChatModelProvider;
  model: ChatModelInfo;
  cache: LmCache;
  logger: Logger;
  markers: string[];
  maxConcurrent?: number;
  timeoutSeconds?: number;
  totalBudgetMinutes?: number;
  /** Injectable clock so budget/backoff logic is testable without real time. */
  now?: () => number;
  /** Injectable delay so backoff is testable without really waiting 30s. */
  sleep?: (ms: number) => Promise<void>;
  onProgress?: (p: ExtractProgress) => void;
  signal?: AbortSignal;
}

export interface ExtractFilesResult {
  results: FileExtraction[];
  cacheHits: number;
  /** Files never attempted or abandoned (budget exhausted, rate-limited out). */
  skipped: string[];
  budgetExhausted: boolean;
}

export async function extractFiles(opts: ExtractFilesOptions): Promise<ExtractFilesResult> {
  const now = opts.now ?? (() => Date.now());
  const sleep = opts.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms).unref?.()));
  const concurrency = Math.max(1, Math.floor(opts.maxConcurrent ?? DEFAULT_MAX_CONCURRENT));
  const budgetMs = Math.max(0, (opts.totalBudgetMinutes ?? DEFAULT_TOTAL_BUDGET_MINUTES) * 60_000);
  const started = now();

  const results: FileExtraction[] = [];
  const skipped: string[] = [];
  let cacheHits = 0;
  let done = 0;
  let budgetExhausted = false;
  let cursor = 0;

  const overBudget = (): boolean => now() - started > budgetMs;

  const report = (): void => {
    opts.onProgress?.({ done, total: opts.files.length, cacheHits });
  };

  const worker = async (): Promise<void> => {
    for (;;) {
      const index = cursor;
      cursor += 1;
      if (index >= opts.files.length) {
        return;
      }
      const file = opts.files[index]!;

      if (opts.signal?.aborted) {
        skipped.push(file.relativePath);
        done += 1;
        report();
        continue;
      }
      if (overBudget()) {
        if (!budgetExhausted) {
          budgetExhausted = true;
          opts.logger.log(
            'LM',
            `WARN total budget of ${opts.totalBudgetMinutes ?? DEFAULT_TOTAL_BUDGET_MINUTES}m exhausted — returning partial results`,
          );
        }
        skipped.push(file.relativePath);
        done += 1;
        report();
        continue;
      }

      const result = await runOne(file);
      if (result === null) {
        skipped.push(file.relativePath);
      } else {
        results.push(result);
        if (result.fromCache) {
          cacheHits += 1;
        }
      }
      done += 1;
      report();
    }
  };

  const runOne = async (file: LmFileInput): Promise<FileExtraction | null> => {
    let delay = 1000;
    for (;;) {
      try {
        return await extractFile({
          repoRoot: opts.repoRoot,
          relativePath: file.relativePath,
          content: file.content,
          provider: opts.provider,
          model: opts.model,
          cache: opts.cache,
          logger: opts.logger,
          markers: opts.markers,
          timeoutSeconds: opts.timeoutSeconds,
          signal: opts.signal,
        });
      } catch (err) {
        if (err instanceof LmRateLimitError) {
          const wait = err.retryAfterMs ?? delay;
          if (wait > MAX_BACKOFF_MS || overBudget()) {
            opts.logger.log(
              'LM',
              `rate limited on ${file.relativePath}; backoff exhausted — skipping`,
            );
            return rateLimitedPlaceholder(file, 'rate_limit', err.message);
          }
          opts.logger.log(
            'LM',
            `rate limited on ${file.relativePath}; retrying in ${wait}ms`,
          );
          await sleep(wait);
          delay = Math.max(delay, wait) * 2;
          continue;
        }
        if (err instanceof LmUnavailableError) {
          opts.logger.log(
            'LM',
            `model unavailable on ${file.relativePath}: ${err.message} — skipping`,
          );
          return rateLimitedPlaceholder(file, 'unavailable', err.message);
        }
        opts.logger.log('LM', `unexpected failure on ${file.relativePath}: ${message(err)}`);
        return rateLimitedPlaceholder(file, 'error', message(err));
      }
    }
  };

  report();
  const workers: Array<Promise<void>> = [];
  for (let i = 0; i < Math.min(concurrency, opts.files.length); i += 1) {
    workers.push(worker());
  }
  await Promise.all(workers);

  opts.logger.log(
    'LM',
    `extraction complete: ${results.length} files, ${cacheHits} cache hits, ${skipped.length} skipped`,
  );
  return { results, cacheHits, skipped, budgetExhausted };
}

/** A file we gave up on still yields an `extraction_failed` marker record. */
function rateLimitedPlaceholder(
  file: LmFileInput,
  failure: FileFailure,
  reason: string,
): FileExtraction {
  return {
    relativePath: file.relativePath,
    hash: hashContent(file.content),
    extraction: withUnresolved(reason, 'extraction_failed'),
    fromCache: false,
    repairAttempts: 0,
    discarded: 0,
    chunks: 0,
    failure,
  };
}
