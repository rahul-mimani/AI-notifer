/**
 * Hand-written strict validator for LM extraction output.
 *
 * No ajv — it is not an allowed dependency, and a hand validator lets us emit
 * error strings that are actually useful in the repair round-trip.
 *
 * Strictness rules:
 *  - unknown fields are rejected at EVERY object level;
 *  - enum fields (transport / verb / injection / call_kind / unresolved.what)
 *    are rejected when out of range;
 *  - wrong primitive types are rejected;
 *  - a MISSING top-level array is tolerated and becomes `[]`, but the contents
 *    of a present array are validated strictly;
 *  - a missing NULLABLE field inside a record is tolerated and becomes null
 *    (models routinely omit nulls); missing REQUIRED fields are rejected.
 */

import type { CallKind, Injection, Transport, UnresolvedWhat, Verb } from '../types.js';

const TRANSPORTS: readonly Transport[] = [
  'rest',
  'kafka',
  'solace',
  'jms',
  'message_router',
  'grpc',
];
const VERBS: readonly Verb[] = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'];
const INJECTIONS: readonly Injection[] = [
  '@Value',
  '@ConfigurationProperties',
  'constructor',
  'setter',
  'field',
];
const CALL_KINDS: readonly CallKind[] = ['direct', 'interface', 'lambda', 'reflective'];
const UNRESOLVED_WHATS: readonly UnresolvedWhat[] = [
  'url',
  'destination',
  'dto_type',
  'bean_wiring',
  'property_value',
  'method_body',
  'extraction_failed',
  'other',
];

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface LmNameType {
  name: string;
  type: string;
}

export interface LmParam {
  name: string;
  type: string;
  required: boolean;
}

export interface LmUnresolved {
  what: UnresolvedWhat;
  reason: string;
  expression: string | null;
}

export interface LmEndpoint {
  transport: Transport;
  verb: Verb | null;
  path_template: string | null;
  destination: string | null;
  request_dto_fqn: string | null;
  response_dto_fqn: string | null;
  path_params: LmNameType[];
  query_params: LmParam[];
  headers: LmParam[];
  logical_name: string | null;
  handler_class_fqn: string;
  handler_method_name: string;
  handler_method_signature: string;
  handler_line: number;
  annotations: Record<string, Record<string, unknown>>;
  confidence: number;
}

export interface LmInvocation {
  transport: Transport;
  enclosing_class_fqn: string;
  enclosing_method_name: string;
  enclosing_method_signature: string;
  line: number;
  literal_url: string | null;
  path_fragment: string | null;
  destination: string | null;
  request_dto_fqn: string | null;
  response_dto_fqn: string | null;
  client_bean: string | null;
  property_key_ref: string | null;
  logical_name: string | null;
  method_name: string;
  confidence_hints: string[];
  unresolved: LmUnresolved[];
  confidence: number;
}

export interface LmDtoField {
  name: string;
  type: string;
  nullable: boolean;
  annotations: string[];
}

export interface LmDto {
  fqn: string;
  fields: LmDtoField[];
  line: number;
  is_generated: boolean;
  confidence: number;
}

export interface LmWiring {
  bean_name: string;
  bean_class_fqn: string | null;
  property_key: string | null;
  injection: Injection;
  line: number;
  defining_class_fqn: string | null;
  confidence: number;
}

export interface LmPropertyBindingField {
  name: string;
  type: string;
  property_subkey: string;
}

export interface LmPropertyBinding {
  prefix: string;
  class_fqn: string;
  fields: LmPropertyBindingField[];
  line: number;
  confidence: number;
}

export interface LmMethodCall {
  caller_class_fqn: string;
  caller_method_signature: string;
  callee_class_fqn: string | null;
  callee_method_name: string;
  callee_signature_guess: string | null;
  line: number;
  call_kind: CallKind;
}

export interface LmExtraction {
  endpoints: LmEndpoint[];
  invocations: LmInvocation[];
  dtos: LmDto[];
  wirings: LmWiring[];
  property_bindings: LmPropertyBinding[];
  method_calls: LmMethodCall[];
  unresolved: LmUnresolved[];
}

export type ValidationResult =
  | { ok: true; value: LmExtraction }
  | { ok: false; errors: string[] };

export function emptyExtraction(): LmExtraction {
  return {
    endpoints: [],
    invocations: [],
    dtos: [],
    wirings: [],
    property_bindings: [],
    method_calls: [],
    unresolved: [],
  };
}

// ---------------------------------------------------------------------------
// Primitive checkers
// ---------------------------------------------------------------------------

class Ctx {
  readonly errors: string[] = [];
  fail(path: string, message: string): void {
    if (this.errors.length < 50) {
      this.errors.push(`${path}: ${message}`);
    }
  }
}

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

function rejectUnknown(
  obj: Record<string, unknown>,
  allowed: readonly string[],
  path: string,
  ctx: Ctx,
): void {
  for (const key of Object.keys(obj)) {
    if (!allowed.includes(key)) {
      ctx.fail(`${path}.${key}`, `unknown field (allowed: ${allowed.join(', ')})`);
    }
  }
}

function reqString(obj: Record<string, unknown>, key: string, path: string, ctx: Ctx): string {
  const v = obj[key];
  if (typeof v !== 'string') {
    ctx.fail(`${path}.${key}`, `expected string, got ${describe(v)}`);
    return '';
  }
  return v;
}

function nullString(
  obj: Record<string, unknown>,
  key: string,
  path: string,
  ctx: Ctx,
): string | null {
  const v = obj[key];
  if (v === undefined || v === null) {
    return null;
  }
  if (typeof v !== 'string') {
    ctx.fail(`${path}.${key}`, `expected string or null, got ${describe(v)}`);
    return null;
  }
  return v;
}

function reqBool(
  obj: Record<string, unknown>,
  key: string,
  path: string,
  ctx: Ctx,
  fallback: boolean,
): boolean {
  const v = obj[key];
  if (v === undefined || v === null) {
    return fallback;
  }
  if (typeof v !== 'boolean') {
    ctx.fail(`${path}.${key}`, `expected boolean, got ${describe(v)}`);
    return fallback;
  }
  return v;
}

function reqLine(obj: Record<string, unknown>, key: string, path: string, ctx: Ctx): number {
  const v = obj[key];
  if (typeof v !== 'number' || !Number.isFinite(v) || !Number.isInteger(v) || v < 1) {
    ctx.fail(`${path}.${key}`, `expected positive integer line number, got ${describe(v)}`);
    return 0;
  }
  return v;
}

function confidence(obj: Record<string, unknown>, path: string, ctx: Ctx): number {
  const v = obj['confidence'];
  if (v === undefined || v === null) {
    return 0.5;
  }
  if (typeof v !== 'number' || !Number.isFinite(v) || v < 0 || v > 1) {
    ctx.fail(`${path}.confidence`, `expected number in [0,1], got ${describe(v)}`);
    return 0.5;
  }
  return v;
}

function enumOf<T extends string>(
  obj: Record<string, unknown>,
  key: string,
  allowed: readonly T[],
  path: string,
  ctx: Ctx,
  fallback: T,
): T {
  const v = obj[key];
  if (typeof v !== 'string' || !(allowed as readonly string[]).includes(v)) {
    ctx.fail(`${path}.${key}`, `expected one of [${allowed.join('|')}], got ${describe(v)}`);
    return fallback;
  }
  return v as T;
}

function nullableEnumOf<T extends string>(
  obj: Record<string, unknown>,
  key: string,
  allowed: readonly T[],
  path: string,
  ctx: Ctx,
): T | null {
  const v = obj[key];
  if (v === undefined || v === null) {
    return null;
  }
  if (typeof v !== 'string' || !(allowed as readonly string[]).includes(v)) {
    ctx.fail(
      `${path}.${key}`,
      `expected one of [${allowed.join('|')}] or null, got ${describe(v)}`,
    );
    return null;
  }
  return v as T;
}

function stringArray(
  obj: Record<string, unknown>,
  key: string,
  path: string,
  ctx: Ctx,
): string[] {
  const v = obj[key];
  if (v === undefined || v === null) {
    return [];
  }
  if (!Array.isArray(v)) {
    ctx.fail(`${path}.${key}`, `expected array of string, got ${describe(v)}`);
    return [];
  }
  const out: string[] = [];
  v.forEach((item, i) => {
    if (typeof item !== 'string') {
      ctx.fail(`${path}.${key}[${i}]`, `expected string, got ${describe(item)}`);
      return;
    }
    out.push(item);
  });
  return out;
}

function objectArray<T>(
  obj: Record<string, unknown>,
  key: string,
  path: string,
  ctx: Ctx,
  item: (o: Record<string, unknown>, p: string, c: Ctx) => T,
): T[] {
  const v = obj[key];
  if (v === undefined || v === null) {
    return [];
  }
  if (!Array.isArray(v)) {
    ctx.fail(`${path}.${key}`, `expected array, got ${describe(v)}`);
    return [];
  }
  const out: T[] = [];
  v.forEach((raw, i) => {
    const p = `${path}.${key}[${i}]`;
    if (!isPlainObject(raw)) {
      ctx.fail(p, `expected object, got ${describe(raw)}`);
      return;
    }
    out.push(item(raw, p, ctx));
  });
  return out;
}

function describe(v: unknown): string {
  if (v === undefined) {
    return 'missing';
  }
  if (v === null) {
    return 'null';
  }
  if (Array.isArray(v)) {
    return 'array';
  }
  return `${typeof v} (${JSON.stringify(v)?.slice(0, 40) ?? '?'})`;
}

// ---------------------------------------------------------------------------
// Record validators
// ---------------------------------------------------------------------------

const NAME_TYPE_KEYS = ['name', 'type'] as const;
function nameType(o: Record<string, unknown>, p: string, c: Ctx): LmNameType {
  rejectUnknown(o, NAME_TYPE_KEYS, p, c);
  return { name: reqString(o, 'name', p, c), type: reqString(o, 'type', p, c) };
}

const PARAM_KEYS = ['name', 'type', 'required'] as const;
function param(o: Record<string, unknown>, p: string, c: Ctx): LmParam {
  rejectUnknown(o, PARAM_KEYS, p, c);
  return {
    name: reqString(o, 'name', p, c),
    type: reqString(o, 'type', p, c),
    required: reqBool(o, 'required', p, c, true),
  };
}

const UNRESOLVED_KEYS = ['what', 'reason', 'expression'] as const;
function unresolvedNote(o: Record<string, unknown>, p: string, c: Ctx): LmUnresolved {
  rejectUnknown(o, UNRESOLVED_KEYS, p, c);
  return {
    what: enumOf(o, 'what', UNRESOLVED_WHATS, p, c, 'other'),
    reason: reqString(o, 'reason', p, c),
    expression: nullString(o, 'expression', p, c),
  };
}

const ENDPOINT_KEYS = [
  'transport',
  'verb',
  'path_template',
  'destination',
  'request_dto_fqn',
  'response_dto_fqn',
  'path_params',
  'query_params',
  'headers',
  'logical_name',
  'handler_class_fqn',
  'handler_method_name',
  'handler_method_signature',
  'handler_line',
  'annotations',
  'confidence',
] as const;

function annotations(
  o: Record<string, unknown>,
  p: string,
  c: Ctx,
): Record<string, Record<string, unknown>> {
  const v = o['annotations'];
  if (v === undefined || v === null) {
    return {};
  }
  if (!isPlainObject(v)) {
    ctxFailObject(v, p, c);
    return {};
  }
  const out: Record<string, Record<string, unknown>> = {};
  for (const [k, raw] of Object.entries(v)) {
    if (!isPlainObject(raw)) {
      c.fail(`${p}.annotations.${k}`, `expected object of attributes, got ${describe(raw)}`);
      continue;
    }
    out[k] = raw;
  }
  return out;
}

function ctxFailObject(v: unknown, p: string, c: Ctx): void {
  c.fail(`${p}.annotations`, `expected object, got ${describe(v)}`);
}

function endpoint(o: Record<string, unknown>, p: string, c: Ctx): LmEndpoint {
  rejectUnknown(o, ENDPOINT_KEYS, p, c);
  return {
    transport: enumOf(o, 'transport', TRANSPORTS, p, c, 'rest'),
    verb: nullableEnumOf(o, 'verb', VERBS, p, c),
    path_template: nullString(o, 'path_template', p, c),
    destination: nullString(o, 'destination', p, c),
    request_dto_fqn: nullString(o, 'request_dto_fqn', p, c),
    response_dto_fqn: nullString(o, 'response_dto_fqn', p, c),
    path_params: objectArray(o, 'path_params', p, c, nameType),
    query_params: objectArray(o, 'query_params', p, c, param),
    headers: objectArray(o, 'headers', p, c, param),
    logical_name: nullString(o, 'logical_name', p, c),
    handler_class_fqn: reqString(o, 'handler_class_fqn', p, c),
    handler_method_name: reqString(o, 'handler_method_name', p, c),
    handler_method_signature: reqString(o, 'handler_method_signature', p, c),
    handler_line: reqLine(o, 'handler_line', p, c),
    annotations: annotations(o, p, c),
    confidence: confidence(o, p, c),
  };
}

const INVOCATION_KEYS = [
  'transport',
  'enclosing_class_fqn',
  'enclosing_method_name',
  'enclosing_method_signature',
  'line',
  'literal_url',
  'path_fragment',
  'destination',
  'request_dto_fqn',
  'response_dto_fqn',
  'client_bean',
  'property_key_ref',
  'logical_name',
  'method_name',
  'confidence_hints',
  'unresolved',
  'confidence',
] as const;

function invocation(o: Record<string, unknown>, p: string, c: Ctx): LmInvocation {
  rejectUnknown(o, INVOCATION_KEYS, p, c);
  return {
    transport: enumOf(o, 'transport', TRANSPORTS, p, c, 'rest'),
    enclosing_class_fqn: reqString(o, 'enclosing_class_fqn', p, c),
    enclosing_method_name: reqString(o, 'enclosing_method_name', p, c),
    enclosing_method_signature: reqString(o, 'enclosing_method_signature', p, c),
    line: reqLine(o, 'line', p, c),
    literal_url: nullString(o, 'literal_url', p, c),
    path_fragment: nullString(o, 'path_fragment', p, c),
    destination: nullString(o, 'destination', p, c),
    request_dto_fqn: nullString(o, 'request_dto_fqn', p, c),
    response_dto_fqn: nullString(o, 'response_dto_fqn', p, c),
    client_bean: nullString(o, 'client_bean', p, c),
    property_key_ref: nullString(o, 'property_key_ref', p, c),
    logical_name: nullString(o, 'logical_name', p, c),
    method_name: reqString(o, 'method_name', p, c),
    confidence_hints: stringArray(o, 'confidence_hints', p, c),
    unresolved: objectArray(o, 'unresolved', p, c, unresolvedNote),
    confidence: confidence(o, p, c),
  };
}

const DTO_FIELD_KEYS = ['name', 'type', 'nullable', 'annotations'] as const;
function dtoField(o: Record<string, unknown>, p: string, c: Ctx): LmDtoField {
  rejectUnknown(o, DTO_FIELD_KEYS, p, c);
  return {
    name: reqString(o, 'name', p, c),
    type: reqString(o, 'type', p, c),
    nullable: reqBool(o, 'nullable', p, c, true),
    annotations: stringArray(o, 'annotations', p, c),
  };
}

const DTO_KEYS = ['fqn', 'fields', 'line', 'is_generated', 'confidence'] as const;
function dto(o: Record<string, unknown>, p: string, c: Ctx): LmDto {
  rejectUnknown(o, DTO_KEYS, p, c);
  return {
    fqn: reqString(o, 'fqn', p, c),
    fields: objectArray(o, 'fields', p, c, dtoField),
    line: reqLine(o, 'line', p, c),
    is_generated: reqBool(o, 'is_generated', p, c, false),
    confidence: confidence(o, p, c),
  };
}

const WIRING_KEYS = [
  'bean_name',
  'bean_class_fqn',
  'property_key',
  'injection',
  'line',
  'defining_class_fqn',
  'confidence',
] as const;
function wiring(o: Record<string, unknown>, p: string, c: Ctx): LmWiring {
  rejectUnknown(o, WIRING_KEYS, p, c);
  return {
    bean_name: reqString(o, 'bean_name', p, c),
    bean_class_fqn: nullString(o, 'bean_class_fqn', p, c),
    property_key: nullString(o, 'property_key', p, c),
    injection: enumOf(o, 'injection', INJECTIONS, p, c, 'field'),
    line: reqLine(o, 'line', p, c),
    defining_class_fqn: nullString(o, 'defining_class_fqn', p, c),
    confidence: confidence(o, p, c),
  };
}

const BINDING_FIELD_KEYS = ['name', 'type', 'property_subkey'] as const;
function bindingField(o: Record<string, unknown>, p: string, c: Ctx): LmPropertyBindingField {
  rejectUnknown(o, BINDING_FIELD_KEYS, p, c);
  return {
    name: reqString(o, 'name', p, c),
    type: reqString(o, 'type', p, c),
    property_subkey: reqString(o, 'property_subkey', p, c),
  };
}

const BINDING_KEYS = ['prefix', 'class_fqn', 'fields', 'line', 'confidence'] as const;
function propertyBinding(o: Record<string, unknown>, p: string, c: Ctx): LmPropertyBinding {
  rejectUnknown(o, BINDING_KEYS, p, c);
  return {
    prefix: reqString(o, 'prefix', p, c),
    class_fqn: reqString(o, 'class_fqn', p, c),
    fields: objectArray(o, 'fields', p, c, bindingField),
    line: reqLine(o, 'line', p, c),
    confidence: confidence(o, p, c),
  };
}

const METHOD_CALL_KEYS = [
  'caller_class_fqn',
  'caller_method_signature',
  'callee_class_fqn',
  'callee_method_name',
  'callee_signature_guess',
  'line',
  'call_kind',
] as const;
function methodCall(o: Record<string, unknown>, p: string, c: Ctx): LmMethodCall {
  rejectUnknown(o, METHOD_CALL_KEYS, p, c);
  return {
    caller_class_fqn: reqString(o, 'caller_class_fqn', p, c),
    caller_method_signature: reqString(o, 'caller_method_signature', p, c),
    callee_class_fqn: nullString(o, 'callee_class_fqn', p, c),
    callee_method_name: reqString(o, 'callee_method_name', p, c),
    callee_signature_guess: nullString(o, 'callee_signature_guess', p, c),
    line: reqLine(o, 'line', p, c),
    call_kind: enumOf(o, 'call_kind', CALL_KINDS, p, c, 'direct'),
  };
}

const TOP_LEVEL_KEYS = [
  'endpoints',
  'invocations',
  'dtos',
  'wirings',
  'property_bindings',
  'method_calls',
  'unresolved',
] as const;

/** Validate a parsed JSON value against the extraction schema. */
export function validateExtraction(value: unknown): ValidationResult {
  const ctx = new Ctx();
  if (!isPlainObject(value)) {
    return { ok: false, errors: [`$: expected object, got ${describe(value)}`] };
  }
  rejectUnknown(value, TOP_LEVEL_KEYS, '$', ctx);
  const out: LmExtraction = {
    endpoints: objectArray(value, 'endpoints', '$', ctx, endpoint),
    invocations: objectArray(value, 'invocations', '$', ctx, invocation),
    dtos: objectArray(value, 'dtos', '$', ctx, dto),
    wirings: objectArray(value, 'wirings', '$', ctx, wiring),
    property_bindings: objectArray(value, 'property_bindings', '$', ctx, propertyBinding),
    method_calls: objectArray(value, 'method_calls', '$', ctx, methodCall),
    unresolved: objectArray(value, 'unresolved', '$', ctx, unresolvedNote),
  };
  if (ctx.errors.length > 0) {
    return { ok: false, errors: ctx.errors };
  }
  return { ok: true, value: out };
}

/**
 * Remove markdown code fences models keep adding. Returns the inner text when a
 * fenced block is found, otherwise the trimmed input unchanged. Stripping a
 * fence is NOT a schema failure — it must not cost a repair round-trip.
 */
export function stripCodeFences(text: string): string {
  const trimmed = text.trim();
  if (!trimmed.startsWith('```')) {
    return trimmed;
  }
  const firstNewline = trimmed.indexOf('\n');
  if (firstNewline === -1) {
    return trimmed;
  }
  const body = trimmed.slice(firstNewline + 1);
  const closing = body.lastIndexOf('```');
  return (closing === -1 ? body : body.slice(0, closing)).trim();
}

export type ParseResult =
  | { ok: true; value: unknown }
  | { ok: false; error: string };

/** Strip fences, then JSON.parse. Never throws. */
export function parseLmJson(raw: string): ParseResult {
  const text = stripCodeFences(raw);
  if (text.length === 0) {
    return { ok: false, error: 'empty response' };
  }
  try {
    return { ok: true, value: JSON.parse(text) as unknown };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}
