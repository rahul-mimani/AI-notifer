/**
 * Single source of truth for every prompt string in the extension.
 *
 * PROMPTS.md is generated from the exported raw templates — never re-type a
 * prompt anywhere else, or the docs and the runtime will drift.
 */

/** Verbatim system prompt. Do not reword. */
export const SYSTEM_PROMPT =
  'You are a structural extractor for Spring Boot Java code. You return only valid JSON matching the provided schema. You never emit prose, markdown, code fences, or commentary. If a field cannot be determined from the source, use null and add an entry to the "unresolved" section explaining specifically what could not be resolved and why. You never guess FQNs — if an import cannot be resolved, mark the type unresolved. You never invent line numbers — only report lines that appear in the numbered source provided. You use JVM erased method descriptors for signatures.';

/** Verbatim repair message, sent once after a parse/validation failure. */
export const REPAIR_MESSAGE =
  'Your previous output was not valid JSON matching the schema. Return only valid JSON matching the schema — no prose, no markdown.';

/**
 * The JSON shape the model is asked to emit. Mirrors `LmExtraction` in
 * ./schema.ts — the validator is the enforcement, this is the instruction.
 */
export const EXTRACTION_SCHEMA_TEXT = `{
  "endpoints": [
    {
      "transport": "rest|kafka|solace|jms|message_router|grpc",
      "verb": "GET|POST|PUT|DELETE|PATCH|null",
      "path_template": "string|null",
      "destination": "string|null",
      "request_dto_fqn": "string|null",
      "response_dto_fqn": "string|null",
      "path_params": [{ "name": "string", "type": "string" }],
      "query_params": [{ "name": "string", "type": "string", "required": true }],
      "headers": [{ "name": "string", "type": "string", "required": true }],
      "logical_name": "string|null",
      "handler_class_fqn": "string",
      "handler_method_name": "string",
      "handler_method_signature": "JVM erased descriptor, e.g. (Ljava/lang/String;)Lcom/acme/Dto;",
      "handler_line": 0,
      "annotations": { "AnnotationName": { "attribute": "value" } },
      "confidence": 0.0
    }
  ],
  "invocations": [
    {
      "transport": "rest|kafka|solace|jms|message_router|grpc",
      "enclosing_class_fqn": "string",
      "enclosing_method_name": "string",
      "enclosing_method_signature": "JVM erased descriptor",
      "line": 0,
      "literal_url": "string|null",
      "path_fragment": "string|null",
      "destination": "string|null",
      "request_dto_fqn": "string|null",
      "response_dto_fqn": "string|null",
      "client_bean": "string|null",
      "property_key_ref": "string|null",
      "logical_name": "string|null",
      "method_name": "string",
      "confidence_hints": ["string"],
      "unresolved": [{ "what": "url|destination|dto_type|bean_wiring|property_value|method_body|extraction_failed|other", "reason": "string", "expression": "string|null" }],
      "confidence": 0.0
    }
  ],
  "dtos": [
    {
      "fqn": "string",
      "fields": [{ "name": "string", "type": "string", "nullable": true, "annotations": ["string"] }],
      "line": 0,
      "is_generated": false,
      "confidence": 0.0
    }
  ],
  "wirings": [
    {
      "bean_name": "string",
      "bean_class_fqn": "string|null",
      "property_key": "string|null",
      "injection": "@Value|@ConfigurationProperties|constructor|setter|field",
      "line": 0,
      "defining_class_fqn": "string|null",
      "confidence": 0.0
    }
  ],
  "property_bindings": [
    {
      "prefix": "string",
      "class_fqn": "string",
      "fields": [{ "name": "string", "type": "string", "property_subkey": "string" }],
      "line": 0,
      "confidence": 0.0
    }
  ],
  "method_calls": [
    {
      "caller_class_fqn": "string",
      "caller_method_signature": "JVM erased descriptor",
      "callee_class_fqn": "string|null",
      "callee_method_name": "string",
      "callee_signature_guess": "string|null",
      "line": 0,
      "call_kind": "direct|interface|lambda|reflective"
    }
  ],
  "unresolved": [
    { "what": "url|destination|dto_type|bean_wiring|property_value|method_body|extraction_failed|other", "reason": "string", "expression": "string|null" }
  ]
}`;

/**
 * Raw user-prompt template. Placeholders: {MESSAGE_ROUTER_MARKERS},
 * {relative_path}, {numbered_source}. `{schema}` is filled from
 * EXTRACTION_SCHEMA_TEXT.
 */
export const USER_PROMPT_TEMPLATE = `Extract structural facts from this Spring Boot Java file. Return only JSON matching this schema:
{schema}

Message Router markers to treat as transport="message_router":
{MESSAGE_ROUTER_MARKERS}

File path:
{relative_path}

Numbered source:
{numbered_source}`;

export interface UserPromptInput {
  relativePath: string;
  numberedSource: string;
  messageRouterMarkers: string[];
}

export function buildUserPrompt(input: UserPromptInput): string {
  const markers =
    input.messageRouterMarkers.length > 0
      ? input.messageRouterMarkers.join('\n')
      : '(none configured)';
  return USER_PROMPT_TEMPLATE.replace('{schema}', EXTRACTION_SCHEMA_TEXT)
    .replace('{MESSAGE_ROUTER_MARKERS}', markers)
    .replace('{relative_path}', input.relativePath)
    .replace('{numbered_source}', input.numberedSource);
}

/**
 * Render `NNN: line`, 1-based, one per source line. Width is at least 3 and
 * grows for files over 999 lines so the gutter stays aligned.
 */
export function numberSource(text: string, startLine = 1): string {
  const lines = text.split('\n');
  const width = Math.max(3, String(startLine + lines.length - 1).length);
  return lines
    .map((line, i) => `${String(startLine + i).padStart(width, '0')}: ${line}`)
    .join('\n');
}

/** Everything PROMPTS.md needs, so the doc generator holds no literals. */
export const PROMPT_TEMPLATES = {
  system: SYSTEM_PROMPT,
  user: USER_PROMPT_TEMPLATE,
  schema: EXTRACTION_SCHEMA_TEXT,
  repair: REPAIR_MESSAGE,
} as const;
