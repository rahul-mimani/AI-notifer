/**
 * THE ONLY FILE IN src/lm THAT IMPORTS vscode.
 *
 * Everything else in the layer talks to `ChatModelProvider`, so the whole
 * pipeline runs under plain Node against `MockChatModelProvider` on machines
 * where GitHub Copilot is not installed.
 */

import * as vscode from 'vscode';

import type { Logger } from '../util/logger.js';
import { LmRateLimitError, LmTimeoutError, LmUnavailableError } from './provider.js';
import type { ChatModelInfo, ChatModelProvider } from './provider.js';

/** Vendors we will accept a chat model from, in preference order. */
const VENDOR_FALLBACKS: ReadonlyArray<vscode.LanguageModelChatSelector> = [
  { vendor: 'copilot' },
  {},
];

export interface VsCodeChatModelProviderOptions {
  /**
   * Called once, immediately before the FIRST request of a run. VS Code shows
   * its own consent modal on first `sendRequest`; this hook lets the extension
   * surface an explanatory message just ahead of it.
   */
  onFirstUse?: (model: ChatModelInfo) => void | Promise<void>;
}

export class VsCodeChatModelProvider implements ChatModelProvider {
  private model: vscode.LanguageModelChat | null = null;
  private info: ChatModelInfo | null = null;
  private firstUseAnnounced = false;
  private readonly opts: VsCodeChatModelProviderOptions;

  constructor(opts: VsCodeChatModelProviderOptions = {}) {
    this.opts = opts;
  }

  async selectModel(preferredId: string, logger: Logger): Promise<ChatModelInfo | null> {
    try {
      if (preferredId) {
        const exact = await vscode.lm.selectChatModels({ id: preferredId });
        if (exact.length > 0) {
          return this.adopt(exact[0]!, logger, `configured id "${preferredId}"`);
        }
        logger.log('LM', `configured model "${preferredId}" not available — falling back`);
      }
      for (const selector of VENDOR_FALLBACKS) {
        const models = await vscode.lm.selectChatModels(selector);
        if (models.length > 0) {
          return this.adopt(models[0]!, logger, `fallback ${JSON.stringify(selector)}`);
        }
      }
    } catch (err) {
      logger.log('LM', `selectChatModels failed: ${describe(err)} — deterministic-only`);
      return null;
    }
    logger.log('LM', 'no chat model available — deterministic-only extraction');
    return null;
  }

  private adopt(model: vscode.LanguageModelChat, logger: Logger, why: string): ChatModelInfo {
    this.model = model;
    this.info = { id: model.id, maxInputTokens: model.maxInputTokens };
    logger.log(
      'LM',
      `selected ${model.vendor}/${model.family} id=${model.id} via ${why} (maxInputTokens=${model.maxInputTokens})`,
    );
    return this.info;
  }

  async sendRequest(system: string, messages: string[], token?: AbortSignal): Promise<string> {
    const model = this.model;
    if (!model || !this.info) {
      throw new LmUnavailableError('no chat model selected; call selectModel first');
    }
    if (!this.firstUseAnnounced) {
      this.firstUseAnnounced = true;
      try {
        await this.opts.onFirstUse?.(this.info);
      } catch {
        /* consent messaging must never break extraction */
      }
    }

    // vscode.lm has no system role; the system prompt is sent as the leading
    // user turn, which is the documented Copilot pattern.
    const chatMessages = [system, ...messages].map((text) =>
      vscode.LanguageModelChatMessage.User(text),
    );

    const cts = new vscode.CancellationTokenSource();
    const onAbort = (): void => cts.cancel();
    if (token) {
      if (token.aborted) {
        cts.cancel();
      }
      token.addEventListener('abort', onAbort);
    }

    try {
      const response = await model.sendRequest(chatMessages, {}, cts.token);
      const fragments: string[] = [];
      for await (const fragment of response.text) {
        fragments.push(fragment);
      }
      return fragments.join('');
    } catch (err) {
      throw mapError(err);
    } finally {
      token?.removeEventListener('abort', onAbort);
      cts.dispose();
    }
  }
}

/** Map vscode LM failures onto the transport-neutral errors in provider.ts. */
export function mapError(err: unknown): Error {
  if (err instanceof vscode.LanguageModelError) {
    const code = err.code ?? '';
    if (/quota|rate|limit|too many|429/i.test(`${code} ${err.message}`)) {
      return new LmRateLimitError(`language model rate limited: ${err.message}`);
    }
    if (
      code === vscode.LanguageModelError.NoPermissions().code ||
      code === vscode.LanguageModelError.Blocked().code ||
      code === vscode.LanguageModelError.NotFound().code ||
      /consent|permission|blocked|not found/i.test(`${code} ${err.message}`)
    ) {
      return new LmUnavailableError(`language model unavailable: ${err.message}`);
    }
    return new LmUnavailableError(`language model error (${code}): ${err.message}`);
  }
  if (err instanceof vscode.CancellationError) {
    return new LmTimeoutError('language model request cancelled');
  }
  if (err instanceof Error) {
    if (/cancel/i.test(err.message)) {
      return new LmTimeoutError(err.message);
    }
    return err;
  }
  return new Error(String(err));
}

function describe(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

/**
 * Default consent message hook. Wire this into `VsCodeChatModelProvider` from
 * the extension host on the first run of a session.
 */
export function defaultConsentNotice(model: ChatModelInfo): void {
  void vscode.window.showInformationMessage(
    `CodeIndex will send Java source from this workspace to the "${model.id}" language model for structural extraction. Results are cached under .codeindex/lm_cache.`,
  );
}
