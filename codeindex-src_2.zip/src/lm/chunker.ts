/**
 * Splitting large Java files so a single request fits the model's input budget.
 *
 * Two hard requirements drive the design:
 *  1. Every chunk keeps ORIGINAL line numbers, so any line the model reports is
 *     still valid against the real file.
 *  2. Brace scanning must ignore braces inside string literals, char literals,
 *     text blocks and comments — otherwise depth tracking desynchronises and
 *     the split lands in the middle of a method.
 *
 * The package/import prelude is repeated in every chunk (and the class header
 * in every method-level chunk) so the model can still resolve FQNs.
 */

import { numberSource } from './prompts.js';
import type { LmExtraction } from './schema.js';
import { emptyExtraction } from './schema.js';

/**
 * ESTIMATE only. ~3.5 characters per token is a rough average for Java source
 * under BPE tokenizers; it is deliberately conservative-ish, and callers should
 * leave headroom on top of it rather than trusting it exactly.
 */
export const CHARS_PER_TOKEN = 3.5;

export function estimateTokens(text: string): number {
  return Math.ceil(text.length / CHARS_PER_TOKEN);
}

/** A brace-delimited block. `depth` is the nesting depth of its opening brace. */
export interface JavaBlock {
  depth: number;
  /** First line of the declaration (annotations included), 1-based. */
  startLine: number;
  /** Line holding the matching closing brace, 1-based. */
  endLine: number;
}

/**
 * Brace-depth scan that is aware of `//`, `/* *\/`, `"…"`, `'…'` and `"""…"""`.
 * Returns blocks opened at depth 0 (top-level types) and depth 1 (members).
 */
export function scanBlocks(source: string): JavaBlock[] {
  const blocks: JavaBlock[] = [];
  const stack: Array<{ depth: number; startLine: number }> = [];
  const pendingStart: Array<number | null> = [];

  let depth = 0;
  let line = 1;
  let i = 0;
  const n = source.length;

  const setPending = (): void => {
    if (pendingStart[depth] === undefined || pendingStart[depth] === null) {
      pendingStart[depth] = line;
    }
  };
  const clearPending = (): void => {
    pendingStart[depth] = null;
  };

  while (i < n) {
    const ch = source[i]!;
    const next = i + 1 < n ? source[i + 1]! : '';

    if (ch === '\n') {
      line += 1;
      i += 1;
      continue;
    }
    // Line comment
    if (ch === '/' && next === '/') {
      while (i < n && source[i] !== '\n') {
        i += 1;
      }
      continue;
    }
    // Block comment
    if (ch === '/' && next === '*') {
      i += 2;
      while (i < n && !(source[i] === '*' && source[i + 1] === '/')) {
        if (source[i] === '\n') {
          line += 1;
        }
        i += 1;
      }
      i += 2;
      continue;
    }
    // Text block """ … """
    if (ch === '"' && next === '"' && source[i + 2] === '"') {
      setPending();
      i += 3;
      while (i < n && !(source[i] === '"' && source[i + 1] === '"' && source[i + 2] === '"')) {
        if (source[i] === '\\') {
          i += 1;
        } else if (source[i] === '\n') {
          line += 1;
        }
        i += 1;
      }
      i += 3;
      continue;
    }
    // String / char literal
    if (ch === '"' || ch === "'") {
      setPending();
      const quote = ch;
      i += 1;
      while (i < n && source[i] !== quote) {
        if (source[i] === '\\') {
          i += 1;
        } else if (source[i] === '\n') {
          // Unterminated literal; bail out of the literal at the newline so a
          // malformed file cannot desynchronise the whole scan.
          break;
        }
        i += 1;
      }
      i += 1;
      continue;
    }

    if (ch === '{') {
      setPending();
      stack.push({ depth, startLine: pendingStart[depth] ?? line });
      depth += 1;
      pendingStart[depth] = null;
      i += 1;
      continue;
    }
    if (ch === '}') {
      const open = stack.pop();
      depth = Math.max(0, depth - 1);
      if (open && open.depth <= 1) {
        blocks.push({ depth: open.depth, startLine: open.startLine, endLine: line });
      }
      clearPending();
      i += 1;
      continue;
    }
    if (ch === ';') {
      clearPending();
      i += 1;
      continue;
    }
    if (ch !== ' ' && ch !== '\t' && ch !== '\r') {
      setPending();
    }
    i += 1;
  }

  blocks.sort((a, b) => a.startLine - b.startLine || a.depth - b.depth);
  return blocks;
}

export interface JavaChunk {
  index: number;
  /** Original 1-based line numbers included in this chunk, ascending. */
  lines: number[];
  startLine: number;
  endLine: number;
  /** `NNN: text` rendering using the ORIGINAL line numbers. */
  numberedSource: string;
  estimatedTokens: number;
}

interface Segment {
  startLine: number;
  endLine: number;
}

/**
 * Split `content` into chunks whose numbered source fits `budgetTokens`.
 * Splits at class boundaries first; a class that still overflows is split at
 * method boundaries. Always returns at least one chunk (fail-open: an
 * un-splittable file is emitted whole and may be truncated by the model).
 */
export function chunkJavaSource(content: string, budgetTokens: number): JavaChunk[] {
  const allLines = content.split('\n');
  const numbered = numberSource(content).split('\n');
  const total = allLines.length;
  const render = (lines: number[]): string => lines.map((l) => numbered[l - 1] ?? '').join('\n');

  const whole = numbered.join('\n');
  if (estimateTokens(whole) <= budgetTokens || total === 0) {
    return [
      {
        index: 0,
        lines: rangeLines(1, total),
        startLine: 1,
        endLine: total,
        numberedSource: whole,
        estimatedTokens: estimateTokens(whole),
      },
    ];
  }

  const blocks = scanBlocks(content);
  const classes = blocks.filter((b) => b.depth === 0);
  if (classes.length === 0) {
    return [
      {
        index: 0,
        lines: rangeLines(1, total),
        startLine: 1,
        endLine: total,
        numberedSource: whole,
        estimatedTokens: estimateTokens(whole),
      },
    ];
  }

  // package + imports, repeated in every chunk so FQNs stay resolvable.
  const preludeEnd = classes[0]!.startLine - 1;
  const prelude = preludeEnd >= 1 ? rangeLines(1, preludeEnd) : [];

  // Build the unit list: one unit per class, or several per class when a class
  // alone overflows.
  const units: Segment[][] = [];
  classes.forEach((cls, i) => {
    // Expand each class to swallow the blank lines / comments that sit between
    // it and the previous class (and, for the last class, the file tail) so the
    // chunks together cover every line of the file.
    const outer: Segment = {
      startLine: i === 0 ? cls.startLine : classes[i - 1]!.endLine + 1,
      endLine: i === classes.length - 1 ? Math.max(cls.endLine, total) : cls.endLine,
    };
    const outerLines = rangeLines(outer.startLine, outer.endLine);
    if (estimateTokens(render([...prelude, ...outerLines])) <= budgetTokens) {
      units.push([outer]);
      return;
    }
    units.push(...splitClassByMethods(cls, outer, blocks, prelude, render, budgetTokens));
  });

  // Greedily pack units into chunks.
  const chunks: JavaChunk[] = [];
  let current: number[] = [];
  const flush = (): void => {
    if (current.length === 0) {
      return;
    }
    const lines = dedupeSorted([...prelude, ...current]);
    const text = render(lines);
    chunks.push({
      index: chunks.length,
      lines,
      startLine: lines[0]!,
      endLine: lines[lines.length - 1]!,
      numberedSource: text,
      estimatedTokens: estimateTokens(text),
    });
    current = [];
  };

  for (const unit of units) {
    const unitLines = unit.flatMap((s) => rangeLines(s.startLine, s.endLine));
    const candidate = dedupeSorted([...prelude, ...current, ...unitLines]);
    if (current.length > 0 && estimateTokens(render(candidate)) > budgetTokens) {
      flush();
    }
    current.push(...unitLines);
  }
  flush();

  return chunks.length > 0
    ? chunks
    : [
        {
          index: 0,
          lines: rangeLines(1, total),
          startLine: 1,
          endLine: total,
          numberedSource: whole,
          estimatedTokens: estimateTokens(whole),
        },
      ];
}

/**
 * Split one oversized class into method-level units. Every unit carries the
 * class header (declaration line .. first member line - 1) plus the closing
 * brace line, so each chunk is still recognisably that class.
 */
function splitClassByMethods(
  cls: JavaBlock,
  outer: Segment,
  blocks: JavaBlock[],
  prelude: number[],
  render: (lines: number[]) => string,
  budgetTokens: number,
): Segment[][] {
  const members = blocks.filter(
    (b) => b.depth === 1 && b.startLine > cls.startLine && b.endLine <= cls.endLine,
  );
  if (members.length === 0) {
    return [[outer]];
  }
  const headerEnd = members[0]!.startLine - 1;
  const header: Segment = {
    startLine: outer.startLine,
    endLine: Math.max(outer.startLine, headerEnd),
  };
  const footer: Segment = { startLine: cls.endLine, endLine: outer.endLine };

  const units: Segment[][] = [];
  let bucket: Segment[] = [];
  const bucketLines = (b: Segment[]): number[] =>
    dedupeSorted([
      ...prelude,
      ...rangeLines(header.startLine, header.endLine),
      ...b.flatMap((s) => rangeLines(s.startLine, s.endLine)),
      ...rangeLines(footer.startLine, footer.endLine),
    ]);

  // Expand members so inter-method blank lines and comments are attached to the
  // following method — together the units cover the whole class body.
  const segs: Segment[] = members.map((m, i) => ({
    startLine: i === 0 ? m.startLine : members[i - 1]!.endLine + 1,
    endLine: i === members.length - 1 ? Math.max(m.endLine, cls.endLine - 1) : m.endLine,
  }));

  for (const seg of segs) {
    if (bucket.length > 0 && estimateTokens(render(bucketLines([...bucket, seg]))) > budgetTokens) {
      units.push(withFrame(bucket, header, footer));
      bucket = [];
    }
    bucket.push(seg);
  }
  if (bucket.length > 0) {
    units.push(withFrame(bucket, header, footer));
  }
  return units;
}

function withFrame(bucket: Segment[], header: Segment, footer: Segment): Segment[] {
  return [header, ...bucket, footer];
}

function rangeLines(start: number, end: number): number[] {
  const out: number[] = [];
  for (let l = Math.max(1, start); l <= end; l += 1) {
    out.push(l);
  }
  return out;
}

function dedupeSorted(lines: number[]): number[] {
  const set = new Set(lines);
  return [...set].sort((a, b) => a - b);
}

/**
 * Concatenate per-chunk extractions, dropping records that are byte-identical
 * to one already present (chunk overlap repeats the prelude and class header,
 * so duplicates are expected).
 */
export function mergeExtractions(parts: LmExtraction[]): LmExtraction {
  const out = emptyExtraction();
  const seen = new Set<string>();
  const push = <T>(bucket: T[], tag: string, items: T[]): void => {
    for (const item of items) {
      const key = `${tag}:${stableKey(item)}`;
      if (seen.has(key)) {
        continue;
      }
      seen.add(key);
      bucket.push(item);
    }
  };
  for (const part of parts) {
    push(out.endpoints, 'e', part.endpoints);
    push(out.invocations, 'i', part.invocations);
    push(out.dtos, 'd', part.dtos);
    push(out.wirings, 'w', part.wirings);
    push(out.property_bindings, 'p', part.property_bindings);
    push(out.method_calls, 'm', part.method_calls);
    push(out.unresolved, 'u', part.unresolved);
  }
  return out;
}

/** Key-order-independent stringify so record identity is stable. */
function stableKey(value: unknown): string {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value) ?? 'null';
  }
  if (Array.isArray(value)) {
    return `[${value.map(stableKey).join(',')}]`;
  }
  const entries = Object.entries(value as Record<string, unknown>).sort(([a], [b]) =>
    a < b ? -1 : a > b ? 1 : 0,
  );
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${stableKey(v)}`).join(',')}}`;
}
