/**
 * vscode-free logging contract. Every module under src/store, src/extractor,
 * src/daemon and src/lm/core takes a Logger rather than importing vscode, so
 * the whole pipeline can be driven from plain Node for sanity runs.
 */
export type Stage =
  | 'WALK'
  | 'FILTER'
  | 'LM'
  | 'YAML'
  | 'NORMALIZE'
  | 'CALLGRAPH'
  | 'STORE'
  | 'DAEMON'
  | 'QUERY';

export interface Logger {
  log(stage: Stage, message: string): void;
}

export const consoleLogger: Logger = {
  log(stage, message) {
    console.log(`[${stage}] ${message}`);
  },
};

export const silentLogger: Logger = {
  log() {
    /* no-op */
  },
};

/** Fail-open helper: log and return the fallback, never throw. */
export function failOpen<T>(
  logger: Logger,
  stage: Stage,
  what: string,
  fallback: T,
  err: unknown,
): T {
  const detail = err instanceof Error ? err.message : String(err);
  logger.log(stage, `ERROR ${what}: ${detail} — continuing with partial results`);
  return fallback;
}
