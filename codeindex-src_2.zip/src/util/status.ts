import * as vscode from 'vscode';

export type StatusState =
  | { kind: 'indexing'; done: number; total: number }
  | { kind: 'ready'; repos: number }
  | { kind: 'lm-unavailable' }
  | { kind: 'errors' };

let item: vscode.StatusBarItem | undefined;

export function initStatus(context: vscode.ExtensionContext): void {
  item = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  item.command = 'codeindex.runDemo';
  // The status text already carries the state, so the tooltip is free to
  // advertise the click action rather than repeat it.
  item.tooltip = 'Click to run end-to-end blast radius demo';
  context.subscriptions.push(item);
  setStatus({ kind: 'ready', repos: 0 });
  item.show();
}

export function setStatus(state: StatusState): void {
  if (!item) {
    return;
  }
  switch (state.kind) {
    case 'indexing':
      item.text = `$(sync~spin) CodeIndex: indexing (${state.done}/${state.total} files)`;
      break;
    case 'ready':
      item.text = `$(check) CodeIndex: ready · ${state.repos} repos loaded`;
      break;
    case 'lm-unavailable':
      item.text = '$(warning) CodeIndex: LM unavailable · deterministic mode';
      break;
    case 'errors':
      item.text = '$(error) CodeIndex: last build had errors';
      break;
  }
}
