import * as vscode from 'vscode';
import type { Logger, Stage } from './logger.js';

/**
 * The vscode-backed adapter for the vscode-free `Logger` contract in
 * logger.ts. Everything in the pipeline takes a `Logger`; only the extension
 * host wires up this implementation, which is what keeps the pipeline
 * runnable from plain Node for sanity runs.
 */

let channel: vscode.OutputChannel | undefined;

export function initLog(context: vscode.ExtensionContext): vscode.OutputChannel {
  channel = vscode.window.createOutputChannel('CodeIndex');
  context.subscriptions.push(channel);
  return channel;
}

export const outputChannelLogger: Logger = {
  log(stage: Stage, message: string): void {
    channel?.appendLine(`[${stage}] ${message}`);
  },
};

export function log(stage: Stage, message: string): void {
  outputChannelLogger.log(stage, message);
}

export function showLog(): void {
  channel?.show(true);
}

// Deliberately NOT re-exported here: `Logger`, `Stage`, `failOpen`.
// This module imports vscode, so re-exporting them would let a pipeline module
// pull the extension host in through the back door just by importing a helper
// from the wrong path. Import those from './logger.js' directly.
