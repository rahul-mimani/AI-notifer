/**
 * LM-output normalization: validated `LmExtraction` objects (one per file) plus
 * the resolved property table -> on-disk store records.
 *
 * Pure and deterministic. No clock, no randomness, no I/O, no `vscode`. Every
 * emitted collection is sorted so two runs over the same inputs are
 * byte-identical.
 *
 * Two hard cases are handled here and are commented in detail at their
 * implementation sites:
 *
 *   1. INTERFACE/IMPL RECONCILIATION (see `reconcileEndpoints`). Spring
 *      registers handlers declared on an interface that a `@RestController`
 *      implements, so the LM legitimately reports the same endpoint twice.
 *   2. PROPERTY ENRICHMENT (see `enrichInvocation`). A consumer whose base URL
 *      comes from `@Value("${...}")` has no literal URL anywhere in its source;
 *      the only way to a joinable path fragment is through the resolved
 *      property table.
 */

import type {
  ConsumptionManifest,
  DtoRecord,
  Endpoint,
  EntryPointKind,
  EntryPointRecord,
  Env,
  Fingerprint,
  IndexRecord,
  InvocationRecord,
  LogicalNameRefRecord,
  ParamSpec,
  PropertyBindingRecord,
  SymbolRecord,
  Transport,
  UnresolvedNote,
  UnresolvedRecord,
  WiringRecord,
} from '../types.js';
import type { Logger } from '../util/logger.js';
import { failOpen } from '../util/logger.js';
import type { LmEndpoint, LmExtraction, LmInvocation } from '../lm/schema.js';
import {
  endpointFingerprint,
  endpointId,
  invocationId,
  normalizeMethodSignature,
  symbolId,
} from './ids.js';
import { collapsePathParams, joinPathTemplates, normalizePathTemplate, pathFragments } from './paths.js';
import { computeDtoShapes } from './shapes.js';
import type { DtoInput } from './shapes.js';
import type { ResolutionResult } from './properties/resolve.js';
import { lookupResolved, placeholderTokens, valueFragments } from './properties/resolve.js';

/* ------------------------------------------------------------------ *
 * Public shapes
 * ------------------------------------------------------------------ */

export interface FileExtractionInput {
  /** Repo-relative, forward-slashed. */
  relativePath: string;
  extraction: LmExtraction;
}

/** One resolved method in this repo. The callgraph pass joins on these. */
export interface MethodSymbolEntry {
  /** `<repo>:<fqn>#<normalized signature>` */
  id: string;
  classFqn: string;
  methodName: string;
  /** Already passed through `normalizeMethodSignature`. */
  signature: string;
  file: string;
  line: number;
}

export interface ClassSymbolEntry {
  fqn: string;
  file: string;
  line: number;
  /**
   * True when the class was observed acting as a declaring interface (some
   * other type's endpoint annotations name it via `declared_on`/`inherited_from`).
   * The LM schema carries no explicit `symbol`/`implements` array, so this is
   * the only interface evidence available — see the note in `buildCallgraph`.
   */
  isInterface: boolean;
  annotationNames: string[];
}

export interface SymbolTable {
  /** Sorted by id. */
  methods: MethodSymbolEntry[];
  byId: Map<string, MethodSymbolEntry>;
  /** `<classFqn>#<normalized signature>` -> entry. */
  byClassSignature: Map<string, MethodSymbolEntry>;
  /** `<classFqn>#<methodName>` -> entries (overloads). */
  byClassMethod: Map<string, MethodSymbolEntry[]>;
  classes: Map<string, ClassSymbolEntry>;
  /** interface FQN -> concrete implementation FQNs, sorted. */
  implementations: Map<string, string[]>;
}

export interface NormalizeOptions {
  repo: string;
  /** Every repo-relative file considered (used for the source map / stats). */
  files: string[];
  extractions: FileExtractionInput[];
  propertyResolution: ResolutionResult;
  packagePrefixes: string[];
  logger: Logger;
  /** Written into every record's `extractor` field. */
  extractorTag: string;
  /** Extra annotation names that mark a message-router handler. */
  messageRouterMarkers?: string[];
}

export interface NormalizeResult {
  endpoints: Endpoint[];
  fingerprints: Fingerprint[];
  records: IndexRecord[];
  manifest: ConsumptionManifest;
  unresolved: UnresolvedRecord[];
  symbolTable: SymbolTable;
  /** dto FQN -> shape hash, for cross-checking and for the sanity suite. */
  dtoShapes: Map<string, string>;
}

/* ------------------------------------------------------------------ *
 * Small helpers
 * ------------------------------------------------------------------ */

const REST_CONTROLLER_ANNOTATIONS = new Set(['RestController', 'Controller']);
const METHOD_MAPPING_ANNOTATIONS = [
  'GetMapping',
  'PostMapping',
  'PutMapping',
  'DeleteMapping',
  'PatchMapping',
] as const;

function sortedUnique(values: Iterable<string>): string[] {
  return [...new Set([...values].filter((v) => v !== ''))].sort();
}

function cmp(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

/** `value` attribute of an annotation, tolerating string | string[] | absent. */
function annValue(attrs: Record<string, unknown> | undefined, key = 'value'): string | null {
  if (!attrs) {
    return null;
  }
  const raw = attrs[key];
  if (typeof raw === 'string') {
    return raw;
  }
  if (Array.isArray(raw) && raw.length > 0 && typeof raw[0] === 'string') {
    return raw[0];
  }
  return null;
}

function matchesPrefix(fqn: string, prefixes: readonly string[]): boolean {
  if (prefixes.length === 0) {
    return true;
  }
  return prefixes.some((p) => p !== '' && (fqn === p || fqn.startsWith(`${p}.`) || fqn.startsWith(`${p}$`)));
}

function toParamSpecs(items: Array<{ name: string; type: string; required?: boolean }>): ParamSpec[] {
  return items.map((p) => ({ name: p.name, type: p.type, required: p.required ?? true }));
}

/** Cumulative literal prefixes of a path, e.g. `/api/v1/x` -> /api, /api/v1, /api/v1/x. */
function cumulativeFragments(template: string): string[] {
  const out: string[] = [];
  let cur = '';
  for (const seg of pathFragments(template)) {
    cur = `${cur}/${seg}`;
    out.push(cur);
  }
  return out;
}

/* ------------------------------------------------------------------ *
 * DTO shapes
 * ------------------------------------------------------------------ */

/**
 * The shape hasher excludes fields carrying a `transient` (or `static`)
 * MODIFIER, but the LM reports Java modifiers inside the field's `annotations`
 * array. Map them across so `transient cacheKey` is genuinely dropped — this is
 * exactly what makes CDU's and POU's `CustomerDto` hash to the same value.
 */
function toDtoInputs(extractions: FileExtractionInput[]): DtoInput[] {
  const byFqn = new Map<string, DtoInput>();
  for (const file of extractions) {
    for (const dto of file.extraction.dtos) {
      if (dto.fqn === '') {
        continue;
      }
      byFqn.set(dto.fqn, {
        fqn: dto.fqn,
        fields: dto.fields.map((f) => ({
          name: f.name,
          type: f.type,
          nullable: f.nullable,
          modifiers: [...f.annotations],
        })),
      });
    }
  }
  return [...byFqn.keys()].sort().map((k) => byFqn.get(k)!);
}

/**
 * Resolve a declared type to a DTO shape hash. Handles the common container
 * case (`java.util.List<com.acme.Foo>`) by falling back to the first generic
 * argument, which is what a wire payload actually carries.
 */
function shapeOfType(
  type: string | null,
  shapes: Map<string, { shape: string }>,
): string | null {
  if (type === null || type === '') {
    return null;
  }
  const direct = shapes.get(type);
  if (direct) {
    return direct.shape;
  }
  const open = type.indexOf('<');
  if (open >= 0 && type.endsWith('>')) {
    const inner = type.slice(open + 1, -1).split(',')[0]!.trim();
    const nested = shapes.get(inner);
    if (nested) {
      return nested.shape;
    }
  }
  return null;
}

/* ------------------------------------------------------------------ *
 * Endpoint candidates
 * ------------------------------------------------------------------ */

interface EndpointCandidate {
  lm: LmEndpoint;
  file: string;
  handlerSymbol: string;
  transport: Transport;
  pathTemplate: string | null;
  pathNormalized: string | null;
  /** Interface FQNs this candidate's annotations point at. */
  declaringTypes: string[];
  hasControllerAnnotation: boolean;
  /** True when the mapping attributes were tagged `inherited_from`. */
  inherited: boolean;
}

/**
 * Class-level `@RequestMapping` joins with the method-level verb mapping.
 * When the LM reported no method-level mapping annotation at all we fall back
 * to its `path_template` verbatim rather than truncating to the class prefix.
 */
function derivePathTemplate(lm: LmEndpoint, file: string, logger: Logger): string | null {
  if (lm.transport !== 'rest') {
    return lm.path_template === null ? null : normalizePathTemplate(lm.path_template);
  }

  const classLevel = annValue(lm.annotations['RequestMapping']);
  let methodLevel: string | null = null;
  let found = false;
  for (const name of METHOD_MAPPING_ANNOTATIONS) {
    const attrs = lm.annotations[name];
    if (attrs !== undefined) {
      found = true;
      methodLevel = annValue(attrs) ?? annValue(attrs, 'path') ?? '';
      break;
    }
  }

  if (!found) {
    return lm.path_template === null ? null : normalizePathTemplate(lm.path_template);
  }

  const joined = joinPathTemplates(classLevel ?? '', methodLevel ?? '');
  if (lm.path_template !== null && normalizePathTemplate(lm.path_template) !== joined) {
    logger.log(
      'NORMALIZE',
      `${file}: ${lm.handler_class_fqn}#${lm.handler_method_name} reported path_template ` +
        `'${lm.path_template}' but class+method mappings join to '${joined}' — using the join`,
    );
  }
  return joined;
}

/** Interface FQNs named by `declared_on` / `inherited_from` markers. */
function declaringTypesOf(lm: LmEndpoint): string[] {
  const out = new Set<string>();
  for (const attrs of Object.values(lm.annotations)) {
    for (const key of ['declared_on', 'inherited_from']) {
      const v = attrs[key];
      if (typeof v === 'string' && v !== '' && v !== lm.handler_class_fqn) {
        out.add(v);
      }
    }
  }
  return [...out].sort();
}

function toCandidate(lm: LmEndpoint, file: string, repo: string, logger: Logger): EndpointCandidate {
  const pathTemplate = derivePathTemplate(lm, file, logger);
  const annotationNames = Object.keys(lm.annotations);
  return {
    lm,
    file,
    handlerSymbol: symbolId(repo, lm.handler_class_fqn, lm.handler_method_signature),
    transport: lm.transport,
    pathTemplate,
    pathNormalized: pathTemplate === null ? null : collapsePathParams(pathTemplate),
    declaringTypes: declaringTypesOf(lm),
    hasControllerAnnotation: annotationNames.some((n) => REST_CONTROLLER_ANNOTATIONS.has(n)),
    inherited: Object.values(lm.annotations).some((a) => typeof a['inherited_from'] === 'string'),
  };
}

/* ------------------------------------------------------------------ *
 * THE INTERFACE / IMPL RECONCILIATION
 * ------------------------------------------------------------------ */

interface ChosenGroup {
  canonical: EndpointCandidate;
  others: EndpointCandidate[];
  rule: string;
  declaringType: string | null;
}

/**
 * Spring registers a handler when a `@RestController` class IMPLEMENTS an
 * interface whose methods carry the mapping annotations. The annotations then
 * physically live on the interface while the traffic is actually served by the
 * concrete class — so the LM sees, and reports, the same endpoint twice:
 * once from the interface file (higher confidence, attributes tagged
 * `declared_on`) and once from the controller file (attributes tagged
 * `inherited_from`, lower confidence).
 *
 * Reconciliation:
 *   group by (transport, verb, path_template_normalized, destination)
 * then pick the CONCRETE IMPL as canonical, because that is what serves traffic
 * and what a stack trace will name, while retaining the interface FQN as the
 * declaring type. Rules are tried in order and the one that fired is logged, so
 * a surprising choice is always explainable:
 *
 *   1. `restcontroller_annotation` — the candidate's class carries
 *      `@RestController`/`@Controller`. Strongest and fixture-independent.
 *   2. `concrete_impl_marker` — the candidate's mapping attributes are tagged
 *      `inherited_from`, i.e. it is the inheriting (concrete) side.
 *   3. `not_declared_as_interface` — the other candidate's class is named by a
 *      `declared_on`/`inherited_from` marker somewhere, so it is an interface.
 *   4. `higher_confidence` — the LM's own confidence.
 *   5. `not_api_package` — DELIBERATELY WEAK: prefer the candidate whose file
 *      does not sit under an `api/` package. Purely a naming convention, only
 *      ever used when nothing structural distinguishes the candidates.
 *   6. `first_by_symbol` — total-order fallback so the build stays deterministic.
 */
function reconcileEndpoints(
  candidates: EndpointCandidate[],
  interfaceFqns: Set<string>,
  logger: Logger,
): ChosenGroup[] {
  const groups = new Map<string, EndpointCandidate[]>();
  for (const c of candidates) {
    const key = [c.transport, c.lm.verb ?? '', c.pathNormalized ?? '', c.lm.destination ?? ''].join('|');
    const list = groups.get(key);
    if (list) {
      list.push(c);
    } else {
      groups.set(key, [c]);
    }
  }

  const out: ChosenGroup[] = [];
  for (const key of [...groups.keys()].sort()) {
    const list = groups
      .get(key)!
      .slice()
      .sort((a, b) => cmp(a.handlerSymbol, b.handlerSymbol));

    let canonical = list[0]!;
    let rule = 'single_candidate';

    if (list.length > 1) {
      const pick = (
        name: string,
        predicate: (c: EndpointCandidate) => boolean,
      ): boolean => {
        const hits = list.filter(predicate);
        if (hits.length === 1) {
          canonical = hits[0]!;
          rule = name;
          return true;
        }
        return false;
      };

      const decided =
        pick('restcontroller_annotation', (c) => c.hasControllerAnnotation) ||
        pick('concrete_impl_marker', (c) => c.inherited) ||
        pick('not_declared_as_interface', (c) => !interfaceFqns.has(c.lm.handler_class_fqn)) ||
        pick(
          'higher_confidence',
          (c) => c.lm.confidence === Math.max(...list.map((x) => x.lm.confidence)),
        ) ||
        pick('not_api_package', (c) => !/(^|\/)api\//.test(c.file));

      if (!decided) {
        canonical = list[0]!;
        rule = 'first_by_symbol';
      }

      logger.log(
        'NORMALIZE',
        `endpoint group [${key}] had ${list.length} candidates ` +
          `(${list.map((c) => c.lm.handler_class_fqn).join(', ')}); ` +
          `chose ${canonical.lm.handler_class_fqn} via rule '${rule}'`,
      );
    }

    const others = list.filter((c) => c !== canonical);
    const declaring = sortedUnique([
      ...canonical.declaringTypes,
      ...others.flatMap((o) => [o.lm.handler_class_fqn, ...o.declaringTypes]),
    ]).filter((f) => f !== canonical.lm.handler_class_fqn);

    out.push({ canonical, others, rule, declaringType: declaring[0] ?? null });
  }
  return out;
}

/* ------------------------------------------------------------------ *
 * Entry points
 * ------------------------------------------------------------------ */

function entryPointKindOf(
  annotationNames: readonly string[],
  methodName: string,
  signature: string,
  markers: readonly string[],
): EntryPointKind | null {
  const has = (n: string): boolean => annotationNames.includes(n);
  if (has('KafkaListener')) {
    return 'kafka_listener';
  }
  if (has('JmsListener') || has('RabbitListener')) {
    return 'jms_listener';
  }
  if (has('Scheduled')) {
    return 'scheduled';
  }
  for (const marker of markers) {
    const bare = marker.replace(/^@/, '');
    if (bare !== '' && has(bare)) {
      return 'message_router_handler';
    }
  }
  if (annotationNames.some((n) => REST_CONTROLLER_ANNOTATIONS.has(n))) {
    return 'rest_controller';
  }
  if (methodName === 'main' && signature.startsWith('main([Ljava/lang/String;)')) {
    return 'main';
  }
  return null;
}

/* ------------------------------------------------------------------ *
 * normalizeRepo
 * ------------------------------------------------------------------ */

export function normalizeRepo(opts: NormalizeOptions): NormalizeResult {
  const { repo, extractions, propertyResolution, packagePrefixes, logger, extractorTag } = opts;
  const markers = opts.messageRouterMarkers ?? [];

  const records: IndexRecord[] = [];
  const unresolved: UnresolvedRecord[] = [];

  /* --- (a) DTO shapes: ONE whole-universe pass ------------------------- */
  // Nested substitution and inheritance both need the complete set, so every
  // DTO from every file is gathered first and hashed together exactly once.
  const dtoInputs = toDtoInputs(extractions);
  let shapeMap = new Map<string, { shape: string; nested_shapes: Record<string, string> }>();
  try {
    shapeMap = computeDtoShapes(dtoInputs);
  } catch (err) {
    shapeMap = failOpen(logger, 'NORMALIZE', 'computeDtoShapes', shapeMap, err);
  }
  logger.log('NORMALIZE', `computed ${shapeMap.size} dto shapes over the whole file universe`);

  const dtoShapes = new Map<string, string>();
  const dtoRecords: DtoRecord[] = [];
  for (const file of extractions) {
    for (const dto of file.extraction.dtos) {
      const computed = shapeMap.get(dto.fqn);
      if (!computed) {
        continue;
      }
      dtoShapes.set(dto.fqn, computed.shape);
      dtoRecords.push({
        kind: 'dto',
        fqn: dto.fqn,
        shape: computed.shape,
        fields: dto.fields.map((f) => ({
          name: f.name,
          type: f.type,
          nullable: f.nullable,
          annotations: [...f.annotations].sort(),
        })),
        nested_shapes: computed.nested_shapes,
        file: file.relativePath,
        line: dto.line,
        is_generated: dto.is_generated,
        extractor: extractorTag,
        extraction_confidence: dto.confidence,
      });
    }
  }
  dtoRecords.sort((a, b) => cmp(a.fqn, b.fqn));

  /* --- symbols: classes, methods, interfaces --------------------------- */
  const classes = new Map<string, ClassSymbolEntry>();
  const methods = new Map<string, MethodSymbolEntry>();
  const interfaceFqns = new Set<string>();
  const implementations = new Map<string, Set<string>>();

  const noteClass = (
    fqn: string,
    file: string,
    line: number,
    annotationNames: readonly string[] = [],
  ): void => {
    if (fqn === '' || !matchesPrefix(fqn, packagePrefixes)) {
      return;
    }
    const existing = classes.get(fqn);
    if (existing) {
      existing.line = Math.min(existing.line, line);
      existing.annotationNames = sortedUnique([...existing.annotationNames, ...annotationNames]);
      return;
    }
    classes.set(fqn, {
      fqn,
      file,
      line,
      isInterface: false,
      annotationNames: sortedUnique(annotationNames),
    });
  };

  const noteMethod = (
    classFqn: string,
    methodName: string,
    rawSignature: string,
    file: string,
    line: number,
  ): MethodSymbolEntry | null => {
    if (classFqn === '' || !matchesPrefix(classFqn, packagePrefixes)) {
      return null;
    }
    const signature = normalizeMethodSignature(rawSignature);
    if (signature === '') {
      return null;
    }
    const id = symbolId(repo, classFqn, signature);
    const existing = methods.get(id);
    if (existing) {
      return existing;
    }
    const entry: MethodSymbolEntry = { id, classFqn, methodName, signature, file, line };
    methods.set(id, entry);
    return entry;
  };

  // Pass 1: gather every symbol the LM saw, including method_call CALLERS —
  // a repository method that is only ever a callee still has to exist in the
  // table or the downstream chain silently breaks at its last hop.
  for (const file of extractions) {
    const ex = file.extraction;
    for (const ep of ex.endpoints) {
      noteClass(ep.handler_class_fqn, file.relativePath, ep.handler_line, Object.keys(ep.annotations));
      noteMethod(
        ep.handler_class_fqn,
        ep.handler_method_name,
        ep.handler_method_signature,
        file.relativePath,
        ep.handler_line,
      );
      for (const declaring of declaringTypesOf(ep)) {
        interfaceFqns.add(declaring);
        const set = implementations.get(declaring) ?? new Set<string>();
        set.add(ep.handler_class_fqn);
        implementations.set(declaring, set);
      }
    }
    for (const inv of ex.invocations) {
      noteClass(inv.enclosing_class_fqn, file.relativePath, inv.line);
      noteMethod(
        inv.enclosing_class_fqn,
        inv.enclosing_method_name,
        inv.enclosing_method_signature,
        file.relativePath,
        inv.line,
      );
    }
    for (const mc of ex.method_calls) {
      noteClass(mc.caller_class_fqn, file.relativePath, mc.line);
      const name = normalizeMethodSignature(mc.caller_method_signature).split('(')[0] ?? '';
      noteMethod(mc.caller_class_fqn, name, mc.caller_method_signature, file.relativePath, mc.line);
    }
    for (const w of ex.wirings) {
      if (w.defining_class_fqn !== null) {
        noteClass(w.defining_class_fqn, file.relativePath, w.line);
      }
    }
    for (const b of ex.property_bindings) {
      noteClass(b.class_fqn, file.relativePath, b.line);
    }
    for (const d of ex.dtos) {
      noteClass(d.fqn, file.relativePath, d.line);
    }
  }

  // An interface named by a declaring marker is genuinely an interface — that
  // marker is the only implements/extends evidence the LM schema carries.
  for (const fqn of interfaceFqns) {
    const cls = classes.get(fqn);
    if (cls) {
      cls.isInterface = true;
    }
  }
  // A class that implements an interface is by construction concrete.
  for (const impls of implementations.values()) {
    for (const impl of impls) {
      const cls = classes.get(impl);
      if (cls) {
        cls.isInterface = false;
      }
    }
  }

  /* --- (b) endpoints + reconciliation ---------------------------------- */
  const candidates: EndpointCandidate[] = [];
  for (const file of extractions) {
    for (const ep of file.extraction.endpoints) {
      candidates.push(toCandidate(ep, file.relativePath, repo, logger));
    }
  }

  const chosen = reconcileEndpoints(candidates, interfaceFqns, logger);
  const endpoints: Endpoint[] = [];
  const fingerprints: Fingerprint[] = [];
  /** handler symbol id -> merged annotation names, for entry-point detection. */
  const handlerAnnotations = new Map<string, string[]>();

  for (const group of chosen) {
    const c = group.canonical;
    const lm = c.lm;

    // Merge annotations across the group so the interface's `declared_on`
    // evidence survives even though the controller is canonical.
    const mergedAnnotations: Record<string, Record<string, unknown>> = {};
    for (const src of [...group.others, c]) {
      for (const [name, attrs] of Object.entries(src.lm.annotations)) {
        mergedAnnotations[name] = { ...(mergedAnnotations[name] ?? {}), ...attrs };
      }
    }
    // `Endpoint` has no dedicated field for the declaring type, and adding one
    // would be a schema break, so it is recorded as a synthetic annotation
    // entry under the reserved key `declaring_type`. Consumers read
    // `endpoint.annotations.declaring_type.fqn`.
    if (group.declaringType !== null) {
      mergedAnnotations['declaring_type'] = {
        fqn: group.declaringType,
        reconciliation_rule: group.rule,
        merged_candidates: group.others.length + 1,
      };
    }

    const requestShape = shapeOfType(lm.request_dto_fqn, shapeMap);
    const responseShape = shapeOfType(lm.response_dto_fqn, shapeMap);
    const handlerSymbol = c.handlerSymbol;
    const id = endpointId(lm.transport, lm.verb, c.pathTemplate, handlerSymbol);
    const fingerprint = endpointFingerprint(
      lm.transport,
      lm.verb,
      c.pathNormalized,
      requestShape,
      responseShape,
      lm.destination,
    );

    endpoints.push({
      id,
      fingerprint,
      transport: lm.transport,
      verb: lm.verb,
      path_template: c.pathTemplate,
      path_template_normalized: c.pathNormalized,
      destination: lm.destination,
      request_dto_fqn: lm.request_dto_fqn,
      response_dto_fqn: lm.response_dto_fqn,
      request_dto_shape: requestShape,
      response_dto_shape: responseShape,
      path_params: toParamSpecs(lm.path_params.map((p) => ({ ...p, required: true }))),
      query_params: toParamSpecs(lm.query_params),
      headers: toParamSpecs(lm.headers),
      status_codes: [],
      logical_name: lm.logical_name,
      handler_symbol: handlerSymbol,
      file: c.file,
      line: lm.handler_line,
      annotations: mergedAnnotations,
      visibility: 'Deprecated' in mergedAnnotations ? 'deprecated' : 'public',
      extractor: extractorTag,
      extraction_confidence: lm.confidence,
    });

    fingerprints.push({
      id,
      fingerprint,
      transport: lm.transport,
      path_template: c.pathTemplate,
      destination: lm.destination,
      request_dto_shape: requestShape,
      response_dto_shape: responseShape,
    });

    handlerAnnotations.set(
      handlerSymbol,
      sortedUnique([...(handlerAnnotations.get(handlerSymbol) ?? []), ...Object.keys(mergedAnnotations)]),
    );

    if (lm.logical_name !== null && lm.logical_name !== '') {
      records.push({
        kind: 'logical_name_ref',
        logical_name: lm.logical_name,
        context: 'openapi_operation_id',
        symbol: handlerSymbol,
        file: c.file,
        line: lm.handler_line,
        extractor: extractorTag,
        extraction_confidence: lm.confidence,
      } satisfies LogicalNameRefRecord);
    }
  }

  endpoints.sort((a, b) =>
    cmp(
      `${a.transport}|${a.verb ?? ''}|${a.path_template ?? ''}|${a.destination ?? ''}|${a.handler_symbol}`,
      `${b.transport}|${b.verb ?? ''}|${b.path_template ?? ''}|${b.destination ?? ''}|${b.handler_symbol}`,
    ),
  );
  fingerprints.sort((a, b) => cmp(a.id, b.id));

  logger.log(
    'NORMALIZE',
    `${candidates.length} endpoint candidates reconciled to ${endpoints.length} endpoints ` +
      `(${endpoints.filter((e) => e.transport === 'rest').length} rest, ` +
      `${endpoints.filter((e) => e.transport !== 'rest').length} non-rest)`,
  );

  /* --- (c) invocations + property enrichment --------------------------- */
  const table = propertyResolution.table;
  const envs: Env[] = table.envs.length > 0 ? table.envs : (['default'] as Env[]);
  const derivedFragmentIndex = new Map<string, Set<string>>();
  const unresolvedPlaceholders = new Set<string>();

  const noteDerived = (fragment: string, key: string): void => {
    if (fragment === '') {
      return;
    }
    const set = derivedFragmentIndex.get(fragment) ?? new Set<string>();
    set.add(key);
    derivedFragmentIndex.set(fragment, set);
  };

  /**
   * THE PROPERTY ENRICHMENT LOOP.
   *
   * A consumer that builds its URL from `@Value("${services.cdu.base-url}")`
   * has NO literal URL in its source, so the LM can only hand us a
   * `property_key_ref` (plus, if it is lucky, a literal path fragment). The
   * only route to a joinable fragment runs through the resolved property table.
   *
   * Rules:
   *  - resolve across EVERY env, not just one: the same key resolves to four
   *    different hosts here and all four must be joinable;
   *  - only fill `path_fragment` when the LM left it null — good LM output is
   *    never overwritten;
   *  - when the LM DID fill it, still record the property-derived fragments in
   *    the manifest (and on the record) because the cross-repo join needs both;
   *  - when the property is UNRESOLVED (Vault ref, absent env var) the verbatim
   *    placeholder text is itself used as a join token. That is deliberate: two
   *    beans wired to the same unresolved `${services.cdu.base-url}` still
   *    match each other.
   */
  const enrichInvocation = (
    inv: LmInvocation,
    file: string,
  ): { pathFragment: string | null; hints: string[]; derived: string[] } => {
    const hints = [...inv.confidence_hints];
    const key = inv.property_key_ref;
    if (key === null || key === '') {
      return { pathFragment: inv.path_fragment, hints, derived: [] };
    }

    const derived = new Set<string>();
    let anyResolved = false;
    for (const env of envs) {
      const value = lookupResolved(table, key, env);
      if (value === null) {
        continue;
      }
      anyResolved = true;
      for (const frag of valueFragments(value)) {
        derived.add(frag);
      }
      // The full resolved value is itself a join token — it is what
      // distinguishes the per-env hosts from each other.
      if (value.includes('/')) {
        derived.add(value.trim());
      }
      for (const token of placeholderTokens(value)) {
        unresolvedPlaceholders.add(token);
        derived.add(token);
      }
    }
    if (!anyResolved) {
      // Unknown key: the placeholder text is still a stable join token.
      const token = `\${${key}}`;
      unresolvedPlaceholders.add(token);
      derived.add(token);
      logger.log(
        'NORMALIZE',
        `${file}:${inv.line} property_key_ref '${key}' is not in the resolved table — ` +
          `using the verbatim placeholder '${token}' as the join token`,
      );
    }

    const derivedSorted = [...derived].sort();
    for (const frag of derivedSorted) {
      noteDerived(frag, key);
    }

    let pathFragment = inv.path_fragment;
    if ((pathFragment === null || pathFragment === '') && derivedSorted.length > 0) {
      // Prefer a path-shaped fragment over a bare placeholder token.
      pathFragment = derivedSorted.find((f) => f.startsWith('/')) ?? derivedSorted[0]!;
      hints.push('path_fragment_from_property');
      logger.log(
        'NORMALIZE',
        `${file}:${inv.line} path_fragment filled from property '${key}' -> '${pathFragment}'`,
      );
    } else if (pathFragment !== null && derivedSorted.length > 0) {
      hints.push('property_fragments_recorded');
      // The LM's own fragment is joinable via this property key too.
      noteDerived(pathFragment, key);
      noteDerived(collapsePathParams(pathFragment), key);
    }

    return { pathFragment, hints: sortedUnique(hints), derived: derivedSorted };
  };

  const invocations: InvocationRecord[] = [];
  for (const file of extractions) {
    for (const inv of file.extraction.invocations) {
      const enclosingSymbol = symbolId(
        repo,
        inv.enclosing_class_fqn,
        inv.enclosing_method_signature,
      );
      const { pathFragment, hints, derived } = enrichInvocation(inv, file.relativePath);
      const notes: UnresolvedNote[] = inv.unresolved.map((u) => ({
        what: u.what,
        reason: u.reason,
        expression: u.expression,
      }));

      const record: InvocationRecord = {
        kind: 'invocation',
        id: invocationId(file.relativePath, inv.line, enclosingSymbol, inv.transport),
        transport: inv.transport,
        enclosing_symbol: enclosingSymbol,
        file: file.relativePath,
        line: inv.line,
        literal_url: inv.literal_url,
        path_fragment: pathFragment,
        destination: inv.destination,
        request_dto_fqn: inv.request_dto_fqn,
        response_dto_fqn: inv.response_dto_fqn,
        client_bean: inv.client_bean,
        property_key_ref: inv.property_key_ref,
        logical_name: inv.logical_name,
        method_name: inv.method_name,
        confidence_hints: hints,
        unresolved: notes,
        annotations: {
          enclosing_method_name: inv.enclosing_method_name,
          property_fragments: derived,
        },
        extractor: extractorTag,
        extraction_confidence: inv.confidence,
      };
      invocations.push(record);

      for (const note of notes) {
        unresolved.push({
          kind: 'unresolved',
          what: note.what,
          context: { file: file.relativePath, line: inv.line, enclosing_symbol: enclosingSymbol },
          reason: note.reason,
          partial_info: {
            invocation_id: record.id,
            method_name: inv.method_name,
            expression: note.expression ?? null,
            client_bean: inv.client_bean,
            property_key_ref: inv.property_key_ref,
          },
        });
      }
    }
  }
  invocations.sort((a, b) => cmp(a.id, b.id));

  /* --- (d) wirings, bindings, file-level unresolved --------------------- */
  const wirings: WiringRecord[] = [];
  const bindings: PropertyBindingRecord[] = [];
  for (const file of extractions) {
    for (const w of file.extraction.wirings) {
      wirings.push({
        kind: 'wiring',
        bean: w.bean_name,
        bean_class: w.bean_class_fqn ?? '',
        property_key: w.property_key ?? '',
        injection: w.injection,
        file: file.relativePath,
        line: w.line,
        defining_class: w.defining_class_fqn,
        extractor: extractorTag,
        extraction_confidence: w.confidence,
      });
    }
    for (const b of file.extraction.property_bindings) {
      bindings.push({
        kind: 'property_binding',
        prefix: b.prefix,
        class_fqn: b.class_fqn,
        fields: b.fields.map((f) => ({
          name: f.name,
          type: f.type,
          property_subkey: f.property_subkey,
        })),
        file: file.relativePath,
        line: b.line,
        extractor: extractorTag,
        extraction_confidence: b.confidence,
      });
    }
    for (const u of file.extraction.unresolved) {
      unresolved.push({
        kind: 'unresolved',
        what: u.what,
        context: { file: file.relativePath, line: 1, enclosing_symbol: null },
        reason: u.reason,
        partial_info: { expression: u.expression ?? null, source: 'lm_file_level' },
      });
    }
  }
  wirings.sort((a, b) => cmp(`${a.file}|${String(a.line).padStart(8, '0')}|${a.bean}`,
    `${b.file}|${String(b.line).padStart(8, '0')}|${b.bean}`));
  bindings.sort((a, b) => cmp(`${a.class_fqn}|${a.prefix}`, `${b.class_fqn}|${b.prefix}`));

  /* --- symbols + entry points ------------------------------------------ */
  const symbolRecords: SymbolRecord[] = [];
  const entryPoints: EntryPointRecord[] = [];

  for (const fqn of [...classes.keys()].sort()) {
    const cls = classes.get(fqn)!;
    symbolRecords.push({
      kind: 'symbol',
      id: symbolId(repo, fqn),
      fqn,
      symbol_kind: cls.isInterface ? 'interface' : 'class',
      file: cls.file,
      line_start: cls.line,
      line_end: cls.line,
      modifiers: [],
      is_entry_point: false,
      entry_point_kind: null,
      entry_point_details: null,
      annotations: cls.annotationNames.map((n) => ({ name: n })),
      enclosing_class: null,
      extractor: extractorTag,
      extraction_confidence: 1.0,
    });
  }

  for (const id of [...methods.keys()].sort()) {
    const m = methods.get(id)!;
    const cls = classes.get(m.classFqn);
    const annotationNames = sortedUnique([
      ...(cls?.annotationNames ?? []),
      ...(handlerAnnotations.get(id) ?? []),
    ]);
    const kind = entryPointKindOf(annotationNames, m.methodName, m.signature, markers);
    // A class-level @RestController only makes its MAPPED methods entry points.
    const isHandler = handlerAnnotations.has(id);
    const effective: EntryPointKind | null =
      kind === 'rest_controller' && !isHandler ? null : kind;

    const details: Record<string, unknown> | null =
      effective === null
        ? null
        : { class_fqn: m.classFqn, method: m.methodName, signature: m.signature };

    symbolRecords.push({
      kind: 'symbol',
      id,
      fqn: m.classFqn,
      symbol_kind: 'method',
      file: m.file,
      line_start: m.line,
      line_end: m.line,
      modifiers: [],
      is_entry_point: effective !== null,
      entry_point_kind: effective,
      entry_point_details: details,
      annotations: annotationNames.map((n) => ({ name: n })),
      enclosing_class: m.classFqn,
      extractor: extractorTag,
      extraction_confidence: 1.0,
    });

    if (effective !== null) {
      entryPoints.push({
        kind: 'entry_point',
        symbol: id,
        entry_kind: effective,
        details,
        file: m.file,
        line: m.line,
      });
    }
  }
  symbolRecords.sort((a, b) => cmp(a.id, b.id));
  entryPoints.sort((a, b) => cmp(a.symbol, b.symbol));

  /* --- (e) consumption manifest ---------------------------------------- */
  const fragmentSet = new Set<string>();
  const destinations = new Set<string>();
  const logicalNames = new Set<string>();

  for (const ep of endpoints) {
    if (ep.path_template !== null) {
      fragmentSet.add(ep.path_template);
      for (const f of cumulativeFragments(ep.path_template)) {
        fragmentSet.add(f);
      }
    }
    if (ep.path_template_normalized !== null) {
      fragmentSet.add(ep.path_template_normalized);
    }
    if (ep.destination !== null && ep.destination !== '') {
      destinations.add(ep.destination);
      // A `${...}` destination also contributes its resolved values per env.
      for (const token of placeholderTokens(ep.destination)) {
        unresolvedPlaceholders.add(token);
        const key = token.slice(2, -1);
        for (const env of envs) {
          const resolved = lookupResolved(table, key, env);
          if (resolved !== null && resolved !== '') {
            destinations.add(resolved);
          }
        }
      }
    }
    if (ep.logical_name !== null && ep.logical_name !== '') {
      logicalNames.add(ep.logical_name);
    }
  }

  for (const inv of invocations) {
    if (inv.path_fragment !== null && inv.path_fragment !== '') {
      fragmentSet.add(inv.path_fragment);
      fragmentSet.add(collapsePathParams(inv.path_fragment));
      for (const f of cumulativeFragments(inv.path_fragment)) {
        fragmentSet.add(f);
      }
    }
    if (inv.destination !== null && inv.destination !== '') {
      destinations.add(inv.destination);
    }
    if (inv.logical_name !== null && inv.logical_name !== '') {
      logicalNames.add(inv.logical_name);
    }
    const derived = inv.annotations['property_fragments'];
    if (Array.isArray(derived)) {
      for (const f of derived) {
        if (typeof f === 'string') {
          fragmentSet.add(f);
        }
      }
    }
  }

  for (const rec of propertyResolution.records) {
    for (const token of placeholderTokens(rec.value)) {
      unresolvedPlaceholders.add(token);
    }
  }

  // Merge the property pass's inverted index with the invocation-derived one.
  const mergedIndex: Record<string, string[]> = {};
  const mergeInto = (frag: string, keys: Iterable<string>): void => {
    const existing = new Set(mergedIndex[frag] ?? []);
    for (const k of keys) {
      existing.add(k);
    }
    mergedIndex[frag] = [...existing].sort();
  };
  for (const [frag, keys] of Object.entries(propertyResolution.pathFragmentIndex)) {
    mergeInto(frag, keys);
  }
  for (const [frag, keys] of derivedFragmentIndex) {
    mergeInto(frag, keys);
  }
  const sortedIndex: Record<string, string[]> = {};
  for (const frag of Object.keys(mergedIndex).sort()) {
    sortedIndex[frag] = mergedIndex[frag]!;
  }

  const manifest: ConsumptionManifest = {
    dto_shapes: sortedUnique(dtoRecords.map((d) => d.shape)),
    dto_fqns: sortedUnique(dtoRecords.map((d) => d.fqn)),
    path_fragments: sortedUnique(fragmentSet),
    destinations: sortedUnique(destinations),
    logical_names: sortedUnique(logicalNames),
    property_keys: sortedUnique(propertyResolution.records.map((r) => r.key)),
    unresolved_placeholders: sortedUnique(unresolvedPlaceholders),
    path_fragment_to_property_keys: sortedIndex,
  };

  const manifestBytes = Buffer.byteLength(JSON.stringify(manifest), 'utf8');
  if (manifestBytes > 50_000) {
    logger.log(
      'NORMALIZE',
      `WARN consumption_manifest is ${manifestBytes} bytes (>50KB budget) — ` +
        `still written, but the phase-1 broadcast will be larger than the spec allows`,
    );
  }

  /* --- assemble records ------------------------------------------------ */
  records.push(...symbolRecords);
  records.push(...dtoRecords);
  records.push(...invocations);
  records.push(...propertyResolution.records);
  records.push(...wirings);
  records.push(...bindings);
  records.push(...entryPoints);
  unresolved.push(...propertyResolution.unresolved);

  unresolved.sort((a, b) =>
    cmp(
      `${a.what}|${a.context.file}|${String(a.context.line).padStart(8, '0')}|${a.reason}`,
      `${b.what}|${b.context.file}|${String(b.context.line).padStart(8, '0')}|${b.reason}`,
    ),
  );
  records.push(...unresolved);

  const symbolTable: SymbolTable = {
    methods: [...methods.keys()].sort().map((k) => methods.get(k)!),
    byId: methods,
    byClassSignature: new Map(
      [...methods.values()].map((m) => [`${m.classFqn}#${m.signature}`, m] as const),
    ),
    byClassMethod: (() => {
      const out = new Map<string, MethodSymbolEntry[]>();
      for (const m of [...methods.keys()].sort().map((k) => methods.get(k)!)) {
        const key = `${m.classFqn}#${m.methodName}`;
        const list = out.get(key);
        if (list) {
          list.push(m);
        } else {
          out.set(key, [m]);
        }
      }
      return out;
    })(),
    classes,
    implementations: new Map(
      [...implementations.keys()].sort().map((k) => [k, [...implementations.get(k)!].sort()] as const),
    ),
  };

  logger.log(
    'NORMALIZE',
    `emitted ${records.length} records from ${extractions.length} extracted files ` +
      `(${opts.files.length} walked): ${symbolRecords.length} symbols, ${dtoRecords.length} dtos, ` +
      `${invocations.length} invocations, ${wirings.length} wirings, ${entryPoints.length} entry points, ` +
      `${unresolved.length} unresolved`,
  );

  return { endpoints, fingerprints, records, manifest, unresolved, symbolTable, dtoShapes };
}
