/**
 * Raw property extraction: YAML, .properties, and k8s ConfigMap sources.
 *
 * Everything here is deterministic and fail-open. A malformed file logs at
 * `[YAML]` and yields zero properties; nothing in this module ever throws out
 * to the caller.
 *
 * Line numbers are REAL, not estimated: the `yaml` package's `LineCounter` is
 * threaded through `parseAllDocuments` so every scalar's byte offset can be
 * converted to a true 1-based line.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import { LineCounter, parseAllDocuments, isMap, isPair, isScalar, isSeq } from 'yaml';
import type { Env, SourceType } from '../../types.js';
import type { Logger } from '../../util/logger.js';

/** One property as it literally appears in a config source, pre-resolution. */
export interface RawProperty {
  key: string;
  raw_value: string;
  line: number;
  source: string;
  source_type: SourceType;
  env: Env;
  branch: string | null;
  /**
   * True when this key was synthesized by relaxed-binding normalization
   * (ConfigMap `SERVICES_CDU_TIMEOUT_MS` -> `services.cdu.timeout-ms`).
   * The resolver prefers the canonical (non-alias) form when both are present.
   */
  is_alias?: boolean;
}

export interface ParseContext {
  source: string;
  sourceType: SourceType;
  env: Env;
  branch?: string | null;
}

function mk(
  key: string,
  rawValue: string,
  line: number,
  ctx: ParseContext,
  isAlias = false,
): RawProperty {
  return {
    key,
    raw_value: rawValue,
    line,
    source: ctx.source,
    source_type: ctx.sourceType,
    env: ctx.env,
    branch: ctx.branch ?? null,
    is_alias: isAlias,
  };
}

/* ------------------------------------------------------------------ */
/* YAML                                                                */
/* ------------------------------------------------------------------ */

function lineOf(node: unknown, lc: LineCounter): number {
  const range = (node as { range?: [number, number, number] } | null | undefined)?.range;
  if (!range) {
    return 1;
  }
  return lc.linePos(range[0]).line;
}

function scalarText(value: unknown): string {
  if (value === null || value === undefined) {
    return '';
  }
  if (typeof value === 'string') {
    return value;
  }
  return String(value);
}

const MAX_YAML_DEPTH = 64;

function flattenNode(
  node: unknown,
  prefix: string,
  ctx: ParseContext,
  lc: LineCounter,
  out: RawProperty[],
  depth: number,
): void {
  if (depth > MAX_YAML_DEPTH) {
    return;
  }

  if (isMap(node)) {
    for (const item of node.items) {
      if (!isPair(item)) {
        continue;
      }
      const keyNode = item.key;
      const keyText = isScalar(keyNode) ? scalarText(keyNode.value) : '';
      if (keyText === '') {
        continue;
      }
      const child = prefix === '' ? keyText : `${prefix}.${keyText}`;
      if (item.value === null || item.value === undefined) {
        out.push(mk(child, '', lineOf(keyNode, lc), ctx));
      } else {
        flattenNode(item.value, child, ctx, lc, out, depth + 1);
      }
    }
    return;
  }

  if (isSeq(node)) {
    node.items.forEach((item, i) => {
      flattenNode(item, `${prefix}[${i}]`, ctx, lc, out, depth + 1);
    });
    return;
  }

  if (isScalar(node)) {
    if (prefix === '') {
      // A bare document-level scalar carries no key; nothing to bind.
      return;
    }
    out.push(mk(prefix, scalarText(node.value), lineOf(node, lc), ctx));
  }
}

/**
 * Flatten a YAML config file to dotted keys with true line numbers.
 * Sequences flatten to `key[0]`, `key[1]`. Multi-document files (Spring's
 * `---` profile documents) are all flattened into the same key space.
 */
export function parseYamlProperties(
  text: string,
  ctx: ParseContext,
  logger?: Logger,
): RawProperty[] {
  const out: RawProperty[] = [];
  try {
    const lc = new LineCounter();
    const docs = parseAllDocuments(text, { lineCounter: lc });
    for (const doc of docs) {
      if (doc.errors.length > 0) {
        logger?.log(
          'YAML',
          `malformed YAML in ${ctx.source}: ${doc.errors[0].message} — yielding zero properties`,
        );
        return [];
      }
    }
    for (const doc of docs) {
      flattenNode(doc.contents, '', ctx, lc, out, 0);
    }
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger?.log('YAML', `failed to parse ${ctx.source}: ${detail} — yielding zero properties`);
    return [];
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* .properties                                                         */
/* ------------------------------------------------------------------ */

function endsWithOddBackslash(s: string): boolean {
  let n = 0;
  for (let i = s.length - 1; i >= 0 && s[i] === '\\'; i--) {
    n++;
  }
  return n % 2 === 1;
}

/** Index of the first unescaped `=` or `:`, or -1. */
function separatorIndex(s: string): number {
  for (let i = 0; i < s.length; i++) {
    if (s[i] === '\\') {
      i++;
      continue;
    }
    if (s[i] === '=' || s[i] === ':') {
      return i;
    }
  }
  return -1;
}

function unescapeKey(s: string): string {
  return s.replace(/\\([:=\s\\])/g, '$1');
}

/**
 * `key=value` / `key:value` files. `#` and `!` start comments. A line ending
 * in an odd number of backslashes continues onto the next physical line; the
 * emitted line number is the FIRST physical line of the logical line.
 */
export function parsePropertiesFile(
  text: string,
  ctx: ParseContext,
  logger?: Logger,
): RawProperty[] {
  const out: RawProperty[] = [];
  try {
    const lines = text.split(/\r\n|\r|\n/);
    let i = 0;
    while (i < lines.length) {
      const startLine = i + 1;
      const first = lines[i];
      const trimmedFirst = first.trim();
      if (trimmedFirst === '' || trimmedFirst.startsWith('#') || trimmedFirst.startsWith('!')) {
        i++;
        continue;
      }

      let logical = first;
      while (endsWithOddBackslash(logical) && i + 1 < lines.length) {
        logical = logical.slice(0, -1) + lines[i + 1].replace(/^[ \t]+/, '');
        i++;
      }
      i++;

      const body = logical.trim();
      if (body === '') {
        continue;
      }

      let key: string;
      let value: string;
      const sep = separatorIndex(body);
      if (sep >= 0) {
        key = body.slice(0, sep);
        value = body.slice(sep + 1);
      } else {
        const ws = body.search(/\s/);
        if (ws < 0) {
          key = body;
          value = '';
        } else {
          key = body.slice(0, ws);
          value = body.slice(ws + 1);
        }
      }

      key = unescapeKey(key.trim());
      value = value.replace(/^[ \t]+/, '').replace(/[ \t]+$/, '');
      if (key === '') {
        continue;
      }
      out.push(mk(key, value, startLine, ctx));
    }
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger?.log('YAML', `failed to parse ${ctx.source}: ${detail} — yielding zero properties`);
    return [];
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* ConfigMap + relaxed binding                                         */
/* ------------------------------------------------------------------ */

/**
 * Trailing tokens that Spring conventionally hyphenates onto the previous
 * token rather than making their own key segment (`TIMEOUT_MS` is one
 * property `timeout-ms`, not `timeout.ms`).
 *
 * SCREAMING_SNAKE -> dotted is genuinely ambiguous: nothing in the string
 * distinguishes `SERVICES_CDU_TIMEOUT_MS` (-> services.cdu.timeout-ms) from
 * `SPRING_PROFILES_ACTIVE` (-> spring.profiles.active). This unit-suffix list
 * resolves the common case for the PRIMARY alias; `relaxedBindingAliases`
 * additionally emits the plain all-dots candidate so joins work either way.
 */
const UNIT_SUFFIXES = new Set([
  'ms',
  'ns',
  'us',
  's',
  'sec',
  'secs',
  'seconds',
  'millis',
  'min',
  'mins',
  'minutes',
  'hours',
  'days',
  'bytes',
  'kb',
  'mb',
  'gb',
]);

const SCREAMING = /^[A-Z][A-Z0-9]*(_[A-Z0-9]+)*$/;

function kebabSegment(seg: string): string {
  return seg
    .replace(/_/g, '-')
    .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
    .toLowerCase();
}

/**
 * Spring relaxed binding: map an environment-style key onto its canonical
 * dotted/kebab property key. `SERVICES_CDU_TIMEOUT_MS` -> `services.cdu.timeout-ms`.
 * Already-canonical keys are returned kebab-normalized and otherwise unchanged.
 */
export function relaxedBindingKey(key: string): string {
  const k = key.trim();
  if (k === '') {
    return '';
  }
  if (SCREAMING.test(k)) {
    const parts = k.toLowerCase().split('_');
    if (parts.length >= 2 && UNIT_SUFFIXES.has(parts[parts.length - 1])) {
      const last = `${parts[parts.length - 2]}-${parts[parts.length - 1]}`;
      return [...parts.slice(0, parts.length - 2), last].join('.');
    }
    return parts.join('.');
  }
  return k.split('.').map(kebabSegment).join('.');
}

/** Every plausible relaxed-binding form for a key, deduped and sorted. */
export function relaxedBindingAliases(key: string): string[] {
  const k = key.trim();
  const out = new Set<string>();
  if (k === '') {
    return [];
  }
  out.add(relaxedBindingKey(k));
  if (SCREAMING.test(k)) {
    out.add(k.toLowerCase().split('_').join('.'));
  }
  out.delete(k);
  return [...out].sort();
}

/**
 * A Kubernetes ConfigMap. Only the top-level `data:` block is read. Each key
 * is emitted verbatim (canonical) plus every relaxed-binding alias, flagged
 * `is_alias` so the resolver prefers the literal form on collision.
 */
export function parseConfigMap(text: string, ctx: ParseContext, logger?: Logger): RawProperty[] {
  const out: RawProperty[] = [];
  try {
    const lc = new LineCounter();
    const docs = parseAllDocuments(text, { lineCounter: lc });
    for (const doc of docs) {
      if (doc.errors.length > 0) {
        logger?.log(
          'YAML',
          `malformed ConfigMap ${ctx.source}: ${doc.errors[0].message} — yielding zero properties`,
        );
        return [];
      }
    }
    for (const doc of docs) {
      const root = doc.contents;
      if (!isMap(root)) {
        continue;
      }
      for (const item of root.items) {
        if (!isPair(item)) {
          continue;
        }
        const keyText = isScalar(item.key) ? scalarText(item.key.value) : '';
        if (keyText !== 'data') {
          continue;
        }
        const dataNode = item.value;
        if (!isMap(dataNode)) {
          continue;
        }
        for (const entry of dataNode.items) {
          if (!isPair(entry)) {
            continue;
          }
          const k = isScalar(entry.key) ? scalarText(entry.key.value) : '';
          if (k === '') {
            continue;
          }
          const v = isScalar(entry.value) ? scalarText(entry.value.value) : '';
          const line = lineOf(entry.key, lc);
          out.push(mk(k, v, line, ctx, false));
          for (const alias of relaxedBindingAliases(k)) {
            out.push(mk(alias, v, line, ctx, true));
          }
        }
      }
    }
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    logger?.log('YAML', `failed to parse ${ctx.source}: ${detail} — yielding zero properties`);
    return [];
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Filename -> Env                                                     */
/* ------------------------------------------------------------------ */

const PROFILE_SYNONYMS: Record<string, Env> = {
  dev: 'dev',
  develop: 'dev',
  development: 'dev',
  local: 'dev',
  uat: 'uat',
  qa: 'uat',
  staging: 'uat',
  stage: 'uat',
  prod: 'prod',
  production: 'prod',
  prd: 'prod',
  shared: 'shared',
  common: 'shared',
  default: 'default',
};

/**
 * Derive the environment a config file applies to from its filename.
 *
 * `application.yml` -> `default`, `application-dev.properties` -> `dev`,
 * `application-shared.yml` -> `shared`, a Config Server `<app>-<profile>.yml`
 * -> that profile. A Config Server `application.yml` applies to every app, so
 * with `{ isConfigServer: true }` it maps to `shared` rather than `default`.
 * Unknown profiles fall back to `default`.
 */
export function envFromFilename(filename: string, opts?: { isConfigServer?: boolean }): Env {
  const base = path.basename(filename).replace(/\.(ya?ml|properties)$/i, '');
  if (base === '') {
    return 'default';
  }
  const dash = base.indexOf('-');
  if (dash < 0) {
    if (opts?.isConfigServer) {
      return 'shared';
    }
    return 'default';
  }
  const profile = base.slice(dash + 1).toLowerCase();
  const direct = PROFILE_SYNONYMS[profile];
  if (direct) {
    return direct;
  }
  // `<app>-<profile>` where the app name itself contains dashes: use the last
  // dash-delimited token as the profile candidate.
  const lastToken = profile.slice(profile.lastIndexOf('-') + 1);
  return PROFILE_SYNONYMS[lastToken] ?? 'default';
}

/* ------------------------------------------------------------------ */
/* Discovery                                                           */
/* ------------------------------------------------------------------ */

export interface DiscoveryOptions {
  configServerPaths?: string[];
  configServerBranches?: string[];
  configMapPaths?: string[];
  /**
   * Optional injection hook for reading a Config Server file at a specific
   * git branch. This module never shells out to git. When absent, the working
   * tree is read once and labelled with the FIRST configured branch.
   */
  readBranch?: (filePath: string, branch: string) => string | null;
}

export interface ConfigSourceDescriptor {
  /** Absolute path on disk. */
  path: string;
  /** Stable, repo-relative-ish identifier written into records. */
  source: string;
  source_type: SourceType;
  env: Env;
  branch: string | null;
  format: 'yaml' | 'properties';
  text: string;
}

const SKIP_DIRS = new Set([
  'node_modules',
  '.git',
  'out',
  'dist',
  'build',
  'target',
  '.gradle',
  '.idea',
  '.vscode',
  'bin',
]);

function walkForResources(root: string, out: string[], depth: number): void {
  if (depth > 12) {
    return;
  }
  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(root, { withFileTypes: true });
  } catch {
    return;
  }
  entries.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
  for (const e of entries) {
    const full = path.join(root, e.name);
    if (e.isDirectory()) {
      if (SKIP_DIRS.has(e.name)) {
        continue;
      }
      walkForResources(full, out, depth + 1);
    } else if (e.isFile()) {
      if (!/^application.*\.(ya?ml|properties)$/i.test(e.name)) {
        continue;
      }
      const norm = full.split(path.sep).join('/');
      if (!norm.includes('/src/main/resources/')) {
        continue;
      }
      out.push(full);
    }
  }
}

function formatOf(file: string): 'yaml' | 'properties' {
  return /\.properties$/i.test(file) ? 'properties' : 'yaml';
}

function readText(file: string): string | null {
  try {
    return fs.readFileSync(file, 'utf8');
  } catch {
    return null;
  }
}

function relSource(repoRoot: string, file: string): string {
  const rel = path.relative(repoRoot, file);
  const useRel = rel !== '' && !rel.startsWith('..') && !path.isAbsolute(rel);
  return (useRel ? rel : file).split(path.sep).join('/');
}

/**
 * Locate every config source for a repo. Deterministic: results are sorted by
 * (source_type, source, branch, env) and no clock/env/randomness is consulted.
 */
export function discoverConfigSources(
  repoRoot: string,
  opts: DiscoveryOptions,
  logger?: Logger,
): ConfigSourceDescriptor[] {
  const out: ConfigSourceDescriptor[] = [];

  // 1. In-repo application*.{yml,yaml,properties} under src/main/resources.
  const resourceFiles: string[] = [];
  walkForResources(repoRoot, resourceFiles, 0);
  for (const file of resourceFiles) {
    const text = readText(file);
    if (text === null) {
      logger?.log('YAML', `unreadable config file ${file} — skipped`);
      continue;
    }
    out.push({
      path: file,
      source: relSource(repoRoot, file),
      source_type: 'application_yml',
      env: envFromFilename(file),
      branch: null,
      format: formatOf(file),
      text,
    });
  }

  // 2. ConfigMaps.
  for (const cmPath of opts.configMapPaths ?? []) {
    const abs = path.isAbsolute(cmPath) ? cmPath : path.join(repoRoot, cmPath);
    const text = readText(abs);
    if (text === null) {
      logger?.log('YAML', `ConfigMap path not readable: ${cmPath} — skipped`);
      continue;
    }
    out.push({
      path: abs,
      source: relSource(repoRoot, abs),
      source_type: 'configmap',
      env: 'default',
      branch: null,
      format: 'yaml',
      text,
    });
  }

  // 3. Config Server checkouts.
  const branches = opts.configServerBranches ?? [];
  const readBranch = opts.readBranch;
  for (const csPath of opts.configServerPaths ?? []) {
    const abs = path.isAbsolute(csPath) ? csPath : path.join(repoRoot, csPath);
    let files: string[];
    try {
      files = fs
        .readdirSync(abs, { withFileTypes: true })
        .filter((e) => e.isFile() && /\.(ya?ml|properties)$/i.test(e.name))
        .map((e) => path.join(abs, e.name))
        .sort();
    } catch {
      logger?.log('YAML', `Config Server path not readable: ${csPath} — skipped`);
      continue;
    }

    if (!readBranch) {
      const label = branches.length > 0 ? branches[0] : null;
      logger?.log(
        'YAML',
        `branch enumeration SKIPPED for Config Server ${csPath}: no readBranch hook supplied. ` +
          `Reading the working tree once and labelling it '${label ?? 'null'}'. ` +
          `Configured branches [${branches.join(', ')}] beyond the first were NOT indexed.`,
      );
      for (const file of files) {
        const text = readText(file);
        if (text === null) {
          continue;
        }
        out.push({
          path: file,
          source: relSource(repoRoot, file),
          source_type: 'config_server',
          env: envFromFilename(file, { isConfigServer: true }),
          branch: label,
          format: formatOf(file),
          text,
        });
      }
      continue;
    }

    for (const branch of branches) {
      for (const file of files) {
        const text = readBranch(file, branch);
        if (text === null) {
          continue;
        }
        out.push({
          path: file,
          source: relSource(repoRoot, file),
          source_type: 'config_server',
          env: envFromFilename(file, { isConfigServer: true }),
          branch,
          format: formatOf(file),
          text,
        });
      }
    }
  }

  out.sort((a, b) => {
    const keyA = `${a.source_type} ${a.source} ${a.branch ?? ''} ${a.env}`;
    const keyB = `${b.source_type} ${b.source} ${b.branch ?? ''} ${b.env}`;
    return keyA < keyB ? -1 : keyA > keyB ? 1 : 0;
  });
  return out;
}

/** Parse a descriptor with the right parser for its kind. */
export function parseDescriptor(
  desc: ConfigSourceDescriptor,
  logger?: Logger,
): RawProperty[] {
  const ctx: ParseContext = {
    source: desc.source,
    sourceType: desc.source_type,
    env: desc.env,
    branch: desc.branch,
  };
  if (desc.source_type === 'configmap') {
    return parseConfigMap(desc.text, ctx, logger);
  }
  if (desc.format === 'properties') {
    return parsePropertiesFile(desc.text, ctx, logger);
  }
  return parseYamlProperties(desc.text, ctx, logger);
}

/** Strip file contents so descriptors can be written into `meta.config_sources`. */
export function toConfigSourceMeta(
  descriptors: ConfigSourceDescriptor[],
): Array<Record<string, unknown>> {
  return descriptors.map((d) => ({
    source: d.source,
    source_type: d.source_type,
    env: d.env,
    branch: d.branch,
    format: d.format,
  }));
}
