/**
 * Property extraction: parse raw config sources, then run the resolution pass.
 */

export type {
  RawProperty,
  ParseContext,
  DiscoveryOptions,
  ConfigSourceDescriptor,
} from './parse.js';
export {
  parseYamlProperties,
  parsePropertiesFile,
  parseConfigMap,
  relaxedBindingKey,
  relaxedBindingAliases,
  envFromFilename,
  discoverConfigSources,
  parseDescriptor,
  toConfigSourceMeta,
} from './parse.js';

export type {
  ResolvedEntry,
  ResolutionTable,
  ResolutionResult,
  PlaceholderIssue,
} from './resolve.js';
export {
  resolveProperties,
  lookupResolved,
  lookupEntry,
  buildPathFragmentIndex,
  valueFragments,
  placeholderTokens,
  isSecretKey,
  MAX_RESOLUTION_DEPTH,
} from './resolve.js';

import type { Logger } from '../../util/logger.js';
import { discoverConfigSources, parseDescriptor } from './parse.js';
import type { DiscoveryOptions } from './parse.js';
import { resolveProperties } from './resolve.js';
import type { ResolutionResult } from './resolve.js';
import type { ConfigSourceDescriptor } from './parse.js';

export interface PropertyExtractionResult extends ResolutionResult {
  sources: ConfigSourceDescriptor[];
}

/**
 * End-to-end: discover every config source under `repoRoot`, parse them all,
 * and run the resolution pass. Deterministic and fail-open.
 */
export function extractProperties(
  repoRoot: string,
  opts: DiscoveryOptions,
  logger: Logger,
): PropertyExtractionResult {
  const sources = discoverConfigSources(repoRoot, opts, logger);
  const raws = sources.flatMap((d) => parseDescriptor(d, logger));
  const resolution = resolveProperties(raws, logger);
  return { ...resolution, sources };
}
