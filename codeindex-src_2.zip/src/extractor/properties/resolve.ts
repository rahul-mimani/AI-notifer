/**
 * THE PROPERTY RESOLUTION PASS.
 *
 * Takes the flat `RawProperty[]` produced by parse.ts (from YAML, .properties
 * and ConfigMap sources alike — the resolver is format-agnostic) and produces
 * fully-resolved `PropertyRecord`s plus an inverted path-fragment index.
 *
 * PLACEHOLDER SYNTAX
 * ------------------
 * Three forms are supported:
 *   ${var}              bare reference
 *   ${var:default}      Spring's actual default syntax
 *   ${var:-default}     the shell-style form the spec text uses
 * The project spec says `${var:-default}` but real Spring Boot uses
 * `${var:default}`; both appear in the wild (and in Helm-templated configs),
 * so BOTH are accepted. Defaults may themselves contain placeholders:
 * `${a:${b}}` resolves `b` when `a` is absent.
 *
 * THE UNRESOLVED-PLACEHOLDER-AS-JOIN-KEY RULE
 * -------------------------------------------
 * When a placeholder cannot be resolved (missing key, env var, Vault ref,
 * cycle, recursion cap) the ORIGINAL placeholder text is left verbatim in
 * `value`. It is never blanked and never replaced with a marker. This is
 * load-bearing: `${services.cdu.base-url}` is itself a stable join token, so
 * two beans wired to the same unresolved placeholder still match each other.
 *
 * DETERMINISM
 * -----------
 * No `process.env`, no clock, no randomness. Keys are resolved in sorted
 * order and every emitted collection is sorted, so two runs over the same
 * inputs are byte-identical.
 */

import type {
  Env,
  PropertyRecord,
  SourceType,
  UnresolvedRecord,
} from '../../types.js';
import type { Logger } from '../../util/logger.js';
import { normalizePathTemplate, pathFragments } from '../paths.js';
import type { RawProperty } from './parse.js';

/** Hard cap on nested placeholder expansion. */
export const MAX_RESOLUTION_DEPTH = 10;

/** ALL_CAPS_WITH_UNDERSCORES — treated as an OS environment variable. */
const ENV_VAR_NAME = /^[A-Z][A-Z0-9]*(_[A-Z0-9]+)*$/;

/** Vault references, e.g. `${vault:secret/pou#cdu-api-key}`. */
const VAULT_SCHEME = /(^|[^A-Za-z0-9_-])vault:/i;

/** Key final-segment heuristic for secret material. */
const SECRET_SEGMENT = /password|secret|token|api-?key|credential/i;

/** Precedence of a source type when two sources set the same (key, env). */
const SOURCE_SPECIFICITY: Record<SourceType, number> = {
  application_yml: 0,
  config_server: 1,
  configmap: 2,
  env_var: 3,
  vault_ref: 3,
};

export interface ResolvedEntry {
  key: string;
  env: Env;
  raw_value: string;
  value: string;
  resolved: boolean;
  is_secret: boolean;
  source: string;
  source_type: SourceType;
  line: number;
  branch: string | null;
  /** Env whose declaration supplied this entry (`shared`/`default` inheritance). */
  declared_in: Env;
  notes: PlaceholderIssue[];
}

export interface PlaceholderIssue {
  reason: string;
  expression: string;
}

export interface ResolutionTable {
  /** Envs that have a materialized view, sorted. */
  envs: Env[];
  get(key: string, env: Env): ResolvedEntry | undefined;
  /** All entries of one env view, sorted by key. */
  entries(env: Env): ResolvedEntry[];
}

export interface ResolutionResult {
  records: PropertyRecord[];
  unresolved: UnresolvedRecord[];
  pathFragmentIndex: Record<string, string[]>;
  table: ResolutionTable;
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function finalSegment(key: string): string {
  const noIndex = key.replace(/\[\d+\]$/, '');
  const dot = noIndex.lastIndexOf('.');
  return dot < 0 ? noIndex : noIndex.slice(dot + 1);
}

/** True when the key name or the value itself indicates secret material. */
export function isSecretKey(key: string, value?: string): boolean {
  if (SECRET_SEGMENT.test(finalSegment(key))) {
    return true;
  }
  return value !== undefined && VAULT_SCHEME.test(value);
}

/** Index of the `}` matching the `{` at `open`, or -1. */
function matchingBrace(text: string, open: number): number {
  let depth = 1;
  for (let i = open + 1; i < text.length; i++) {
    if (text[i] === '{') {
      depth++;
    } else if (text[i] === '}') {
      depth--;
      if (depth === 0) {
        return i;
      }
    }
  }
  return -1;
}

/** First top-level `:` inside a placeholder body, ignoring nested `${}`. */
function topLevelColon(inner: string): number {
  let depth = 0;
  for (let i = 0; i < inner.length; i++) {
    const ch = inner[i];
    if (ch === '{') {
      depth++;
    } else if (ch === '}') {
      depth = Math.max(0, depth - 1);
    } else if (ch === ':' && depth === 0) {
      return i;
    }
  }
  return -1;
}

/** Every `${...}` token in a string, brace-nesting aware. */
export function placeholderTokens(text: string): string[] {
  const out: string[] = [];
  for (let i = 0; i < text.length - 1; i++) {
    if (text[i] === '$' && text[i + 1] === '{') {
      const close = matchingBrace(text, i + 1);
      if (close < 0) {
        break;
      }
      out.push(text.slice(i, close + 1));
      i = close;
    }
  }
  return out;
}

interface Outcome {
  text: string;
  ok: boolean;
  notes: PlaceholderIssue[];
}

/* ------------------------------------------------------------------ */
/* Per-env resolver                                                    */
/* ------------------------------------------------------------------ */

interface ViewEntry {
  raw: RawProperty;
  declaredIn: Env;
}

class EnvResolver {
  private readonly memo = new Map<string, Outcome>();
  private readonly stack: string[] = [];

  constructor(
    private readonly view: Map<string, ViewEntry>,
    private readonly env: Env,
  ) {}

  /** Resolve an arbitrary value string in this env's view. */
  public resolveText(text: string, depth = 0): Outcome {
    if (!text.includes('${')) {
      return { text, ok: true, notes: [] };
    }

    let out = '';
    let ok = true;
    const notes: PlaceholderIssue[] = [];

    for (let i = 0; i < text.length; i++) {
      if (text[i] === '$' && i + 1 < text.length && text[i + 1] === '{') {
        const close = matchingBrace(text, i + 1);
        if (close < 0) {
          // Unbalanced `${` — keep the remainder verbatim.
          out += text.slice(i);
          break;
        }
        const original = text.slice(i, close + 1);
        const inner = text.slice(i + 2, close);
        const res = this.resolvePlaceholder(inner, original, depth + 1);
        out += res.text;
        if (!res.ok) {
          ok = false;
        }
        notes.push(...res.notes);
        i = close;
        continue;
      }
      out += text[i];
    }

    return { text: out, ok, notes };
  }

  private resolvePlaceholder(inner: string, original: string, depth: number): Outcome {
    if (depth > MAX_RESOLUTION_DEPTH) {
      return {
        text: original,
        ok: false,
        notes: [
          {
            reason:
              `placeholder recursion cap of ${MAX_RESOLUTION_DEPTH} levels exceeded ` +
              `while expanding '${original}' (chain: ${this.stack.join(' -> ')})`,
            expression: original,
          },
        ],
      };
    }

    // Vault refs are never resolvable at index time.
    if (VAULT_SCHEME.test(inner)) {
      return {
        text: original,
        ok: false,
        notes: [
          {
            reason: `vault reference '${original}' is not resolvable at index time (secret material is never read)`,
            expression: original,
          },
        ],
      };
    }

    const colon = topLevelColon(inner);
    let name: string;
    let def: string | undefined;
    if (colon >= 0) {
      name = inner.slice(0, colon);
      // Accept BOTH `${var:default}` (real Spring) and `${var:-default}` (spec text).
      def = inner[colon + 1] === '-' ? inner.slice(colon + 2) : inner.slice(colon + 1);
    } else {
      name = inner;
    }
    name = name.trim();

    const target = this.view.get(name);
    if (target) {
      const res = this.resolveKey(name, depth);
      if (res.ok) {
        return { text: res.text, ok: true, notes: [] };
      }
      return {
        text: original,
        ok: false,
        notes:
          res.notes.length > 0
            ? res.notes
            : [
                {
                  reason: `property '${name}' is itself unresolved for env '${this.env}'`,
                  expression: original,
                },
              ],
      };
    }

    // Not defined. A supplied default IS deterministically resolvable.
    if (def !== undefined) {
      const res = this.resolveText(def, depth);
      if (res.ok) {
        return { text: res.text, ok: true, notes: [] };
      }
      return {
        text: original,
        ok: false,
        notes: res.notes.length > 0 ? res.notes : [
          { reason: `default expression of '${original}' is unresolved`, expression: original },
        ],
      };
    }

    const reason = ENV_VAR_NAME.test(name)
      ? `env var not present at index time (${name})`
      : `property '${name}' is not defined for env '${this.env}'`;
    return { text: original, ok: false, notes: [{ reason, expression: original }] };
  }

  /** Resolve a property key's own value, with cycle detection. */
  public resolveKey(key: string, depth = 0): Outcome {
    const cached = this.memo.get(key);
    if (cached) {
      return cached;
    }

    const idx = this.stack.indexOf(key);
    if (idx >= 0) {
      const cyclePath = [...this.stack.slice(idx), key].join(' -> ');
      return {
        text: '',
        ok: false,
        notes: [
          {
            reason: `placeholder dependency cycle: ${cyclePath}`,
            expression: `\${${key}}`,
          },
        ],
      };
    }

    const entry = this.view.get(key);
    if (!entry) {
      return {
        text: '',
        ok: false,
        notes: [
          {
            reason: `property '${key}' is not defined for env '${this.env}'`,
            expression: `\${${key}}`,
          },
        ],
      };
    }

    this.stack.push(key);
    const res = this.resolveText(entry.raw.raw_value, depth);
    this.stack.pop();

    // Only successful outcomes are memoized. Failures are depth- and
    // stack-sensitive (recursion cap, cycle participation), so caching them
    // would let the order of the first visit leak into later results.
    if (res.ok) {
      this.memo.set(key, res);
    }
    return res;
  }
}

/* ------------------------------------------------------------------ */
/* resolveProperties                                                   */
/* ------------------------------------------------------------------ */

function winnerOf(candidates: RawProperty[]): RawProperty {
  let best = candidates[0];
  let bestScore = -1;
  for (const c of candidates) {
    // more-specific source type wins; a canonical key beats a relaxed-binding
    // alias; on a tie the LATER declaration wins.
    const score = SOURCE_SPECIFICITY[c.source_type] * 2 + (c.is_alias ? 0 : 1);
    if (score >= bestScore) {
      best = c;
      bestScore = score;
    }
  }
  return best;
}

export function resolveProperties(raws: RawProperty[], logger: Logger): ResolutionResult {
  // 1. Bucket by (env, key), preserving input order within a bucket.
  const buckets = new Map<string, RawProperty[]>();
  for (const raw of raws) {
    const bk = `${raw.env} ${raw.key}`;
    const list = buckets.get(bk);
    if (list) {
      list.push(raw);
    } else {
      buckets.set(bk, [raw]);
    }
  }

  // 2. Pick winners and log shadowing.
  const winners = new Map<string, RawProperty>();
  for (const bk of [...buckets.keys()].sort()) {
    const list = buckets.get(bk)!;
    const win = winnerOf(list);
    winners.set(bk, win);
    if (list.length > 1) {
      const losers = list.filter((c) => c !== win);
      for (const l of losers) {
        logger.log(
          'YAML',
          `shadowed property '${l.key}' (env ${l.env}): ${l.source}:${l.line} ` +
            `is overridden by ${win.source}:${win.line} — both records emitted, ` +
            `'${win.source}' used for substitution`,
        );
      }
    }
  }

  // 3. Which env views to materialize.
  const declaredEnvs = new Set<Env>();
  for (const raw of raws) {
    declaredEnvs.add(raw.env);
  }
  declaredEnvs.add('default');
  const viewEnvs = ([...declaredEnvs] as Env[]).sort();

  // 4. Build the effective view for each env: same-env, then shared, then default.
  //
  // Materializing inherited keys per env is what makes
  //   services.cdu.base-url: ${cdu.host}/cdu-service   (declared only in default)
  // resolve to the DEV host under env `dev` — which is how Spring actually
  // behaves. The PropertyRecord for the declaration still carries env=default;
  // the per-env effective values live in the table and are what
  // `lookupResolved` returns.
  const allKeys = [...new Set(raws.map((r) => r.key))].sort();
  const views = new Map<Env, Map<string, ViewEntry>>();
  for (const env of viewEnvs) {
    const view = new Map<string, ViewEntry>();
    for (const key of allKeys) {
      const chain: Env[] = env === 'shared' ? ['shared', 'default'] : [env, 'shared', 'default'];
      for (const src of chain) {
        const w = winners.get(`${src} ${key}`);
        if (w) {
          view.set(key, { raw: w, declaredIn: src });
          break;
        }
      }
    }
    views.set(env, view);
  }

  // 5. Resolve each view. Sorted key order keeps the (order-sensitive)
  //    recursion-cap outcomes deterministic.
  const resolvers = new Map<Env, EnvResolver>();
  const tableData = new Map<Env, Map<string, ResolvedEntry>>();
  for (const env of viewEnvs) {
    const view = views.get(env)!;
    const resolver = new EnvResolver(view, env);
    resolvers.set(env, resolver);
    const entries = new Map<string, ResolvedEntry>();
    for (const key of [...view.keys()].sort()) {
      const ve = view.get(key)!;
      const res = resolver.resolveKey(key);
      // resolveKey returns text='' only on a cycle/missing detected at the
      // top of the stack; in that case fall back to the raw value so the
      // placeholder survives verbatim.
      const value = res.ok ? res.text : res.text === '' ? ve.raw.raw_value : res.text;
      entries.set(key, {
        key,
        env,
        raw_value: ve.raw.raw_value,
        value,
        resolved: res.ok,
        is_secret: isSecretKey(key, ve.raw.raw_value) || isSecretKey(key, value),
        source: ve.raw.source,
        source_type: ve.raw.source_type,
        line: ve.raw.line,
        branch: ve.raw.branch,
        declared_in: ve.declaredIn,
        notes: res.notes,
      });
    }
    tableData.set(env, entries);
  }

  // 6. Emit ONE PropertyRecord per (key, env, source) — including shadowed
  //    declarations, which are resolved against their own env's view.
  const records: PropertyRecord[] = [];
  const unresolved: UnresolvedRecord[] = [];
  const seenUnresolved = new Set<string>();

  const sortedRaws = [...raws].sort((a, b) => {
    const ka = `${a.key} ${a.env} ${a.source} ${String(a.line).padStart(8, '0')}`;
    const kb = `${b.key} ${b.env} ${b.source} ${String(b.line).padStart(8, '0')}`;
    return ka < kb ? -1 : ka > kb ? 1 : 0;
  });

  for (const raw of sortedRaws) {
    const resolver = resolvers.get(raw.env) ?? resolvers.get('default')!;

    // The winning declaration already has an authoritative entry in the table.
    // Reusing it (rather than re-resolving) keeps records and table in exact
    // agreement, which matters for depth-sensitive outcomes like the
    // recursion cap: a re-resolution starting at depth 0 could otherwise
    // "succeed" where the table entry legitimately hit the cap.
    const isWinner = winners.get(`${raw.env} ${raw.key}`) === raw;
    const entry = isWinner ? tableData.get(raw.env)?.get(raw.key) : undefined;
    const res: Outcome =
      entry && entry.declared_in === raw.env
        ? { text: entry.value, ok: entry.resolved, notes: entry.notes }
        : resolver.resolveText(raw.raw_value);

    const value = res.ok ? res.text : res.text === '' ? raw.raw_value : res.text;
    const secret = isSecretKey(raw.key, raw.raw_value) || isSecretKey(raw.key, value);

    records.push({
      kind: 'property',
      key: raw.key,
      value,
      raw_value: raw.raw_value,
      env: raw.env,
      source: raw.source,
      source_type: raw.source_type,
      line: raw.line,
      branch: raw.branch,
      is_secret: secret,
      extractor: 'deterministic',
      extraction_confidence: 1.0,
    });

    if (!res.ok) {
      const notes =
        res.notes.length > 0
          ? res.notes
          : [{ reason: 'value contains an unresolvable placeholder', expression: raw.raw_value }];
      for (const note of notes) {
        const dedupe = `${raw.key} ${raw.env} ${raw.source} ${note.reason}`;
        if (seenUnresolved.has(dedupe)) {
          continue;
        }
        seenUnresolved.add(dedupe);
        unresolved.push({
          kind: 'unresolved',
          what: 'property_value',
          context: { file: raw.source, line: raw.line, enclosing_symbol: null },
          reason: note.reason,
          partial_info: {
            key: raw.key,
            env: raw.env,
            raw_value: raw.raw_value,
            value,
            expression: note.expression,
            is_secret: secret,
          },
        });
      }
    }
  }

  unresolved.sort((a, b) => {
    const ka = `${String(a.partial_info.key)} ${String(a.partial_info.env)} ${a.context.file} ${a.reason}`;
    const kb = `${String(b.partial_info.key)} ${String(b.partial_info.env)} ${b.context.file} ${b.reason}`;
    return ka < kb ? -1 : ka > kb ? 1 : 0;
  });

  const table: ResolutionTable = {
    envs: viewEnvs,
    get(key, env) {
      return tableData.get(env)?.get(key);
    },
    entries(env) {
      const m = tableData.get(env);
      if (!m) {
        return [];
      }
      return [...m.keys()].sort().map((k) => m.get(k)!);
    },
  };

  return {
    records,
    unresolved,
    pathFragmentIndex: buildPathFragmentIndex(records),
    table,
  };
}

/* ------------------------------------------------------------------ */
/* lookupResolved                                                      */
/* ------------------------------------------------------------------ */

/**
 * Resolve a property key for an env, honouring same-env -> shared -> default
 * precedence. Returns the fully-resolved value (which may still contain a
 * verbatim `${...}` if it was unresolvable) or null if the key is unknown.
 */
export function lookupResolved(
  table: ResolutionTable,
  key: string,
  env: Env,
): string | null {
  const chain: Env[] = env === 'shared' ? ['shared', 'default'] : [env, 'shared', 'default'];
  for (const e of chain) {
    const hit = table.get(key, e);
    if (hit) {
      return hit.value;
    }
  }
  return null;
}

/** Same precedence chain, but returns the whole entry. */
export function lookupEntry(
  table: ResolutionTable,
  key: string,
  env: Env,
): ResolvedEntry | undefined {
  const chain: Env[] = env === 'shared' ? ['shared', 'default'] : [env, 'shared', 'default'];
  for (const e of chain) {
    const hit = table.get(key, e);
    if (hit) {
      return hit;
    }
  }
  return undefined;
}

/* ------------------------------------------------------------------ */
/* buildPathFragmentIndex                                              */
/* ------------------------------------------------------------------ */

const PURE_NUMBER = /^[+-]?\d+(\.\d+)?$/;
const BOOLEANISH = /^(true|false|yes|no|on|off|null)$/i;

/**
 * Path-like fragments contributed by one property value.
 *
 * - a URL or bare path yields CUMULATIVE segments:
 *   `https://h/cdu-service/v1` -> `/cdu-service`, `/cdu-service/v1`
 * - a segment that is itself a placeholder resets the accumulator, so
 *   `${cdu.host}/cdu-service` still yields `/cdu-service`
 * - every `${...}` token is indexed VERBATIM as its own joinable fragment.
 *   This is the prod/vault case: an unresolved `${services.cdu.base-url}`
 *   must still match a consumer wired to the same placeholder.
 */
export function valueFragments(value: string): string[] {
  const out = new Set<string>();

  for (const token of placeholderTokens(value)) {
    out.add(token);
  }

  const trimmed = value.trim();
  if (trimmed === '' || !trimmed.includes('/')) {
    return [...out];
  }
  // A vault ref's "path" is a secret address, not a service path. Index only
  // the placeholder token so the join key survives without leaking structure.
  if (VAULT_SCHEME.test(trimmed)) {
    return [...out];
  }
  if (PURE_NUMBER.test(trimmed) || BOOLEANISH.test(trimmed)) {
    return [...out];
  }

  const normalized = normalizePathTemplate(trimmed);
  if (normalized === '/' || normalized === '') {
    return [...out];
  }

  const segments = normalized.includes('$')
    ? normalized.split('/').filter((s) => s !== '')
    : pathFragments(normalized);

  let cur = '';
  for (const seg of segments) {
    if (seg.includes('$') || seg.includes('{')) {
      cur = '';
      continue;
    }
    cur = `${cur}/${seg}`;
    out.add(cur);
  }

  return [...out];
}

/**
 * fragment -> property key(s) that produced it. Keys sorted, arrays sorted and
 * deduped: this lands in consumption_manifest.json and must be byte-stable.
 */
export function buildPathFragmentIndex(records: PropertyRecord[]): Record<string, string[]> {
  const map = new Map<string, Set<string>>();
  for (const rec of records) {
    for (const frag of valueFragments(rec.value)) {
      let set = map.get(frag);
      if (!set) {
        set = new Set<string>();
        map.set(frag, set);
      }
      set.add(rec.key);
    }
  }

  const out: Record<string, string[]> = {};
  for (const frag of [...map.keys()].sort()) {
    out[frag] = [...map.get(frag)!].sort();
  }
  return out;
}
