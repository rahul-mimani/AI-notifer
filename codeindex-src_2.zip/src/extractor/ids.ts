/**
 * Stable identity + hashing primitives.
 *
 * Every function here is pure: no I/O, no clock, no randomness. The same input
 * must produce the same output across processes, machines and index builds —
 * these hashes are written to disk and compared across repos and commits.
 *
 * All hashes are SHA256 rendered as lowercase hex.
 */
import { createHash } from 'node:crypto';
import { collapsePathParams } from './paths.js';

/** SHA256 of a UTF-8 string, lowercase hex. */
export function sha256Hex(input: string): string {
  return createHash('sha256').update(input, 'utf8').digest('hex');
}

/**
 * Field separator for composite hash inputs. A single space cannot appear in
 * any normalized component (paths, verbs, transports, symbol ids and shape
 * hashes are all whitespace-free), so the join is unambiguous.
 */
const SEP = ' ';

function nz(value: string | null | undefined): string {
  return value === null || value === undefined ? '' : value;
}

/** Join components with the reserved separator and hash. */
function hashJoined(parts: Array<string | null | undefined>): string {
  return sha256Hex(parts.map(nz).join(SEP));
}

/* ------------------------------------------------------------------ *
 * Canonical JSON
 * ------------------------------------------------------------------ */

function canonicalize(value: unknown): unknown {
  if (value === null || typeof value !== 'object') {
    return value;
  }
  if (Array.isArray(value)) {
    // Arrays are ordered data — order is preserved.
    return value.map(canonicalize);
  }
  const src = value as Record<string, unknown>;
  const out: Record<string, unknown> = {};
  for (const key of Object.keys(src).sort()) {
    out[key] = canonicalize(src[key]);
  }
  return out;
}

/**
 * JSON serialization with object keys sorted recursively, so that two
 * structurally-equal values always serialize to the same string. Array order
 * is significant and is preserved.
 */
export function canonicalJson(value: unknown): string {
  return JSON.stringify(canonicalize(value));
}

/* ------------------------------------------------------------------ *
 * Symbol ids
 * ------------------------------------------------------------------ */

/**
 * `<repo>:<fqn>#<method_signature>` for methods,
 * `<repo>:<fqn>` for classes / interfaces.
 */
export function symbolId(repo: string, fqn: string, methodSignature?: string | null): string {
  const base = `${nz(repo)}:${nz(fqn)}`;
  const sig = nz(methodSignature).trim();
  return sig === '' ? base : `${base}#${normalizeMethodSignature(sig)}`;
}

const PRIMITIVES: Record<string, string> = {
  void: 'V',
  boolean: 'Z',
  byte: 'B',
  char: 'C',
  short: 'S',
  int: 'I',
  long: 'J',
  float: 'F',
  double: 'D',
};

/** Simple names we can confidently expand to their JDK package. */
const WELL_KNOWN: Record<string, string> = {
  String: 'java/lang/String',
  Object: 'java/lang/Object',
  Integer: 'java/lang/Integer',
  Long: 'java/lang/Long',
  Short: 'java/lang/Short',
  Byte: 'java/lang/Byte',
  Character: 'java/lang/Character',
  Boolean: 'java/lang/Boolean',
  Float: 'java/lang/Float',
  Double: 'java/lang/Double',
  Number: 'java/lang/Number',
  CharSequence: 'java/lang/CharSequence',
  List: 'java/util/List',
  ArrayList: 'java/util/ArrayList',
  Map: 'java/util/Map',
  HashMap: 'java/util/HashMap',
  Set: 'java/util/Set',
  Collection: 'java/util/Collection',
  Optional: 'java/util/Optional',
  BigDecimal: 'java/math/BigDecimal',
  BigInteger: 'java/math/BigInteger',
};

/** Erase generics: `Map<String, List<Foo>>` -> `Map`. */
function eraseGenerics(type: string): string {
  let out = '';
  let depth = 0;
  for (const ch of type) {
    if (ch === '<') {
      depth++;
    } else if (ch === '>') {
      if (depth > 0) {
        depth--;
      }
    } else if (depth === 0) {
      out += ch;
    }
  }
  return out;
}

/** Source-ish Java type -> JVM descriptor. Always succeeds. */
function typeToDescriptor(rawType: string): string {
  let type = eraseGenerics(rawType).trim();
  // Drop annotations and varargs sugar.
  type = type.replace(/@\S+\s*/g, '').trim();
  let arrayDims = 0;
  if (type.endsWith('...')) {
    type = type.slice(0, -3).trim();
    arrayDims++;
  }
  while (type.endsWith('[]')) {
    type = type.slice(0, -2).trim();
    arrayDims++;
  }
  // A parameter may carry a name: `String name` -> take the first token.
  const tokens = type.split(/\s+/).filter((t) => t !== '' && !isJavaModifier(t));
  if (tokens.length > 1) {
    type = tokens[0]!;
  } else {
    type = tokens[0] ?? '';
  }

  const prefix = '['.repeat(arrayDims);
  if (type === '') {
    return `${prefix}Ljava/lang/Object;`;
  }
  const prim = PRIMITIVES[type];
  if (prim !== undefined) {
    return prefix + prim;
  }
  const known = WELL_KNOWN[type];
  if (known !== undefined) {
    return `${prefix}L${known};`;
  }
  // Unknown type: keep it verbatim (dots -> slashes) so it stays reversible.
  return `${prefix}L${type.replace(/\./g, '/')};`;
}

const JAVA_MODIFIERS = new Set(['final', 'transient', 'volatile', 'static', 'synchronized']);
function isJavaModifier(token: string): boolean {
  return JAVA_MODIFIERS.has(token);
}

/** Split on top-level commas, respecting `<>` nesting. */
function splitTopLevel(text: string): string[] {
  const parts: string[] = [];
  let depth = 0;
  let cur = '';
  for (const ch of text) {
    if (ch === '<') {
      depth++;
      cur += ch;
    } else if (ch === '>') {
      if (depth > 0) {
        depth--;
      }
      cur += ch;
    } else if (ch === ',' && depth === 0) {
      parts.push(cur);
      cur = '';
    } else {
      cur += ch;
    }
  }
  if (cur.trim() !== '' || parts.length > 0) {
    parts.push(cur);
  }
  return parts.map((p) => p.trim()).filter((p) => p !== '');
}

/**
 * Try to read `text` as an already-valid JVM parameter descriptor sequence.
 * Returns null when it is not one (so we fall back to source-ish parsing).
 */
function parseDescriptorParams(text: string): string[] | null {
  const out: string[] = [];
  let i = 0;
  while (i < text.length) {
    let dims = '';
    while (text[i] === '[') {
      dims += '[';
      i++;
    }
    const ch = text[i];
    if (ch === undefined) {
      return null;
    }
    if ('VZBCSIJFD'.includes(ch)) {
      out.push(dims + ch);
      i++;
      continue;
    }
    if (ch === 'L') {
      const end = text.indexOf(';', i);
      if (end < 0) {
        return null;
      }
      out.push(dims + text.slice(i, end + 1));
      i = end + 1;
      continue;
    }
    return null;
  }
  return out;
}

/**
 * Canonical JVM erased-descriptor form of a method signature.
 *
 * Accepts both:
 *   - descriptor input:  `(Ljava/lang/String;J)V`  or `getUser(Ljava/lang/String;)V`
 *   - source-ish input:  `getUser(String, long)`   or `getUser(List<Foo> foos)`
 *
 * Output shape is `name(<params>)<return?>` where `name` and the return
 * descriptor are omitted when the input did not carry them. Generics are
 * erased. If the input cannot be parsed at all it is returned with whitespace
 * normalized rather than throwing — tolerant and, crucially, consistent.
 */
export function normalizeMethodSignature(sig: string | null | undefined): string {
  const raw = nz(sig).trim().replace(/\s+/g, ' ');
  if (raw === '') {
    return '';
  }

  const open = raw.indexOf('(');
  const close = raw.lastIndexOf(')');
  if (open < 0 || close < open) {
    // No parameter list at all — e.g. a bare method name.
    return raw.replace(/\s+/g, '');
  }

  const namePart = raw.slice(0, open).trim();
  const paramsPart = raw.slice(open + 1, close).trim();
  const returnPart = raw.slice(close + 1).trim();

  // A method name may be given as `public User getUser` — keep the last token.
  const nameTokens = namePart.split(/[\s.]+/).filter((t) => t !== '');
  const name = nameTokens.length > 0 ? nameTokens[nameTokens.length - 1]! : '';

  let params: string[];
  if (paramsPart === '') {
    params = [];
  } else if (!/[,\s]/.test(paramsPart) && parseDescriptorParams(paramsPart) !== null) {
    params = parseDescriptorParams(paramsPart)!;
  } else {
    params = splitTopLevel(paramsPart).map(typeToDescriptor);
  }

  let ret = '';
  if (returnPart !== '') {
    const asDesc = parseDescriptorParams(returnPart);
    ret = asDesc !== null && asDesc.length === 1 ? asDesc[0]! : typeToDescriptor(returnPart);
  }

  return `${name}(${params.join('')})${ret}`;
}

/* ------------------------------------------------------------------ *
 * Endpoint / invocation ids
 * ------------------------------------------------------------------ */

/**
 * Identity of an endpoint declaration: what it is and who handles it.
 * Uses the display path template, so this id changes if the author renames a
 * path variable — that is intended, it is a *different declaration*.
 */
export function endpointId(
  transport: string | null | undefined,
  verb: string | null | undefined,
  pathTemplate: string | null | undefined,
  handlerSymbol: string | null | undefined,
): string {
  return hashJoined([transport, verb, pathTemplate, handlerSymbol]);
}

/**
 * Behavioural fingerprint of an endpoint — the thing consumers actually bind
 * to. Two builds with the same fingerprint are wire-compatible.
 *
 * The path component is passed through `collapsePathParams` so that the hash
 * is computed over the MATCHING form (`/users/{}`), not the display form.
 * Rationale: renaming `{id}` -> `{userId}` changes no wire contract — no
 * consumer request stops working — so it must not read as a breaking change.
 * Changing the path *structure* (`/users/{id}` -> `/users/{id}/profile`, or
 * `/users/{id}` -> `/users/all`) does change the fingerprint, because that
 * genuinely breaks callers. Collapsing here is idempotent, so callers may pass
 * either the display or the already-normalized template safely.
 */
export function endpointFingerprint(
  transport: string | null | undefined,
  verb: string | null | undefined,
  pathTemplateNormalized: string | null | undefined,
  requestDtoShape: string | null | undefined,
  responseDtoShape: string | null | undefined,
  destination: string | null | undefined,
): string {
  const path = nz(pathTemplateNormalized) === '' ? '' : collapsePathParams(pathTemplateNormalized);
  return hashJoined([transport, verb, path, requestDtoShape, responseDtoShape, destination]);
}

/** Identity of a single outbound call site. */
export function invocationId(
  file: string | null | undefined,
  line: number | null | undefined,
  enclosingSymbol: string | null | undefined,
  transport: string | null | undefined,
): string {
  const lineStr = line === null || line === undefined ? '' : String(line);
  return hashJoined([file, lineStr, enclosingSymbol, transport]);
}
