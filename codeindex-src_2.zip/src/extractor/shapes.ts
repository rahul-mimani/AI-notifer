/**
 * DTO shape hashing.
 *
 * Spec implemented here, verbatim:
 *   collect fields including inherited (exclude synthetic/transient);
 *   recursively substitute nested DTO types with their shape hash;
 *   sort tuples by field name; serialize as canonical JSON; SHA256
 *
 * Pure and deterministic: no I/O, no clock, no randomness. Computing the same
 * DTO universe in any input order yields byte-identical hashes.
 */
import { canonicalJson, sha256Hex } from './ids.js';

export interface DtoFieldInput {
  name: string;
  type: string;
  nullable: boolean;
  /** Java modifiers, e.g. `['private', 'transient']`. */
  modifiers?: string[];
}

export interface DtoInput {
  fqn: string;
  fields: DtoFieldInput[];
  /** Fully-qualified superclass name, if any. */
  superFqn?: string;
}

export interface DtoShapeResult {
  /** SHA256 hex of the canonical shape serialization. */
  shape: string;
  /** field_name -> shape hash of the nested DTO that field resolves to. */
  nested_shapes: Record<string, string>;
}

/* ------------------------------------------------------------------ *
 * Field filtering
 * ------------------------------------------------------------------ */

const EXCLUDED_MODIFIERS = new Set(['transient', 'static']);

/**
 * Compiler-generated fields must never affect the shape: `this$0` (outer-class
 * back-reference), `$jacocoData`, `serialVersionUID`, switch-map tables, etc.
 */
function isSynthetic(name: string): boolean {
  return (
    name.startsWith('$') ||
    name.includes('$') ||
    name === 'serialVersionUID'
  );
}

function isIncluded(field: DtoFieldInput): boolean {
  if (isSynthetic(field.name)) {
    return false;
  }
  for (const m of field.modifiers ?? []) {
    if (EXCLUDED_MODIFIERS.has(m.toLowerCase())) {
      return false;
    }
  }
  return true;
}

/**
 * Superclass fields first, then subclass fields override same-named ones.
 * `seen` guards against a malformed inheritance cycle.
 */
function collectFields(
  fqn: string,
  universe: Map<string, DtoInput>,
  seen: Set<string>,
): DtoFieldInput[] {
  const dto = universe.get(fqn);
  if (dto === undefined || seen.has(fqn)) {
    return [];
  }
  seen.add(fqn);

  const merged = new Map<string, DtoFieldInput>();
  if (dto.superFqn !== undefined && dto.superFqn !== '') {
    for (const f of collectFields(dto.superFqn, universe, seen)) {
      merged.set(f.name, f);
    }
  }
  for (const f of dto.fields) {
    if (isIncluded(f)) {
      merged.set(f.name, f);
    } else {
      // An excluded override still removes the inherited field of that name:
      // the concrete class genuinely does not serialize it.
      merged.delete(f.name);
    }
  }
  return [...merged.values()];
}

/* ------------------------------------------------------------------ *
 * Type substitution
 * ------------------------------------------------------------------ */

/** Split generic arguments on top-level commas. */
function splitArgs(text: string): string[] {
  const out: string[] = [];
  let depth = 0;
  let cur = '';
  for (const ch of text) {
    if (ch === '<') {
      depth++;
      cur += ch;
    } else if (ch === '>') {
      depth--;
      cur += ch;
    } else if (ch === ',' && depth === 0) {
      out.push(cur);
      cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

/**
 * Substitute every known-DTO type inside `rawType` with that DTO's shape hash,
 * preserving the surrounding container: `List<Foo>` -> `List<{shape}>`,
 * `Map<String,Foo>` -> `Map<String,{shape}>`, `Foo[]` -> `{shape}[]`.
 *
 * Unknown types (`String`, `com.external.Thing`) pass through literally.
 * `nested` collects field-level nested shape hashes as a side effect.
 */
function substituteType(
  rawType: string,
  resolve: (fqn: string) => string,
  universe: Map<string, DtoInput>,
  nested: string[],
): string {
  const type = rawType.trim();
  if (type === '') {
    return '';
  }

  if (type.endsWith('[]')) {
    return substituteType(type.slice(0, -2), resolve, universe, nested) + '[]';
  }

  const open = type.indexOf('<');
  if (open >= 0 && type.endsWith('>')) {
    const outer = type.slice(0, open).trim();
    const inner = type.slice(open + 1, -1);
    const args = splitArgs(inner).map((a) => substituteType(a, resolve, universe, nested));
    return `${outer}<${args.join(',')}>`;
  }

  if (universe.has(type)) {
    const shape = resolve(type);
    nested.push(shape);
    return shape;
  }
  return type;
}

/* ------------------------------------------------------------------ *
 * Shape computation
 * ------------------------------------------------------------------ */

interface ShapeComputation {
  hash: string;
  /** True when a cycle placeholder was used anywhere in this subtree. */
  cyclic: boolean;
  nested: Record<string, string>;
}

/**
 * Compute shapes for a whole DTO universe at once. Nested substitution and
 * inheritance both need the full set, so this is deliberately set-oriented.
 *
 * CYCLE HANDLING
 * --------------
 * `A { B b }` and `B { A a }` would recurse forever. When the DFS re-enters a
 * FQN already on the current stack, that back-edge is replaced by the stable
 * placeholder `#cycle:<fqn>` instead of recursing.
 *
 * The placeholder alone is not enough for determinism: which node the back-edge
 * names depends on where the DFS started (rooted at A, B's field reads
 * `#cycle:A`; rooted at B, A's field reads `#cycle:B`). So every DTO's shape is
 * DEFINED as "computed with a fresh stack rooted at itself", and results that
 * consumed a cycle placeholder are never memoized for reuse under a different
 * root. Acyclic results are context-independent and are memoized freely. The
 * outcome depends only on the subgraph reachable from each DTO, making the
 * whole set independent of input order — asserted in the sanity check.
 */
export function computeDtoShapes(dtos: DtoInput[]): Map<string, DtoShapeResult> {
  const universe = new Map<string, DtoInput>();
  for (const dto of dtos) {
    universe.set(dto.fqn, dto);
  }

  /** Memo of acyclic (context-independent) results only. */
  const memo = new Map<string, ShapeComputation>();

  function compute(fqn: string, stack: string[]): ShapeComputation {
    const cached = memo.get(fqn);
    if (cached !== undefined) {
      return cached;
    }

    const nextStack = [...stack, fqn];
    let cyclic = false;
    const nested: Record<string, string> = {};

    const resolve = (childFqn: string): string => {
      if (nextStack.includes(childFqn)) {
        cyclic = true;
        return `#cycle:${childFqn}`;
      }
      const child = compute(childFqn, nextStack);
      if (child.cyclic) {
        cyclic = true;
      }
      return child.hash;
    };

    const fields = collectFields(fqn, universe, new Set<string>());
    const tuples = fields.map((f) => {
      const found: string[] = [];
      const type = substituteType(f.type, resolve, universe, found);
      if (found.length > 0) {
        // A field resolving to several DTOs (e.g. Map<Foo,Bar>) records the
        // first, matching the "one nested shape per field" store contract.
        nested[f.name] = found[0]!;
      }
      return { name: f.name, nullable: f.nullable === true, type };
    });

    tuples.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
    const hash = sha256Hex(canonicalJson(tuples));

    const computed: ShapeComputation = { hash, cyclic, nested };
    if (!cyclic) {
      memo.set(fqn, computed);
    }
    return computed;
  }

  const result = new Map<string, DtoShapeResult>();
  // Sort the roots so iteration order never influences memoization outcomes.
  const roots = [...universe.keys()].sort();
  for (const fqn of roots) {
    const computed = compute(fqn, []);
    result.set(fqn, { shape: computed.hash, nested_shapes: computed.nested });
  }
  return result;
}
