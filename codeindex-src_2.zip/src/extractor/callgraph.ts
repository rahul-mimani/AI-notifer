/**
 * Callgraph pass 2: resolve the LM's per-file `method_calls` (pass 1) against
 * the whole-repo symbol table and pack them into the binary reverse-adjacency
 * format the store defines.
 *
 * Pass 1 is what the LM already produced: a caller-side list of call sites with
 * a best-effort `callee_class_fqn` / `callee_method_name` / `callee_signature_guess`.
 * Pass 2 (here) turns those guesses into real symbol ids by joining against the
 * symbol table normalize.ts built from every `handler_method_signature`,
 * `enclosing_method_signature` and `caller_method_signature` in the repo.
 *
 * SIGNATURE TOLERANCE
 * -------------------
 * Both sides of the join go through `normalizeMethodSignature` before being
 * compared. The fixtures are authored to join on those exact strings and a
 * mismatch SILENTLY DROPS AN EDGE, which is the worst possible failure mode
 * here, so resolution is deliberately layered:
 *   1. exact class + normalized signature;
 *   2. class + method name (all overloads, when the guess was wrong or absent);
 *   3. interface fan-out (below);
 *   4. give up — counted and logged as an unresolved callee.
 *
 * Unresolvable callees are overwhelmingly framework noise (`RestTemplate`,
 * `KafkaTemplate`, `java.util.Map`), so they are skipped rather than
 * synthesized, but the count is always reported at `[CALLGRAPH]`.
 *
 * FORWARD ADJACENCY
 * -----------------
 * The packed format is reverse-only (indexed by callee, yields callers) because
 * the blast-radius walk only ever asks "who calls this?". The daemon ALSO needs
 * downstream walks (handler -> service -> repository), which reverse adjacency
 * cannot serve without a full scan, so a plain-JSON forward map is returned as
 * well and written to `callgraph.fwd.json`. That file is an ADDITION to the
 * documented store spec — see the note in the build report / SCHEMA.md.
 */

import type { CallEdge, CallKind } from '../types.js';
import type { Logger } from '../util/logger.js';
import { failOpen } from '../util/logger.js';
import type { LmMethodCall } from '../lm/schema.js';
import { normalizeMethodSignature, symbolId } from './ids.js';
import type { FileExtractionInput, MethodSymbolEntry, SymbolTable } from './normalize.js';
import { packCallgraph } from '../store/callgraph-codec.js';

export interface ForwardCallSite {
  callee: string;
  file_id: number;
  line: number;
  call_kind: CallKind;
}

/** caller symbol id -> its call sites. Keys sorted; arrays sorted. */
export type ForwardAdjacency = Record<string, ForwardCallSite[]>;

export interface CallgraphStats {
  symbols: number;
  edges: number;
  resolved_exact: number;
  resolved_by_name: number;
  interface_edges: number;
  unresolved_callees: number;
  excluded_by_prefix: number;
  unknown_callers: number;
}

export interface BuildCallgraphOptions {
  repo: string;
  extractions: FileExtractionInput[];
  symbolTable: SymbolTable;
  /** Existing file_id -> path table. Extended in place-safe fashion. */
  sourceMap: string[];
  packagePrefixes: string[];
  logger: Logger;
}

export interface BuildCallgraphResult {
  bin: Buffer;
  idx: Record<string, number>;
  sourceMap: string[];
  stats: CallgraphStats;
  /** Symbol ids in index order — hand these straight to `writeBundle`. */
  symbols: string[];
  edges: CallEdge[];
  forward: ForwardAdjacency;
}

function matchesPrefix(fqn: string, prefixes: readonly string[]): boolean {
  if (prefixes.length === 0) {
    return true;
  }
  return prefixes.some(
    (p) => p !== '' && (fqn === p || fqn.startsWith(`${p}.`) || fqn.startsWith(`${p}$`)),
  );
}

export function buildCallgraph(opts: BuildCallgraphOptions): BuildCallgraphResult {
  const { repo, extractions, symbolTable, packagePrefixes, logger } = opts;

  const stats: CallgraphStats = {
    symbols: 0,
    edges: 0,
    resolved_exact: 0,
    resolved_by_name: 0,
    interface_edges: 0,
    unresolved_callees: 0,
    excluded_by_prefix: 0,
    unknown_callers: 0,
  };

  // --- symbol string table -------------------------------------------------
  // Sorted so the packed bytes depend only on the logical graph.
  const symbols = symbolTable.methods.map((m) => m.id).sort();
  const symbolIndex = new Map<string, number>();
  symbols.forEach((id, i) => symbolIndex.set(id, i));
  stats.symbols = symbols.length;

  // --- file_id table -------------------------------------------------------
  const sourceMap = [...opts.sourceMap];
  const fileIds = new Map<string, number>();
  sourceMap.forEach((f, i) => {
    if (!fileIds.has(f)) {
      fileIds.set(f, i);
    }
  });
  const fileIdOf = (file: string): number => {
    const existing = fileIds.get(file);
    if (existing !== undefined) {
      return existing;
    }
    const id = sourceMap.length;
    sourceMap.push(file);
    fileIds.set(file, id);
    return id;
  };

  // --- interface knowledge -------------------------------------------------
  // The LM schema carries no `implements`/`extends` array, so the only
  // structural evidence available is the endpoint reconciliation pass: a class
  // whose mapping annotations name another type via `declared_on`/
  // `inherited_from` implements that type. That is what `symbolTable
  // .implementations` holds. LIMITATION: interfaces that are never involved in
  // an endpoint declaration are invisible here, so a call through such an
  // interface resolves only if the interface's own method is in the symbol
  // table (name-based match) — we never guess an implementation from a name
  // alone unless it is the single unambiguous candidate.
  const interfaceFqns = new Set(
    [...symbolTable.classes.values()].filter((c) => c.isInterface).map((c) => c.fqn),
  );
  for (const key of symbolTable.implementations.keys()) {
    interfaceFqns.add(key);
  }
  if (interfaceFqns.size === 0) {
    logger.log(
      'CALLGRAPH',
      'no interface/implements information was derivable from the LM output — ' +
        'interface fan-out is limited to unambiguous name-based matches',
    );
  }

  // --- edge accumulation ---------------------------------------------------
  const edgeKeys = new Set<string>();
  const edges: CallEdge[] = [];
  const forwardSets = new Map<string, Map<string, ForwardCallSite>>();

  const addEdge = (
    callerId: string,
    calleeId: string,
    fileId: number,
    line: number,
    callKind: CallKind,
  ): void => {
    const calleeIndex = symbolIndex.get(calleeId);
    const callerIndex = symbolIndex.get(callerId);
    if (calleeIndex === undefined || callerIndex === undefined) {
      return;
    }
    const key = `${calleeIndex}|${callerIndex}|${fileId}|${line}|${callKind}`;
    if (edgeKeys.has(key)) {
      return;
    }
    edgeKeys.add(key);
    edges.push({
      callee_index: calleeIndex,
      caller_index: callerIndex,
      file_id: fileId,
      line,
      call_kind: callKind,
    });
    const fwd = forwardSets.get(callerId) ?? new Map<string, ForwardCallSite>();
    fwd.set(`${calleeId}|${fileId}|${line}|${callKind}`, {
      callee: calleeId,
      file_id: fileId,
      line,
      call_kind: callKind,
    });
    forwardSets.set(callerId, fwd);
  };

  /** Layered resolution of one call site's callee. */
  const resolveCallee = (
    mc: LmMethodCall,
  ): { targets: MethodSymbolEntry[]; how: 'exact' | 'by_name' | 'none' } => {
    const calleeClass = mc.callee_class_fqn;
    if (calleeClass === null || calleeClass === '') {
      return { targets: [], how: 'none' };
    }
    const guess = normalizeMethodSignature(mc.callee_signature_guess ?? '');
    if (guess !== '') {
      const exact = symbolTable.byClassSignature.get(`${calleeClass}#${guess}`);
      if (exact) {
        return { targets: [exact], how: 'exact' };
      }
    }
    const byName = symbolTable.byClassMethod.get(`${calleeClass}#${mc.callee_method_name}`);
    if (byName && byName.length > 0) {
      return { targets: byName, how: 'by_name' };
    }
    return { targets: [], how: 'none' };
  };

  for (const file of extractions) {
    for (const mc of file.extraction.method_calls) {
      try {
        const callerId = symbolId(repo, mc.caller_class_fqn, mc.caller_method_signature);
        if (!symbolIndex.has(callerId)) {
          stats.unknown_callers += 1;
          continue;
        }
        const calleeClass = mc.callee_class_fqn ?? '';

        // Both endpoints of an edge must be in-scope. Out-of-scope callees are
        // third-party/JDK frames, which are noise for a blast-radius walk.
        if (calleeClass !== '' && !matchesPrefix(calleeClass, packagePrefixes)) {
          stats.excluded_by_prefix += 1;
          continue;
        }
        if (!matchesPrefix(mc.caller_class_fqn, packagePrefixes)) {
          stats.excluded_by_prefix += 1;
          continue;
        }

        const fileId = fileIdOf(file.relativePath);
        const isInterfaceCall = calleeClass !== '' && interfaceFqns.has(calleeClass);
        const { targets, how } = resolveCallee(mc);

        if (isInterfaceCall) {
          // INTERFACE CALL: emit one edge per known concrete implementation
          // PLUS one to the interface method itself, all tagged `interface`.
          const impls = symbolTable.implementations.get(calleeClass) ?? [];
          let emitted = 0;
          for (const target of targets) {
            addEdge(callerId, target.id, fileId, mc.line, 'interface');
            emitted += 1;
          }
          for (const impl of impls) {
            const implTargets =
              symbolTable.byClassMethod.get(`${impl}#${mc.callee_method_name}`) ?? [];
            for (const t of implTargets) {
              addEdge(callerId, t.id, fileId, mc.line, 'interface');
              emitted += 1;
            }
          }
          if (emitted > 0) {
            stats.interface_edges += emitted;
            if (how === 'exact') {
              stats.resolved_exact += 1;
            } else if (how === 'by_name') {
              stats.resolved_by_name += 1;
            }
            continue;
          }
          stats.unresolved_callees += 1;
          continue;
        }

        if (targets.length === 0) {
          stats.unresolved_callees += 1;
          continue;
        }
        if (how === 'exact') {
          stats.resolved_exact += 1;
        } else {
          stats.resolved_by_name += 1;
          logger.log(
            'CALLGRAPH',
            `${file.relativePath}:${mc.line} callee signature guess ` +
              `'${mc.callee_signature_guess ?? ''}' did not match; fell back to ` +
              `${calleeClass}#${mc.callee_method_name} (${targets.length} overload(s))`,
          );
        }
        for (const target of targets) {
          addEdge(callerId, target.id, fileId, mc.line, mc.call_kind);
        }
      } catch (err) {
        failOpen(logger, 'CALLGRAPH', `resolving call site in ${file.relativePath}`, undefined, err);
      }
    }
  }

  stats.edges = edges.length;

  // --- forward map, fully sorted ------------------------------------------
  const forward: ForwardAdjacency = {};
  for (const caller of [...forwardSets.keys()].sort()) {
    const sites = [...forwardSets.get(caller)!.values()].sort((a, b) =>
      a.callee < b.callee
        ? -1
        : a.callee > b.callee
          ? 1
          : a.line - b.line || a.file_id - b.file_id,
    );
    forward[caller] = sites;
  }

  let bin: Buffer;
  try {
    bin = packCallgraph(symbols, edges);
  } catch (err) {
    bin = failOpen(logger, 'CALLGRAPH', 'packCallgraph', packCallgraph([], []), err);
  }

  const idx: Record<string, number> = {};
  symbols.forEach((id, i) => {
    idx[id] = i;
  });

  logger.log(
    'CALLGRAPH',
    `${stats.symbols} symbols, ${stats.edges} edges ` +
      `(${stats.resolved_exact} exact, ${stats.resolved_by_name} by name, ` +
      `${stats.interface_edges} interface) — skipped ${stats.unresolved_callees} unresolvable ` +
      `callees (framework noise), ${stats.excluded_by_prefix} out-of-prefix call sites, ` +
      `${stats.unknown_callers} calls from callers absent from the symbol table`,
  );

  return { bin, idx, sourceMap, stats, symbols, edges, forward };
}
