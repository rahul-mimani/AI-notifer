/**
 * REST path template normalization.
 *
 * Pure, deterministic, no I/O. Two distinct forms exist for every template:
 *   - DISPLAY form   (`normalizePathTemplate`): keeps param names -> `/users/{id}`
 *   - MATCHING form  (`collapsePathParams`):    erases param names -> `/users/{}`
 *
 * The matching form is what fingerprints and consumer matching use, so that
 * renaming a path variable is not mistaken for a structural change.
 */

/** Scheme + host prefix, e.g. `https://api.example.com:8443`. */
const SCHEME_HOST = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^/]*/;

/** Accepts null/undefined/non-string without throwing. */
function asString(raw: unknown): string {
  if (raw === null || raw === undefined) {
    return '';
  }
  return typeof raw === 'string' ? raw : String(raw);
}

/**
 * Normalize a raw path template into its DISPLAY form.
 *
 * - drops `scheme://host[:port]` if present
 * - collapses runs of `/` into a single `/`
 * - ensures exactly one leading `/`
 * - strips trailing slashes, except the root path which stays `/`
 * - preserves `{id}` param names verbatim
 *
 * Empty / null-ish input normalizes to `/` so that a class-level
 * `@RequestMapping("")` behaves like the root of the controller.
 */
export function normalizePathTemplate(raw: unknown): string {
  let s = asString(raw).trim();
  if (s === '') {
    return '/';
  }

  // Drop scheme + authority. Only when a scheme is actually present; a bare
  // `//foo` is treated as a duplicate-slash path, not a protocol-relative URL.
  s = s.replace(SCHEME_HOST, '');
  if (s === '') {
    return '/';
  }

  // Drop query string / fragment — they are not part of a path template.
  const qIndex = s.search(/[?#]/);
  if (qIndex >= 0) {
    s = s.slice(0, qIndex);
  }

  s = s.replace(/\/{2,}/g, '/');

  if (!s.startsWith('/')) {
    s = '/' + s;
  }

  // Strip trailing slashes but keep the root.
  while (s.length > 1 && s.endsWith('/')) {
    s = s.slice(0, -1);
  }

  return s;
}

/**
 * Join a class-level and a method-level template. Either may be empty/null.
 * The result is normalized and can never contain a double slash.
 */
export function joinPathTemplates(classLevel: unknown, methodLevel: unknown): string {
  const cls = asString(classLevel).trim();
  const method = asString(methodLevel).trim();

  // An absolute URL at the method level wins outright (scheme+host present).
  if (SCHEME_HOST.test(method)) {
    return normalizePathTemplate(method);
  }

  if (cls === '' && method === '') {
    return '/';
  }
  if (cls === '') {
    return normalizePathTemplate(method);
  }
  if (method === '') {
    return normalizePathTemplate(cls);
  }

  const clsNorm = normalizePathTemplate(cls);
  const methodNorm = normalizePathTemplate(method);
  if (clsNorm === '/') {
    return methodNorm;
  }
  if (methodNorm === '/') {
    return clsNorm;
  }
  return normalizePathTemplate(clsNorm + methodNorm);
}

/**
 * Collapse every path variable to `{}` — the MATCHING form.
 *
 * Handles:
 *   `{id}`               -> `{}`
 *   `{id:[0-9]+}`        -> `{}`   (Spring regex-constrained variable)
 *   `{*spring}`          -> `{}`   (capturing pattern variable)
 *   `*` and `**`         -> left as-is (Ant-style wildcards are structural)
 *
 * Braces are matched with depth counting so a regex containing `{2,4}`
 * quantifiers (e.g. `{code:[a-z]{2,4}}`) still collapses to a single `{}`.
 */
export function collapsePathParams(template: unknown): string {
  const s = normalizePathTemplate(template);
  let out = '';
  let depth = 0;

  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === '{') {
      if (depth === 0) {
        out += '{}';
      }
      depth++;
    } else if (ch === '}') {
      if (depth > 0) {
        depth--;
      } else {
        // Unbalanced closing brace — keep it so the input stays recoverable.
        out += ch;
      }
    } else if (depth === 0) {
      out += ch;
    }
  }

  return out;
}

/**
 * The literal (non-parameter) path segments, in order. Used for consumer-side
 * fragment matching where only literal text is available in a URL string.
 *
 * Segments that are entirely a path variable or a wildcard are dropped;
 * a mixed segment like `v1-{ver}` contributes nothing (it is not a stable
 * literal) — only fully-literal segments are returned.
 */
export function pathFragments(template: unknown): string[] {
  const collapsed = collapsePathParams(template);
  const out: string[] = [];
  for (const seg of collapsed.split('/')) {
    if (seg === '' || seg === '*' || seg === '**') {
      continue;
    }
    if (seg.includes('{')) {
      continue;
    }
    out.push(seg);
  }
  return out;
}
