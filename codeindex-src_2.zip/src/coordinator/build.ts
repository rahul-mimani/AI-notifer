/**
 * The build coordinator.
 *
 * Order of operations:
 *   walk -> pre-filter -> discover + parse config sources -> resolveProperties
 *        -> LM extract (cache-first) -> normalize -> callgraph -> write bundle
 *
 * Guarantees:
 *  - `built_at` is INJECTED by the caller and never generated here, so two
 *    builds of the same tree are byte-identical;
 *  - fail-open everywhere: a stage that blows up logs and yields its empty
 *    result, the build always produces a loadable bundle;
 *  - DETERMINISTIC-ONLY MODE: when `config.lmEnabled` is false, or the provider
 *    has no model, the walk / filter / config / property stages still run and a
 *    valid bundle with property + wiring records and empty endpoint/invocation
 *    sets is written. The build is never aborted.
 *
 * No `vscode` import — the config shape is declared structurally below so this
 * module stays drivable from plain Node.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import { makeGitReadBranchMulti } from './git.js';

import type {
  ConsumptionManifest,
  Endpoint,
  Fingerprint,
  IndexRecord,
  Meta,
  Transport,
} from '../types.js';
import type { Logger } from '../util/logger.js';
import { failOpen } from '../util/logger.js';
import { buildCallgraph } from '../extractor/callgraph.js';
import type { CallgraphStats, ForwardAdjacency } from '../extractor/callgraph.js';
import { normalizeRepo } from '../extractor/normalize.js';
import type { FileExtractionInput } from '../extractor/normalize.js';
import {
  discoverConfigSources,
  parseDescriptor,
  resolveProperties,
  toConfigSourceMeta,
} from '../extractor/properties/index.js';
import type { ConfigSourceDescriptor } from '../extractor/properties/index.js';
import type { ResolutionResult } from '../extractor/properties/resolve.js';
import { extractFiles } from '../lm/extractor.js';
import type { LmCache } from '../lm/extractor.js';
import type { ChatModelProvider } from '../lm/provider.js';
import { bundlePaths, writeBundle } from '../store/index.js';
import type { WriteResult } from '../store/writer.js';
import { logFilterStats, newFilterStats, preFilter, recordFilter } from './filter.js';
import { FileLmCache } from './lm-cache.js';
import { walkJavaFiles } from './walk.js';

export const INDEXER_VERSION = '0.1.0';
export const SCHEMA_VERSION = '0.1.0';

/** Extra bundle file this coordinator writes beyond the documented store spec. */
export const FORWARD_CALLGRAPH_FILE = 'callgraph.fwd.json';

/**
 * Markers added on top of `BASE_MARKERS`. `@SpringBootApplication` pulls in the
 * boot class so its `main` is registered as an entry point; without it nothing
 * in the repo ever references that file and the reference closure below cannot
 * reach it either.
 */
const STRUCTURAL_MARKERS: readonly string[] = ['@SpringBootApplication'];

/** Safety cap on the reference-closure expansion of the LM candidate set. */
const MAX_EXPANSION_WAVES = 6;

const TRANSPORTS_SUPPORTED: Transport[] = [
  'rest',
  'kafka',
  'solace',
  'jms',
  'message_router',
  'grpc',
];

/**
 * Structural mirror of `CodeIndexConfig` from src/config.ts. Declared here so
 * this module never imports the vscode-dependent config module.
 */
export interface BuildConfig {
  packagePrefixes: string[];
  sourceRoots: string[];
  configServerPaths: string[];
  configServerBranches: string[];
  configMapPaths: string[];
  messageRouterMarkers: string[];
  lmModel: string;
  lmMaxConcurrent: number;
  lmTimeoutSeconds: number;
  lmTotalBudgetMinutes: number;
  lmEnabled: boolean;
  includeTests?: boolean;
}

export interface BuildProgress {
  stage: string;
  message: string;
  done?: number;
  total?: number;
}

export interface BuildIndexOptions {
  repoRoot: string;
  repo: string;
  provider: ChatModelProvider;
  /** Preferred chat model id; passed through to `provider.selectModel`. */
  model: string;
  config: BuildConfig;
  logger: Logger;
  /** ISO timestamp, INJECTED. Never generated inside this module. */
  builtAt: string;
  onProgress?: (p: BuildProgress) => void;
  /** Defaults to a `FileLmCache` over `<repoRoot>/.codeindex/lm_cache`. */
  cache?: LmCache;
  /** Where the bundle is written. Defaults to `repoRoot`. */
  outputRoot?: string;
  repoUrl?: string;
  commit?: string;
  branch?: string;
  signal?: AbortSignal;
}

export interface BuildIndexResult {
  meta: Meta;
  endpoints: Endpoint[];
  fingerprints: Fingerprint[];
  manifest: ConsumptionManifest;
  records: IndexRecord[];
  callgraphSymbols: string[];
  sourceMap: string[];
  forward: ForwardAdjacency;
  callgraphStats: CallgraphStats;
  properties: ResolutionResult;
  configSources: ConfigSourceDescriptor[];
  write: WriteResult;
  /** True when no LM was used (disabled or unavailable). */
  deterministicOnly: boolean;
  bundleRoot: string;
}

/** Every dotted identifier inside a (possibly generic) type expression. */
const FQN_TOKEN = /[A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)+/g;

function collectFqns(text: string | null | undefined, into: Set<string>): void {
  if (text === null || text === undefined || text === '') {
    return;
  }
  for (const m of text.matchAll(FQN_TOKEN)) {
    into.add(m[0]);
  }
}

function matchesPrefix(fqn: string, prefixes: readonly string[]): boolean {
  if (prefixes.length === 0) {
    return true;
  }
  return prefixes.some(
    (p) => p !== '' && (fqn === p || fqn.startsWith(`${p}.`) || fqn.startsWith(`${p}$`)),
  );
}

/**
 * In-repo files referenced by a wave of extractions but not yet extracted.
 * A FQN maps to a file by suffix match against the walked set, which is robust
 * to any source-root layout.
 */
function referencedFiles(
  wave: readonly FileExtractionInput[],
  packagePrefixes: readonly string[],
  contentByPath: ReadonlyMap<string, string>,
  alreadyExtracted: ReadonlySet<string>,
): Array<{ relativePath: string; content: string }> {
  const fqns = new Set<string>();
  for (const file of wave) {
    const ex = file.extraction;
    for (const ep of ex.endpoints) {
      collectFqns(ep.handler_class_fqn, fqns);
      collectFqns(ep.request_dto_fqn, fqns);
      collectFqns(ep.response_dto_fqn, fqns);
      for (const attrs of Object.values(ep.annotations)) {
        for (const key of ['declared_on', 'inherited_from']) {
          const v = attrs[key];
          if (typeof v === 'string') {
            collectFqns(v, fqns);
          }
        }
      }
    }
    for (const inv of ex.invocations) {
      collectFqns(inv.enclosing_class_fqn, fqns);
      collectFqns(inv.request_dto_fqn, fqns);
      collectFqns(inv.response_dto_fqn, fqns);
    }
    for (const dto of ex.dtos) {
      collectFqns(dto.fqn, fqns);
      for (const f of dto.fields) {
        collectFqns(f.type, fqns);
      }
    }
    for (const w of ex.wirings) {
      collectFqns(w.bean_class_fqn, fqns);
      collectFqns(w.defining_class_fqn, fqns);
    }
    for (const b of ex.property_bindings) {
      collectFqns(b.class_fqn, fqns);
      for (const f of b.fields) {
        collectFqns(f.type, fqns);
      }
    }
    for (const mc of ex.method_calls) {
      collectFqns(mc.caller_class_fqn, fqns);
      collectFqns(mc.callee_class_fqn, fqns);
    }
  }

  const out = new Map<string, string>();
  for (const fqn of [...fqns].sort()) {
    if (!matchesPrefix(fqn, packagePrefixes)) {
      continue;
    }
    // Nested types (`Outer$Inner`) live in the outer type's file.
    const suffix = `/${fqn.split('$')[0]!.split('.').join('/')}.java`;
    for (const [relativePath, content] of contentByPath) {
      if (
        (relativePath.endsWith(suffix) || relativePath === suffix.slice(1)) &&
        !alreadyExtracted.has(relativePath) &&
        !out.has(relativePath)
      ) {
        out.set(relativePath, content);
      }
    }
  }
  return [...out.keys()]
    .sort()
    .map((relativePath) => ({ relativePath, content: out.get(relativePath)! }));
}

function defaultProperties(): ResolutionResult {
  return {
    records: [],
    unresolved: [],
    pathFragmentIndex: {},
    table: {
      envs: [],
      get: () => undefined,
      entries: () => [],
    },
  };
}

export async function buildIndex(opts: BuildIndexOptions): Promise<BuildIndexResult> {
  const { repoRoot, repo, config, logger, builtAt } = opts;
  const outputRoot = opts.outputRoot ?? repoRoot;
  const report = (stage: string, message: string, done?: number, total?: number): void => {
    logger.log('WALK', message);
    opts.onProgress?.({ stage, message, done, total });
  };

  /* ---------------- 1. walk ------------------------------------------- */
  opts.onProgress?.({ stage: 'walk', message: 'Walking repo…' });
  logger.log('WALK', 'Walking repo…');
  let walked: Array<{ relativePath: string; absolutePath: string; size: number }> = [];
  try {
    walked = await walkJavaFiles(
      repoRoot,
      { sourceRoots: config.sourceRoots, includeTests: config.includeTests },
      logger,
    );
  } catch (err) {
    walked = failOpen(logger, 'WALK', 'walkJavaFiles', [], err);
  }
  const allFiles = walked.map((w) => w.relativePath);

  /* ---------------- 2. pre-filter ------------------------------------- */
  const stats = newFilterStats();
  const candidates: Array<{ relativePath: string; content: string }> = [];
  const contentByPath = new Map<string, string>();
  for (let i = 0; i < walked.length; i++) {
    const file = walked[i]!;
    opts.onProgress?.({
      stage: 'filter',
      message: `Filtering candidate files… (${i + 1} of ${walked.length})`,
      done: i + 1,
      total: walked.length,
    });
    let content: string;
    try {
      content = fs.readFileSync(file.absolutePath, 'utf8');
    } catch (err) {
      failOpen(logger, 'FILTER', `read ${file.relativePath}`, undefined, err);
      continue;
    }
    contentByPath.set(file.relativePath, content);
    const result = preFilter(content, [...config.messageRouterMarkers, ...STRUCTURAL_MARKERS]);
    recordFilter(stats, result);
    if (result.keep) {
      candidates.push({ relativePath: file.relativePath, content });
    }
  }
  logFilterStats(logger, stats);

  /* ---------------- 3. config sources + properties -------------------- */
  opts.onProgress?.({ stage: 'config', message: 'Parsing config sources…' });
  logger.log('YAML', 'Parsing config sources…');
  let configSources: ConfigSourceDescriptor[] = [];
  try {
    // Without a readBranch hook, only the first configured branch gets read and
    // labelled — which silently misreports per-env values. Supply a git-backed
    // hook so `configServerBranches` actually means something; it returns null
    // when git is unusable and the caller degrades with an explicit log.
    const readBranch = config.configServerPaths.length > 0
      ? makeGitReadBranchMulti(config.configServerPaths, logger) ?? undefined
      : undefined;

    configSources = discoverConfigSources(
      repoRoot,
      {
        configServerPaths: config.configServerPaths,
        configServerBranches: config.configServerBranches,
        configMapPaths: config.configMapPaths,
        readBranch,
      },
      logger,
    );
  } catch (err) {
    configSources = failOpen(logger, 'YAML', 'discoverConfigSources', [], err);
  }

  let properties = defaultProperties();
  try {
    const raws = configSources.flatMap((d) => parseDescriptor(d, logger));
    properties = resolveProperties(raws, logger);
    logger.log(
      'YAML',
      `${configSources.length} config sources -> ${raws.length} raw properties, ` +
        `${properties.records.length} records, ${properties.unresolved.length} unresolved`,
    );
  } catch (err) {
    properties = failOpen(logger, 'YAML', 'resolveProperties', defaultProperties(), err);
  }

  /* ---------------- 4. LM extraction (cache-first) --------------------- */
  const cache: LmCache = opts.cache ?? new FileLmCache(outputRoot, logger);
  const extractions: FileExtractionInput[] = [];
  let deterministicOnly = false;

  let model = null as Awaited<ReturnType<ChatModelProvider['selectModel']>>;
  if (!config.lmEnabled) {
    deterministicOnly = true;
    logger.log(
      'LM',
      'DETERMINISTIC-ONLY MODE: codeindex.lm.enabled is false — no LM calls will be made. ' +
        'Property, wiring and config records are still extracted; endpoint and invocation ' +
        'sets will be empty.',
    );
  } else {
    try {
      model = await opts.provider.selectModel(config.lmModel, logger);
    } catch (err) {
      model = failOpen(logger, 'LM', 'selectModel', null, err);
    }
    if (model === null) {
      deterministicOnly = true;
      logger.log(
        'LM',
        'DETERMINISTIC-ONLY MODE: no chat model is available — falling back to ' +
          'deterministic extraction only. The build continues and writes a valid bundle.',
      );
    }
  }

  if (!deterministicOnly && model !== null) {
    // The marker pre-filter deliberately only sees the TRANSPORT surface —
    // plain POJO DTOs, services and repositories carry no marker at all. Those
    // files still matter (DTO shapes are the cross-repo join key, and a call
    // chain that stops at the first unextracted service is useless), so the
    // marker hits are treated as WAVE 1 and the candidate set is then closed
    // over the in-repo types wave N actually referenced. This costs LM calls
    // only for files something in scope genuinely points at.
    const extracted = new Set<string>();
    let pending = candidates.slice().sort((a, b) => (a.relativePath < b.relativePath ? -1 : 1));
    let wave = 0;
    let doneCount = 0;
    let cacheHits = 0;

    while (pending.length > 0 && wave < MAX_EXPANSION_WAVES) {
      wave += 1;
      const total = doneCount + pending.length;
      opts.onProgress?.({
        stage: 'lm',
        message: `Extracting via LM… (${doneCount} of ${total}, cache hits: ${cacheHits})`,
        done: doneCount,
        total,
      });
      const waveStart = doneCount;
      const waveExtractions: FileExtractionInput[] = [];
      try {
        const result = await extractFiles({
          repoRoot: outputRoot,
          files: pending,
          provider: opts.provider,
          model,
          cache,
          logger,
          markers: config.messageRouterMarkers,
          maxConcurrent: config.lmMaxConcurrent,
          timeoutSeconds: config.lmTimeoutSeconds,
          totalBudgetMinutes: config.lmTotalBudgetMinutes,
          signal: opts.signal,
          onProgress: (p) =>
            opts.onProgress?.({
              stage: 'lm',
              message: `Extracting via LM… (${waveStart + p.done} of ${waveStart + p.total}, cache hits: ${cacheHits + p.cacheHits})`,
              done: waveStart + p.done,
              total: waveStart + p.total,
            }),
        });
        cacheHits += result.cacheHits;
        for (const r of result.results) {
          waveExtractions.push({ relativePath: r.relativePath, extraction: r.extraction });
        }
        if (result.skipped.length > 0) {
          logger.log('LM', `${result.skipped.length} files were skipped in wave ${wave}: partial index`);
        }
      } catch (err) {
        failOpen(logger, 'LM', `extractFiles wave ${wave}`, undefined, err);
      }

      for (const f of pending) {
        extracted.add(f.relativePath);
      }
      doneCount += pending.length;
      extractions.push(...waveExtractions);

      const next = referencedFiles(waveExtractions, config.packagePrefixes, contentByPath, extracted);
      if (next.length > 0) {
        logger.log(
          'LM',
          `wave ${wave} referenced ${next.length} further in-scope file(s) with no marker of their own ` +
            `(${next.map((f) => f.relativePath).join(', ')}) — extracting them in wave ${wave + 1}`,
        );
      }
      pending = next;
    }
    if (pending.length > 0) {
      logger.log(
        'LM',
        `WARN reference-closure cap of ${MAX_EXPANSION_WAVES} waves reached; ` +
          `${pending.length} referenced file(s) were not extracted — partial index`,
      );
    }
  }
  // Deterministic ordering regardless of the concurrency schedule above.
  extractions.sort((a, b) =>
    a.relativePath < b.relativePath ? -1 : a.relativePath > b.relativePath ? 1 : 0,
  );

  /* ---------------- 5. normalize --------------------------------------- */
  opts.onProgress?.({ stage: 'normalize', message: 'Normalizing extraction output…' });
  const normalized = normalizeRepo({
    repo,
    files: allFiles,
    extractions,
    propertyResolution: properties,
    packagePrefixes: config.packagePrefixes,
    logger,
    extractorTag: deterministicOnly ? 'deterministic' : `lm:${model?.id ?? 'unknown'}`,
    messageRouterMarkers: config.messageRouterMarkers,
  });

  /* ---------------- 6. callgraph --------------------------------------- */
  opts.onProgress?.({ stage: 'callgraph', message: 'Building callgraph…' });
  logger.log('CALLGRAPH', 'Building callgraph…');
  const callgraph = buildCallgraph({
    repo,
    extractions,
    symbolTable: normalized.symbolTable,
    sourceMap: allFiles,
    packagePrefixes: config.packagePrefixes,
    logger,
  });

  /* ---------------- 7. write ------------------------------------------- */
  opts.onProgress?.({ stage: 'store', message: 'Writing store…' });
  logger.log('STORE', 'Writing store…');

  const countsByKind: Record<string, number> = {};
  for (const rec of normalized.records) {
    countsByKind[`records_${rec.kind}`] = (countsByKind[`records_${rec.kind}`] ?? 0) + 1;
  }

  const meta: Meta = {
    repo,
    repo_url: opts.repoUrl ?? '',
    commit: opts.commit ?? '',
    branch: opts.branch ?? '',
    built_at: builtAt,
    indexer_version: INDEXER_VERSION,
    schema_version: SCHEMA_VERSION,
    source_roots: [...config.sourceRoots].sort(),
    package_prefixes: [...config.packagePrefixes].sort(),
    config_sources: toConfigSourceMeta(configSources),
    transports_supported: TRANSPORTS_SUPPORTED,
    stats: {
      java_files_walked: allFiles.length,
      files_filtered_out: stats.skipped,
      lm_candidates: candidates.length,
      files_extracted: extractions.length,
      endpoints: normalized.endpoints.length,
      fingerprints: normalized.fingerprints.length,
      records_total: normalized.records.length,
      ...countsByKind,
      callgraph_symbols: callgraph.stats.symbols,
      callgraph_edges: callgraph.stats.edges,
      callgraph_interface_edges: callgraph.stats.interface_edges,
      callgraph_unresolved_callees: callgraph.stats.unresolved_callees,
      callgraph_excluded_by_prefix: callgraph.stats.excluded_by_prefix,
      source_map_files: callgraph.sourceMap.length,
      deterministic_only: deterministicOnly ? 1 : 0,
    },
  };

  let write: WriteResult = { bytes: {}, totalBytes: 0 };
  const paths = bundlePaths(outputRoot);
  try {
    write = writeBundle(
      outputRoot,
      {
        meta,
        endpoints: normalized.endpoints,
        fingerprints: normalized.fingerprints,
        manifest: normalized.manifest,
        records: normalized.records,
        callgraphSymbols: callgraph.symbols,
        callgraphEdges: callgraph.edges,
        sourceMap: callgraph.sourceMap,
      },
      logger,
    );
  } catch (err) {
    write = failOpen(logger, 'STORE', 'writeBundle', write, err);
  }

  // ADDITION TO THE DOCUMENTED STORE SPEC: the packed callgraph is reverse-only
  // (callee -> callers), which cannot serve the daemon's downstream walks
  // (handler -> service -> repository). The forward adjacency is therefore
  // written alongside it as plain JSON. Needs documenting in SCHEMA.md.
  try {
    const fwdPath = path.join(paths.root, FORWARD_CALLGRAPH_FILE);
    const buf = Buffer.from(JSON.stringify(callgraph.forward, null, 2) + '\n', 'utf8');
    fs.mkdirSync(paths.root, { recursive: true });
    fs.writeFileSync(fwdPath, buf);
    write.bytes[FORWARD_CALLGRAPH_FILE] = buf.byteLength;
    write.totalBytes += buf.byteLength;
    logger.log('STORE', `wrote ${FORWARD_CALLGRAPH_FILE} (${buf.byteLength} bytes)`);
  } catch (err) {
    failOpen(logger, 'STORE', `write ${FORWARD_CALLGRAPH_FILE}`, undefined, err);
  }

  report('done', `build complete for ${repo} (${write.totalBytes} bytes)`);

  return {
    meta,
    endpoints: normalized.endpoints,
    fingerprints: normalized.fingerprints,
    manifest: normalized.manifest,
    records: normalized.records,
    callgraphSymbols: callgraph.symbols,
    sourceMap: callgraph.sourceMap,
    forward: callgraph.forward,
    callgraphStats: callgraph.stats,
    properties,
    configSources,
    write,
    deterministicOnly,
    bundleRoot: paths.root,
  };
}
