import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import type { Logger } from '../util/logger.js';
import { failOpen } from '../util/logger.js';

/** Directories never worth walking, regardless of source roots. */
const PRUNED_DIRS = new Set([
  '.git',
  '.codeindex',
  'node_modules',
  'target',
  'build',
  'out',
  'bin',
  '.gradle',
  '.idea',
  '.mvn',
]);

export interface WalkedFile {
  /** Repo-relative, forward slashes, no leading slash. */
  relativePath: string;
  absolutePath: string;
  size: number;
}

export interface WalkOptions {
  sourceRoots: string[];
  /** Test sources are excluded by default per the store spec. */
  includeTests?: boolean;
}

/** Repo-relative path with forward slashes and no leading slash. */
export function toRepoRelative(repoRoot: string, absolutePath: string): string {
  return path.relative(repoRoot, absolutePath).split(path.sep).join('/');
}

function isTestPath(relativePath: string): boolean {
  return relativePath.startsWith('src/test/') || relativePath.includes('/src/test/');
}

async function walkDir(dir: string, repoRoot: string, acc: WalkedFile[], logger: Logger): Promise<void> {
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch (err) {
    failOpen(logger, 'WALK', `readdir ${dir}`, undefined, err);
    return;
  }
  // Sorted so the walk order — and therefore every downstream id ordering — is deterministic.
  entries.sort((a, b) => a.name.localeCompare(b.name));
  for (const entry of entries) {
    if (entry.isSymbolicLink()) {
      continue;
    }
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (PRUNED_DIRS.has(entry.name)) {
        continue;
      }
      await walkDir(abs, repoRoot, acc, logger);
    } else if (entry.isFile() && entry.name.endsWith('.java')) {
      try {
        const stat = await fs.stat(abs);
        acc.push({
          relativePath: toRepoRelative(repoRoot, abs),
          absolutePath: abs,
          size: stat.size,
        });
      } catch (err) {
        failOpen(logger, 'WALK', `stat ${abs}`, undefined, err);
      }
    }
  }
}

/**
 * Walk the configured source roots for .java files. Falls back to walking the
 * whole repo when no configured source root exists on disk, so a repo with an
 * unusual layout still indexes rather than silently producing nothing.
 */
export async function walkJavaFiles(
  repoRoot: string,
  options: WalkOptions,
  logger: Logger,
): Promise<WalkedFile[]> {
  const acc: WalkedFile[] = [];
  const roots: string[] = [];

  for (const root of options.sourceRoots) {
    const abs = path.resolve(repoRoot, root);
    try {
      const stat = await fs.stat(abs);
      if (stat.isDirectory()) {
        roots.push(abs);
      }
    } catch {
      logger.log('WALK', `source root not found, skipping: ${root}`);
    }
  }

  if (roots.length === 0) {
    logger.log('WALK', `no configured source root exists; falling back to full repo walk`);
    roots.push(repoRoot);
  }

  for (const root of roots) {
    await walkDir(root, repoRoot, acc, logger);
  }

  let files = acc;
  if (!options.includeTests) {
    const before = files.length;
    files = files.filter((f) => !isTestPath(f.relativePath));
    if (before !== files.length) {
      logger.log('WALK', `excluded ${before - files.length} test files`);
    }
  }

  // Dedupe (overlapping source roots) and sort for determinism.
  const seen = new Set<string>();
  const unique = files.filter((f) => {
    if (seen.has(f.relativePath)) {
      return false;
    }
    seen.add(f.relativePath);
    return true;
  });
  unique.sort((a, b) => a.relativePath.localeCompare(b.relativePath));

  logger.log('WALK', `${unique.length} java files under ${roots.length} source root(s)`);
  return unique;
}
