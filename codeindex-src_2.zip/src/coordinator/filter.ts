import type { Logger } from '../util/logger.js';

/**
 * Fixed marker set from the spec. A .java file is a candidate for LM
 * extraction if it contains any of these, or any configured Message Router
 * marker. Everything else is skipped before we spend a single LM call.
 */
export const BASE_MARKERS: readonly string[] = [
  '@RestController',
  '@Controller',
  '@RequestMapping',
  '@GetMapping',
  '@PostMapping',
  '@PutMapping',
  '@DeleteMapping',
  '@PatchMapping',
  '@KafkaListener',
  '@JmsListener',
  '@RabbitListener',
  'RestTemplate',
  'WebClient',
  'FeignClient',
  'KafkaTemplate',
  'JmsTemplate',
  'RabbitTemplate',
  'UriComponentsBuilder',
  'UriBuilder',
  '@Value',
  '@ConfigurationProperties',
  '@Bean',
];

export interface FilterResult {
  keep: boolean;
  matched: string[];
}

/**
 * Note: this is a deliberately dumb substring scan, not a parser. A marker
 * inside a comment or string literal produces a false positive, which costs
 * one wasted LM call — acceptable. A false negative would silently lose an
 * endpoint, which is not, so we never try to be clever here.
 */
export function preFilter(content: string, extraMarkers: readonly string[] = []): FilterResult {
  const matched: string[] = [];
  for (const marker of BASE_MARKERS) {
    if (content.includes(marker)) {
      matched.push(marker);
    }
  }
  for (const marker of extraMarkers) {
    if (marker && content.includes(marker) && !matched.includes(marker)) {
      matched.push(marker);
    }
  }
  return { keep: matched.length > 0, matched };
}

export interface FilterStats {
  total: number;
  kept: number;
  skipped: number;
  byMarker: Record<string, number>;
}

export function newFilterStats(): FilterStats {
  return { total: 0, kept: 0, skipped: 0, byMarker: {} };
}

export function recordFilter(stats: FilterStats, result: FilterResult): void {
  stats.total += 1;
  if (result.keep) {
    stats.kept += 1;
    for (const marker of result.matched) {
      stats.byMarker[marker] = (stats.byMarker[marker] ?? 0) + 1;
    }
  } else {
    stats.skipped += 1;
  }
}

export function logFilterStats(logger: Logger, stats: FilterStats): void {
  logger.log('FILTER', `${stats.kept} candidates, ${stats.skipped} skipped of ${stats.total} java files`);
  const ranked = Object.entries(stats.byMarker).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  for (const [marker, count] of ranked) {
    logger.log('FILTER', `  ${marker}: ${count}`);
  }
}
