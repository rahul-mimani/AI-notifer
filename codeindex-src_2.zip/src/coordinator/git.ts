import { execFileSync } from 'node:child_process';
import * as path from 'node:path';
import type { Logger } from '../util/logger.js';

/**
 * Reading a Spring Cloud Config Server checkout means reading files from
 * branches other than the one currently checked out. `git show <branch>:<path>`
 * is the only way to do that without mutating the user's working tree, which we
 * must never do.
 *
 * This shells out to the user's own `git`. It is not a bundled binary or a
 * dependency — if git is absent or the path is not a repo, every call returns
 * null and the caller falls back to the working tree, so a build still
 * succeeds with partial results.
 */

let gitAvailable: boolean | null = null;

function haveGit(logger: Logger): boolean {
  if (gitAvailable !== null) {
    return gitAvailable;
  }
  try {
    execFileSync('git', ['--version'], { stdio: 'pipe', timeout: 5000 });
    gitAvailable = true;
  } catch {
    logger.log('YAML', 'git not available on PATH; Config Server branch enumeration disabled');
    gitAvailable = false;
  }
  return gitAvailable;
}

/**
 * Build a `readBranch` hook rooted at a Config Server checkout. Returns null
 * when git is unusable, so the caller can log the degradation explicitly
 * rather than silently indexing one branch and labelling it as all of them.
 */
export function makeGitReadBranch(
  repoPath: string,
  logger: Logger,
): ((filePath: string, branch: string) => string | null) | null {
  if (!haveGit(logger)) {
    return null;
  }
  try {
    execFileSync('git', ['rev-parse', '--is-inside-work-tree'], {
      cwd: repoPath,
      stdio: 'pipe',
      timeout: 5000,
    });
  } catch {
    logger.log('YAML', `not a git repository, cannot enumerate branches: ${repoPath}`);
    return null;
  }

  return (filePath: string, branch: string): string | null => {
    // git wants a repo-relative path with forward slashes.
    const rel = path.isAbsolute(filePath)
      ? path.relative(repoPath, filePath).split(path.sep).join('/')
      : filePath.split(path.sep).join('/');
    for (const ref of [branch, `origin/${branch}`]) {
      try {
        return execFileSync('git', ['show', `${ref}:${rel}`], {
          cwd: repoPath,
          stdio: ['pipe', 'pipe', 'pipe'],
          encoding: 'utf8',
          timeout: 15000,
          maxBuffer: 8 * 1024 * 1024,
        });
      } catch {
        // Try the remote-tracking form before giving up on this branch.
      }
    }
    logger.log('YAML', `branch ${branch} has no ${rel} (tried local and origin/)`);
    return null;
  };
}

/**
 * A readBranch hook spanning several Config Server checkouts, dispatching each
 * file to the checkout that actually contains it. Returns null only when none
 * of the configured paths is a usable git repo.
 */
export function makeGitReadBranchMulti(
  repoPaths: string[],
  logger: Logger,
): ((filePath: string, branch: string) => string | null) | null {
  const hooks: Array<{ root: string; read: (f: string, b: string) => string | null }> = [];
  for (const repoPath of repoPaths) {
    const read = makeGitReadBranch(repoPath, logger);
    if (read) {
      hooks.push({ root: path.resolve(repoPath), read });
    }
  }
  if (hooks.length === 0) {
    return null;
  }
  // Longest root first, so a nested checkout wins over its parent.
  hooks.sort((a, b) => b.root.length - a.root.length);

  return (filePath: string, branch: string): string | null => {
    const abs = path.resolve(filePath);
    const owner = hooks.find((h) => abs === h.root || abs.startsWith(h.root + path.sep));
    if (!owner) {
      logger.log('YAML', `no Config Server checkout owns ${filePath}; cannot read branch ${branch}`);
      return null;
    }
    return owner.read(abs, branch);
  };
}
