/**
 * File-backed `LmCache`, bridging src/lm to the store's
 * `.codeindex/lm_cache/<content_hash>.json`.
 *
 * The LM layer hands us an opaque RAW STRING and expects the exact same string
 * back — for multi-chunk files that string is the documented envelope
 * `{"__codeindex_lm_chunks__":[ ...raw chunk responses... ]}`. Storing that
 * verbatim as a JSON string would double-escape a whole JSON document and make
 * the cache file unreadable to a human, so the envelope is unwrapped into real
 * JSON on write and re-serialized on read. The CHUNK STRINGS THEMSELVES are
 * preserved byte-for-byte either way, which is all `decodeCacheEnvelope` needs.
 *
 * Fail-open: a missing, unreadable or corrupt entry is a cache MISS, never an
 * error. Nothing here throws at the caller.
 */

import type { LmCache } from '../lm/extractor.js';
import type { Logger } from '../util/logger.js';
import { readLmCache, writeLmCache } from '../store/writer.js';

const CACHE_ENVELOPE_MARKER = '__codeindex_lm_chunks__';

function isEnvelope(value: unknown): value is Record<string, unknown> {
  return (
    value !== null &&
    typeof value === 'object' &&
    !Array.isArray(value) &&
    Array.isArray((value as Record<string, unknown>)[CACHE_ENVELOPE_MARKER])
  );
}

export class FileLmCache implements LmCache {
  /** Counters the sanity suite asserts against. */
  hits = 0;
  misses = 0;
  writes = 0;

  constructor(
    private readonly repoRoot: string,
    private readonly logger?: Logger,
  ) {}

  async read(hash: string): Promise<string | null> {
    const stored = readLmCache<unknown>(this.repoRoot, hash, this.logger);
    if (stored === null || stored === undefined) {
      this.misses += 1;
      return null;
    }
    this.hits += 1;
    if (typeof stored === 'string') {
      return stored;
    }
    if (isEnvelope(stored)) {
      // Re-serialize the envelope; the chunk strings inside are untouched.
      return JSON.stringify(stored);
    }
    // Anything else was written by an older/other producer — hand it back as
    // JSON text and let the validator decide whether it still parses.
    return JSON.stringify(stored);
  }

  async write(hash: string, raw: string): Promise<void> {
    let payload: unknown = raw;
    try {
      const parsed: unknown = JSON.parse(raw);
      if (isEnvelope(parsed)) {
        payload = parsed;
      }
    } catch {
      /* not JSON at all — store the raw string verbatim */
    }
    const ok = writeLmCache(this.repoRoot, hash, payload, this.logger);
    if (ok) {
      this.writes += 1;
    }
  }
}
