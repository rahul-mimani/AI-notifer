/**
 * Java code-lens provider.
 *
 * One lens above every endpoint handler ("N consumers · Show blast radius") and
 * one above every outbound invocation ("Calls {producer}:{route} · confidence
 * n", or the unresolved form).
 *
 * Cheap by construction: everything is read out of the already-resident
 * in-memory bundles. Nothing here builds an index, reads a file, or awaits.
 * `onDidChangeCodeLenses` fires from the registry's change event so lenses
 * refresh after a build instead of on a timer.
 */

import * as vscode from 'vscode';

import type { Endpoint, InvocationRecord } from '../types.js';
import { toRepoRelative } from '../store/paths.js';
import { outputChannelLogger } from '../util/log.js';
import { endpointLensTitle, invocationLensTitle } from './pure.js';
import type { CodeIndexState } from './state.js';
import { consumerCountFor, resolveInvocationTargets } from './targets.js';
import type { InvocationTarget } from './targets.js';

export class CodeIndexLensProvider implements vscode.CodeLensProvider {
  private readonly emitter = new vscode.EventEmitter<void>();
  readonly onDidChangeCodeLenses = this.emitter.event;

  private readonly targetCache = new Map<string, Map<string, InvocationTarget>>();

  constructor(private readonly state: CodeIndexState) {
    state.onDidChangeIndex(() => {
      this.targetCache.clear();
      this.emitter.fire();
    });
  }

  dispose(): void {
    this.emitter.dispose();
  }

  provideCodeLenses(document: vscode.TextDocument): vscode.ProviderResult<vscode.CodeLens[]> {
    try {
      if (document.languageId !== 'java') {
        return [];
      }
      const entry = this.state.repoForFile(document.uri.fsPath);
      if (entry === null) {
        return [];
      }
      const relative = toRepoRelative(entry.repoRoot, document.uri.fsPath);
      const lenses: vscode.CodeLens[] = [];

      const others = this.state.registry
        .list()
        .map((name) => this.state.registry.get(name))
        .filter((r): r is NonNullable<typeof r> => r !== undefined);

      for (const ep of endpointsInFile(entry.index.endpointsByFile, relative)) {
        const count = consumerCountFor(ep, others, entry.repo, outputChannelLogger);
        lenses.push(
          new vscode.CodeLens(rangeFor(document, ep.line), {
            title: endpointLensTitle(count),
            command: 'codeindex.blastRadiusAtCursor',
            tooltip: `Blast radius for ${ep.transport} ${ep.path_template ?? ep.destination ?? ep.id}`,
            arguments: [{ repo: entry.repo, endpointId: ep.id, file: relative, line: ep.line }],
          }),
        );
      }

      const targets = this.targetsFor(entry.repo);
      for (const inv of invocationsInFile(entry.index.invocationsByFile, relative)) {
        const target = targets.get(inv.id) ?? null;
        lenses.push(
          new vscode.CodeLens(rangeFor(document, inv.line), {
            title: invocationLensTitle(target),
            command: target === null ? 'codeindex.showOutput' : 'codeindex.blastRadiusAcrossConsumers',
            tooltip:
              target === null
                ? 'CodeIndex could not resolve a producer endpoint for this call'
                : `Resolved to ${target.producerRepo}:${target.endpointId}`,
            arguments: target === null ? [] : [{ producerRepo: target.producerRepo, endpointId: target.endpointId }],
          }),
        );
      }

      return lenses;
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      outputChannelLogger.log('QUERY', `ERROR providing code lenses: ${detail} — no lenses shown`);
      return [];
    }
  }

  private targetsFor(repo: string): Map<string, InvocationTarget> {
    const cached = this.targetCache.get(repo);
    if (cached !== undefined) {
      return cached;
    }
    const consumer = this.state.registry.get(repo);
    if (consumer === undefined) {
      return new Map();
    }
    const producers = this.state.registry
      .list()
      .map((name) => this.state.registry.get(name))
      .filter((r): r is NonNullable<typeof r> => r !== undefined);
    const map = resolveInvocationTargets(consumer, producers, outputChannelLogger);
    this.targetCache.set(repo, map);
    return map;
  }
}

/**
 * Tolerate an index keyed by a different path form than the editor gives us
 * (the daemon's point lookups do the same thing for the same reason).
 */
function fromByFile<T>(byFile: Map<string, T[]>, relative: string): readonly T[] {
  const direct = byFile.get(relative);
  if (direct !== undefined) {
    return direct;
  }
  for (const [key, list] of byFile) {
    if (relative.endsWith(`/${key}`) || key.endsWith(`/${relative}`)) {
      return list;
    }
  }
  return [];
}

function endpointsInFile(byFile: Map<string, Endpoint[]>, relative: string): readonly Endpoint[] {
  return fromByFile(byFile, relative);
}

function invocationsInFile(
  byFile: Map<string, InvocationRecord[]>,
  relative: string,
): readonly InvocationRecord[] {
  return fromByFile(byFile, relative);
}

/** Clamp a 1-based record line into the document. */
function rangeFor(document: vscode.TextDocument, line: number): vscode.Range {
  const zeroBased = Math.min(Math.max(0, line - 1), Math.max(0, document.lineCount - 1));
  return new vscode.Range(zeroBased, 0, zeroBased, 0);
}
