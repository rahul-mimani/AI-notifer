/**
 * Invocation -> producer-endpoint resolution for hovers and code lenses.
 *
 * The store records an outbound invocation without a target: which producer
 * endpoint it hits is a cross-repo join, computed by `findInvocations`. Hovers
 * and lenses need the answer per invocation and must never trigger work at
 * typing speed, so the whole map is computed ONCE per consumer repo from the
 * already-resident bundles and memoized until the registry changes.
 *
 * vscode-free by construction: `src/sanity/ui-sanity.ts` drives it directly.
 */

import type { Endpoint } from '../types.js';
import { changedFromEndpoint } from '../daemon/blast.js';
import { findInvocations, isConsumed } from '../daemon/match.js';
import type { QueryRepo } from '../daemon/match.js';
import { silentLogger } from '../util/logger.js';
import type { Logger } from '../util/logger.js';
import { endpointRoute } from './pure.js';

export interface InvocationTarget {
  producerRepo: string;
  endpointId: string;
  route: string;
  matchedVia: string[];
  confidence: number;
}

/**
 * Map every invocation in `consumer` to the best-scoring endpoint across
 * `producers`. Ties break on the higher confidence, then on repo/endpoint id so
 * the result is deterministic.
 *
 * Never throws: a producer that blows up is skipped with a log line.
 */
export function resolveInvocationTargets(
  consumer: QueryRepo,
  producers: readonly QueryRepo[],
  logger: Logger = silentLogger,
): Map<string, InvocationTarget> {
  const best = new Map<string, InvocationTarget>();

  for (const producer of producers) {
    if (producer.repo === consumer.repo) {
      continue;
    }
    for (const ep of producer.bundle.endpoints) {
      try {
        const hits = findInvocations(consumer.bundle, changedFromEndpoint(ep), {
          index: consumer.index,
          producerEndpoint: ep,
          logger,
        });
        for (const hit of hits) {
          const candidate: InvocationTarget = {
            producerRepo: producer.repo,
            endpointId: ep.id,
            route: endpointRoute(ep),
            matchedVia: [...hit.matched_via],
            confidence: hit.confidence,
          };
          const prior = best.get(hit.invocation_id);
          if (prior === undefined || isBetter(candidate, prior)) {
            best.set(hit.invocation_id, candidate);
          }
        }
      } catch (err) {
        const detail = err instanceof Error ? err.message : String(err);
        logger.log(
          'QUERY',
          `ERROR resolving invocations of '${consumer.repo}' against ${producer.repo}:${ep.id}: ${detail} — skipped`,
        );
      }
    }
  }
  return best;
}

function isBetter(candidate: InvocationTarget, prior: InvocationTarget): boolean {
  if (candidate.confidence !== prior.confidence) {
    return candidate.confidence > prior.confidence;
  }
  if (candidate.producerRepo !== prior.producerRepo) {
    return candidate.producerRepo < prior.producerRepo;
  }
  return candidate.endpointId < prior.endpointId;
}

/**
 * How many of `consumers` consume `ep`, using the phase-1 manifest gate only.
 * Cheap enough for a code lens: set lookups, no record scanning.
 */
export function consumerCountFor(
  ep: Endpoint,
  consumers: readonly QueryRepo[],
  producerRepo: string,
  logger: Logger = silentLogger,
): number {
  let n = 0;
  const changed = changedFromEndpoint(ep);
  for (const consumer of consumers) {
    if (consumer.repo === producerRepo) {
      continue;
    }
    try {
      if (isConsumed(changed, consumer.bundle.manifest, { producerEndpoint: ep, logger }).consumed) {
        n += 1;
      }
    } catch {
      /* a bad manifest never breaks a lens */
    }
  }
  return n;
}
