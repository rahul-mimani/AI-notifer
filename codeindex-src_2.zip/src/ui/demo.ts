/**
 * The end-to-end demo PIPELINE, with no vscode in it.
 *
 * `codeindex.runDemo` is a thin shell around `runDemoPipeline`: the shell does
 * the folder prompts, the progress notification and the webview; every decision
 * that could be wrong — what to diff against, which endpoint to analyse, when
 * the baseline may be advanced — lives here. `src/sanity/demo-sanity.ts` drives
 * this exact function under plain Node, so the demo's logic is verified even on
 * a machine where the Extension Development Host cannot be launched.
 *
 * Flow:
 *   1. read the baseline (if any) BEFORE rebuilding, since the build overwrites it
 *   2. index producer, then consumer (cache-first: a repeat run is fast)
 *   3. diff new fingerprints against the baseline, passing BOTH bundles so path
 *      renames pair correctly and DTO field diffs are emitted
 *   4. select the endpoint to analyse: first `modified`, else first `added`,
 *      else first `removed`, else the first endpoint in the bundle
 *   5. run `blastRadius`
 *   6. the CALLER advances the baseline, and only after the webview opened
 */

import type { BlastRadiusResult, ChangedEndpoint, Endpoint } from '../types.js';
import type { BuildConfig, BuildIndexResult, BuildProgress } from '../coordinator/build.js';
import { buildIndex } from '../coordinator/build.js';
import { detectChanges } from '../daemon/changes.js';
import { changedFromEndpoint } from '../daemon/blast.js';
import { isConsumed } from '../daemon/match.js';
import type { IndexRegistry } from '../daemon/daemon.js';
import type { ChatModelProvider } from '../lm/provider.js';
import type { Logger } from '../util/logger.js';
import { readBaseline } from './baseline.js';
import { changeSummary, endpointPickLabel } from './pure.js';

export interface DemoRepoSpec {
  root: string;
  repo: string;
  config: BuildConfig;
  provider: ChatModelProvider;
}

export interface DemoOptions {
  producer: DemoRepoSpec;
  consumer: DemoRepoSpec;
  registry: IndexRegistry;
  logger: Logger;
  /** ISO timestamp, injected so two runs of the same tree are comparable. */
  builtAt: string;
  maxDepth: number;
  /** Bundles are written here instead of into the repo, when supplied. */
  outputRootFor?: (spec: DemoRepoSpec) => string;
  onProgress?: (p: BuildProgress) => void;
  signal?: AbortSignal;
}

export interface DemoOutcome {
  producerBuild: BuildIndexResult;
  consumerBuild: BuildIndexResult;
  /** True when a `fingerprints.prev.jsonl` baseline existed before this run. */
  hadBaseline: boolean;
  changes: ChangedEndpoint[];
  /** The change driving the analysis, or null when none was detected. */
  selectedChange: ChangedEndpoint | null;
  selectedEndpointId: string;
  result: BlastRadiusResult;
  deterministicOnly: boolean;
  /** Producer bundle root the caller must snapshot on success. */
  producerBundleRoot: string;
}

/** Endpoint selection priority: modified > added > removed. */
export function selectChange(changes: readonly ChangedEndpoint[]): ChangedEndpoint | null {
  for (const kind of ['modified', 'added', 'removed'] as const) {
    const hit = changes.find((c) => c.change_kind === kind);
    if (hit !== undefined) {
      return hit;
    }
  }
  return null;
}

/**
 * Run the whole demo. Throws only if the build coordinator itself throws (it is
 * fail-open, so in practice it does not); every degraded case — no model, no
 * baseline, no changes, no endpoints — is represented in the outcome instead.
 */
export async function runDemoPipeline(opts: DemoOptions): Promise<DemoOutcome | null> {
  const { producer, consumer, registry, logger } = opts;

  /* --- 1. baseline, read BEFORE the rebuild overwrites it ---------------- */
  const baseline = readBaseline(producer.root, logger);
  const hadBaseline = baseline !== null;
  logger.log(
    'DAEMON',
    `DEMO 1/5 baseline: ${
      hadBaseline
        ? `${baseline.fingerprints.length} fingerprint(s) from the previous run` +
          `${baseline.bundle === null ? ' (fingerprints only — degraded diff)' : ''}`
        : 'none — this is a first run, change detection is skipped'
    }`,
  );

  /* --- 2. index both repos ---------------------------------------------- */
  logger.log('DAEMON', `DEMO 2/5 indexing producer '${producer.repo}' from ${producer.root}`);
  const producerBuild = await buildIndex({
    repoRoot: producer.root,
    repo: producer.repo,
    provider: producer.provider,
    model: producer.config.lmModel,
    config: producer.config,
    logger,
    builtAt: opts.builtAt,
    outputRoot: opts.outputRootFor?.(producer),
    signal: opts.signal,
    onProgress: opts.onProgress,
  });
  if (opts.signal?.aborted ?? false) {
    return null;
  }

  logger.log('DAEMON', `DEMO 2/5 indexing consumer '${consumer.repo}' from ${consumer.root}`);
  const consumerBuild = await buildIndex({
    repoRoot: consumer.root,
    repo: consumer.repo,
    provider: consumer.provider,
    model: consumer.config.lmModel,
    config: consumer.config,
    logger,
    builtAt: opts.builtAt,
    outputRoot: opts.outputRootFor?.(consumer),
    signal: opts.signal,
    onProgress: opts.onProgress,
  });
  if (opts.signal?.aborted ?? false) {
    return null;
  }

  const deterministicOnly = producerBuild.deterministicOnly || consumerBuild.deterministicOnly;
  if (deterministicOnly) {
    logger.log(
      'DAEMON',
      'DEMO: NO CHAT MODEL AVAILABLE — both repos were indexed deterministic-only. Endpoint and ' +
        'invocation sets will be empty; the run still completes and still opens the webview.',
    );
  }

  /* --- load both bundles into the registry ------------------------------ */
  const producerRoot = opts.outputRootFor?.(producer) ?? producer.root;
  const consumerRoot = opts.outputRootFor?.(consumer) ?? consumer.root;
  registry.unload(producer.repo, logger);
  registry.unload(consumer.repo, logger);
  const producerEntry = registry.load(producerRoot, logger, producer.repo);
  registry.load(consumerRoot, logger, consumer.repo);

  /* --- 3. change detection ---------------------------------------------- */
  let changes: ChangedEndpoint[] = [];
  if (baseline !== null) {
    // BOTH bundles go in: without the old one, a renamed path is reported as an
    // unrelated add plus an unrelated remove instead of `modified/path_changed`,
    // and DTO field-level reasons cannot be produced at all.
    changes = detectChanges(baseline.fingerprints, producerBuild.fingerprints, {
      oldBundle: baseline.bundle,
      newBundle: producerEntry.bundle,
      logger,
    });
    logger.log('DAEMON', `DEMO 3/5 detectChanges: ${changes.length} change(s)`);
    for (const c of changes) {
      logger.log('DAEMON', `  ${c.id} — ${changeSummary(c)}`);
    }
  } else {
    logger.log('DAEMON', 'DEMO 3/5 detectChanges: skipped, no baseline');
  }

  /* --- 4. endpoint selection -------------------------------------------- */
  const selectedChange = selectChange(changes);
  let selectedEndpointId: string;
  let changedForQuery: ChangedEndpoint | null;

  if (selectedChange !== null) {
    selectedEndpointId = selectedChange.id;
    changedForQuery = selectedChange;
    logger.log('DAEMON', `DEMO 4/5 analysing changed endpoint ${selectedEndpointId} (${selectedChange.change_kind})`);
  } else {
    // Prefer an endpoint the consumer actually consumes. `endpoints[0]` is
    // whatever sorted first — often a messaging surface nobody calls — which
    // makes a first run (no baseline) open on an empty "not consumed" result
    // and look broken. Falling back to endpoints[0] only when no endpoint has
    // a consumer keeps the spec's behaviour as the genuine last resort.
    const consumed = producerBuild.endpoints.find(
      (ep) => isConsumed(changedFromEndpoint(ep), consumerBuild.manifest, { producerEndpoint: ep }).consumed,
    );
    const first: Endpoint | undefined = consumed ?? producerBuild.endpoints[0];
    if (first === undefined) {
      logger.log(
        'DAEMON',
        `DEMO 4/5 '${producer.repo}' has no endpoints${
          deterministicOnly ? ' (deterministic-only mode)' : ''
        } — nothing to analyse`,
      );
      return null;
    }
    selectedEndpointId = first.id;
    changedForQuery = changedFromEndpoint(first);
    logger.log(
      'DAEMON',
      consumed !== undefined
        ? `DEMO 4/5 no changes — analysing first CONSUMED endpoint ${endpointPickLabel(first)}`
        : `DEMO 4/5 no changes, none consumed — analysing first endpoint ${endpointPickLabel(first)}`,
    );
  }

  /* --- 5. blast radius --------------------------------------------------- */
  const result = registry.blastRadius(producer.repo, [consumer.repo], selectedEndpointId, {
    changed: changedForQuery,
    maxDepth: opts.maxDepth,
    logger,
  });
  logger.log('DAEMON', 'DEMO 5/5 blast radius computed');

  return {
    producerBuild,
    consumerBuild,
    hadBaseline,
    changes,
    selectedChange,
    selectedEndpointId,
    result,
    deterministicOnly,
    producerBundleRoot: producerRoot,
  };
}

/** `Demo complete — N changed endpoints, M consumers impacted.` */
export function demoNotification(outcome: DemoOutcome): string {
  const impacted = outcome.result.consumer_blast_radius.filter((c) => c.consumed).length;
  return `Demo complete — ${outcome.changes.length} changed endpoints, ${impacted} consumers impacted.`;
}
