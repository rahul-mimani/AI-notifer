/**
 * Human-readable impact report.
 *
 * The webview answers "what is connected to what". This answers "what should I
 * tell my team" — plain prose suitable for a PR description, a change request,
 * or a release note. Pure and vscode-free so it can be asserted in sanity runs.
 */

import type {
  BlastRadiusResult,
  ChangedEndpoint,
  ConsumerBlastRadius,
  InvocationHit,
} from '../types.js';

/* ------------------------------------------------------------------ *
 * phrasing helpers
 * ------------------------------------------------------------------ */

function plural(n: number, one: string, many = `${one}s`): string {
  return n === 1 ? `1 ${one}` : `${n} ${many}`;
}

function describeTarget(c: ChangedEndpoint): string {
  if (c.transport === 'rest') {
    return `${c.verb ?? 'ANY'} ${c.path_template ?? '(unknown path)'}`;
  }
  if (c.destination !== null && c.destination !== '') {
    return `${c.transport} destination "${c.destination}"`;
  }
  return `${c.transport} endpoint`;
}

/** Turn the diff_reason enum list into something a human would say. */
function describeChange(c: ChangedEndpoint): string {
  if (c.change_kind === 'added') {
    return 'This endpoint is **new**. Nothing can be broken by it yet, but consumers may need to start calling it.';
  }
  if (c.change_kind === 'removed') {
    return 'This endpoint has been **removed**. Any consumer still calling it will fail at runtime.';
  }

  const reasons = c.diff_reason ?? [];
  const parts: string[] = [];

  if (reasons.includes('path_changed')) {
    parts.push('the URL path changed, so existing callers will hit the old path and get a 404');
  }
  if (reasons.includes('verb_changed')) {
    parts.push('the HTTP method changed, so existing callers will get a 405');
  }
  if (reasons.includes('destination_changed')) {
    parts.push('the messaging destination changed, so publishers and subscribers are no longer pointed at the same place');
  }
  if (reasons.includes('request_dto_shape_changed')) {
    parts.push('the request body shape changed, so callers sending the old shape may be rejected');
  }
  if (reasons.includes('response_dto_shape_changed')) {
    parts.push('the response body shape changed, so callers parsing the old shape may break');
  }

  if (parts.length === 0) {
    return 'This endpoint changed, but the specific reason could not be attributed.';
  }
  const joined =
    parts.length === 1
      ? parts[0]
      : `${parts.slice(0, -1).join('; ')}; and ${parts[parts.length - 1]}`;
  return `${joined[0]!.toUpperCase()}${joined.slice(1)}.`;
}

/** Field-level detail, phrased rather than tabulated. */
function describeFieldDiffs(c: ChangedEndpoint): string[] {
  const out: string[] = [];
  for (const d of c.diff_details ?? []) {
    // The shape-hash pseudo-fields restate the fingerprint diff as two 64-char
    // hashes. True, but unreadable, and the real field diffs say it better.
    if (d.field === 'request_dto_shape' || d.field === 'response_dto_shape') {
      continue;
    }
    if (d.before === null && d.after !== null) {
      out.push(`Field \`${d.field}\` was **added** (\`${d.after}\`).`);
    } else if (d.before !== null && d.after === null) {
      out.push(
        `Field \`${d.field}\` was **removed** (was \`${d.before}\`) — this is the most likely to break a consumer, ` +
          'because anything reading that field will now get nothing.',
      );
    } else if (d.before !== d.after) {
      out.push(`Field \`${d.field}\` changed type from \`${d.before}\` to \`${d.after}\`.`);
    }
  }
  return out;
}

/** What a match signal actually means, in words. */
function explainSignal(signal: string): string {
  if (signal.startsWith('property_value:')) {
    return `its URL is built from the property \`${signal.slice('property_value:'.length)}\``;
  }
  if (signal.startsWith('wired_bean:')) {
    return `it uses the client bean \`${signal.slice('wired_bean:'.length)}\``;
  }
  switch (signal) {
    case 'dto_shape_match':
      return 'it sends or receives a payload with exactly the same field structure';
    case 'dto_fqn_match':
      return 'it references the same DTO type by name';
    case 'destination_match':
      return 'it reads from or writes to the same messaging destination';
    case 'logical_name_match':
      return 'it refers to the same logical service name';
    default:
      return signal;
  }
}

function confidenceWord(c: number): string {
  if (c >= 0.9) {
    return 'high confidence';
  }
  if (c >= 0.75) {
    return 'moderate confidence';
  }
  return 'low confidence';
}

/** The short symbol name — full ids are unreadable in prose. */
function shortSymbol(id: string): string {
  const afterRepo = id.includes(':') ? id.slice(id.indexOf(':') + 1) : id;
  const [type, method] = afterRepo.split('#');
  const cls = (type ?? '').split('.').pop() ?? type ?? id;
  if (method === undefined || method === '') {
    return cls;
  }
  const name = method.includes('(') ? method.slice(0, method.indexOf('(')) : method;
  return `${cls}.${name}`;
}

/* ------------------------------------------------------------------ *
 * sections
 * ------------------------------------------------------------------ */

function producerSection(r: BlastRadiusResult): string[] {
  const p = r.producer_blast_radius;
  const lines: string[] = ['## Impact inside the producer', ''];

  const downstream = p.feeder_chains.filter((n) => n.depth > 0);
  if (downstream.length === 0) {
    lines.push(
      'No internal methods behind this endpoint were resolved. Either the handler is self-contained, ' +
        'or the call graph could not follow it — check the unresolved section below.',
    );
  } else {
    lines.push(
      `The handler reaches ${plural(downstream.length, 'internal method')} in \`${p.repo}\`. ` +
        'These are the methods whose behaviour this change flows through, so they are what to re-test:',
      '',
    );
    for (const n of downstream) {
      lines.push(`${'  '.repeat(Math.max(0, n.depth - 1))}- \`${shortSymbol(n.symbol)}\``);
    }
  }

  const upstream = p.caller_chains.filter((n) => n.depth > 0);
  lines.push('');
  if (upstream.length === 0) {
    lines.push(
      '_No other code inside the producer calls this handler — it is only reached from outside the repo._',
    );
  } else {
    lines.push(`${plural(upstream.length, 'internal caller')} also invoke this handler directly:`, '');
    for (const n of upstream) {
      lines.push(`- \`${shortSymbol(n.symbol)}\``);
    }
  }
  return lines;
}

function invocationLines(hit: InvocationHit): string[] {
  const reasons = hit.matched_via.map(explainSignal);
  const why =
    reasons.length === 1
      ? reasons[0]
      : `${reasons.slice(0, -1).join(', ')}, and ${reasons[reasons.length - 1]}`;
  const lines = [
    `- **\`${shortSymbol(hit.symbol)}\`** — \`${hit.file}:${hit.line_range[0]}\``,
    `  - Calls \`${hit.method_name}\`; matched with ${confidenceWord(hit.confidence)} (${hit.confidence.toFixed(2)}) because ${why}.`,
  ];
  for (const u of hit.unresolved ?? []) {
    lines.push(`  - ⚠ Not fully resolved: ${u.reason}`);
  }
  return lines;
}

function consumerSection(c: ConsumerBlastRadius): string[] {
  const lines: string[] = [`### \`${c.repo}\``, ''];

  if (!c.consumed) {
    lines.push(
      `**Not affected.** Nothing in \`${c.repo}\` appears to call this endpoint or use its payload shape. ` +
        'No action needed.',
      '',
      '_Worth a sanity check if you expected otherwise: a stale index, or a URL built in a way the ' +
        'extractor could not follow, would both look like this._',
    );
    return lines;
  }

  lines.push(
    `**Affected.** ${plural(c.direct_invocations.length, 'call site')} in \`${c.repo}\` ` +
      'will exercise the changed endpoint.',
    '',
  );
  for (const hit of c.direct_invocations) {
    lines.push(...invocationLines(hit));
  }

  if (c.entry_points.length > 0) {
    lines.push(
      '',
      'Those call sites are reachable from the following entry points — these are the ' +
        'user-facing or event-driven flows that would actually surface a failure:',
      '',
    );
    for (const ep of c.entry_points) {
      const kind =
        ep.entry_kind === 'rest_controller'
          ? 'an inbound REST request'
          : ep.entry_kind === 'kafka_listener'
            ? 'a Kafka message'
            : ep.entry_kind === 'jms_listener'
              ? 'a JMS message'
              : ep.entry_kind === 'scheduled'
                ? 'a scheduled job'
                : ep.entry_kind === 'main'
                  ? 'application startup'
                  : `a ${String(ep.entry_kind)}`;
      lines.push(`- \`${shortSymbol(ep.symbol)}\` — triggered by ${kind}`);
    }
  } else {
    lines.push(
      '',
      '_No entry point was reached within the depth limit, so it is unclear which user-facing flow ' +
        'this sits under. Raising `codeindex.maxCallerDepth` may reveal more._',
    );
  }

  lines.push('', `Distinct affected symbols in this repo: ${c.total_affected_symbols}.`);
  return lines;
}

/* ------------------------------------------------------------------ *
 * headline risk
 * ------------------------------------------------------------------ */

function headline(r: BlastRadiusResult): string {
  const affected = r.consumer_blast_radius.filter((c) => c.consumed);
  const sites = affected.reduce((n, c) => n + c.direct_invocations.length, 0);
  const entries = affected.reduce((n, c) => n + c.entry_points.length, 0);
  const breaking =
    r.changed_endpoint.change_kind === 'removed' ||
    (r.changed_endpoint.diff_reason ?? []).some((x) =>
      ['path_changed', 'verb_changed', 'destination_changed', 'dto_field_removed'].includes(x),
    );

  if (affected.length === 0) {
    return (
      'No consumer in the analysed set calls this endpoint. This change looks **safe to ship** ' +
      'as far as these repos are concerned.'
    );
  }
  const risk = breaking ? 'This is a **breaking change**' : 'This is a **potentially breaking change**';
  return (
    `${risk} affecting ${plural(affected.length, 'consumer repo')}, ` +
    `${plural(sites, 'call site')}, and ${plural(entries, 'entry point')}. ` +
    (breaking
      ? 'Consumers will need to be updated and released in step with this change.'
      : 'Review the call sites below to confirm whether they tolerate the new shape.')
  );
}

/* ------------------------------------------------------------------ *
 * entry point
 * ------------------------------------------------------------------ */

export function renderImpactReport(r: BlastRadiusResult, opts?: { producerRepo?: string }): string {
  const c = r.changed_endpoint;
  const producer = opts?.producerRepo ?? r.producer_blast_radius.repo;
  const out: string[] = [];

  out.push(`# Impact report — ${describeTarget(c)}`, '');
  out.push(headline(r), '');

  out.push('## What changed', '');
  out.push(`\`${describeTarget(c)}\` in **${producer}** was **${c.change_kind}**.`, '');
  out.push(describeChange(c), '');
  const fields = describeFieldDiffs(c);
  if (fields.length > 0) {
    out.push('Specifically:', '');
    for (const f of fields) {
      out.push(`- ${f}`);
    }
    out.push('');
  }
  if (c.handler_symbol !== null && c.file !== null) {
    out.push(`Handled by \`${shortSymbol(c.handler_symbol)}\` at \`${c.file}:${c.line ?? '?'}\`.`, '');
  }

  out.push(...producerSection(r), '');

  out.push('## Impact on consumers', '');
  if (r.consumer_blast_radius.length === 0) {
    out.push(
      '_No consumer repositories were analysed. Configure `codeindex.consumerRepos` to include them._',
    );
  } else {
    for (const consumer of r.consumer_blast_radius) {
      out.push(...consumerSection(consumer), '');
    }
  }

  const unresolved = r.unresolved_across_analysis ?? [];
  out.push('## Needs manual review', '');
  if (unresolved.length === 0) {
    out.push('_Everything in this analysis resolved cleanly._');
  } else {
    out.push(
      `${plural(unresolved.length, 'item')} could not be resolved automatically. ` +
        'These are blind spots — the analysis above may be incomplete where they appear:',
      '',
    );
    for (const u of unresolved) {
      const where =
        u.context?.file !== undefined && u.context.file !== ''
          ? ` (\`${u.context.file}:${u.context.line}\`)`
          : '';
      out.push(`- **${u.what}**${where} — ${u.reason}`);
    }
  }

  out.push(
    '',
    '---',
    '',
    '_Generated by CodeIndex. Confidence scores reflect how the call site was matched, ' +
      'not how likely it is to break — always read the reasoning above._',
  );

  return out.join('\n');
}
