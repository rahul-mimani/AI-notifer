/**
 * "Why is this endpoint showing zero consumers?"
 *
 * The blast radius is a pipeline: extract -> index -> phase-1 gate -> phase-2
 * join -> walk. A zero result can come from any stage, and the UI cannot tell
 * you which. This walks every stage in order and reports the FIRST one that
 * produced nothing, so a black box becomes a pointer at the actual problem.
 *
 * Pure and vscode-free so it can be asserted in sanity runs.
 */

import type { ConsumptionManifest, Endpoint, InvocationRecord } from '../types.js';
import type { LoadedBundle } from '../store/reader.js';
import { changedFromEndpoint } from '../daemon/blast.js';
import { isConsumed } from '../daemon/match.js';
import { collapsePathParams, normalizePathTemplate } from '../extractor/paths.js';
import { silentLogger } from '../util/logger.js';

export interface DiagnoseInput {
  producerRepo: string;
  consumerRepo: string;
  endpoint: Endpoint;
  consumerBundle: LoadedBundle;
}

function invocationsOf(b: LoadedBundle): InvocationRecord[] {
  const byKind = b.byKind?.invocation;
  return Array.isArray(byKind) ? (byKind as InvocationRecord[]) : [];
}

function tokens(ep: Endpoint): string[] {
  const out = new Set<string>();
  for (const t of [ep.path_template, ep.path_template_normalized]) {
    if (t !== null && t !== '') {
      out.add(t);
      out.add(collapsePathParams(normalizePathTemplate(t)));
    }
  }
  if (ep.destination !== null && ep.destination !== '') {
    out.add(ep.destination);
  }
  return [...out].sort();
}

/** The last path segment — the bit most likely to be shared across a prefix. */
function lastSegment(t: string | null): string {
  if (t === null || t === '') {
    return '';
  }
  const segs = t.split('?')[0]!.split('/').filter((s) => s !== '' && !s.startsWith('{'));
  return segs.length > 0 ? segs[segs.length - 1]! : '';
}

export function diagnoseMatch(input: DiagnoseInput): string {
  const { producerRepo, consumerRepo, endpoint, consumerBundle } = input;
  const out: string[] = [];
  const invocations = invocationsOf(consumerBundle);
  const manifest: ConsumptionManifest | null = consumerBundle.manifest ?? null;

  out.push(`# Match diagnostic — \`${producerRepo}\` → \`${consumerRepo}\``, '');
  out.push(
    `Endpoint: **${endpoint.verb ?? endpoint.transport} ${endpoint.path_template ?? endpoint.destination ?? '(none)'}**`,
    `Handler: \`${endpoint.handler_symbol}\``,
    '',
  );

  /* --- stage 1: did the consumer extract ANY invocations? ---------------- */
  out.push('## Stage 1 — did the consumer index extract any outbound calls?', '');
  if (invocations.length === 0) {
    out.push(
      `❌ **`+consumerRepo+`\'s index contains ZERO invocation records.**`,
      '',
      'Nothing can match, because the consumer side has no outbound calls indexed at all. This is an',
      'EXTRACTION problem, not a matching problem — fixing path or DTO matching will not help.',
      '',
      'Most likely causes, in order:',
      '',
      '1. **The calling file was never sent to the model.** The pre-filter only sends files containing',
      '   a known marker (`RestTemplate`, `WebClient`, `FeignClient`, `@KafkaListener`, …). If the call',
      '   goes through your own wrapper or an interface — e.g. a `DomainApi` interface whose impl holds',
      '   the actual `RestTemplate` — the interface file has no marker and is skipped.',
      '   → Check `[FILTER]` in the output channel for the file, and run',
      '     `CodeIndex: Show Raw LM Extraction for Current File` on it. No cache entry means it was never sent.',
      '2. **No chat model was available** and the build ran deterministic-only. Endpoints, invocations and',
      '   DTOs are all empty in that mode. Check the status bar and `[LM]` lines.',
      '3. **The build was truncated** by `codeindex.lm.totalBudgetMinutes`. Check `[LM]` for a budget warning.',
      '',
      '**Stop here and fix this first** — the stages below cannot succeed regardless of what they say.',
    );
    return out.join('\n');
  }
  out.push(`✅ ${invocations.length} invocation record(s) found in \`${consumerRepo}\`.`, '');

  /* --- stage 2: does anything reference this endpoint's path/property? --- */
  out.push('## Stage 2 — does any invocation reference this endpoint?', '');
  const seg = lastSegment(endpoint.path_template);
  const near = invocations.filter((inv) => {
    const hay = [inv.path_fragment, inv.literal_url, inv.property_key_ref, inv.destination]
      .filter((x): x is string => typeof x === 'string' && x !== '')
      .join(' ')
      .toLowerCase();
    return seg !== '' && hay.includes(seg.toLowerCase());
  });

  if (near.length === 0) {
    out.push(
      `❌ No invocation mentions \`${seg}\` in its path fragment, literal URL, property key, or destination.`,
      '',
      'The calls were extracted, but none of them look like they target this endpoint. Either:',
      '',
      '- the URL is assembled in a way the extractor could not follow (check the unresolved records below), or',
      '- the call really does live somewhere else, or',
      '- the path segment differs between the two repos (e.g. the consumer knows it as `/tag` but the',
      '  producer maps it under a different name entirely).',
      '',
      'Every extracted invocation, for comparison:',
      '',
    );
  } else {
    out.push(`✅ ${near.length} invocation(s) mention \`${seg}\`:`, '');
  }

  for (const inv of near.length > 0 ? near : invocations.slice(0, 25)) {
    out.push(
      `- \`${inv.file}:${inv.line}\` — \`${inv.method_name}\``,
      `  - path_fragment: \`${inv.path_fragment ?? 'null'}\``,
      `  - literal_url: \`${inv.literal_url ?? 'null'}\``,
      `  - property_key_ref: \`${inv.property_key_ref ?? 'null'}\``,
      `  - client_bean: \`${inv.client_bean ?? 'null'}\``,
      `  - request/response DTO: \`${inv.request_dto_fqn ?? 'null'}\` / \`${inv.response_dto_fqn ?? 'null'}\``,
    );
    for (const u of inv.unresolved ?? []) {
      out.push(`  - ⚠ unresolved (${u.what}): ${u.reason}`);
    }
  }
  out.push('');

  /* --- stage 3: the phase-1 gate ---------------------------------------- */
  out.push('## Stage 3 — the phase-1 consumption gate', '');
  if (manifest === null) {
    out.push('❌ The consumer bundle has no `consumption_manifest.json`. Rebuild its index.', '');
  } else {
    const gate = isConsumed(changedFromEndpoint(endpoint), manifest, {
      producerEndpoint: endpoint,
      logger: silentLogger,
    });
    if (gate.consumed) {
      out.push(`✅ Gate PASSED. Signals: ${gate.signals.map((s) => `\`${s}\``).join(', ')}`, '');
    } else {
      out.push(
        '❌ **Gate FAILED — this is why you see zero consumers.** Phase 2 never ran.',
        '',
        'The gate compares the endpoint against the consumer manifest. Nothing overlapped.',
        '',
        `Endpoint offers: ${tokens(endpoint).map((t) => `\`${t}\``).join(', ') || '_nothing_'}`,
        '',
        'Consumer manifest holds:',
        '',
        `- path fragments: ${(manifest.path_fragments ?? []).slice(0, 30).map((f) => `\`${f}\``).join(', ') || '_none_'}`,
        `- destinations: ${(manifest.destinations ?? []).map((f) => `\`${f}\``).join(', ') || '_none_'}`,
        `- DTO shapes: ${(manifest.dto_shapes ?? []).length} recorded`,
        `- property keys: ${(manifest.property_keys ?? []).slice(0, 20).map((f) => `\`${f}\``).join(', ') || '_none_'}`,
        '',
        'Compare the two lists above. A common cause is a **context path or gateway prefix**: the consumer',
        'holds `/cdu/tag` while the producer maps `/tag`. Suffix matching covers that, so if you see it here',
        'the fragments differ in some other way — a different spelling, or the producer path never made it',
        'into the manifest at all.',
        '',
        'If the DTO shape count is 0, the consumer indexed no DTOs — usually the same pre-filter problem',
        'described in stage 1, since plain POJOs carry no marker.',
        '',
      );
    }
  }

  /* --- stage 4: unresolved --------------------------------------------- */
  const unresolved = (consumerBundle.byKind?.unresolved ?? []) as Array<{
    what: string;
    reason: string;
    context?: { file?: string; line?: number };
  }>;
  out.push('## Stage 4 — unresolved records in the consumer', '');
  if (unresolved.length === 0) {
    out.push('_None._');
  } else {
    out.push(`${unresolved.length} record(s) the extractor could not resolve:`, '');
    for (const u of unresolved.slice(0, 40)) {
      const where = u.context?.file !== undefined ? ` (\`${u.context.file}:${u.context.line}\`)` : '';
      out.push(`- **${u.what}**${where} — ${u.reason}`);
    }
  }

  return out.join('\n');
}
