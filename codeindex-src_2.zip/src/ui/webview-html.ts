import * as vscode from 'vscode';

/**
 * Builds the HTML shell for the blast radius webview.
 *
 * This is the only module under src/ui that touches the vscode API. The panel
 * body itself is rendered entirely by media/webview/blast-radius.js from the
 * BlastRadiusResult message; this function only produces the shell, the CSP,
 * and the resource URIs.
 */

const NONCE_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

/** Generates a fresh 32-character nonce for the CSP script allowance. */
export function getNonce(): string {
  let text = '';
  for (let i = 0; i < 32; i++) {
    text += NONCE_ALPHABET.charAt(Math.floor(Math.random() * NONCE_ALPHABET.length));
  }
  return text;
}

/**
 * Renders the webview shell.
 *
 * The CSP is strict: no inline scripts (the single script tag carries a
 * nonce), no inline styles, and no external origins. Styles, scripts and fonts
 * may only load from the webview's own resource root.
 */
export function renderBlastRadiusHtml(
  webview: vscode.Webview,
  extensionUri: vscode.Uri
): string {
  const nonce = getNonce();

  const styleUri = webview.asWebviewUri(
    vscode.Uri.joinPath(extensionUri, 'media', 'webview', 'blast-radius.css')
  );
  const scriptUri = webview.asWebviewUri(
    vscode.Uri.joinPath(extensionUri, 'media', 'webview', 'blast-radius.js')
  );

  const csp = [
    `default-src 'none'`,
    `style-src ${webview.cspSource}`,
    `script-src 'nonce-${nonce}'`,
    `font-src ${webview.cspSource}`
  ].join('; ');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Security-Policy" content="${csp};">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="${styleUri.toString()}">
  <title>Blast Radius</title>
</head>
<body>
  <div class="toolbar">
    <button type="button" id="expand-all">Expand all</button>
    <button type="button" id="collapse-all">Collapse all</button>
    <input type="search" id="filter" placeholder="Filter by symbol or file&#8230;"
           aria-label="Filter invocations and chain nodes">
    <span class="filter-count" id="filter-count"></span>
  </div>
  <main id="root">
    <div class="state-msg">Waiting for analysis&#8230;</div>
  </main>
  <script nonce="${nonce}" src="${scriptUri.toString()}"></script>
</body>
</html>`;
}
