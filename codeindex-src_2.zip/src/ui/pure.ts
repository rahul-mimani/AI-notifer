/**
 * The vscode-FREE half of the UI layer.
 *
 * Everything here is a pure function over the store/query contracts: lens
 * titles, hover markdown, LM-cache path computation, the multi-chunk cache
 * envelope formatter, and file->repo-root resolution. `src/sanity/ui-sanity.ts`
 * drives all of it under plain Node, which is only possible because this module
 * imports nothing from `vscode`.
 *
 * The vscode-dependent modules (hover.ts, lens.ts, panel.ts, commands.ts) are
 * deliberately thin glue over these functions.
 */

import { createHash } from 'node:crypto';
import * as path from 'node:path';

import type {
  BlastRadiusResult,
  ChangedEndpoint,
  ConsumptionManifest,
  Endpoint,
  InvocationRecord,
} from '../types.js';
import { isConsumed } from '../daemon/match.js';

/* ------------------------------------------------------------------ *
 * Small formatting primitives
 * ------------------------------------------------------------------ */

/** Short form of a fingerprint hash for display. */
export function shortFingerprint(fingerprint: string | null | undefined): string {
  if (fingerprint === null || fingerprint === undefined || fingerprint === '') {
    return '(none)';
  }
  return fingerprint.length <= 12 ? fingerprint : fingerprint.slice(0, 12);
}

/** `GET /api/v1/customers/{id}` for REST, the destination for everything else. */
export function endpointRoute(ep: {
  transport: string;
  verb: string | null;
  path_template: string | null;
  destination: string | null;
}): string {
  if (ep.verb !== null && ep.verb !== '' && ep.path_template !== null && ep.path_template !== '') {
    return `${ep.verb} ${ep.path_template}`;
  }
  if (ep.path_template !== null && ep.path_template !== '') {
    return ep.path_template;
  }
  if (ep.destination !== null && ep.destination !== '') {
    return ep.destination;
  }
  return '(no route)';
}

/** QuickPick label for an endpoint: transport + verb + path/destination. */
export function endpointPickLabel(ep: Endpoint): string {
  return `${ep.transport} · ${endpointRoute(ep)}`;
}

/** QuickPick detail line for an endpoint. */
export function endpointPickDetail(ep: Endpoint): string {
  const bits = [`${ep.file}:${ep.line}`, `fingerprint ${shortFingerprint(ep.fingerprint)}`];
  if (ep.logical_name !== null && ep.logical_name !== '') {
    bits.push(`logical_name ${ep.logical_name}`);
  }
  return bits.join(' · ');
}

/** One-line summary of a `ChangedEndpoint` for QuickPicks and log lines. */
export function changeSummary(changed: ChangedEndpoint): string {
  const reasons = changed.diff_reason.length === 0 ? 'no diff reason' : changed.diff_reason.join(', ');
  return `${changed.change_kind} · ${changed.transport} ${endpointRoute(changed)} · ${reasons}`;
}

/** The declaring interface FQN, when the endpoint was declared on one. */
export function declaringTypeOf(ep: Endpoint): string | null {
  const entry = ep.annotations['declaring_type'];
  if (entry === undefined || entry === null) {
    return null;
  }
  const fqn = (entry as Record<string, unknown>)['fqn'];
  return typeof fqn === 'string' && fqn !== '' ? fqn : null;
}

/* ------------------------------------------------------------------ *
 * Code lens titles
 * ------------------------------------------------------------------ */

/** `"3 consumers · Show blast radius"` (singular at 1, "No consumers" at 0). */
export function endpointLensTitle(consumerCount: number): string {
  const n = Number.isFinite(consumerCount) && consumerCount > 0 ? Math.floor(consumerCount) : 0;
  const noun = n === 1 ? 'consumer' : 'consumers';
  return `$(radio-tower) ${n} ${noun} · Show blast radius`;
}

export interface ResolvedInvocationTarget {
  producerRepo: string;
  endpointId: string;
  /** Human route, e.g. `GET /api/v1/customers/{id}`. Falls back to the id. */
  route?: string;
  confidence: number;
}

/**
 * `"Calls cdu:GET /api/v1/customers/{id} · confidence 0.95"`, or the unresolved
 * form when nothing matched.
 */
export function invocationLensTitle(target: ResolvedInvocationTarget | null): string {
  if (target === null) {
    return '$(question) Unresolved target · click to inspect';
  }
  const label = target.route !== undefined && target.route !== '' ? target.route : target.endpointId;
  return `$(arrow-right) Calls ${target.producerRepo}:${label} · confidence ${formatConfidence(target.confidence)}`;
}

/** Two-decimal confidence, trailing zeros trimmed (0.95, 0.8, 1). */
export function formatConfidence(confidence: number): string {
  if (!Number.isFinite(confidence)) {
    return '0';
  }
  return String(Math.round(confidence * 100) / 100);
}

/* ------------------------------------------------------------------ *
 * Hover markdown
 * ------------------------------------------------------------------ */

export interface ConsumerManifestRef {
  repo: string;
  manifest: ConsumptionManifest;
}

function bullet(label: string, value: string): string {
  return `- **${label}:** ${value}`;
}

function changedFrom(ep: Endpoint): ChangedEndpoint {
  return {
    id: ep.id,
    change_kind: 'modified',
    diff_reason: [],
    diff_details: [],
    handler_symbol: ep.handler_symbol,
    file: ep.file,
    line: ep.line,
    transport: ep.transport,
    verb: ep.verb,
    path_template: ep.path_template,
    destination: ep.destination,
  };
}

/**
 * Which of the supplied consumer manifests consume `ep`, with the phase-1
 * signals that fired. Pure: `isConsumed` is set lookups over the manifest.
 */
export function consumersOf(
  ep: Endpoint,
  consumers: readonly ConsumerManifestRef[],
): Array<{ repo: string; signals: string[] }> {
  const changed = changedFrom(ep);
  const out: Array<{ repo: string; signals: string[] }> = [];
  for (const c of consumers) {
    try {
      const gate = isConsumed(changed, c.manifest, { producerEndpoint: ep });
      if (gate.consumed) {
        out.push({ repo: c.repo, signals: gate.signals });
      }
    } catch {
      /* a bad manifest must never break a hover */
    }
  }
  return out.sort((a, b) => (a.repo < b.repo ? -1 : a.repo > b.repo ? 1 : 0));
}

/** Hover body for an endpoint handler method. Markdown source, no vscode types. */
export function endpointHoverMarkdown(
  ep: Endpoint,
  repo: string,
  consumers: readonly ConsumerManifestRef[],
): string {
  const lines: string[] = [];
  lines.push(`### CodeIndex · endpoint in \`${repo}\``);
  lines.push('');
  lines.push(bullet('Transport', `\`${ep.transport}\``));
  lines.push(bullet('Route', `\`${endpointRoute(ep)}\``));
  if (ep.destination !== null && ep.destination !== '') {
    lines.push(bullet('Destination', `\`${ep.destination}\``));
  }
  lines.push(bullet('Fingerprint', `\`${shortFingerprint(ep.fingerprint)}\``));
  lines.push(
    bullet('Logical name', ep.logical_name === null || ep.logical_name === '' ? '_none_' : `\`${ep.logical_name}\``),
  );

  const declaring = declaringTypeOf(ep);
  if (declaring !== null) {
    lines.push(bullet('Declared on', `\`${declaring}\` (annotations inherited by the handler class)`));
  }

  const consuming = consumersOf(ep, consumers);
  lines.push('');
  if (consumers.length === 0) {
    lines.push('_No consumer repos configured — set `codeindex.consumerRepos`._');
  } else if (consuming.length === 0) {
    lines.push(`_Not consumed by any of the ${consumers.length} configured consumer repo(s)._`);
  } else {
    lines.push(`**Consumed by ${consuming.length} of ${consumers.length} configured repo(s):**`);
    for (const c of consuming) {
      const why = c.signals.length === 0 ? 'no signals recorded' : c.signals.join(', ');
      lines.push(`- \`${c.repo}\` — ${why}`);
    }
  }
  return lines.join('\n');
}

export interface InvocationHoverTarget {
  producerRepo: string;
  endpointId: string;
  route: string;
  matchedVia: readonly string[];
  confidence: number;
}

/** Hover body for an outbound invocation. */
export function invocationHoverMarkdown(
  inv: InvocationRecord,
  repo: string,
  target: InvocationHoverTarget | null,
): string {
  const lines: string[] = [];
  lines.push(`### CodeIndex · outbound call in \`${repo}\``);
  lines.push('');
  lines.push(bullet('Transport', `\`${inv.transport}\``));
  lines.push(bullet('Method', `\`${inv.method_name}\``));
  if (inv.literal_url !== null && inv.literal_url !== '') {
    lines.push(bullet('Literal URL', `\`${inv.literal_url}\``));
  }
  if (inv.path_fragment !== null && inv.path_fragment !== '') {
    lines.push(bullet('Path fragment', `\`${inv.path_fragment}\``));
  }
  if (inv.property_key_ref !== null && inv.property_key_ref !== '') {
    lines.push(bullet('Property key', `\`${inv.property_key_ref}\``));
  }

  lines.push('');
  if (target === null) {
    lines.push('**Target:** _unresolved_ — no producer endpoint matched this call.');
  } else {
    lines.push(`**Target:** \`${target.producerRepo}\` · \`${target.route}\``);
    lines.push(
      bullet(
        'Matched via',
        target.matchedVia.length === 0 ? '_nothing_' : target.matchedVia.map((s) => `\`${s}\``).join(', '),
      ),
    );
    lines.push(bullet('Confidence', formatConfidence(target.confidence)));
  }

  if (inv.unresolved.length > 0) {
    lines.push('');
    lines.push(`**Unresolved (${inv.unresolved.length}):**`);
    for (const note of inv.unresolved) {
      const expr = note.expression === null || note.expression === undefined || note.expression === ''
        ? ''
        : ` \`${note.expression}\``;
      lines.push(`- \`${note.what}\` — ${note.reason}${expr}`);
    }
  }
  return lines.join('\n');
}

/* ------------------------------------------------------------------ *
 * LM cache
 * ------------------------------------------------------------------ */

/** The cache key for a file: sha256 of its content. Mirrors `lm/extractor.ts`. */
export function lmCacheKeyFor(content: string): string {
  return createHash('sha256').update(content, 'utf8').digest('hex');
}

/** `<repoRoot>/.codeindex/lm_cache/<sha256>.json` for a file's content. */
export function lmCacheEntryPathFor(repoRoot: string, content: string): string {
  return path.join(path.resolve(repoRoot), '.codeindex', 'lm_cache', `${lmCacheKeyFor(content)}.json`);
}

/** Directory holding all cache entries for a repo. */
export function lmCacheDirFor(repoRoot: string): string {
  return path.join(path.resolve(repoRoot), '.codeindex', 'lm_cache');
}

const CACHE_ENVELOPE_MARKER = '__codeindex_lm_chunks__';

/**
 * Render a cache entry for human reading.
 *
 * A single-chunk entry is a JSON string holding the model's raw reply; the
 * multi-chunk envelope is `{"__codeindex_lm_chunks__":[ ...raw replies... ]}`.
 * Both are unwrapped: each chunk is parsed (fenced JSON tolerated) and
 * pretty-printed under a `// ---- chunk N of M ----` banner, so the reader sees
 * the model's actual structural output rather than an escaped blob.
 */
export function formatLmCacheContent(raw: string): string {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return raw;
  }

  if (typeof parsed === 'string') {
    return prettyChunk(parsed);
  }

  if (
    parsed !== null &&
    typeof parsed === 'object' &&
    !Array.isArray(parsed) &&
    Array.isArray((parsed as Record<string, unknown>)[CACHE_ENVELOPE_MARKER])
  ) {
    const chunks = (parsed as Record<string, unknown>)[CACHE_ENVELOPE_MARKER] as unknown[];
    const blocks = chunks.map((chunk, i) => {
      const body = typeof chunk === 'string' ? prettyChunk(chunk) : JSON.stringify(chunk, null, 2);
      return `// ---- chunk ${i + 1} of ${chunks.length} ----\n${body}`;
    });
    return blocks.join('\n\n');
  }

  return JSON.stringify(parsed, null, 2);
}

/** Parse-and-pretty-print one raw model reply, tolerating ```json fences. */
export function prettyChunk(raw: string): string {
  const stripped = stripCodeFence(raw);
  try {
    return JSON.stringify(JSON.parse(stripped), null, 2);
  } catch {
    return stripped;
  }
}

/** Remove a surrounding ```json ... ``` fence, if present. */
export function stripCodeFence(text: string): string {
  const trimmed = text.trim();
  if (!trimmed.startsWith('```')) {
    return trimmed;
  }
  const firstNewline = trimmed.indexOf('\n');
  if (firstNewline < 0) {
    return trimmed;
  }
  const withoutOpen = trimmed.slice(firstNewline + 1);
  const closing = withoutOpen.lastIndexOf('```');
  return (closing < 0 ? withoutOpen : withoutOpen.slice(0, closing)).trim();
}

/* ------------------------------------------------------------------ *
 * Path / repo-root resolution
 * ------------------------------------------------------------------ */

export interface RepoRootRef {
  repo: string;
  repoRoot: string;
}

/**
 * A `codeindex.consumerRepos[].indexPath` may name the `.codeindex` directory,
 * a `meta.json` inside it, or the repo root. Normalize to the repo root.
 */
export function repoRootFromIndexPath(indexPath: string): string {
  let p = path.resolve(indexPath);
  if (path.basename(p).endsWith('.json') || path.basename(p).endsWith('.jsonl')) {
    p = path.dirname(p);
  }
  if (path.basename(p) === '.codeindex') {
    p = path.dirname(p);
  }
  return p;
}

/**
 * Resolve a repo-relative `file` from a blast-radius payload back to a real
 * absolute path.
 *
 * The payload mixes producer and consumer files and does not label which repo a
 * given path came from, so every candidate root is probed in order and the
 * first that actually exists on disk wins. `exists` is injected so this is
 * testable without touching the filesystem.
 *
 * Returns null when nothing matches — callers must show a message rather than
 * opening the wrong file or failing silently.
 */
export function resolveFileAgainstRoots(
  file: string,
  roots: readonly RepoRootRef[],
  exists: (candidate: string) => boolean,
): { absolutePath: string; repo: string } | null {
  if (file === '') {
    return null;
  }
  const normalized = file.split('\\').join('/').replace(/^\/+/, '');

  if (path.isAbsolute(file) && exists(file)) {
    const owner = roots.find((r) => path.resolve(file).startsWith(path.resolve(r.repoRoot) + path.sep));
    return { absolutePath: file, repo: owner?.repo ?? '' };
  }

  for (const root of roots) {
    const candidate = path.join(path.resolve(root.repoRoot), ...normalized.split('/'));
    if (exists(candidate)) {
      return { absolutePath: candidate, repo: root.repo };
    }
  }
  return null;
}

/**
 * Prefer the roots that a blast-radius result actually names, in the order
 * producer-then-consumers, so an ambiguous relative path resolves against the
 * repo that most likely produced it.
 */
export function orderRootsForResult(
  result: BlastRadiusResult,
  known: readonly RepoRootRef[],
): RepoRootRef[] {
  const byRepo = new Map(known.map((r) => [r.repo, r] as const));
  const ordered: RepoRootRef[] = [];
  const seen = new Set<string>();
  const push = (repo: string): void => {
    const ref = byRepo.get(repo);
    if (ref !== undefined && !seen.has(repo)) {
      seen.add(repo);
      ordered.push(ref);
    }
  };
  push(result.producer_blast_radius.repo);
  for (const c of result.consumer_blast_radius) {
    push(c.repo);
  }
  for (const ref of known) {
    if (!seen.has(ref.repo)) {
      seen.add(ref.repo);
      ordered.push(ref);
    }
  }
  return ordered;
}

/* ------------------------------------------------------------------ *
 * Result shape checks (shared by the panel and demo-sanity)
 * ------------------------------------------------------------------ */

/**
 * Structural validation of a `BlastRadiusResult` before it is posted to the
 * webview. The renderer indexes into every one of these fields unconditionally,
 * so a malformed payload would blank the panel with no explanation.
 */
export function validateBlastRadiusResult(value: unknown): string[] {
  const problems: string[] = [];
  const r = value as Partial<BlastRadiusResult> | null | undefined;
  if (r === null || r === undefined || typeof r !== 'object') {
    return ['result is not an object'];
  }
  if (r.changed_endpoint === undefined || typeof r.changed_endpoint.id !== 'string') {
    problems.push('changed_endpoint.id missing');
  }
  const p = r.producer_blast_radius;
  if (p === undefined || typeof p.repo !== 'string') {
    problems.push('producer_blast_radius.repo missing');
  } else if (!Array.isArray(p.feeder_chains) || !Array.isArray(p.caller_chains)) {
    problems.push('producer_blast_radius chains are not arrays');
  }
  if (!Array.isArray(r.consumer_blast_radius)) {
    problems.push('consumer_blast_radius is not an array');
  } else {
    for (const c of r.consumer_blast_radius) {
      if (typeof c.repo !== 'string' || typeof c.consumed !== 'boolean') {
        problems.push('a consumer entry is missing repo/consumed');
        break;
      }
      if (!Array.isArray(c.direct_invocations) || !Array.isArray(c.caller_chains) || !Array.isArray(c.entry_points)) {
        problems.push(`consumer '${c.repo}' has non-array chains`);
        break;
      }
    }
  }
  if (!Array.isArray(r.unresolved_across_analysis)) {
    problems.push('unresolved_across_analysis is not an array');
  }
  return problems;
}

/** Human summary of a result, for the output channel and notifications. */
export function summarizeResult(result: BlastRadiusResult): string {
  const consumed = result.consumer_blast_radius.filter((c) => c.consumed);
  const invocations = result.consumer_blast_radius.reduce((n, c) => n + c.direct_invocations.length, 0);
  const entries = result.consumer_blast_radius.reduce((n, c) => n + c.entry_points.length, 0);
  return (
    `${result.changed_endpoint.id} · ` +
    `${consumed.length}/${result.consumer_blast_radius.length} consumer(s) consumed, ` +
    `${invocations} invocation(s), ${entries} entry point(s), ` +
    `${result.producer_blast_radius.feeder_chains.length} feeder node(s), ` +
    `${result.unresolved_across_analysis.length} unresolved`
  );
}
