/**
 * The demo's change-detection BASELINE.
 *
 * WHY THIS FILE EXISTS
 * --------------------
 * `runDemo` rebuilds the producer in place, which overwrites
 * `.codeindex/fingerprints.jsonl`. Without a preserved copy of the PREVIOUS
 * build there is nothing to diff against and the demo can only ever say "first
 * run". So after a successful run we snapshot the bundle's "before" state into
 * sibling `.prev` files, and the next run diffs against them.
 *
 * WHY THREE FILES AND NOT JUST FINGERPRINTS
 * -----------------------------------------
 * `detectChanges` degrades hard when given bare fingerprint lists:
 *
 *  - `endpointId` hashes the DISPLAY path template, so RENAMING A PATH mints a
 *    brand-new id. An id-only join reports that as one `removed` plus one
 *    unrelated `added` and can never emit `path_changed`. The recovery pass that
 *    re-pairs them keys on `(transport, handler_symbol)` — and `handler_symbol`
 *    lives on `Endpoint`, not on `Fingerprint`. Hence `endpoints.prev.jsonl`.
 *  - A shape-hash change says THAT a payload moved, not WHAT moved. The
 *    field-level reasons (`dto_field_added` / `_removed` / `_type_changed`) come
 *    from diffing the DTO RECORDS behind the two shapes. Those live in
 *    `index.jsonl.gz`. Snapshotting the whole gzipped record stream to get them
 *    is wasteful, so only the `dto` records are extracted, into
 *    `dtos.prev.jsonl`.
 *
 * `fingerprints.prev.jsonl` remains the marker file: its presence is what
 * "there is a baseline" means. The other two are read opportunistically, and a
 * baseline missing them still produces a correct (just less detailed) diff.
 *
 * vscode-free, so `src/sanity/demo-sanity.ts` exercises exactly this code.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';

import type { DtoRecord, Endpoint, Fingerprint, IndexRecord } from '../types.js';
import type { Logger } from '../util/logger.js';
import { failOpen } from '../util/logger.js';
import { bundlePaths } from '../store/paths.js';
import { readJsonl, writeJsonl } from '../store/jsonl.js';
import { emptyManifest, emptyMeta, loadBundle } from '../store/reader.js';
import type { LoadedBundle } from '../store/reader.js';
import { CallgraphReader } from '../store/callgraph-codec.js';

export const FINGERPRINTS_PREV = 'fingerprints.prev.jsonl';
export const ENDPOINTS_PREV = 'endpoints.prev.jsonl';
export const DTOS_PREV = 'dtos.prev.jsonl';

export interface BaselinePaths {
  fingerprints: string;
  endpoints: string;
  dtos: string;
}

export function baselinePaths(repoRoot: string): BaselinePaths {
  const root = bundlePaths(repoRoot).root;
  return {
    fingerprints: path.join(root, FINGERPRINTS_PREV),
    endpoints: path.join(root, ENDPOINTS_PREV),
    dtos: path.join(root, DTOS_PREV),
  };
}

/** True when a previous run left a baseline to diff against. */
export function hasBaseline(repoRoot: string): boolean {
  try {
    return fs.existsSync(baselinePaths(repoRoot).fingerprints);
  } catch {
    return false;
  }
}

export interface Baseline {
  fingerprints: Fingerprint[];
  /**
   * A minimal `LoadedBundle` carrying just the endpoints and DTO records
   * `detectChanges` reads. Null when only fingerprints were preserved, in which
   * case the diff degrades to id-only add/remove.
   */
  bundle: LoadedBundle | null;
}

/**
 * Read the baseline written by the previous successful run.
 *
 * Returns null when there is no baseline at all. Never throws: a corrupt or
 * half-written baseline degrades to whatever parsed.
 */
export function readBaseline(repoRoot: string, logger: Logger): Baseline | null {
  const p = baselinePaths(repoRoot);
  try {
    if (!fs.existsSync(p.fingerprints)) {
      return null;
    }
  } catch {
    return null;
  }

  const fingerprints = readJsonl<Fingerprint>(p.fingerprints, logger, 'QUERY');
  const endpoints = fs.existsSync(p.endpoints) ? readJsonl<Endpoint>(p.endpoints, logger, 'QUERY') : [];
  const dtos = fs.existsSync(p.dtos) ? readJsonl<DtoRecord>(p.dtos, logger, 'QUERY') : [];

  if (endpoints.length === 0 && dtos.length === 0) {
    logger.log(
      'QUERY',
      `baseline at ${p.fingerprints} has fingerprints only — path renames and DTO field diffs will not be detected`,
    );
    return { fingerprints, bundle: null };
  }

  logger.log(
    'QUERY',
    `baseline loaded: ${fingerprints.length} fingerprint(s), ${endpoints.length} endpoint(s), ${dtos.length} dto(s)`,
  );
  return { fingerprints, bundle: minimalBundle(repoRoot, endpoints, dtos) };
}

/**
 * A `LoadedBundle` populated with only the fields `detectChanges` touches:
 * `endpointsById` and `byKind.dto`. Everything else is empty but well-formed,
 * so passing it anywhere else degrades rather than crashes.
 */
export function minimalBundle(
  repoRoot: string,
  endpoints: readonly Endpoint[],
  dtos: readonly DtoRecord[],
): LoadedBundle {
  const byKind = {
    symbol: [] as IndexRecord[],
    dto: [...dtos] as IndexRecord[],
    invocation: [] as IndexRecord[],
    property: [] as IndexRecord[],
    wiring: [] as IndexRecord[],
    property_binding: [] as IndexRecord[],
    entry_point: [] as IndexRecord[],
    logical_name_ref: [] as IndexRecord[],
    alias: [] as IndexRecord[],
    unresolved: [] as IndexRecord[],
  };
  const endpointsById = new Map<string, Endpoint>();
  for (const ep of endpoints) {
    endpointsById.set(ep.id, ep);
  }
  return {
    bundleRoot: bundlePaths(repoRoot).root,
    present: true,
    meta: emptyMeta(),
    endpoints: [...endpoints],
    fingerprints: [],
    manifest: emptyManifest(),
    records: [...dtos],
    byKind,
    symbolsById: new Map(),
    recordsByFile: new Map(),
    endpointsById,
    callgraph: CallgraphReader.empty(),
    callgraphIndex: {},
    sourceMap: [],
    loadMs: 0,
  };
}

/**
 * Snapshot the CURRENT bundle as the next run's baseline.
 *
 * Call this ONLY after a run has succeeded. On failure the old baseline must
 * survive untouched, so a retry still diffs against the same "before" state
 * rather than silently comparing the failed build against itself.
 *
 * Returns the number of records written per file. Fail-open: a failed snapshot
 * logs and reports zeros; it never breaks the run that just succeeded.
 */
export function writeBaseline(
  repoRoot: string,
  logger: Logger,
): { fingerprints: number; endpoints: number; dtos: number } {
  const zero = { fingerprints: 0, endpoints: 0, dtos: 0 };
  try {
    const p = bundlePaths(repoRoot);
    const prev = baselinePaths(repoRoot);

    const fingerprints = readJsonl<Fingerprint>(p.fingerprints, logger, 'QUERY');
    const endpoints = readJsonl<Endpoint>(p.endpoints, logger, 'QUERY');
    const bundle = loadBundle(repoRoot, logger);
    const dtos = bundle.byKind.dto as DtoRecord[];

    writeJsonl(prev.fingerprints, fingerprints);
    writeJsonl(prev.endpoints, endpoints);
    writeJsonl(prev.dtos, dtos);

    logger.log(
      'QUERY',
      `baseline refreshed at ${p.root}: ${fingerprints.length} fingerprint(s), ` +
        `${endpoints.length} endpoint(s), ${dtos.length} dto(s) — the next run diffs against this`,
    );
    return { fingerprints: fingerprints.length, endpoints: endpoints.length, dtos: dtos.length };
  } catch (err) {
    return failOpen(logger, 'QUERY', `writeBaseline(${repoRoot})`, zero, err);
  }
}

/** Remove the baseline. Used by the sanity suite to force a first-run path. */
export function clearBaseline(repoRoot: string): void {
  const p = baselinePaths(repoRoot);
  for (const file of [p.fingerprints, p.endpoints, p.dtos]) {
    try {
      fs.rmSync(file, { force: true });
    } catch {
      /* nothing to remove */
    }
  }
}
