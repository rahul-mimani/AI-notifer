/**
 * Blast-radius webview panel lifecycle.
 *
 * TWO MODES, ONE PANEL TYPE
 * -------------------------
 *  - FULL RESULT — `{type:'result', payload: BlastRadiusResult}`: the producer
 *    feeder tree, per-consumer impact and the unresolved list.
 *  - CHANGE LIST — `{type:'changeList', payload: ChangedEndpoint[]}`: pure
 *    `detectChanges` output, no blast radius computed. Each row carries a "Show
 *    blast radius" button which posts `requestBlastRadius` back; the owner of
 *    the panel supplies `onRequestBlastRadius` to answer it, and the reply is an
 *    ordinary `result` message that swaps the view into the full report.
 *
 * Panels are singletons per key (an endpoint id, or `changes:<producer>` for a
 * change list), context is retained when hidden, and resources are locked to
 * `media/`.
 *
 * Protocol:
 *   host -> view   loading | result | changeList | error
 *   view -> host   ready | openLocation{file,line} | requestBlastRadius{endpointId}
 *
 * `openLocation` carries only a repo-relative path, so the panel remembers the
 * repo roots in play and probes them producer-first (see `orderRootsForResult`).
 * A path that resolves against none of them produces a warning, never a silent
 * no-op.
 */

import * as fs from 'node:fs';
import * as vscode from 'vscode';

import type { BlastRadiusResult, ChangedEndpoint } from '../types.js';
import { log, showLog } from '../util/log.js';
import { renderBlastRadiusHtml } from './webview-html.js';
import {
  orderRootsForResult,
  resolveFileAgainstRoots,
  summarizeResult,
  validateBlastRadiusResult,
} from './pure.js';
import type { RepoRootRef } from './pure.js';

const VIEW_TYPE = 'codeindex.blastRadius';
const TITLE = 'CodeIndex: Blast Radius';

type Outbound =
  | { type: 'loading' }
  | { type: 'result'; payload: BlastRadiusResult }
  | { type: 'changeList'; payload: ChangedEndpoint[] }
  | { type: 'error'; message: string };

interface PanelEntry {
  panel: vscode.WebviewPanel;
  /** Buffered message, posted as soon as the view says it is ready. */
  pending: Outbound | null;
  ready: boolean;
  roots: RepoRootRef[];
  /** Answers the view's "Show blast radius" button, in change-list mode. */
  onRequestBlastRadius: ((endpointId: string) => void) | null;
}

const panels = new Map<string, PanelEntry>();

/** Key for the change-list panel of a given producer. */
export function changeListKey(producerRepo: string): string {
  return `changes:${producerRepo}`;
}

/**
 * Open (or reveal) the panel for `key` and show a loading state.
 *
 * Results are posted separately, so a caller can open the panel before the
 * analysis finishes.
 */
export function openBlastRadiusPanel(
  extensionUri: vscode.Uri,
  key: string,
  onRequestBlastRadius?: (endpointId: string) => void,
): void {
  const existing = panels.get(key);
  if (existing !== undefined) {
    existing.panel.reveal(existing.panel.viewColumn ?? vscode.ViewColumn.Beside, false);
    existing.pending = null;
    if (onRequestBlastRadius !== undefined) {
      existing.onRequestBlastRadius = onRequestBlastRadius;
    }
    post(existing, { type: 'loading' });
    return;
  }

  const panel = vscode.window.createWebviewPanel(VIEW_TYPE, TITLE, vscode.ViewColumn.Beside, {
    enableScripts: true,
    retainContextWhenHidden: true,
    localResourceRoots: [vscode.Uri.joinPath(extensionUri, 'media')],
  });

  const entry: PanelEntry = {
    panel,
    pending: null,
    ready: false,
    roots: [],
    onRequestBlastRadius: onRequestBlastRadius ?? null,
  };
  panels.set(key, entry);

  panel.webview.html = renderBlastRadiusHtml(panel.webview, extensionUri);

  panel.webview.onDidReceiveMessage((raw: unknown) => {
    try {
      handleInbound(entry, raw);
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      log('QUERY', `ERROR handling webview message: ${detail} — ignored`);
    }
  });

  panel.onDidDispose(() => {
    panels.delete(key);
    log('QUERY', `webview panel '${key}' disposed`);
  });

  post(entry, { type: 'loading' });
  log('QUERY', `opened webview panel '${key}'`);
}

/** True when a panel for `key` is currently open. */
export function isPanelOpen(key: string): boolean {
  return panels.has(key);
}

/** Update the repo roots a panel resolves `openLocation` paths against. */
export function setPanelRoots(key: string, roots: readonly RepoRootRef[]): void {
  const entry = panels.get(key);
  if (entry !== undefined) {
    entry.roots = [...roots];
  }
}

/**
 * Post a finished result to the panel for `key`.
 *
 * A structurally invalid payload is reported to the view as an error rather
 * than blanking it: the renderer dereferences every top-level field.
 */
export function postResult(
  extensionUri: vscode.Uri,
  key: string,
  result: BlastRadiusResult,
  knownRoots: readonly RepoRootRef[],
): void {
  const entry = ensurePanel(extensionUri, key);
  if (entry === null) {
    return;
  }

  const problems = validateBlastRadiusResult(result);
  if (problems.length > 0) {
    log('QUERY', `blast radius payload for '${key}' is malformed: ${problems.join('; ')}`);
    postError(key, `The analysis produced an unusable result: ${problems.join('; ')}`);
    return;
  }

  entry.roots = orderRootsForResult(result, knownRoots);
  log('QUERY', `posting blast radius to webview — ${summarizeResult(result)}`);
  post(entry, { type: 'result', payload: result });
}

/** Post a change list (detectChanges output) to the panel for `key`. */
export function postChangeList(
  extensionUri: vscode.Uri,
  key: string,
  changes: readonly ChangedEndpoint[],
  knownRoots: readonly RepoRootRef[],
  onRequestBlastRadius: (endpointId: string) => void,
): void {
  const entry = ensurePanel(extensionUri, key, onRequestBlastRadius);
  if (entry === null) {
    return;
  }
  entry.onRequestBlastRadius = onRequestBlastRadius;
  entry.roots = [...knownRoots];
  log('QUERY', `posting change list to webview — ${changes.length} change(s)`);
  post(entry, { type: 'changeList', payload: [...changes] });
}

/** Show an error inside the panel (and the output channel). */
export function postError(key: string, message: string): void {
  log('QUERY', `webview error for '${key}': ${message}`);
  const entry = panels.get(key);
  if (entry !== undefined) {
    post(entry, { type: 'error', message });
  }
}

function ensurePanel(
  extensionUri: vscode.Uri,
  key: string,
  onRequestBlastRadius?: (endpointId: string) => void,
): PanelEntry | null {
  let entry = panels.get(key);
  if (entry === undefined) {
    openBlastRadiusPanel(extensionUri, key, onRequestBlastRadius);
    entry = panels.get(key);
  }
  return entry ?? null;
}

/**
 * Send, or buffer until the view reports itself ready. The view posts
 * `{type:'ready'}` once its script has run; anything sent before that lands on
 * a document with no listener and is lost.
 */
function post(entry: PanelEntry, message: Outbound): void {
  if (entry.ready) {
    void entry.panel.webview.postMessage(message);
  } else {
    entry.pending = message;
  }
}

function handleInbound(entry: PanelEntry, raw: unknown): void {
  if (raw === null || typeof raw !== 'object') {
    return;
  }
  const message = raw as Record<string, unknown>;

  if (message['type'] === 'ready') {
    entry.ready = true;
    if (entry.pending !== null) {
      const buffered = entry.pending;
      entry.pending = null;
      void entry.panel.webview.postMessage(buffered);
    }
    return;
  }

  if (message['type'] === 'openLocation') {
    const file = typeof message['file'] === 'string' ? message['file'] : '';
    const rawLine = message['line'];
    const line = typeof rawLine === 'number' && Number.isFinite(rawLine) ? Math.max(1, Math.floor(rawLine)) : 1;
    void openLocation(entry.roots, file, line);
    return;
  }

  if (message['type'] === 'requestBlastRadius') {
    const endpointId = typeof message['endpointId'] === 'string' ? message['endpointId'] : '';
    if (endpointId === '') {
      log('QUERY', 'requestBlastRadius arrived without an endpointId — ignored');
      return;
    }
    if (entry.onRequestBlastRadius === null) {
      log('QUERY', `requestBlastRadius(${endpointId}) but this panel has no handler — ignored`);
      post(entry, { type: 'error', message: 'This view cannot compute a blast radius.' });
      return;
    }
    log('QUERY', `webview requested blast radius for ${endpointId}`);
    post(entry, { type: 'loading' });
    entry.onRequestBlastRadius(endpointId);
  }
}

/** Open `file:line`, resolved against the repo roots this result came from. */
export async function openLocation(
  roots: readonly RepoRootRef[],
  file: string,
  line: number,
): Promise<void> {
  const hit = resolveFileAgainstRoots(file, roots, (candidate) => {
    try {
      return fs.existsSync(candidate);
    } catch {
      return false;
    }
  });

  if (hit === null) {
    const tried = roots.map((r) => r.repoRoot).join(', ');
    log(
      'QUERY',
      `openLocation: could not resolve '${file}' against any known repo root (${tried === '' ? 'none loaded' : tried})`,
    );
    void vscode.window
      .showWarningMessage(
        `CodeIndex: could not locate "${file}" in any indexed repo. Build or load the repo that owns it.`,
        'Show Log',
      )
      .then((choice) => {
        if (choice === 'Show Log') {
          showLog();
        }
      });
    return;
  }

  try {
    const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(hit.absolutePath));
    const editor = await vscode.window.showTextDocument(doc, {
      viewColumn: vscode.ViewColumn.One,
      preserveFocus: false,
    });
    const zeroBased = Math.max(0, line - 1);
    const target = new vscode.Range(zeroBased, 0, zeroBased, 0);
    editor.selection = new vscode.Selection(target.start, target.start);
    editor.revealRange(target, vscode.TextEditorRevealType.InCenterIfOutsideViewport);
    log('QUERY', `openLocation: ${hit.absolutePath}:${line} (repo '${hit.repo}')`);
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    log('QUERY', `ERROR opening ${hit.absolutePath}:${line}: ${detail}`);
    void vscode.window.showWarningMessage(`CodeIndex: could not open ${hit.absolutePath}: ${detail}`);
  }
}

/** Dispose every open panel. Called from `deactivate`. */
export function disposeAllPanels(): void {
  for (const entry of [...panels.values()]) {
    entry.panel.dispose();
  }
  panels.clear();
}
