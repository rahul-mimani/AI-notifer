/**
 * `CancelledError` lives in its own vscode-free module so both the progress
 * helpers (which do import vscode) and the sanity suite can reach it.
 *
 * Commands distinguish it from a real failure: a cancellation is reported as an
 * informational message and leaves the status bar at rest, whereas a failure
 * sets the error status.
 */
export class CancelledError extends Error {
  constructor(message = 'cancelled by user') {
    super(message);
    this.name = 'CancelledError';
  }
}
