/**
 * `withProgress` glue for long-running work.
 *
 * Two jobs:
 *  - turn a `vscode.CancellationToken` into the `AbortSignal` the build
 *    coordinator (and through it the LM layer) actually honours, so cancelling
 *    the notification stops LM requests rather than just hiding the toast;
 *  - forward `BuildProgress` sub-stages to both the notification and the status
 *    bar, and guarantee the status bar returns to rest whatever happens.
 */

import * as vscode from 'vscode';

import type { BuildProgress } from '../coordinator/build.js';
import { log } from '../util/log.js';
import { setStatus } from '../util/status.js';

export { CancelledError } from './progress-error.js';
import { CancelledError } from './progress-error.js';

export interface ProgressHandle {
  /** Report a sub-stage. `done`/`total` also drive the status bar. */
  report(p: BuildProgress): void;
  /** Aborts when the user cancels. Pass straight into `buildIndex({signal})`. */
  readonly signal: AbortSignal;
  readonly token: vscode.CancellationToken;
  /** True once cancellation has been requested. */
  cancelled(): boolean;
  /** Throw `CancelledError` if the user has cancelled. */
  throwIfCancelled(): void;
}

/**
 * Run `body` inside a cancellable notification progress.
 *
 * The status bar is driven from the same reports and restored by `onDone`
 * on every exit path, including throw and cancel.
 */
export async function withCancellableProgress<T>(
  title: string,
  body: (handle: ProgressHandle) => Promise<T>,
  onDone?: () => void,
): Promise<T> {
  return vscode.window.withProgress(
    { location: vscode.ProgressLocation.Notification, title, cancellable: true },
    async (progress, token) => {
      const controller = new AbortController();
      const sub = token.onCancellationRequested(() => {
        log('DAEMON', `${title}: cancellation requested — aborting in-flight work`);
        controller.abort();
      });

      let lastMessage = '';
      const handle: ProgressHandle = {
        signal: controller.signal,
        token,
        cancelled: () => token.isCancellationRequested,
        throwIfCancelled: () => {
          if (token.isCancellationRequested) {
            throw new CancelledError();
          }
        },
        report: (p: BuildProgress) => {
          if (p.message !== lastMessage) {
            lastMessage = p.message;
            progress.report({ message: p.message });
          }
          if (p.done !== undefined && p.total !== undefined && p.total > 0) {
            setStatus({ kind: 'indexing', done: p.done, total: p.total });
          }
        },
      };

      try {
        return await body(handle);
      } finally {
        sub.dispose();
        onDone?.();
      }
    },
  );
}

/** Non-cancellable notification progress, for short query-only work. */
export async function withSimpleProgress<T>(title: string, body: () => Promise<T>): Promise<T> {
  return vscode.window.withProgress(
    { location: vscode.ProgressLocation.Notification, title, cancellable: false },
    async () => body(),
  );
}
