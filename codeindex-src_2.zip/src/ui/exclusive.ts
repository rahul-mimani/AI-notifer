/**
 * Single-writer guard for the commands that WRITE a bundle.
 *
 * The status bar item's command is `codeindex.runDemo`, so a user clicking it
 * twice — now a very likely interaction — would otherwise start a second build
 * over the same `.codeindex/` directory while the first is still writing it.
 * Two concurrent writers corrupt the bundle, so the second invocation is
 * refused with a message instead of being queued.
 *
 * The flag is reset in a `finally`, which is what keeps a CANCELLATION or a
 * THROWN ERROR from leaving the command permanently dead — the failure mode a
 * naive boolean guard always has.
 *
 * vscode-free (the notifier is injected) so `ui-sanity.ts` can assert the
 * re-entrancy behaviour directly.
 */

let busy = false;
let busyLabel = '';

/** True while a bundle-writing command is in flight. */
export function isBusy(): boolean {
  return busy;
}

/** The label of the command currently holding the lock, or ''. */
export function currentLabel(): string {
  return busyLabel;
}

/** Test hook: force-release the lock. Never call this from the extension. */
export function resetBusyForTests(): void {
  busy = false;
  busyLabel = '';
}

/**
 * Run `body` only if no other bundle writer is in flight.
 *
 * Returns true when `body` ran, false when the call was refused (in which case
 * `onRefused` has been told which command is holding the lock).
 */
export async function runExclusive(
  label: string,
  body: () => Promise<void>,
  onRefused: (holder: string) => void,
): Promise<boolean> {
  if (busy) {
    onRefused(busyLabel);
    return false;
  }
  busy = true;
  busyLabel = label;
  try {
    await body();
    return true;
  } finally {
    busy = false;
    busyLabel = '';
  }
}
