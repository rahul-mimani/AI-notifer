/**
 * Java hover provider.
 *
 * Thin glue: locate the resident repo owning the hovered file, ask the daemon
 * for the endpoint or invocation at that line, and hand the record to the pure
 * markdown builders in `pure.ts`.
 *
 * Returns null immediately when no index is loaded or the file belongs to no
 * resident repo — a hover must never block typing and must never build.
 */

import * as vscode from 'vscode';

import { toRepoRelative } from '../store/paths.js';
import { outputChannelLogger } from '../util/log.js';
import { endpointHoverMarkdown, invocationHoverMarkdown } from './pure.js';
import type { ConsumerManifestRef } from './pure.js';
import type { CodeIndexState } from './state.js';
import { resolveInvocationTargets } from './targets.js';
import type { InvocationTarget } from './targets.js';

export class CodeIndexHoverProvider implements vscode.HoverProvider {
  /** Invocation-target maps, keyed by repo, invalidated on registry change. */
  private readonly targetCache = new Map<string, Map<string, InvocationTarget>>();

  constructor(private readonly state: CodeIndexState) {
    state.onDidChangeIndex(() => this.targetCache.clear());
  }

  provideHover(
    document: vscode.TextDocument,
    position: vscode.Position,
  ): vscode.ProviderResult<vscode.Hover> {
    try {
      if (document.languageId !== 'java') {
        return null;
      }
      const entry = this.state.repoForFile(document.uri.fsPath);
      if (entry === null) {
        return null;
      }
      const relative = toRepoRelative(entry.repoRoot, document.uri.fsPath);
      const line = position.line + 1;

      const endpoint = this.state.registry.getEndpointAt(entry.repo, relative, line);
      if (endpoint !== null) {
        const consumers: ConsumerManifestRef[] = [];
        for (const repo of this.state.registry.list()) {
          const other = this.state.registry.get(repo);
          if (other !== undefined && other.repo !== entry.repo) {
            consumers.push({ repo: other.repo, manifest: other.bundle.manifest });
          }
        }
        return new vscode.Hover(
          markdown(endpointHoverMarkdown(endpoint, entry.repo, consumers)),
        );
      }

      const invocation = this.state.registry.getInvocationAt(entry.repo, relative, line);
      if (invocation !== null) {
        const target = this.targetsFor(entry.repo).get(invocation.id) ?? null;
        return new vscode.Hover(
          markdown(
            invocationHoverMarkdown(
              invocation,
              entry.repo,
              target === null
                ? null
                : {
                    producerRepo: target.producerRepo,
                    endpointId: target.endpointId,
                    route: target.route,
                    matchedVia: target.matchedVia,
                    confidence: target.confidence,
                  },
            ),
          ),
        );
      }
      return null;
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      outputChannelLogger.log('QUERY', `ERROR providing hover: ${detail} — no hover shown`);
      return null;
    }
  }

  private targetsFor(repo: string): Map<string, InvocationTarget> {
    const cached = this.targetCache.get(repo);
    if (cached !== undefined) {
      return cached;
    }
    const consumer = this.state.registry.get(repo);
    if (consumer === undefined) {
      return new Map();
    }
    const producers = this.state.registry
      .list()
      .map((name) => this.state.registry.get(name))
      .filter((r): r is NonNullable<typeof r> => r !== undefined);
    const map = resolveInvocationTargets(consumer, producers, outputChannelLogger);
    this.targetCache.set(repo, map);
    return map;
  }
}

function markdown(source: string): vscode.MarkdownString {
  const md = new vscode.MarkdownString(source);
  md.isTrusted = false;
  md.supportThemeIcons = true;
  return md;
}
