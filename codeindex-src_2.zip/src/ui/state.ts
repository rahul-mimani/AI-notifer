/**
 * Extension-host state shared by the commands, hover, lens and panel.
 *
 * Holds the one `IndexRegistry` every surface queries, remembers which repo
 * root each resident repo came from (the webview needs it to turn a
 * repo-relative path back into a file it can open), and fires a change event so
 * the code-lens provider can refresh without polling.
 */

import * as vscode from 'vscode';

import { IndexRegistry } from '../daemon/index.js';
import type { LoadedRepo } from '../daemon/index.js';
import { outputChannelLogger, log } from '../util/log.js';
import { setStatus } from '../util/status.js';
import type { RepoRootRef } from './pure.js';

export class CodeIndexState {
  readonly registry = new IndexRegistry(outputChannelLogger);

  /** True once model selection has come back empty in this session. */
  lmUnavailable = false;
  /** True when the last build finished with skipped files or partial results. */
  lastBuildHadErrors = false;
  /** True while a build is running, so the status bar is not stomped. */
  building = false;

  private readonly onDidChangeEmitter = new vscode.EventEmitter<void>();
  readonly onDidChangeIndex = this.onDidChangeEmitter.event;

  constructor(
    readonly extensionUri: vscode.Uri,
    /** `context.globalState` — remembers the demo's last-used folder paths. */
    readonly memento: vscode.Memento,
  ) {}

  dispose(): void {
    this.onDidChangeEmitter.dispose();
  }

  /** Load a bundle from `repoRoot` and announce the change. Never throws. */
  loadRepo(repoRoot: string, repoName?: string): LoadedRepo | null {
    try {
      const entry = this.registry.load(repoRoot, outputChannelLogger, repoName);
      this.notifyChanged();
      return entry;
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      log('DAEMON', `ERROR loading bundle from ${repoRoot}: ${detail} — repo not registered`);
      return null;
    }
  }

  /** Every resident repo as a `{repo, repoRoot}` pair. */
  roots(): RepoRootRef[] {
    const out: RepoRootRef[] = [];
    for (const repo of this.registry.list()) {
      const entry = this.registry.get(repo);
      if (entry !== undefined) {
        out.push({ repo: entry.repo, repoRoot: entry.repoRoot });
      }
    }
    return out;
  }

  /** The resident repo whose root contains `absolutePath`, longest root first. */
  repoForFile(absolutePath: string): LoadedRepo | null {
    const normalized = absolutePath.split('\\').join('/');
    let best: LoadedRepo | null = null;
    for (const repo of this.registry.list()) {
      const entry = this.registry.get(repo);
      if (entry === undefined) {
        continue;
      }
      const root = entry.repoRoot.split('\\').join('/');
      if (normalized === root || normalized.startsWith(`${root}/`)) {
        if (best === null || entry.repoRoot.length > best.repoRoot.length) {
          best = entry;
        }
      }
    }
    return best;
  }

  notifyChanged(): void {
    this.onDidChangeEmitter.fire();
    this.restStatus();
  }

  /**
   * Return the status bar to a resting state. Called on every command exit —
   * success, failure and cancellation — so `indexing` is never left spinning.
   */
  restStatus(): void {
    if (this.building) {
      return;
    }
    if (this.lastBuildHadErrors) {
      setStatus({ kind: 'errors' });
      return;
    }
    if (this.lmUnavailable) {
      setStatus({ kind: 'lm-unavailable' });
      return;
    }
    setStatus({ kind: 'ready', repos: this.registry.list().length });
  }
}
