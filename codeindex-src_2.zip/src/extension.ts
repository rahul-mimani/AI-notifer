/**
 * Extension entry point.
 *
 * Wires the ten contributed commands to their real implementations in
 * `src/ui/commands.ts`, registers the Java hover and code-lens providers, and
 * pre-loads any bundles that already exist so hovers and lenses work on the
 * first keystroke of a session rather than only after a build.
 *
 * Nothing of substance lives here — every command body is a `guard`ed function
 * from the UI layer, so a failure logs, sets the error status, and shows a
 * message instead of throwing into the host.
 */

import * as fs from 'node:fs';
import * as vscode from 'vscode';

import { readConfig } from './config.js';
import { bundlePaths } from './store/paths.js';
import { initLog, log, outputChannelLogger, showLog } from './util/log.js';
import { failOpen } from './util/logger.js';
import { initStatus } from './util/status.js';
import {
  blastRadiusAcrossConsumersCommand,
  blastRadiusAtCursorCommand,
  buildIndexCommand,
  buildIndexForFolderCommand,
  checkConsumerImpactCommand,
  clearLmCacheCommand,
  configureConsumerReposCommand,
  detectChangesCommand,
  diagnoseMatchCommand,
  impactReportCommand,
  runDemoCommand,
  showRawLmExtractionCommand,
} from './ui/commands.js';
import { CodeIndexHoverProvider } from './ui/hover.js';
import { CodeIndexLensProvider } from './ui/lens.js';
import { disposeAllPanels } from './ui/panel.js';
import { repoRootFromIndexPath } from './ui/pure.js';
import { CodeIndexState } from './ui/state.js';

const JAVA: vscode.DocumentSelector = { language: 'java', scheme: 'file' };

export function activate(context: vscode.ExtensionContext): void {
  initLog(context);
  initStatus(context);

  const state = new CodeIndexState(context.extensionUri, context.globalState);
  context.subscriptions.push({ dispose: () => state.dispose() });

  const cfg = readConfig();
  log(
    'DAEMON',
    `activated · sourceRoots=${cfg.sourceRoots.join(',')} lmEnabled=${cfg.lmEnabled} ` +
      `consumerRepos=${cfg.consumerRepos.length}`,
  );

  /* ---------------- commands ------------------------------------------- */
  const commands: Array<[string, (...args: never[]) => unknown]> = [
    ['codeindex.buildIndex', buildIndexCommand(state)],
    ['codeindex.buildIndexForFolder', buildIndexForFolderCommand(state)],
    ['codeindex.detectChanges', detectChangesCommand(state)],
    ['codeindex.checkConsumerImpact', checkConsumerImpactCommand(state)],
    ['codeindex.blastRadiusAtCursor', blastRadiusAtCursorCommand(state)],
    ['codeindex.blastRadiusAcrossConsumers', blastRadiusAcrossConsumersCommand(state)],
    ['codeindex.impactReport', impactReportCommand(state)],
    ['codeindex.diagnoseMatch', diagnoseMatchCommand(state)],
    ['codeindex.runDemo', runDemoCommand(state)],
    ['codeindex.showRawLmExtraction', showRawLmExtractionCommand(state)],
    ['codeindex.clearLmCache', clearLmCacheCommand(state)],
    ['codeindex.configureConsumerRepos', configureConsumerReposCommand()],
    // Not contributed in package.json on purpose: it is the status bar's old
    // click target and is still referenced from warning-message affordances.
    ['codeindex.showOutput', () => showLog()],
  ];

  for (const [id, handler] of commands) {
    context.subscriptions.push(
      vscode.commands.registerCommand(id, handler as (...args: unknown[]) => unknown),
    );
  }

  /* ---------------- language features ----------------------------------- */
  const lens = new CodeIndexLensProvider(state);
  context.subscriptions.push(
    { dispose: () => lens.dispose() },
    vscode.languages.registerHoverProvider(JAVA, new CodeIndexHoverProvider(state)),
    vscode.languages.registerCodeLensProvider(JAVA, lens),
  );

  /* ---------------- pre-load resident bundles ---------------------------- */
  preloadBundles(state, cfg.consumerRepos.map((r) => r.indexPath));

  state.restStatus();
}

/**
 * Load every bundle already on disk — each open workspace folder, plus every
 * configured consumer repo — so the first hover of a session has an index to
 * answer from. A missing bundle is normal and silent; a broken one logs.
 */
function preloadBundles(state: CodeIndexState, consumerIndexPaths: readonly string[]): void {
  const roots = new Set<string>();
  for (const folder of vscode.workspace.workspaceFolders ?? []) {
    roots.add(folder.uri.fsPath);
  }
  for (const indexPath of consumerIndexPaths) {
    if (indexPath !== '') {
      roots.add(repoRootFromIndexPath(indexPath));
    }
  }

  let loaded = 0;
  for (const root of [...roots].sort()) {
    try {
      if (!fs.existsSync(bundlePaths(root).meta)) {
        continue;
      }
      if (state.loadRepo(root) !== null) {
        loaded += 1;
      }
    } catch (err) {
      failOpen(outputChannelLogger, 'DAEMON', `preload ${root}`, undefined, err);
    }
  }
  log('DAEMON', `preload: ${loaded} bundle(s) resident of ${roots.size} candidate root(s)`);
}

export function deactivate(): void {
  disposeAllPanels();
}
