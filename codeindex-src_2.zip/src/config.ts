import * as vscode from 'vscode';

export interface ConsumerRepoSetting {
  name: string;
  indexPath: string;
}

export interface CodeIndexConfig {
  packagePrefixes: string[];
  sourceRoots: string[];
  configServerPaths: string[];
  configServerBranches: string[];
  configMapPaths: string[];
  consumerRepos: ConsumerRepoSetting[];
  messageRouterMarkers: string[];
  maxCallerDepth: number;
  lmModel: string;
  lmMaxConcurrent: number;
  lmTimeoutSeconds: number;
  lmTotalBudgetMinutes: number;
  lmEnabled: boolean;
}

export function readConfig(scope?: vscode.Uri): CodeIndexConfig {
  const c = vscode.workspace.getConfiguration('codeindex', scope);
  return {
    packagePrefixes: c.get<string[]>('packagePrefixes', []),
    sourceRoots: c.get<string[]>('sourceRoots', ['src/main/java']),
    configServerPaths: c.get<string[]>('configServerPaths', []),
    configServerBranches: c.get<string[]>('configServerBranches', ['dev', 'uat', 'prod']),
    configMapPaths: c.get<string[]>('configMapPaths', []),
    consumerRepos: c.get<ConsumerRepoSetting[]>('consumerRepos', []),
    messageRouterMarkers: c.get<string[]>('messageRouter.markers', []),
    maxCallerDepth: c.get<number>('maxCallerDepth', 4),
    lmModel: c.get<string>('lm.model', ''),
    lmMaxConcurrent: c.get<number>('lm.maxConcurrent', 4),
    lmTimeoutSeconds: c.get<number>('lm.timeoutSeconds', 60),
    lmTotalBudgetMinutes: c.get<number>('lm.totalBudgetMinutes', 10),
    lmEnabled: c.get<boolean>('lm.enabled', true),
  };
}

export const INDEXER_VERSION = '0.1.0';
export const SCHEMA_VERSION = '0.1.0';
