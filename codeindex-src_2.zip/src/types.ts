/**
 * Store record contracts. Field names here are the on-disk field names — they
 * are written verbatim into .codeindex/. Do not rename without bumping
 * SCHEMA_VERSION.
 */

export type Transport = 'rest' | 'kafka' | 'solace' | 'jms' | 'message_router' | 'grpc';

export type Verb = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

export type SymbolKind = 'class' | 'interface' | 'method' | 'field' | 'annotation';

export type EntryPointKind =
  | 'rest_controller'
  | 'kafka_listener'
  | 'jms_listener'
  | 'scheduled'
  | 'main'
  | 'message_router_handler'
  | 'grpc_handler';

export type Env = 'dev' | 'uat' | 'prod' | 'default' | 'shared';

export type SourceType =
  | 'application_yml'
  | 'config_server'
  | 'configmap'
  | 'env_var'
  | 'vault_ref';

export type Injection =
  | '@Value'
  | '@ConfigurationProperties'
  | 'constructor'
  | 'setter'
  | 'field';

export type UnresolvedWhat =
  | 'url'
  | 'destination'
  | 'dto_type'
  | 'bean_wiring'
  | 'property_value'
  | 'method_body'
  | 'extraction_failed'
  | 'other';

export type CallKind = 'direct' | 'interface' | 'lambda' | 'reflective';

export const CALL_KIND_CODE: Record<CallKind, number> = {
  direct: 0,
  interface: 1,
  lambda: 2,
  reflective: 3,
};

export interface ParamSpec {
  name: string;
  type: string;
  required: boolean;
}

export interface UnresolvedNote {
  what: UnresolvedWhat;
  reason: string;
  expression?: string | null;
}

export interface Meta {
  repo: string;
  repo_url: string;
  commit: string;
  branch: string;
  built_at: string;
  indexer_version: string;
  schema_version: string;
  source_roots: string[];
  package_prefixes: string[];
  config_sources: Array<Record<string, unknown>>;
  transports_supported: Transport[];
  stats: Record<string, number>;
}

export interface Endpoint {
  id: string;
  fingerprint: string;
  transport: Transport;
  verb: Verb | null;
  path_template: string | null;
  path_template_normalized: string | null;
  destination: string | null;
  request_dto_fqn: string | null;
  response_dto_fqn: string | null;
  request_dto_shape: string | null;
  response_dto_shape: string | null;
  path_params: ParamSpec[];
  query_params: ParamSpec[];
  headers: ParamSpec[];
  status_codes: number[];
  logical_name: string | null;
  handler_symbol: string;
  file: string;
  line: number;
  annotations: Record<string, Record<string, unknown>>;
  visibility: 'public' | 'internal' | 'deprecated';
  extractor: string;
  extraction_confidence: number;
}

export interface Fingerprint {
  id: string;
  fingerprint: string;
  transport: Transport;
  path_template: string | null;
  destination: string | null;
  request_dto_shape: string | null;
  response_dto_shape: string | null;
}

export interface ConsumptionManifest {
  dto_shapes: string[];
  dto_fqns: string[];
  path_fragments: string[];
  destinations: string[];
  logical_names: string[];
  property_keys: string[];
  unresolved_placeholders: string[];
  /**
   * Inverted index built by the property resolution pass: a path-like fragment
   * appearing in any resolved property value maps to the property key(s) that
   * produced it. Powers Phase 2 "path_fragment via property value" matching.
   */
  path_fragment_to_property_keys: Record<string, string[]>;
}

export interface SymbolRecord {
  kind: 'symbol';
  id: string;
  fqn: string;
  symbol_kind: SymbolKind;
  file: string;
  line_start: number;
  line_end: number;
  modifiers: string[];
  is_entry_point: boolean;
  entry_point_kind: EntryPointKind | null;
  entry_point_details: Record<string, unknown> | null;
  annotations: Array<Record<string, unknown>>;
  enclosing_class: string | null;
  extractor: string;
  extraction_confidence: number;
}

export interface DtoField {
  name: string;
  type: string;
  nullable: boolean;
  annotations: string[];
}

export interface DtoRecord {
  kind: 'dto';
  fqn: string;
  shape: string;
  fields: DtoField[];
  nested_shapes: Record<string, string>;
  file: string;
  line: number;
  is_generated: boolean;
  extractor: string;
  extraction_confidence: number;
}

export interface InvocationRecord {
  kind: 'invocation';
  id: string;
  transport: Transport;
  enclosing_symbol: string;
  file: string;
  line: number;
  literal_url: string | null;
  path_fragment: string | null;
  destination: string | null;
  request_dto_fqn: string | null;
  response_dto_fqn: string | null;
  client_bean: string | null;
  property_key_ref: string | null;
  logical_name: string | null;
  method_name: string;
  confidence_hints: string[];
  unresolved: UnresolvedNote[];
  annotations: Record<string, unknown>;
  extractor: string;
  extraction_confidence: number;
}

export interface PropertyRecord {
  kind: 'property';
  key: string;
  /** Fully-resolved value after the placeholder substitution pass. */
  value: string;
  raw_value: string;
  env: Env;
  source: string;
  source_type: SourceType;
  line: number;
  branch: string | null;
  is_secret: boolean;
  extractor: 'deterministic';
  extraction_confidence: 1.0;
}

export interface WiringRecord {
  kind: 'wiring';
  bean: string;
  bean_class: string;
  property_key: string;
  injection: Injection;
  file: string;
  line: number;
  defining_class: string | null;
  extractor: string;
  extraction_confidence: number;
}

export interface PropertyBindingRecord {
  kind: 'property_binding';
  prefix: string;
  class_fqn: string;
  fields: Array<{ name: string; type: string; property_subkey: string }>;
  file: string;
  line: number;
  extractor: string;
  extraction_confidence: number;
}

export interface EntryPointRecord {
  kind: 'entry_point';
  symbol: string;
  entry_kind: EntryPointKind;
  details: Record<string, unknown> | null;
  file: string;
  line: number;
}

export interface LogicalNameRefRecord {
  kind: 'logical_name_ref';
  logical_name: string;
  context: 'feign' | 'service_discovery' | 'openapi_operation_id' | 'custom_annotation';
  symbol: string;
  file: string;
  line: number;
  extractor: string;
  extraction_confidence: number;
}

export interface AliasRecord {
  kind: 'alias';
  canonical_key: string;
  aliases: string[];
  confidence: number;
}

export interface UnresolvedRecord {
  kind: 'unresolved';
  what: UnresolvedWhat;
  context: { file: string; line: number; enclosing_symbol: string | null };
  reason: string;
  partial_info: Record<string, unknown>;
}

export type IndexRecord =
  | SymbolRecord
  | DtoRecord
  | InvocationRecord
  | PropertyRecord
  | WiringRecord
  | PropertyBindingRecord
  | EntryPointRecord
  | LogicalNameRefRecord
  | AliasRecord
  | UnresolvedRecord;

// ---------------------------------------------------------------------------
// Query-layer results. These cross the daemon -> webview boundary, so they are
// plain JSON-serializable structures with no methods.
// ---------------------------------------------------------------------------

export type ChangeKind = 'added' | 'removed' | 'modified';

export type DiffReason =
  | 'path_changed'
  | 'verb_changed'
  | 'request_dto_shape_changed'
  | 'response_dto_shape_changed'
  | 'dto_field_added'
  | 'dto_field_removed'
  | 'dto_field_type_changed'
  | 'destination_changed';

export interface FieldDiff {
  field: string;
  before: string | null;
  after: string | null;
}

export interface ChangedEndpoint {
  id: string;
  change_kind: ChangeKind;
  diff_reason: DiffReason[];
  diff_details: FieldDiff[];
  handler_symbol: string | null;
  file: string | null;
  line: number | null;
  transport: Transport;
  verb: Verb | null;
  path_template: string | null;
  destination: string | null;
}

export type MatchSignal =
  | 'dto_shape_match'
  | 'dto_fqn_match'
  | 'destination_match'
  | 'logical_name_match'
  | `property_value:${string}`
  | `wired_bean:${string}`;

export interface ChainNode {
  symbol: string;
  depth: number;
  call_site: { file: string; line: number } | null;
  is_entry_point: boolean;
  entry_kind: EntryPointKind | null;
}

export interface InvocationHit {
  invocation_id: string;
  symbol: string;
  file: string;
  line_range: [number, number];
  matched_via: MatchSignal[];
  confidence: number;
  transport: Transport;
  method_name: string;
  unresolved: UnresolvedNote[];
}

export interface ProducerBlastRadius {
  repo: string;
  /** Downstream: methods the handler calls (handler -> service -> repository). */
  feeder_chains: ChainNode[];
  /** Upstream: internal callers of the handler, if any. */
  caller_chains: ChainNode[];
  total_affected_symbols: number;
}

export interface ConsumerBlastRadius {
  repo: string;
  consumed: boolean;
  phase1_signals: string[];
  direct_invocations: InvocationHit[];
  caller_chains: Array<{ caller: string; callee: string; file: string; line: number; depth: number }>;
  entry_points: Array<{ symbol: string; entry_kind: EntryPointKind; details: Record<string, unknown> | null }>;
  total_affected_symbols: number;
}

export interface BlastRadiusResult {
  changed_endpoint: ChangedEndpoint;
  producer_blast_radius: ProducerBlastRadius;
  consumer_blast_radius: ConsumerBlastRadius[];
  unresolved_across_analysis: UnresolvedRecord[];
}

/** One packed callgraph edge, pre-serialization. */
export interface CallEdge {
  callee_index: number;
  caller_index: number;
  file_id: number;
  line: number;
  call_kind: CallKind;
}
