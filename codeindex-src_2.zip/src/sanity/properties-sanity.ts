/**
 * Sanity harness for config parsing + the property resolution pass.
 *
 * Run with:  npx tsc --outDir out && node out/sanity/properties-sanity.js
 *
 * All fixtures are inline string literals so line-number assertions can be
 * counted by hand. Each source is written as an array of physical lines joined
 * with `\n`, so the 1-based array index + 1 IS the asserted line number.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import { silentLogger } from '../util/logger.js';
import type { Env, PropertyRecord, UnresolvedRecord } from '../types.js';
import {
  envFromFilename,
  parseConfigMap,
  parsePropertiesFile,
  parseYamlProperties,
  relaxedBindingKey,
  type ParseContext,
  type RawProperty,
} from '../extractor/properties/parse.js';
import {
  lookupResolved,
  resolveProperties,
  type ResolutionResult,
} from '../extractor/properties/resolve.js';

/* ------------------------------------------------------------------ */
/* Assertion plumbing                                                  */
/* ------------------------------------------------------------------ */

let failures = 0;
let checks = 0;

function check(name: string, ok: boolean, detail = ''): void {
  checks++;
  if (ok) {
    console.log(`PASS  ${name}`);
  } else {
    failures++;
    console.log(`FAIL  ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

function eq(name: string, actual: unknown, expected: unknown): void {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  check(name, a === e, `expected ${e}, got ${a}`);
}

function contains(name: string, haystack: string, needle: string): void {
  check(name, haystack.includes(needle), `expected to contain "${needle}", got "${haystack}"`);
}

/* ------------------------------------------------------------------ */
/* Fixtures — line numbers are the array index + 1                     */
/* ------------------------------------------------------------------ */

//  1  spring:
//  2    application:
//  3      name: pou-service
//  4
//  5  cdu:
//  6    host: https://cdu.default.internal
//  7
//  8  services:
//  9    cdu:
// 10      base-url: ${cdu.host}/cdu-service
// 11      timeout-ms: 3000
// 12      api-key: ${CDU_API_KEY:-changeme}
// 13
// 14  tiered:
// 15    value: from-default
// 16
// 17  fallbacks:
// 18    colon: ${MISSING_ONE:fallback}
// 19    dashcolon: ${MISSING_TWO:-fallback}
// 20    nested: ${missing.a:${nested.b}}
// 21
// 22  nested:
// 23    b: nested-b-value
// 24
// 25  cyc:
// 26    a: ${cyc.b}
// 27    b: ${cyc.c}
// 28    c: ${cyc.a}
// 29
// 30  envonly:
// 31    url: ${SERVICE_BASE_URL}
const APP_YML = [
  'spring:',
  '  application:',
  '    name: pou-service',
  '',
  'cdu:',
  '  host: https://cdu.default.internal',
  '',
  'services:',
  '  cdu:',
  '    base-url: ${cdu.host}/cdu-service',
  '    timeout-ms: 3000',
  '    api-key: ${CDU_API_KEY:-changeme}',
  '',
  'tiered:',
  '  value: from-default',
  '',
  'fallbacks:',
  '  colon: ${MISSING_ONE:fallback}',
  '  dashcolon: ${MISSING_TWO:-fallback}',
  '  nested: ${missing.a:${nested.b}}',
  '',
  'nested:',
  '  b: nested-b-value',
  '',
  'cyc:',
  '  a: ${cyc.b}',
  '  b: ${cyc.c}',
  '  c: ${cyc.a}',
  '',
  'envonly:',
  '  url: ${SERVICE_BASE_URL}',
].join('\n');

const APP_SHARED_YML = [
  'tiered:',
  '  value: from-shared',
  'shared:',
  '  only: shared-only-value',
].join('\n');

const APP_DEV_YML = [
  'cdu:',
  '  host: https://cdu.dev.internal',
  'tiered:',
  '  value: from-dev',
].join('\n');

const APP_UAT_YML = ['cdu:', '  host: https://cdu.uat.internal'].join('\n');

const APP_PROD_YML = [
  'cdu:',
  '  host: https://cdu.prod.internal',
  'services:',
  '  cdu:',
  '    api-key: ${vault:secret/pou#cdu-api-key}',
].join('\n');

// An 11-hop chain: chain.p00 -> chain.p01 -> ... -> chain.p11.
// Resolving chain.p00 needs 11 nested expansions and must hit the cap of 10.
// Resolving chain.p01 needs exactly 10 and must still succeed.
const CHAIN_YML = [
  'chain:',
  '  p00: ${chain.p01}',
  '  p01: ${chain.p02}',
  '  p02: ${chain.p03}',
  '  p03: ${chain.p04}',
  '  p04: ${chain.p05}',
  '  p05: ${chain.p06}',
  '  p06: ${chain.p07}',
  '  p07: ${chain.p08}',
  '  p08: ${chain.p09}',
  '  p09: ${chain.p10}',
  '  p10: ${chain.p11}',
  '  p11: deep-end',
].join('\n');

const MALFORMED_YML = ['foo: [1, 2', 'bar: {', '  - nope', '\tmixed: tabs'].join('\n');

const CONFIGMAP_YML = [
  'apiVersion: v1',
  'kind: ConfigMap',
  'metadata:',
  '  name: pou-service-config',
  'data:',
  '  SPRING_PROFILES_ACTIVE: "prod"',
  '  SERVER_PORT: "8080"',
  '  SERVICES_CDU_TIMEOUT_MS: "5000"',
  '  POU_ORDERS_TOPIC: "pou-orders"',
].join('\n');

//  1  # CDU service configuration
//  2  cdu.host=https://cdu.default.internal
//  3  cdu.base-url=${cdu.host}/cdu-api
//  4  cdu.timeout-ms=${CDU_TIMEOUT:2500}
//  5  ! bang comment
//  6  cdu.description=first line \
//  7    continued second line
//  8  cdu.api-key=${CDU_SECRET_KEY}
//  9  cdu.colon.form:https://cdu.default.internal/colon-api
const CDU_PROPERTIES = [
  '# CDU service configuration',
  'cdu.host=https://cdu.default.internal',
  'cdu.base-url=${cdu.host}/cdu-api',
  'cdu.timeout-ms=${CDU_TIMEOUT:2500}',
  '! bang comment',
  'cdu.description=first line \\',
  '  continued second line',
  'cdu.api-key=${CDU_SECRET_KEY}',
  'cdu.colon.form:https://cdu.default.internal/colon-api',
].join('\n');

const CDU_PROD_PROPERTIES = ['cdu.host=https://cdu.prod.internal'].join('\n');

/* ------------------------------------------------------------------ */
/* Parse helpers                                                       */
/* ------------------------------------------------------------------ */

function ctx(source: string, env: Env, sourceType: ParseContext['sourceType'] = 'application_yml'): ParseContext {
  return { source, sourceType, env, branch: null };
}

function recordFor(res: ResolutionResult, key: string, env: Env): PropertyRecord | undefined {
  return res.records.find((r) => r.key === key && r.env === env);
}

function unresolvedFor(res: ResolutionResult, key: string): UnresolvedRecord | undefined {
  return res.unresolved.find((u) => u.partial_info.key === key);
}

/* ------------------------------------------------------------------ */
/* main                                                                */
/* ------------------------------------------------------------------ */

function main(): void {
  console.log('== properties sanity ==\n');

  /* ---------------- YAML parse + line numbers ---------------- */

  const yamlRaws: RawProperty[] = [
    ...parseYamlProperties(APP_YML, ctx('application.yml', 'default'), silentLogger),
    ...parseYamlProperties(CHAIN_YML, ctx('chain.yml', 'default'), silentLogger),
    ...parseYamlProperties(APP_SHARED_YML, ctx('application-shared.yml', 'shared'), silentLogger),
    ...parseYamlProperties(APP_DEV_YML, ctx('application-dev.yml', 'dev'), silentLogger),
    ...parseYamlProperties(APP_UAT_YML, ctx('application-uat.yml', 'uat'), silentLogger),
    ...parseYamlProperties(APP_PROD_YML, ctx('application-prod.yml', 'prod'), silentLogger),
  ];

  const byKey = (rs: RawProperty[], k: string, src: string) =>
    rs.find((r) => r.key === k && r.source === src);

  eq('yaml: true line — spring.application.name', byKey(yamlRaws, 'spring.application.name', 'application.yml')?.line, 3);
  eq('yaml: true line — cdu.host', byKey(yamlRaws, 'cdu.host', 'application.yml')?.line, 6);
  eq('yaml: true line — services.cdu.base-url', byKey(yamlRaws, 'services.cdu.base-url', 'application.yml')?.line, 10);
  eq('yaml: true line — services.cdu.api-key', byKey(yamlRaws, 'services.cdu.api-key', 'application.yml')?.line, 12);
  eq('yaml: true line — envonly.url', byKey(yamlRaws, 'envonly.url', 'application.yml')?.line, 31);
  eq('yaml: true line — chain.p11', byKey(yamlRaws, 'chain.p11', 'chain.yml')?.line, 13);
  eq('yaml: raw_value preserved verbatim', byKey(yamlRaws, 'services.cdu.base-url', 'application.yml')?.raw_value, '${cdu.host}/cdu-service');
  eq('yaml: numeric scalar stringified', byKey(yamlRaws, 'services.cdu.timeout-ms', 'application.yml')?.raw_value, '3000');

  const res = resolveProperties(yamlRaws, silentLogger);

  /* ---------------- recursive resolution ---------------- */

  eq(
    'recursive resolution: ${cdu.host}/cdu-service (default)',
    recordFor(res, 'services.cdu.base-url', 'default')?.value,
    'https://cdu.default.internal/cdu-service',
  );

  /* ---------------- per-env override ---------------- */

  eq('per-env: cdu.host default', lookupResolved(res.table, 'cdu.host', 'default'), 'https://cdu.default.internal');
  eq('per-env: cdu.host dev', lookupResolved(res.table, 'cdu.host', 'dev'), 'https://cdu.dev.internal');
  eq('per-env: cdu.host uat', lookupResolved(res.table, 'cdu.host', 'uat'), 'https://cdu.uat.internal');
  eq('per-env: cdu.host prod', lookupResolved(res.table, 'cdu.host', 'prod'), 'https://cdu.prod.internal');

  eq(
    'per-env: services.cdu.base-url resolves per env (dev)',
    lookupResolved(res.table, 'services.cdu.base-url', 'dev'),
    'https://cdu.dev.internal/cdu-service',
  );
  eq(
    'per-env: services.cdu.base-url resolves per env (uat)',
    lookupResolved(res.table, 'services.cdu.base-url', 'uat'),
    'https://cdu.uat.internal/cdu-service',
  );
  eq(
    'per-env: services.cdu.base-url resolves per env (prod)',
    lookupResolved(res.table, 'services.cdu.base-url', 'prod'),
    'https://cdu.prod.internal/cdu-service',
  );

  /* ---------------- precedence: same-env > shared > default ---------------- */

  eq('precedence: tiered.value dev -> same-env', lookupResolved(res.table, 'tiered.value', 'dev'), 'from-dev');
  eq('precedence: tiered.value uat -> shared', lookupResolved(res.table, 'tiered.value', 'uat'), 'from-shared');
  eq('precedence: tiered.value default -> default', lookupResolved(res.table, 'tiered.value', 'default'), 'from-default');

  /* ---------------- both default syntaxes + nested default ---------------- */

  eq('default syntax ${MISSING:fallback}', recordFor(res, 'fallbacks.colon', 'default')?.value, 'fallback');
  eq('default syntax ${MISSING:-fallback}', recordFor(res, 'fallbacks.dashcolon', 'default')?.value, 'fallback');
  eq('nested default ${a:${b}}', recordFor(res, 'fallbacks.nested', 'default')?.value, 'nested-b-value');

  /* ---------------- cycle ---------------- */

  eq('cycle: cyc.a keeps its placeholder', recordFor(res, 'cyc.a', 'default')?.value, '${cyc.b}');
  eq('cycle: cyc.b keeps its placeholder', recordFor(res, 'cyc.b', 'default')?.value, '${cyc.c}');
  eq('cycle: cyc.c keeps its placeholder', recordFor(res, 'cyc.c', 'default')?.value, '${cyc.a}');
  const cycUn = unresolvedFor(res, 'cyc.a');
  check('cycle: cyc.a emits unresolved', cycUn !== undefined);
  contains('cycle: reason names the cycle path', cycUn?.reason ?? '', 'cyc.a -> cyc.b -> cyc.c -> cyc.a');

  /* ---------------- recursion cap ---------------- */

  eq('cap: chain.p00 keeps its placeholder', recordFor(res, 'chain.p00', 'default')?.value, '${chain.p01}');
  const capUn = unresolvedFor(res, 'chain.p00');
  check('cap: chain.p00 emits unresolved', capUn !== undefined);
  contains('cap: reason names the recursion cap', capUn?.reason ?? '', 'recursion cap of 10');
  eq('cap: chain.p01 (10 deep) still resolves', recordFor(res, 'chain.p01', 'default')?.value, 'deep-end');

  /* ---------------- vault ---------------- */

  const vaultRec = recordFor(res, 'services.cdu.api-key', 'prod');
  eq('vault: value kept verbatim', vaultRec?.value, '${vault:secret/pou#cdu-api-key}');
  eq('vault: is_secret set', vaultRec?.is_secret, true);
  const vaultUn = res.unresolved.find(
    (u) => u.partial_info.key === 'services.cdu.api-key' && u.partial_info.env === 'prod',
  );
  check('vault: emits unresolved', vaultUn !== undefined);
  contains('vault: reason is vault-specific', vaultUn?.reason ?? '', 'vault reference');

  /* ---------------- env vars ---------------- */

  const envRec = recordFor(res, 'envonly.url', 'default');
  eq('env var: placeholder kept verbatim', envRec?.value, '${SERVICE_BASE_URL}');
  const envUn = unresolvedFor(res, 'envonly.url');
  contains('env var: reason', envUn?.reason ?? '', 'env var not present at index time');
  eq(
    'env var: placeholder is still a joinable fragment',
    res.pathFragmentIndex['${SERVICE_BASE_URL}'],
    ['envonly.url'],
  );
  eq(
    'env var with default is resolvable deterministically',
    recordFor(res, 'services.cdu.api-key', 'default')?.value,
    'changeme',
  );

  /* ---------------- is_secret heuristic ---------------- */

  eq('is_secret: services.cdu.api-key', recordFor(res, 'services.cdu.api-key', 'default')?.is_secret, true);
  eq('is_secret: cdu.host is not secret', recordFor(res, 'cdu.host', 'default')?.is_secret, false);

  /* ---------------- fragment index ---------------- */

  eq('fragment index: /cdu-service', res.pathFragmentIndex['/cdu-service'], ['services.cdu.base-url']);
  eq(
    'fragment index: unresolved ${cyc.b} indexed as a join token',
    res.pathFragmentIndex['${cyc.b}'],
    ['cyc.a'],
  );
  const fragKeys = Object.keys(res.pathFragmentIndex);
  eq('fragment index: keys are sorted', fragKeys, [...fragKeys].sort());

  /* ---------------- cumulative fragments ---------------- */

  const cumulative = resolveProperties(
    parseYamlProperties(
      ['svc:', '  url: https://h/cdu-service/v1'].join('\n'),
      ctx('cum.yml', 'default'),
      silentLogger,
    ),
    silentLogger,
  );
  eq('fragment index: cumulative /cdu-service', cumulative.pathFragmentIndex['/cdu-service'], ['svc.url']);
  eq('fragment index: cumulative /cdu-service/v1', cumulative.pathFragmentIndex['/cdu-service/v1'], ['svc.url']);

  /* ---------------- ConfigMap + relaxed binding ---------------- */

  eq('relaxedBindingKey: SERVICES_CDU_TIMEOUT_MS', relaxedBindingKey('SERVICES_CDU_TIMEOUT_MS'), 'services.cdu.timeout-ms');
  eq('relaxedBindingKey: SPRING_PROFILES_ACTIVE', relaxedBindingKey('SPRING_PROFILES_ACTIVE'), 'spring.profiles.active');
  eq('relaxedBindingKey: SERVER_PORT', relaxedBindingKey('SERVER_PORT'), 'server.port');
  eq('relaxedBindingKey: camelCase final segment', relaxedBindingKey('services.cdu.timeoutMs'), 'services.cdu.timeout-ms');

  const cmRaws = parseConfigMap(CONFIGMAP_YML, ctx('pou-configmap.yaml', 'default', 'configmap'), silentLogger);
  const cmKeys = cmRaws.map((r) => r.key);
  check('configmap: canonical key emitted', cmKeys.includes('SERVICES_CDU_TIMEOUT_MS'));
  check('configmap: relaxed alias emitted', cmKeys.includes('services.cdu.timeout-ms'));
  eq(
    'configmap: alias flagged is_alias',
    cmRaws.find((r) => r.key === 'services.cdu.timeout-ms')?.is_alias,
    true,
  );
  eq(
    'configmap: canonical not flagged is_alias',
    cmRaws.find((r) => r.key === 'SERVICES_CDU_TIMEOUT_MS')?.is_alias,
    false,
  );
  eq(
    'configmap: only the data: block is read (no metadata.name)',
    cmKeys.filter((k) => k.includes('metadata')).length,
    0,
  );
  eq('configmap: value carried onto the alias', cmRaws.find((r) => r.key === 'services.cdu.timeout-ms')?.raw_value, '5000');

  /* ---------------- .properties parity ---------------- */

  const propRaws: RawProperty[] = [
    ...parsePropertiesFile(CDU_PROPERTIES, ctx('application.properties', 'default'), silentLogger),
    ...parsePropertiesFile(CDU_PROD_PROPERTIES, ctx('application-prod.properties', 'prod'), silentLogger),
  ];
  const propRes = resolveProperties(propRaws, silentLogger);

  eq('properties: comment lines ignored', propRaws.filter((r) => r.key.startsWith('#') || r.key.startsWith('!')).length, 0);
  eq('properties: key count', propRaws.filter((r) => r.source === 'application.properties').length, 6);
  eq('properties: true line — cdu.host', byKey(propRaws, 'cdu.host', 'application.properties')?.line, 2);
  eq('properties: true line — cdu.base-url', byKey(propRaws, 'cdu.base-url', 'application.properties')?.line, 3);
  eq('properties: true line — cdu.description (continuation start)', byKey(propRaws, 'cdu.description', 'application.properties')?.line, 6);
  eq('properties: true line — cdu.api-key', byKey(propRaws, 'cdu.api-key', 'application.properties')?.line, 8);
  eq('properties: true line — cdu.colon.form', byKey(propRaws, 'cdu.colon.form', 'application.properties')?.line, 9);

  eq(
    'properties: backslash continuation joins into one logical value',
    recordFor(propRes, 'cdu.description', 'default')?.value,
    'first line continued second line',
  );
  eq(
    'properties: recursive resolution a=${b}/x',
    recordFor(propRes, 'cdu.base-url', 'default')?.value,
    'https://cdu.default.internal/cdu-api',
  );
  eq('properties: ${VAR:default} inline default', recordFor(propRes, 'cdu.timeout-ms', 'default')?.value, '2500');
  eq(
    'properties: colon separator form',
    recordFor(propRes, 'cdu.colon.form', 'default')?.value,
    'https://cdu.default.internal/colon-api',
  );
  eq('properties: per-env override cdu.host prod', lookupResolved(propRes.table, 'cdu.host', 'prod'), 'https://cdu.prod.internal');
  eq(
    'properties: per-env override propagates into cdu.base-url prod',
    lookupResolved(propRes.table, 'cdu.base-url', 'prod'),
    'https://cdu.prod.internal/cdu-api',
  );
  eq('properties: is_secret heuristic on cdu.api-key', recordFor(propRes, 'cdu.api-key', 'default')?.is_secret, true);
  eq('properties: unresolved env var kept verbatim', recordFor(propRes, 'cdu.api-key', 'default')?.value, '${CDU_SECRET_KEY}');
  eq('properties: fragment index /cdu-api', propRes.pathFragmentIndex['/cdu-api'], ['cdu.base-url']);

  /* ---------------- cross-format join ---------------- */

  const mixedRes = resolveProperties([...yamlRaws, ...propRaws], silentLogger);
  eq(
    'cross-format: .properties key resolves in the combined table',
    lookupResolved(mixedRes.table, 'cdu.base-url', 'default'),
    'https://cdu.default.internal/cdu-api',
  );
  eq(
    'cross-format: .yml key resolves in the combined table',
    lookupResolved(mixedRes.table, 'services.cdu.base-url', 'default'),
    'https://cdu.default.internal/cdu-service',
  );
  eq(
    'cross-format: both fragments present in one index',
    [mixedRes.pathFragmentIndex['/cdu-api'], mixedRes.pathFragmentIndex['/cdu-service']],
    [['cdu.base-url'], ['services.cdu.base-url']],
  );
  check(
    'cross-format: shadowing logged when .properties and .yml collide',
    (() => {
      const msgs: string[] = [];
      const collide = [
        ...parseYamlProperties('cdu:\n  host: https://from-yaml', ctx('a.yml', 'default'), silentLogger),
        ...parsePropertiesFile('cdu.host=https://from-properties', ctx('b.properties', 'default'), silentLogger),
      ];
      resolveProperties(collide, { log: (_s, m) => msgs.push(m) });
      return msgs.some((m) => m.includes('shadowed property') && m.includes('cdu.host'));
    })(),
  );

  /* ---------------- envFromFilename ---------------- */

  eq('env: application.yml', envFromFilename('src/main/resources/application.yml'), 'default');
  eq('env: application.properties', envFromFilename('src/main/resources/application.properties'), 'default');
  eq('env: application-dev.yml', envFromFilename('application-dev.yml'), 'dev');
  eq('env: application-dev.properties', envFromFilename('application-dev.properties'), 'dev');
  eq('env: application-uat.properties', envFromFilename('application-uat.properties'), 'uat');
  eq('env: application-prod.properties', envFromFilename('application-prod.properties'), 'prod');
  eq('env: application-prod.yaml', envFromFilename('application-prod.yaml'), 'prod');
  eq('env: application-shared.yml', envFromFilename('application-shared.yml'), 'shared');
  eq('env: config-server pou-uat.yml', envFromFilename('pou-uat.yml', { isConfigServer: true }), 'uat');
  eq('env: config-server application.yml -> shared', envFromFilename('application.yml', { isConfigServer: true }), 'shared');
  eq('env: unknown profile -> default', envFromFilename('application-banana.yml'), 'default');

  /* ---------------- malformed YAML fails open ---------------- */

  let threw = false;
  let malformed: RawProperty[] = [];
  try {
    malformed = parseYamlProperties(MALFORMED_YML, ctx('broken.yml', 'default'), silentLogger);
  } catch {
    threw = true;
  }
  check('malformed YAML does not throw', !threw);
  eq('malformed YAML yields zero properties', malformed.length, 0);

  let logged = false;
  parseYamlProperties(MALFORMED_YML, ctx('broken.yml', 'default'), {
    log: (stage) => {
      if (stage === 'YAML') {
        logged = true;
      }
    },
  });
  check('malformed YAML logs at [YAML]', logged);

  /* ---------------- determinism ---------------- */

  const a = resolveProperties([...yamlRaws, ...propRaws], silentLogger);
  const b = resolveProperties([...yamlRaws, ...propRaws], silentLogger);
  check('determinism: records byte-identical', JSON.stringify(a.records) === JSON.stringify(b.records));
  check(
    'determinism: fragment index byte-identical',
    JSON.stringify(a.pathFragmentIndex) === JSON.stringify(b.pathFragmentIndex),
  );
  check(
    'determinism: unresolved byte-identical',
    JSON.stringify(a.unresolved) === JSON.stringify(b.unresolved),
  );

  /* ---------------- fixture repo end-to-end (optional) ---------------- */

  const repoRoot = path.resolve(process.argv[2] ?? process.cwd());
  const pouDir = path.join(repoRoot, 'fixtures/pou/src/main/resources');
  const cduDir = path.join(repoRoot, 'fixtures/cdu/src/main/resources');

  console.log('\n== fixture end-to-end ==');
  const fixtureRaws: RawProperty[] = [];
  let sawFixture = false;

  for (const [dir, label] of [
    [pouDir, 'pou'],
    [cduDir, 'cdu'],
  ] as Array<[string, string]>) {
    let files: string[];
    try {
      files = fs.readdirSync(dir).sort();
    } catch {
      console.log(`SKIP  fixtures/${label}/src/main/resources does not exist yet`);
      continue;
    }
    for (const f of files) {
      if (!/^application.*\.(ya?ml|properties)$/i.test(f)) {
        continue;
      }
      sawFixture = true;
      const text = fs.readFileSync(path.join(dir, f), 'utf8');
      const c = ctx(`fixtures/${label}/src/main/resources/${f}`, envFromFilename(f));
      fixtureRaws.push(
        ...(/\.properties$/i.test(f)
          ? parsePropertiesFile(text, c, silentLogger)
          : parseYamlProperties(text, c, silentLogger)),
      );
    }
  }

  if (!sawFixture) {
    console.log('SKIP  no fixture config files found');
  } else {
    const fres = resolveProperties(fixtureRaws, silentLogger);
    const reportKeys = [
      'services.cdu.base-url',
      'services.cdu.api-key',
      'cdu.base-url',
      'cdu.events.topic',
      'cdu.instance.region',
      'cdu.events.description',
    ];
    for (const key of reportKeys) {
      const anywhere = (['default', 'dev', 'uat', 'prod'] as Env[]).map(
        (e) => [e, lookupResolved(fres.table, key, e)] as const,
      );
      if (anywhere.every(([, v]) => v === null)) {
        continue;
      }
      for (const [e, v] of anywhere) {
        console.log(`      ${key} [${e}] = ${v ?? '(undefined)'}`);
      }
    }
    console.log(`      fixture records: ${fres.records.length}, unresolved: ${fres.unresolved.length}`);
    for (const u of fres.unresolved) {
      console.log(`      unresolved ${String(u.partial_info.key)} [${String(u.partial_info.env)}]: ${u.reason}`);
    }
    check('fixtures: services.cdu.base-url resolves for prod', typeof lookupResolved(fres.table, 'services.cdu.base-url', 'prod') === 'string');
  }

  console.log(`\n${checks - failures}/${checks} checks passed`);
  if (failures > 0) {
    console.log(`${failures} FAILURE(S)`);
    process.exitCode = 1;
  }
}

main();
