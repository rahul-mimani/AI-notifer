/**
 * Sanity harness for the id + hashing primitives.
 *
 * Runs with plain Node (no vscode): `npx tsc --outDir out && node out/sanity/hash-sanity.js`
 * Prints PASS/FAIL per assertion and sets process.exitCode = 1 on any failure.
 */
import {
  canonicalJson,
  endpointFingerprint,
  endpointId,
  invocationId,
  normalizeMethodSignature,
  sha256Hex,
  symbolId,
} from '../extractor/ids.js';
import {
  collapsePathParams,
  joinPathTemplates,
  normalizePathTemplate,
  pathFragments,
} from '../extractor/paths.js';
import { computeDtoShapes, type DtoInput } from '../extractor/shapes.js';

let failures = 0;
let total = 0;

function check(name: string, ok: boolean, detail?: string): void {
  total++;
  if (ok) {
    console.log(`PASS  ${name}`);
  } else {
    failures++;
    process.exitCode = 1;
    console.log(`FAIL  ${name}${detail !== undefined ? ` — ${detail}` : ''}`);
  }
}

function eq(name: string, actual: unknown, expected: unknown): void {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  check(name, a === e, `expected ${e}, got ${a}`);
}

function ne(name: string, a: unknown, b: unknown): void {
  check(name, JSON.stringify(a) !== JSON.stringify(b), `both were ${JSON.stringify(a)}`);
}

/* ------------------------------------------------------------------ */
function pathTests(): void {
  console.log('\n-- paths --');
  eq('host stripped', normalizePathTemplate('https://api.example.com/v1/users'), '/v1/users');
  eq(
    'host+port stripped',
    normalizePathTemplate('http://localhost:8080/v1/users/{id}'),
    '/v1/users/{id}',
  );
  eq('trailing slash stripped', normalizePathTemplate('/v1/users/'), '/v1/users');
  eq('multiple trailing slashes stripped', normalizePathTemplate('/v1/users///'), '/v1/users');
  eq('root stays root', normalizePathTemplate('/'), '/');
  eq('double slash collapsed', normalizePathTemplate('/v1//users///{id}'), '/v1/users/{id}');
  eq('leading slash added', normalizePathTemplate('v1/users'), '/v1/users');
  eq('empty string -> root', normalizePathTemplate(''), '/');
  eq('null -> root', normalizePathTemplate(null), '/');
  eq('undefined -> root', normalizePathTemplate(undefined), '/');
  eq('query string dropped', normalizePathTemplate('/v1/users?active=true'), '/v1/users');
  eq('param names preserved', normalizePathTemplate('/v1/users/{userId}'), '/v1/users/{userId}');

  eq('join class+method', joinPathTemplates('/api/v1', '/users/{id}'), '/api/v1/users/{id}');
  eq('join without slashes', joinPathTemplates('api/v1', 'users'), '/api/v1/users');
  eq('join no double slash', joinPathTemplates('/api/v1/', '/users/'), '/api/v1/users');
  eq('join empty class level', joinPathTemplates('', '/users'), '/users');
  eq('join empty method level', joinPathTemplates('/api', ''), '/api');
  eq('join both empty', joinPathTemplates('', ''), '/');
  eq('join null both', joinPathTemplates(null, null), '/');
  eq('join class root', joinPathTemplates('/', '/users'), '/users');
  check(
    'join never contains double slash',
    !joinPathTemplates('/api//', '//users//{id}//').includes('//'),
    joinPathTemplates('/api//', '//users//{id}//'),
  );

  eq('collapse simple param', collapsePathParams('/v1/users/{id}'), '/v1/users/{}');
  eq('collapse param rename-stable', collapsePathParams('/v1/users/{userId}'), '/v1/users/{}');
  eq('collapse regex-constrained var', collapsePathParams('/v1/users/{id:[0-9]+}'), '/v1/users/{}');
  eq(
    'collapse regex with brace quantifier',
    collapsePathParams('/v1/code/{code:[a-z]{2,4}}'),
    '/v1/code/{}',
  );
  eq('collapse multiple params', collapsePathParams('/a/{x}/b/{y}'), '/a/{}/b/{}');
  eq('wildcards preserved', collapsePathParams('/v1/files/**'), '/v1/files/**');
  eq('single wildcard preserved', collapsePathParams('/v1/*/files'), '/v1/*/files');
  eq('collapse normalizes host too', collapsePathParams('https://h/v1/{id}/'), '/v1/{}');

  eq('path fragments', pathFragments('/api/v1/users/{id}/orders'), ['api', 'v1', 'users', 'orders']);
  eq('path fragments drop wildcards', pathFragments('/api/*/files/**'), ['api', 'files']);
  eq('path fragments of root', pathFragments('/'), []);
}

/* ------------------------------------------------------------------ */
const FQN_A = 'com.acme.dto.Address';
const FQN_U = 'com.acme.dto.User';

function baseUser(): DtoInput {
  return {
    fqn: FQN_U,
    fields: [
      { name: 'id', type: 'long', nullable: false },
      { name: 'name', type: 'String', nullable: true },
      { name: 'address', type: FQN_A, nullable: true },
    ],
  };
}

function address(): DtoInput {
  return {
    fqn: FQN_A,
    fields: [
      { name: 'street', type: 'String', nullable: true },
      { name: 'zip', type: 'String', nullable: true },
    ],
  };
}

function shapeOf(dtos: DtoInput[], fqn: string): string {
  const r = computeDtoShapes(dtos);
  const v = r.get(fqn);
  if (v === undefined) {
    throw new Error(`missing shape for ${fqn}`);
  }
  return v.shape;
}

function shapeTests(): void {
  console.log('\n-- dto shapes --');

  const normal = shapeOf([baseUser(), address()], FQN_U);

  // Field source order must not matter.
  const reordered: DtoInput = {
    fqn: FQN_U,
    fields: [
      { name: 'address', type: FQN_A, nullable: true },
      { name: 'name', type: 'String', nullable: true },
      { name: 'id', type: 'long', nullable: false },
    ],
  };
  eq('field order independence', shapeOf([reordered, address()], FQN_U), normal);
  eq('dto input order independence', shapeOf([address(), baseUser()], FQN_U), normal);

  // Type change.
  const typeChanged = baseUser();
  typeChanged.fields[0] = { name: 'id', type: 'String', nullable: false };
  ne('field type change alters hash', shapeOf([typeChanged, address()], FQN_U), normal);

  // Rename.
  const renamed = baseUser();
  renamed.fields[1] = { name: 'fullName', type: 'String', nullable: true };
  ne('field rename alters hash', shapeOf([renamed, address()], FQN_U), normal);

  // Nullability change.
  const nullChanged = baseUser();
  nullChanged.fields[1] = { name: 'name', type: 'String', nullable: false };
  ne('nullability change alters hash', shapeOf([nullChanged, address()], FQN_U), normal);

  // Nested change propagates.
  const addr2 = address();
  addr2.fields.push({ name: 'country', type: 'String', nullable: true });
  ne('nested dto change propagates to parent', shapeOf([baseUser(), addr2], FQN_U), normal);

  // nested_shapes wiring.
  const res = computeDtoShapes([baseUser(), address()]);
  eq(
    'nested_shapes maps field to nested shape',
    res.get(FQN_U)!.nested_shapes['address'],
    res.get(FQN_A)!.shape,
  );
  check(
    'nested_shapes omits non-dto fields',
    res.get(FQN_U)!.nested_shapes['name'] === undefined,
  );

  // Inheritance.
  const base: DtoInput = {
    fqn: 'com.acme.dto.Base',
    fields: [{ name: 'createdAt', type: 'String', nullable: true }],
  };
  const child: DtoInput = {
    fqn: 'com.acme.dto.Child',
    superFqn: 'com.acme.dto.Base',
    fields: [{ name: 'id', type: 'long', nullable: false }],
  };
  const flat: DtoInput = {
    fqn: 'com.acme.dto.Child',
    fields: [
      { name: 'id', type: 'long', nullable: false },
      { name: 'createdAt', type: 'String', nullable: true },
    ],
  };
  eq(
    'inherited fields included',
    shapeOf([base, child], 'com.acme.dto.Child'),
    shapeOf([flat], 'com.acme.dto.Child'),
  );
  ne(
    'inherited fields actually contribute',
    shapeOf([base, child], 'com.acme.dto.Child'),
    shapeOf([{ fqn: 'com.acme.dto.Child', fields: child.fields }], 'com.acme.dto.Child'),
  );

  // Subclass override wins.
  const overrideChild: DtoInput = {
    fqn: 'com.acme.dto.Child',
    superFqn: 'com.acme.dto.Base',
    fields: [{ name: 'createdAt', type: 'long', nullable: false }],
  };
  eq(
    'subclass overrides inherited field',
    shapeOf([base, overrideChild], 'com.acme.dto.Child'),
    shapeOf(
      [{ fqn: 'com.acme.dto.Child', fields: [{ name: 'createdAt', type: 'long', nullable: false }] }],
      'com.acme.dto.Child',
    ),
  );

  // transient / static / synthetic exclusion.
  const noisy: DtoInput = {
    fqn: FQN_U,
    fields: [
      { name: 'id', type: 'long', nullable: false },
      { name: 'name', type: 'String', nullable: true },
      { name: 'address', type: FQN_A, nullable: true },
      { name: 'cache', type: 'String', nullable: true, modifiers: ['private', 'transient'] },
      { name: 'LOG', type: 'String', nullable: false, modifiers: ['private', 'static', 'final'] },
      { name: 'this$0', type: 'Object', nullable: false },
      { name: '$jacocoData', type: 'boolean[]', nullable: false },
      { name: 'serialVersionUID', type: 'long', nullable: false },
    ],
  };
  eq('transient/static/synthetic excluded', shapeOf([noisy, address()], FQN_U), normal);

  // Container substitution.
  const withList: DtoInput = {
    fqn: 'com.acme.dto.Order',
    fields: [{ name: 'addrs', type: `List<${FQN_A}>`, nullable: true }],
  };
  const listRes = computeDtoShapes([withList, address()]);
  eq(
    'List<Foo> records nested shape',
    listRes.get('com.acme.dto.Order')!.nested_shapes['addrs'],
    listRes.get(FQN_A)!.shape,
  );
  const addrChanged = address();
  addrChanged.fields.push({ name: 'country', type: 'String', nullable: true });
  ne(
    'List<Foo> substitution propagates nested change',
    computeDtoShapes([withList, addrChanged]).get('com.acme.dto.Order')!.shape,
    listRes.get('com.acme.dto.Order')!.shape,
  );
  ne(
    'List<Foo> differs from bare Foo',
    listRes.get('com.acme.dto.Order')!.shape,
    computeDtoShapes([
      { fqn: 'com.acme.dto.Order', fields: [{ name: 'addrs', type: FQN_A, nullable: true }] },
      address(),
    ]).get('com.acme.dto.Order')!.shape,
  );
  // Map / array / Optional containers resolve without throwing.
  const containers: DtoInput = {
    fqn: 'com.acme.dto.Bag',
    fields: [
      { name: 'byKey', type: `Map<String,${FQN_A}>`, nullable: true },
      { name: 'arr', type: `${FQN_A}[]`, nullable: true },
      { name: 'maybe', type: `Optional<${FQN_A}>`, nullable: true },
      { name: 'external', type: 'com.external.Thing', nullable: true },
    ],
  };
  const bag = computeDtoShapes([containers, address()]).get('com.acme.dto.Bag')!;
  check('Map/array/Optional resolve to nested shape', ['byKey', 'arr', 'maybe'].every(
    (f) => bag.nested_shapes[f] === computeDtoShapes([containers, address()]).get(FQN_A)!.shape,
  ));
  check('unknown type is not a nested shape', bag.nested_shapes['external'] === undefined);

  // Cycles.
  const a: DtoInput = {
    fqn: 'com.acme.dto.A',
    fields: [
      { name: 'b', type: 'com.acme.dto.B', nullable: true },
      { name: 'label', type: 'String', nullable: true },
    ],
  };
  const b: DtoInput = {
    fqn: 'com.acme.dto.B',
    fields: [
      { name: 'a', type: 'com.acme.dto.A', nullable: true },
      { name: 'count', type: 'int', nullable: false },
    ],
  };
  const forward = computeDtoShapes([a, b]);
  const backward = computeDtoShapes([b, a]);
  check('A<->B cycle terminates', forward.size === 2 && backward.size === 2);
  eq('cycle shape order-independent (A)', backward.get('com.acme.dto.A')!.shape, forward.get('com.acme.dto.A')!.shape);
  eq('cycle shape order-independent (B)', backward.get('com.acme.dto.B')!.shape, forward.get('com.acme.dto.B')!.shape);
  ne('cycle A and B have distinct shapes', forward.get('com.acme.dto.A')!.shape, forward.get('com.acme.dto.B')!.shape);
  // A three-node cycle plus a self-reference must also terminate.
  const selfRef: DtoInput = {
    fqn: 'com.acme.dto.Node',
    fields: [
      { name: 'parent', type: 'com.acme.dto.Node', nullable: true },
      { name: 'children', type: 'List<com.acme.dto.Node>', nullable: true },
    ],
  };
  check('self-referential dto terminates', computeDtoShapes([selfRef]).get('com.acme.dto.Node') !== undefined);
  ne(
    'cycle change still propagates',
    computeDtoShapes([{ ...a, fields: [...a.fields, { name: 'extra', type: 'String', nullable: true }] }, b]).get(
      'com.acme.dto.B',
    )!.shape,
    forward.get('com.acme.dto.B')!.shape,
  );
}

/* ------------------------------------------------------------------ */
function idTests(): void {
  console.log('\n-- ids --');

  eq('sha256 known vector', sha256Hex('abc'),
    'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
  check('sha256 lowercase hex 64 chars', /^[0-9a-f]{64}$/.test(sha256Hex('anything')));

  eq('class symbol id', symbolId('svc-a', 'com.acme.UserController'), 'svc-a:com.acme.UserController');
  check(
    'method symbol id has # separator',
    symbolId('svc-a', 'com.acme.UserController', 'getUser(String)').startsWith(
      'svc-a:com.acme.UserController#',
    ),
    symbolId('svc-a', 'com.acme.UserController', 'getUser(String)'),
  );
  ne(
    'method vs class symbol id differ',
    symbolId('svc-a', 'com.acme.UserController'),
    symbolId('svc-a', 'com.acme.UserController', 'getUser(String)'),
  );

  eq(
    'source-ish signature -> descriptor',
    normalizeMethodSignature('getUser(String, long)'),
    'getUser(Ljava/lang/String;J)',
  );
  eq(
    'generics erased',
    normalizeMethodSignature('save(List<Foo>, Map<String, Bar>)'),
    'save(Ljava/util/List;Ljava/util/Map;)',
  );
  eq(
    'descriptor input preserved',
    normalizeMethodSignature('(Ljava/lang/String;)V'),
    '(Ljava/lang/String;)V',
  );
  eq(
    'named descriptor input preserved',
    normalizeMethodSignature('getUser(Ljava/lang/String;)V'),
    'getUser(Ljava/lang/String;)V',
  );
  eq('no-arg signature', normalizeMethodSignature('ping()'), 'ping()');
  eq('array params', normalizeMethodSignature('run(String[], int)'), 'run([Ljava/lang/String;I)');
  eq('param names dropped', normalizeMethodSignature('getUser(String id, long ts)'),
    'getUser(Ljava/lang/String;J)');
  eq(
    'source and descriptor forms agree',
    normalizeMethodSignature('getUser(String)'),
    normalizeMethodSignature('getUser(Ljava/lang/String;)'),
  );
  eq('unparseable input tolerated', normalizeMethodSignature('  weird   thing  '), 'weirdthing');
  eq('empty signature tolerated', normalizeMethodSignature(''), '');
  eq('null signature tolerated', normalizeMethodSignature(null), '');
  eq(
    'signature normalization is stable',
    normalizeMethodSignature('getUser( String , long )'),
    normalizeMethodSignature('getUser(String,long)'),
  );

  const handler = symbolId('svc-a', 'com.acme.UserController', 'getUser(String)');
  const id1 = endpointId('rest', 'GET', '/api/v1/users/{id}', handler);
  const id2 = endpointId('rest', 'GET', '/api/v1/users/{id}', handler);
  eq('endpointId stable across invocations', id2, id1);
  check('endpointId is sha256 hex', /^[0-9a-f]{64}$/.test(id1));
  ne('endpointId sensitive to verb', endpointId('rest', 'POST', '/api/v1/users/{id}', handler), id1);
  ne('endpointId sensitive to path', endpointId('rest', 'GET', '/api/v1/users', handler), id1);
  eq('endpointId null handling', endpointId('rest', null, null, null), endpointId('rest', '', '', ''));

  const shapeReq = sha256Hex('req');
  const shapeRes = sha256Hex('res');
  const fp = endpointFingerprint('rest', 'GET', '/api/v1/users/{id}', shapeReq, shapeRes, null);
  eq(
    'fingerprint stable across invocations',
    endpointFingerprint('rest', 'GET', '/api/v1/users/{id}', shapeReq, shapeRes, null),
    fp,
  );
  eq(
    'fingerprint ignores path-param rename',
    endpointFingerprint('rest', 'GET', '/api/v1/users/{userId}', shapeReq, shapeRes, null),
    fp,
  );
  eq(
    'fingerprint ignores regex constraint on param',
    endpointFingerprint('rest', 'GET', '/api/v1/users/{id:[0-9]+}', shapeReq, shapeRes, null),
    fp,
  );
  eq(
    'fingerprint accepts pre-collapsed path (idempotent)',
    endpointFingerprint('rest', 'GET', '/api/v1/users/{}', shapeReq, shapeRes, null),
    fp,
  );
  eq(
    'fingerprint ignores trailing slash',
    endpointFingerprint('rest', 'GET', '/api/v1/users/{id}/', shapeReq, shapeRes, null),
    fp,
  );
  ne(
    'fingerprint sensitive to path structure change',
    endpointFingerprint('rest', 'GET', '/api/v1/users/{id}/profile', shapeReq, shapeRes, null),
    fp,
  );
  ne(
    'fingerprint sensitive to literal-vs-param change',
    endpointFingerprint('rest', 'GET', '/api/v1/users/all', shapeReq, shapeRes, null),
    fp,
  );
  ne(
    'fingerprint sensitive to request shape',
    endpointFingerprint('rest', 'GET', '/api/v1/users/{id}', sha256Hex('req2'), shapeRes, null),
    fp,
  );
  ne(
    'fingerprint sensitive to response shape',
    endpointFingerprint('rest', 'GET', '/api/v1/users/{id}', shapeReq, sha256Hex('res2'), null),
    fp,
  );
  ne(
    'fingerprint sensitive to destination',
    endpointFingerprint('kafka', null, null, shapeReq, shapeRes, 'topic.a'),
    endpointFingerprint('kafka', null, null, shapeReq, shapeRes, 'topic.b'),
  );

  const inv = invocationId('src/main/java/A.java', 42, 'svc:com.acme.A#call()', 'rest');
  eq('invocationId stable', invocationId('src/main/java/A.java', 42, 'svc:com.acme.A#call()', 'rest'), inv);
  ne('invocationId sensitive to line', invocationId('src/main/java/A.java', 43, 'svc:com.acme.A#call()', 'rest'), inv);
  ne('invocationId sensitive to file', invocationId('src/main/java/B.java', 42, 'svc:com.acme.A#call()', 'rest'), inv);

  console.log('\n-- canonicalJson --');
  eq(
    'key order independence',
    canonicalJson({ b: 1, a: 2 }),
    canonicalJson({ a: 2, b: 1 }),
  );
  eq(
    'nested key order independence',
    canonicalJson({ x: { d: 1, c: [{ z: 1, y: 2 }] } }),
    canonicalJson({ x: { c: [{ y: 2, z: 1 }], d: 1 } }),
  );
  eq('sorted output', canonicalJson({ b: 1, a: 2 }), '{"a":2,"b":1}');
  ne('array order preserved', canonicalJson([1, 2]), canonicalJson([2, 1]));
  eq('null handled', canonicalJson({ a: null }), '{"a":null}');
  eq('primitives handled', canonicalJson('x'), '"x"');
}

function main(): void {
  pathTests();
  shapeTests();
  idTests();
  console.log(`\n${total - failures}/${total} assertions passed`);
  if (failures > 0) {
    console.log(`${failures} FAILED`);
    process.exitCode = 1;
  }
}

main();
