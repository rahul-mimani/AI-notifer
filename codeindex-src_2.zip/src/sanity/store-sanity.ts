/**
 * Store-layer sanity run. Builds a synthetic bundle, round-trips it, and proves
 * the four properties the layer promises: round-trip fidelity, correct reverse
 * adjacency, byte-level determinism, and fail-open behaviour on corruption.
 *
 * Run:  node out/sanity/store-sanity.js
 */
import * as fs from 'node:fs';
import * as path from 'node:path';
import {
  AliasRecord,
  CallEdge,
  ConsumptionManifest,
  DtoRecord,
  Endpoint,
  EntryPointRecord,
  Fingerprint,
  IndexRecord,
  InvocationRecord,
  LogicalNameRefRecord,
  Meta,
  PropertyBindingRecord,
  PropertyRecord,
  SymbolRecord,
  UnresolvedRecord,
  WiringRecord,
} from '../types.js';
import { consoleLogger, silentLogger, Logger } from '../util/logger.js';
import { CallgraphReader, bundlePaths, loadBundle, readLmCache, writeBundle, writeLmCache } from '../store/index.js';
import type { StoreBundle } from '../store/index.js';

const SCRATCH =
  '/private/tmp/claude-501/-Users-rahulmimani-Documents-AI-notifer/9ca18e4b-6c95-419c-93f4-3d33304dc826/scratchpad';

let failures = 0;

function check(name: string, ok: boolean, detail?: string): void {
  if (ok) {
    console.log(`PASS  ${name}`);
  } else {
    failures++;
    console.log(`FAIL  ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

function deepEqual(a: unknown, b: unknown): boolean {
  return JSON.stringify(a) === JSON.stringify(b);
}

function checkEqual(name: string, actual: unknown, expected: unknown): void {
  const ok = deepEqual(actual, expected);
  check(
    name,
    ok,
    ok ? undefined : `expected ${JSON.stringify(expected)} got ${JSON.stringify(actual)}`,
  );
}

// ---------------------------------------------------------------- fixtures

const SYMBOLS = [
  'com.acme.OrderController#createOrder(OrderRequest)',
  'com.acme.OrderService#place(Order)',
  'com.acme.OrderRepository#save(Order)',
  'com.acme.AuditClient#emit(AuditEvent)',
  'com.acme.Unused#neverCalled()',
];

const FILES = [
  'src/main/java/com/acme/OrderController.java',
  'src/main/java/com/acme/OrderService.java',
  'src/main/java/com/acme/OrderRepository.java',
  'src/main/java/com/acme/AuditClient.java',
];

/**
 * Reverse adjacency, expressed as callee ← callers:
 *   0 OrderController#createOrder   ← (nobody: it is the entry point)
 *   1 OrderService#place            ← 0
 *   2 OrderRepository#save          ← 1, 1 (two call sites), 3
 *   3 AuditClient#emit              ← 1
 *   4 Unused#neverCalled            ← (nobody)
 * Deliberately unsorted on input so the codec has to sort it.
 */
const EDGES: CallEdge[] = [
  { callee_index: 2, caller_index: 3, file_id: 3, line: 88, call_kind: 'reflective' },
  { callee_index: 1, caller_index: 0, file_id: 0, line: 42, call_kind: 'direct' },
  { callee_index: 2, caller_index: 1, file_id: 1, line: 130, call_kind: 'interface' },
  { callee_index: 3, caller_index: 1, file_id: 1, line: 140, call_kind: 'lambda' },
  { callee_index: 2, caller_index: 1, file_id: 1, line: 120, call_kind: 'direct' },
];

function makeRecords(): IndexRecord[] {
  const symbol: SymbolRecord = {
    kind: 'symbol',
    id: SYMBOLS[0]!,
    fqn: 'com.acme.OrderController.createOrder',
    symbol_kind: 'method',
    file: FILES[0]!,
    line_start: 40,
    line_end: 55,
    modifiers: ['public'],
    is_entry_point: true,
    entry_point_kind: 'rest_controller',
    entry_point_details: { path: '/orders' },
    annotations: [{ name: 'PostMapping', value: '/orders' }],
    enclosing_class: 'com.acme.OrderController',
    extractor: 'deterministic',
    extraction_confidence: 1,
  };
  const symbol2: SymbolRecord = {
    ...symbol,
    id: SYMBOLS[1]!,
    fqn: 'com.acme.OrderService.place',
    file: FILES[1]!,
    line_start: 100,
    line_end: 160,
    is_entry_point: false,
    entry_point_kind: null,
    entry_point_details: null,
    annotations: [],
    enclosing_class: 'com.acme.OrderService',
  };
  const dto: DtoRecord = {
    kind: 'dto',
    fqn: 'com.acme.dto.OrderRequest',
    shape: 'sha256:orderrequest',
    fields: [{ name: 'orderId', type: 'java.lang.String', nullable: false, annotations: ['NotNull'] }],
    nested_shapes: { 'com.acme.dto.Line': 'sha256:line' },
    file: 'src/main/java/com/acme/dto/OrderRequest.java',
    line: 12,
    is_generated: false,
    extractor: 'lm',
    extraction_confidence: 0.9,
  };
  const invocation: InvocationRecord = {
    kind: 'invocation',
    id: 'inv:1',
    transport: 'rest',
    enclosing_symbol: SYMBOLS[1]!,
    file: FILES[1]!,
    line: 120,
    literal_url: null,
    path_fragment: '/inventory/reserve',
    destination: null,
    request_dto_fqn: 'com.acme.dto.ReserveRequest',
    response_dto_fqn: null,
    client_bean: 'inventoryClient',
    property_key_ref: 'inventory.base-url',
    logical_name: 'inventory-service',
    method_name: 'reserve',
    confidence_hints: ['literal_path'],
    unresolved: [{ what: 'url', reason: 'base url from property', expression: '${inventory.base-url}' }],
    annotations: {},
    extractor: 'lm',
    extraction_confidence: 0.8,
  };
  const property: PropertyRecord = {
    kind: 'property',
    key: 'inventory.base-url',
    value: 'https://inventory.prod.acme/api',
    raw_value: 'https://inventory.${env.domain}/api',
    env: 'prod',
    source: 'src/main/resources/application-prod.yml',
    source_type: 'application_yml',
    line: 7,
    branch: 'prod',
    is_secret: false,
    extractor: 'deterministic',
    extraction_confidence: 1.0,
  };
  const wiring: WiringRecord = {
    kind: 'wiring',
    bean: 'inventoryClient',
    bean_class: 'com.acme.InventoryClient',
    property_key: 'inventory.base-url',
    injection: '@Value',
    file: FILES[3]!,
    line: 22,
    defining_class: 'com.acme.ClientConfig',
    extractor: 'deterministic',
    extraction_confidence: 1,
  };
  const binding: PropertyBindingRecord = {
    kind: 'property_binding',
    prefix: 'inventory',
    class_fqn: 'com.acme.InventoryProperties',
    fields: [{ name: 'baseUrl', type: 'java.lang.String', property_subkey: 'base-url' }],
    file: 'src/main/java/com/acme/InventoryProperties.java',
    line: 9,
    extractor: 'deterministic',
    extraction_confidence: 1,
  };
  const entryPoint: EntryPointRecord = {
    kind: 'entry_point',
    symbol: SYMBOLS[0]!,
    entry_kind: 'rest_controller',
    details: { verb: 'POST', path: '/orders' },
    file: FILES[0]!,
    line: 40,
  };
  const logicalNameRef: LogicalNameRefRecord = {
    kind: 'logical_name_ref',
    logical_name: 'inventory-service',
    context: 'feign',
    symbol: 'com.acme.InventoryClient',
    file: FILES[3]!,
    line: 15,
    extractor: 'deterministic',
    extraction_confidence: 1,
  };
  const alias: AliasRecord = {
    kind: 'alias',
    canonical_key: 'inventory.base-url',
    aliases: ['INVENTORY_BASE_URL', 'inventory_base_url'],
    confidence: 0.95,
  };
  const unresolved: UnresolvedRecord = {
    kind: 'unresolved',
    what: 'destination',
    context: { file: FILES[2]!, line: 200, enclosing_symbol: SYMBOLS[2]! },
    reason: 'topic name built at runtime',
    partial_info: { prefix: 'orders.' },
  };
  return [
    symbol,
    symbol2,
    dto,
    invocation,
    property,
    wiring,
    binding,
    entryPoint,
    logicalNameRef,
    alias,
    unresolved,
  ];
}

function makeBundle(): StoreBundle {
  const meta: Meta = {
    repo: 'acme-orders',
    repo_url: 'https://github.example/acme/orders',
    commit: 'deadbeefdeadbeefdeadbeefdeadbeefdeadbeef',
    branch: 'main',
    // Passed IN — the store layer must never generate this.
    built_at: '2026-07-19T00:00:00.000Z',
    indexer_version: '0.1.0',
    schema_version: '1',
    source_roots: ['src/main/java'],
    package_prefixes: ['com.acme'],
    config_sources: [{ type: 'application_yml', path: 'src/main/resources' }],
    transports_supported: ['rest', 'kafka'],
    stats: { files: 4, symbols: SYMBOLS.length, edges: EDGES.length },
  };
  const endpoints: Endpoint[] = [
    {
      id: 'ep:POST:/orders',
      fingerprint: 'fp:1',
      transport: 'rest',
      verb: 'POST',
      path_template: '/orders',
      path_template_normalized: '/orders',
      destination: null,
      request_dto_fqn: 'com.acme.dto.OrderRequest',
      response_dto_fqn: 'com.acme.dto.OrderResponse',
      request_dto_shape: 'sha256:orderrequest',
      response_dto_shape: 'sha256:orderresponse',
      path_params: [],
      query_params: [{ name: 'dryRun', type: 'boolean', required: false }],
      headers: [{ name: 'X-Tenant', type: 'string', required: true }],
      status_codes: [200, 400],
      logical_name: 'orders-service',
      handler_symbol: SYMBOLS[0]!,
      file: FILES[0]!,
      line: 40,
      annotations: { PostMapping: { value: '/orders' } },
      visibility: 'public',
      extractor: 'deterministic',
      extraction_confidence: 1,
    },
  ];
  const fingerprints: Fingerprint[] = [
    {
      id: 'ep:POST:/orders',
      fingerprint: 'fp:1',
      transport: 'rest',
      path_template: '/orders',
      destination: null,
      request_dto_shape: 'sha256:orderrequest',
      response_dto_shape: 'sha256:orderresponse',
    },
  ];
  const manifest: ConsumptionManifest = {
    dto_shapes: ['sha256:orderrequest'],
    dto_fqns: ['com.acme.dto.OrderRequest'],
    path_fragments: ['/inventory/reserve'],
    destinations: ['orders.created'],
    logical_names: ['inventory-service'],
    property_keys: ['inventory.base-url'],
    unresolved_placeholders: ['${env.domain}'],
    path_fragment_to_property_keys: { '/inventory': ['inventory.base-url'] },
  };
  return {
    meta,
    endpoints,
    fingerprints,
    manifest,
    records: makeRecords(),
    callgraphSymbols: SYMBOLS,
    callgraphEdges: EDGES,
    sourceMap: FILES,
  };
}

// ---------------------------------------------------------------- helpers

function freshRepo(name: string): string {
  const dir = path.join(SCRATCH, 'store-sanity', name);
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function bundleFileHashes(repoRoot: string): Record<string, string> {
  const root = bundlePaths(repoRoot).root;
  const out: Record<string, string> = {};
  for (const name of fs.readdirSync(root).sort()) {
    const full = path.join(root, name);
    if (fs.statSync(full).isFile()) {
      out[name] = fs.readFileSync(full).toString('hex');
    }
  }
  return out;
}

function callersTuples(reader: CallgraphReader, callee: number): string[] {
  return reader
    .callersOf(callee)
    .map((c) => `${c.caller_index}@${c.file_id}:${c.line}/${c.call_kind}`);
}

// ---------------------------------------------------------------- main

export function main(): void {
  const logger: Logger = process.env['SANITY_VERBOSE'] ? consoleLogger : silentLogger;
  const bundle = makeBundle();

  console.log('--- store sanity ---');

  // 1. write + read round trip
  const repoA = freshRepo('repo-a');
  const written = writeBundle(repoA, bundle, logger);
  check('writeBundle emitted all 8 bundle files', Object.keys(written.bytes).length === 8,
    `got ${Object.keys(written.bytes).join(', ')}`);

  const cgBytes = fs.statSync(bundlePaths(repoA).callgraphBin).size;
  console.log(`INFO  callgraph.bin on disk = ${cgBytes} bytes`);

  const loaded = loadBundle(repoA, logger);
  check('bundle reports present', loaded.present);
  checkEqual('meta round-trips', loaded.meta, bundle.meta);
  checkEqual('meta.built_at preserved verbatim', loaded.meta.built_at, bundle.meta.built_at);
  checkEqual('endpoints round-trip', loaded.endpoints, bundle.endpoints);
  checkEqual('fingerprints round-trip', loaded.fingerprints, bundle.fingerprints);
  checkEqual('consumption_manifest round-trips', loaded.manifest, bundle.manifest);
  checkEqual('index records round-trip (gzip jsonl)', loaded.records, bundle.records);
  checkEqual('source_map round-trips', loaded.sourceMap, bundle.sourceMap);

  // 2. record bucketing + lookup maps
  const kinds = Object.keys(loaded.byKind).sort();
  checkEqual(
    'byKind has every kind bucket',
    kinds,
    ['alias', 'dto', 'entry_point', 'invocation', 'logical_name_ref', 'property',
      'property_binding', 'symbol', 'unresolved', 'wiring'],
  );
  check('every kind bucket is non-empty (all kinds exercised)',
    kinds.every((k) => loaded.byKind[k as keyof typeof loaded.byKind]!.length > 0));
  checkEqual('byKind.symbol has 2 symbols', loaded.byKind.symbol.length, 2);
  check('symbolsById resolves the controller symbol',
    loaded.symbolsById.get(SYMBOLS[0]!)?.file === FILES[0]);
  check('recordsByFile buckets by repo-relative file',
    (loaded.recordsByFile.get(FILES[1]!) ?? []).length === 2,
    `got ${(loaded.recordsByFile.get(FILES[1]!) ?? []).length}`);
  check('every recordsByFile key is repo-relative forward-slashed',
    [...loaded.recordsByFile.keys()].every((f) => !f.startsWith('/') && !f.includes('\\')));
  check('endpointsById resolves', loaded.endpointsById.get('ep:POST:/orders')?.verb === 'POST');
  check('callgraph.idx.json maps symbol id → index',
    loaded.callgraphIndex[SYMBOLS[2]!] === 2 && loaded.callgraphIndex[SYMBOLS[0]!] === 0);
  check('loadMs recorded', typeof loaded.loadMs === 'number' && loaded.loadMs >= 0);

  // 3. callgraph reverse adjacency
  const cg = loaded.callgraph;
  checkEqual('callgraph symbol_count', cg.symbolCountValue, SYMBOLS.length);
  checkEqual('callgraph edge_count', cg.edgeCountValue, EDGES.length);
  checkEqual('callgraph string table round-trips', cg.symbols(), SYMBOLS);

  checkEqual('callersOf(0) — entry point has ZERO callers', callersTuples(cg, 0), []);
  checkEqual('callersOf(4) — unused symbol has ZERO callers', callersTuples(cg, 4), []);
  checkEqual('callersOf(1) — single caller', callersTuples(cg, 1), ['0@0:42/direct']);
  checkEqual(
    'callersOf(2) — MULTIPLE callers, sorted by (caller, line)',
    callersTuples(cg, 2),
    ['1@1:120/direct', '1@1:130/interface', '3@3:88/reflective'],
  );
  checkEqual('callersOf(3) — lambda call kind decoded', callersTuples(cg, 3), ['1@1:140/lambda']);
  checkEqual('callersOf(out of range) is empty', callersTuples(cg, 99), []);
  checkEqual('callersOf(-1) is empty', callersTuples(cg, -1), []);
  checkEqual('callersOfSymbol by id matches by index', cg.callersOfSymbol(SYMBOLS[2]!), cg.callersOf(2));

  const totalReachable = SYMBOLS.reduce((n, _s, i) => n + cg.callersOf(i).length, 0);
  checkEqual('every edge is reachable through the offset table', totalReachable, EDGES.length);

  // 4. determinism — same bundle written twice is byte-identical
  const hashesA = bundleFileHashes(repoA);
  const repoB = freshRepo('repo-b');
  writeBundle(repoB, bundle, logger);
  const hashesB = bundleFileHashes(repoB);
  checkEqual('second write is byte-identical (all files)', hashesB, hashesA);
  check('index.jsonl.gz specifically is byte-identical (gzip mtime=0)',
    hashesA['index.jsonl.gz'] === hashesB['index.jsonl.gz']);

  // Rewriting in place over an existing bundle is also stable.
  writeBundle(repoA, bundle, logger);
  checkEqual('rewrite in place is byte-identical', bundleFileHashes(repoA), hashesA);

  // Edge input order must not affect output.
  const repoC = freshRepo('repo-c');
  writeBundle(repoC, { ...bundle, callgraphEdges: EDGES.slice().reverse() }, logger);
  check('shuffled edge input yields identical callgraph.bin',
    bundleFileHashes(repoC)['callgraph.bin'] === hashesA['callgraph.bin']);

  // 5. lm_cache
  writeLmCache(repoA, 'abc123', { raw: 'model output', tokens: 42 }, logger);
  checkEqual('lm_cache round-trips', readLmCache(repoA, 'abc123', logger), {
    raw: 'model output',
    tokens: 42,
  });
  checkEqual('lm_cache miss returns null', readLmCache(repoA, 'nosuchhash', logger), null);

  // 6. fail-open on corruption
  const repoD = freshRepo('repo-d');
  writeBundle(repoD, bundle, logger);
  const pD = bundlePaths(repoD);
  const corrupt = fs.readFileSync(pD.callgraphBin);
  corrupt.write('XXXX', 0, 4, 'ascii');
  fs.writeFileSync(pD.callgraphBin, corrupt);

  let threw = false;
  let corruptLoaded: ReturnType<typeof loadBundle> | null = null;
  try {
    corruptLoaded = loadBundle(repoD, logger);
  } catch {
    threw = true;
  }
  check('corrupt callgraph.bin (bad magic) does not throw', !threw);
  check('corrupt callgraph degrades to an empty reader',
    corruptLoaded !== null && corruptLoaded.callgraph.symbolCountValue === 0 &&
      corruptLoaded.callgraph.edgeCountValue === 0);
  checkEqual('empty reader callersOf is empty', corruptLoaded?.callgraph.callersOf(2) ?? [], []);
  checkEqual('other sections still load despite corrupt callgraph',
    corruptLoaded?.records.length, bundle.records.length);

  // Bad version byte.
  const badVersion = fs.readFileSync(pD.callgraphBin);
  badVersion.write('CGRF', 0, 4, 'ascii');
  badVersion.writeUInt8(99, 4);
  check('bad version degrades to empty reader',
    CallgraphReader.fromBuffer(badVersion, logger).symbolCountValue === 0);
  check('truncated buffer degrades to empty reader',
    CallgraphReader.fromBuffer(Buffer.alloc(3), logger).symbolCountValue === 0);

  // Malformed / blank lines in JSONL are skipped, not fatal.
  fs.appendFileSync(pD.endpoints, '\n\n{ this is not json }\n\n');
  const afterJunk = loadBundle(repoD, logger);
  checkEqual('malformed + blank JSONL lines are skipped', afterJunk.endpoints, bundle.endpoints);

  // Entirely missing bundle.
  const repoE = freshRepo('repo-e');
  let missingThrew = false;
  let missing: ReturnType<typeof loadBundle> | null = null;
  try {
    missing = loadBundle(repoE, logger);
  } catch {
    missingThrew = true;
  }
  check('missing bundle does not throw', !missingThrew);
  check('missing bundle degrades to empty',
    missing !== null && !missing.present && missing.records.length === 0 &&
      missing.endpoints.length === 0 && missing.callgraph.symbolCountValue === 0);

  console.log('--- done ---');
  if (failures > 0) {
    console.log(`${failures} assertion(s) FAILED`);
    process.exitCode = 1;
  } else {
    console.log('all assertions PASSED');
  }
}

main();
