/**
 * Daemon query-layer sanity run — the real proof for changes / match / walk /
 * blast / registry.
 *
 * Builds BOTH fixture repos end to end exactly as `indexer-sanity.ts` does
 * (MockChatModelProvider over `fixtures/lm-responses/`), then builds four
 * MUTATED variants of CDU to drive `detectChanges`, loads everything into an
 * `IndexRegistry` and asserts the query results against `fixtures/expected.json`
 * and `fixtures/README.md`.
 *
 * Bundles are written to the scratchpad, never into fixtures/.
 *
 * Run:  npx tsc --outDir out && node out/sanity/daemon-sanity.js
 */

import * as fs from 'node:fs';
import * as path from 'node:path';

import type {
  BlastRadiusResult,
  ChainNode,
  ChangedEndpoint,
  DtoRecord,
  Endpoint,
  InvocationHit,
} from '../types.js';
import { consoleLogger, silentLogger } from '../util/logger.js';
import type { Logger } from '../util/logger.js';
import { MockChatModelProvider } from '../lm/provider.js';
import { emptyExtraction } from '../lm/schema.js';
import type { LmEndpoint, LmExtraction } from '../lm/schema.js';
import { buildIndex } from '../coordinator/build.js';
import type { BuildConfig, BuildIndexResult } from '../coordinator/build.js';
import { symbolId } from '../extractor/ids.js';
import { loadBundle } from '../store/index.js';
import {
  IndexRegistry,
  blastRadius,
  detectChanges,
  findInvocations,
  forwardIndexFrom,
  getEndpointAt,
  getInvocationAt,
  isConsumed,
  walkCallers,
  walkFeeders,
} from '../daemon/index.js';

/* ------------------------------------------------------------------ *
 * Harness
 * ------------------------------------------------------------------ */

let passed = 0;
let failed = 0;

function check(label: string, ok: boolean, detail = ''): void {
  if (ok) {
    passed += 1;
    console.log(`PASS  ${label}${detail === '' ? '' : ` — ${detail}`}`);
  } else {
    failed += 1;
    process.exitCode = 1;
    console.log(`FAIL  ${label}${detail === '' ? '' : ` — ${detail}`}`);
  }
}

function eq(label: string, actual: unknown, expected: unknown): void {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  check(label, a === e, a === e ? String(a) : `got ${a}, expected ${e}`);
}

function section(name: string): void {
  console.log(`\n=== ${name} ===`);
}

/* ------------------------------------------------------------------ *
 * Paths
 * ------------------------------------------------------------------ */

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const FIXTURES = path.join(REPO_ROOT, 'fixtures');
const SCRATCH_ROOT =
  '/private/tmp/claude-501/-Users-rahulmimani-Documents-AI-notifer/9ca18e4b-6c95-419c-93f4-3d33304dc826/scratchpad';
/** Own subdirectory: the scratchpad root is shared and must never be wiped. */
const SCRATCH = path.join(SCRATCH_ROOT, 'daemon-sanity');

/* ------------------------------------------------------------------ *
 * Build harness (mirrors indexer-sanity.ts, plus an extraction mutator)
 * ------------------------------------------------------------------ */

type Mutator = (relativePath: string, extraction: LmExtraction) => LmExtraction;

function fixtureResponsePath(repo: string, relativePath: string): string {
  return path.join(FIXTURES, 'lm-responses', repo, `${relativePath.split('/').join('__')}.json`);
}

function makeProvider(repo: string, mutate?: Mutator): MockChatModelProvider {
  return new MockChatModelProvider((_system, messages) => {
    const prompt = messages[0] ?? '';
    const match = /File path:\n(.+)\n/.exec(prompt);
    const relativePath = match?.[1]?.trim() ?? '';
    const file = fixtureResponsePath(repo, relativePath);
    if (relativePath === '' || !fs.existsSync(file)) {
      return JSON.stringify(emptyExtraction());
    }
    const raw = fs.readFileSync(file, 'utf8');
    if (!mutate) {
      return raw;
    }
    return JSON.stringify(mutate(relativePath, JSON.parse(raw) as LmExtraction));
  });
}

function configFor(repo: 'cdu' | 'pou'): BuildConfig {
  return {
    packagePrefixes: [`com.acme.${repo}`],
    sourceRoots: ['src/main/java'],
    configServerPaths: [],
    configServerBranches: [],
    configMapPaths: repo === 'pou' ? [path.join(FIXTURES, 'configmap', 'pou-configmap.yaml')] : [],
    messageRouterMarkers: [],
    lmModel: 'mock-model',
    lmMaxConcurrent: 4,
    lmTimeoutSeconds: 60,
    lmTotalBudgetMinutes: 10,
    lmEnabled: true,
  };
}

const BUILT_AT = '2026-01-01T00:00:00.000Z';

async function build(
  repo: 'cdu' | 'pou',
  outDirName: string,
  logger: Logger,
  mutate?: Mutator,
): Promise<{ result: BuildIndexResult; outputRoot: string }> {
  const outputRoot = path.join(SCRATCH, outDirName);
  const result = await buildIndex({
    repoRoot: path.join(FIXTURES, repo),
    repo,
    provider: makeProvider(repo, mutate),
    model: 'mock-model',
    config: configFor(repo),
    logger,
    builtAt: BUILT_AT,
    outputRoot,
  });
  return { result, outputRoot };
}

/* ------------------------------------------------------------------ *
 * The four CDU mutations
 * ------------------------------------------------------------------ */

const UPDATE_REQUEST_JAVA = 'src/main/java/com/acme/cdu/dto/UpdateCustomerRequest.java';
const CUSTOMER_API_JAVA = 'src/main/java/com/acme/cdu/api/CustomerApi.java';
const CUSTOMER_CONTROLLER_JAVA = 'src/main/java/com/acme/cdu/controller/CustomerController.java';

/** `UpdateCustomerRequest.displayName` : String -> LocalizedName, plus a new field. */
const mutateDtoField: Mutator = (rel, ex) => {
  if (rel !== UPDATE_REQUEST_JAVA) {
    return ex;
  }
  for (const dto of ex.dtos) {
    if (dto.fqn !== 'com.acme.cdu.dto.UpdateCustomerRequest') {
      continue;
    }
    for (const field of dto.fields) {
      if (field.name === 'displayName') {
        field.type = 'com.acme.cdu.dto.LocalizedName';
      }
    }
    dto.fields.push({
      name: 'preferredLocale',
      type: 'java.lang.String',
      nullable: true,
      annotations: [],
    });
  }
  return ex;
};

/** `GET /api/v1/customers/{id}/addresses` -> `.../postal-addresses`. */
const mutatePath: Mutator = (rel, ex) => {
  if (rel !== CUSTOMER_API_JAVA && rel !== CUSTOMER_CONTROLLER_JAVA) {
    return ex;
  }
  for (const ep of ex.endpoints) {
    if (ep.handler_method_name !== 'listAddresses') {
      continue;
    }
    ep.path_template = '/api/v1/customers/{id}/postal-addresses';
    const mapping = ep.annotations['GetMapping'];
    if (mapping) {
      mapping['value'] = '/{id}/postal-addresses';
    }
  }
  return ex;
};

/** Drop the `listAddresses` endpoint entirely. */
const mutateDrop: Mutator = (rel, ex) => {
  if (rel !== CUSTOMER_API_JAVA && rel !== CUSTOMER_CONTROLLER_JAVA) {
    return ex;
  }
  ex.endpoints = ex.endpoints.filter((ep) => ep.handler_method_name !== 'listAddresses');
  return ex;
};

/** Add a brand-new `DELETE /api/v1/customers/{id}` handler on the controller. */
const mutateAdd: Mutator = (rel, ex) => {
  if (rel !== CUSTOMER_CONTROLLER_JAVA) {
    return ex;
  }
  const added: LmEndpoint = {
    transport: 'rest',
    verb: 'DELETE',
    path_template: '/api/v1/customers/{id}',
    destination: null,
    request_dto_fqn: null,
    response_dto_fqn: null,
    path_params: [{ name: 'id', type: 'java.lang.String' }],
    query_params: [],
    headers: [],
    logical_name: 'cdu-service.deleteCustomer',
    handler_class_fqn: 'com.acme.cdu.controller.CustomerController',
    handler_method_name: 'deleteCustomer',
    handler_method_signature: 'deleteCustomer(Ljava/lang/String;)V',
    handler_line: 42,
    annotations: {
      RestController: {},
      RequestMapping: { value: '/api/v1/customers' },
      DeleteMapping: { value: '/{id}' },
      PathVariable: { value: 'id' },
    },
    confidence: 0.9,
  };
  ex.endpoints.push(added);
  return ex;
};

/* ------------------------------------------------------------------ *
 * Symbol helpers
 * ------------------------------------------------------------------ */

const C = (fqn: string, sig: string): string => symbolId('cdu', `com.acme.cdu.${fqn}`, sig);
const P = (fqn: string, sig: string): string => symbolId('pou', `com.acme.pou.${fqn}`, sig);

const CDU_GET_CUSTOMER = C(
  'controller.CustomerController',
  'getCustomer(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;',
);
const CDU_UPDATE_CUSTOMER = C(
  'controller.CustomerController',
  'updateCustomer(Ljava/lang/String;Lcom/acme/cdu/dto/UpdateCustomerRequest;)Lcom/acme/cdu/dto/CustomerDto;',
);
const CDU_FIND_BY_ID = C('service.CustomerService', 'findById(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;');
const CDU_LOAD = C('repository.CustomerRepository', 'load(Ljava/lang/String;)Lcom/acme/cdu/dto/CustomerDto;');

const POU_FETCH = P(
  'service.CustomerLookupService',
  'fetchCustomer(Ljava/lang/String;)Lcom/acme/pou/dto/CustomerDto;',
);
const POU_UPDATE = P(
  'service.CustomerLookupService',
  'updateCustomer(Ljava/lang/String;Lcom/acme/pou/dto/UpdateCustomerRequest;)Lcom/acme/pou/dto/CustomerDto;',
);
const POU_ENRICH = P(
  'service.EnrichmentService',
  'enrich(Ljava/lang/String;Ljava/lang/String;)Lcom/acme/pou/dto/CustomerDto;',
);
const POU_PROCESS = P(
  'service.OrderService',
  'process(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/acme/pou/dto/CustomerDto;',
);
const POU_CREATE_ORDER = P(
  'web.OrderController',
  'createOrder(Lcom/acme/pou/dto/OrderRequest;)Lorg/springframework/http/ResponseEntity;',
);
const POU_ON_EVENT = P('listener.OrderEventListener', 'onOrderEvent(Ljava/lang/String;)V');

function findEndpoint(endpoints: readonly Endpoint[], verb: string, pathTemplate: string): Endpoint | undefined {
  return endpoints.find((e) => e.verb === verb && e.path_template === pathTemplate);
}

function nodeAt(nodes: readonly ChainNode[], symbol: string): ChainNode | undefined {
  return nodes.find((n) => n.symbol === symbol);
}

function hitFor(hits: readonly InvocationHit[], symbol: string): InvocationHit | undefined {
  return hits.find((h) => h.symbol === symbol);
}

function short(symbol: string): string {
  const [fqnPart, sig] = symbol.split('#');
  const fqn = (fqnPart ?? '').split(':').slice(1).join(':');
  const cls = fqn.split('.').slice(-1)[0] ?? fqn;
  return `${cls}.${(sig ?? '').split('(')[0] ?? ''}`;
}

/* ------------------------------------------------------------------ *
 * Main
 * ------------------------------------------------------------------ */

async function main(): Promise<void> {
  fs.rmSync(SCRATCH, { recursive: true, force: true });
  fs.mkdirSync(SCRATCH, { recursive: true });

  const quiet = silentLogger;

  /* ================= builds ========================================== */
  section('Fixture builds');
  const cdu = await build('cdu', 'cdu-base', quiet);
  const pou = await build('pou', 'pou-base', quiet);
  const cduDto = await build('cdu', 'cdu-dto', quiet, mutateDtoField);
  const cduPath = await build('cdu', 'cdu-path', quiet, mutatePath);
  const cduDrop = await build('cdu', 'cdu-drop', quiet, mutateDrop);
  const cduAdd = await build('cdu', 'cdu-add', quiet, mutateAdd);
  check('CDU + POU + 4 mutated CDU bundles built', true,
    `cdu=${cdu.result.endpoints.length} endpoints, pou=${pou.result.endpoints.length} endpoints`);

  const base = loadBundle(cdu.outputRoot, quiet);
  const dtoB = loadBundle(cduDto.outputRoot, quiet);
  const pathB = loadBundle(cduPath.outputRoot, quiet);
  const dropB = loadBundle(cduDrop.outputRoot, quiet);
  const addB = loadBundle(cduAdd.outputRoot, quiet);

  /* ================= detectChanges =================================== */
  section('detectChanges — stability');
  const none = detectChanges(base.fingerprints, base.fingerprints, {
    oldBundle: base,
    newBundle: base,
    logger: quiet,
  });
  eq('an unchanged build against itself yields ZERO changes', none.length, 0);
  const noneFromPaths = detectChanges(cdu.outputRoot, cdu.outputRoot, { logger: quiet });
  eq('  same via FILE PATHS rather than arrays', noneFromPaths.length, 0);
  check(
    '  path form and array form agree',
    JSON.stringify(none) === JSON.stringify(noneFromPaths),
  );

  section('detectChanges — request DTO field type change');
  const dtoChanges = detectChanges(base.fingerprints, dtoB.fingerprints, {
    oldBundle: base,
    newBundle: dtoB,
    logger: quiet,
  });
  const putBase = findEndpoint(base.endpoints, 'PUT', '/api/v1/customers/{id}')!;
  const putChanged = dtoChanges.find((c) => c.id === putBase.id);
  check('PUT /api/v1/customers/{id} reported as modified', putChanged?.change_kind === 'modified',
    `${dtoChanges.length} change(s): ${dtoChanges.map((c) => `${c.change_kind} ${c.verb} ${c.path_template}`).join('; ')}`);
  check(
    '  diff_reason contains request_dto_shape_changed',
    putChanged?.diff_reason.includes('request_dto_shape_changed') === true,
    JSON.stringify(putChanged?.diff_reason),
  );
  check(
    '  diff_reason contains dto_field_type_changed',
    putChanged?.diff_reason.includes('dto_field_type_changed') === true,
    JSON.stringify(putChanged?.diff_reason),
  );
  check(
    '  diff_reason contains dto_field_added',
    putChanged?.diff_reason.includes('dto_field_added') === true,
    JSON.stringify(putChanged?.diff_reason),
  );
  const displayNameDiff = putChanged?.diff_details.find(
    (d) => d.field === 'UpdateCustomerRequest.displayName',
  );
  eq('  diff_details before for displayName', displayNameDiff?.before, 'java.lang.String');
  eq('  diff_details after for displayName', displayNameDiff?.after, 'com.acme.cdu.dto.LocalizedName');
  const localeDiff = putChanged?.diff_details.find(
    (d) => d.field === 'UpdateCustomerRequest.preferredLocale',
  );
  eq('  added field has before=null', localeDiff?.before, null);
  eq('  added field has after=java.lang.String', localeDiff?.after, 'java.lang.String');
  eq('  handler_symbol carried through', putChanged?.handler_symbol, CDU_UPDATE_CUSTOMER);
  eq('  verb carried through', putChanged?.verb, 'PUT');
  eq('  transport carried through', putChanged?.transport, 'rest');
  eq('  line carried through', putChanged?.line, 34);
  check('  file carried through', putChanged?.file?.endsWith('controller/CustomerController.java') === true,
    String(putChanged?.file));

  section('detectChanges — path template change');
  const pathChanges = detectChanges(base.fingerprints, pathB.fingerprints, {
    oldBundle: base,
    newBundle: pathB,
    logger: quiet,
  });
  const renamed = pathChanges.find((c) => c.path_template === '/api/v1/customers/{id}/postal-addresses');
  eq('exactly one change reported', pathChanges.length, 1);
  check('  reported as modified, not remove+add', renamed?.change_kind === 'modified',
    String(renamed?.change_kind));
  check('  diff_reason contains path_changed', renamed?.diff_reason.includes('path_changed') === true,
    JSON.stringify(renamed?.diff_reason));
  const pathDetail = renamed?.diff_details.find((d) => d.field === 'path_template');
  eq('  before path', pathDetail?.before, '/api/v1/customers/{id}/addresses');
  eq('  after path', pathDetail?.after, '/api/v1/customers/{id}/postal-addresses');

  section('detectChanges — endpoint removed / added');
  const dropChanges = detectChanges(base.fingerprints, dropB.fingerprints, {
    oldBundle: base,
    newBundle: dropB,
    logger: quiet,
  });
  eq('one change reported for the dropped endpoint', dropChanges.length, 1);
  eq('  change_kind', dropChanges[0]?.change_kind, 'removed');
  eq('  path_template comes from the OLD bundle', dropChanges[0]?.path_template, '/api/v1/customers/{id}/addresses');
  eq('  handler_symbol comes from the OLD bundle', dropChanges[0]?.handler_symbol,
    C('controller.CustomerController', 'listAddresses(Ljava/lang/String;)Ljava/util/List;'));

  const addChanges = detectChanges(base.fingerprints, addB.fingerprints, {
    oldBundle: base,
    newBundle: addB,
    logger: quiet,
  });
  eq('one change reported for the added endpoint', addChanges.length, 1);
  eq('  change_kind', addChanges[0]?.change_kind, 'added');
  eq('  verb', addChanges[0]?.verb, 'DELETE');
  eq('  path_template', addChanges[0]?.path_template, '/api/v1/customers/{id}');
  eq('  diff_reason is empty for a pure add', addChanges[0]?.diff_reason, []);

  /* ================= registry ======================================== */
  section('IndexRegistry');
  const registry = new IndexRegistry(quiet);
  const cduRepo = registry.load(cduDto.outputRoot, quiet, 'cdu');
  const pouRepo = registry.load(pou.outputRoot, quiet, 'pou');
  eq('both repos resident', registry.list(), ['cdu', 'pou']);
  check('  cdu forward callgraph present', cduRepo.forward.present && cduRepo.forward.edgeCount > 0,
    `${cduRepo.forward.callerCount} callers / ${cduRepo.forward.edgeCount} edges`);
  check('  pou forward callgraph present', pouRepo.forward.present && pouRepo.forward.edgeCount > 0,
    `${pouRepo.forward.callerCount} callers / ${pouRepo.forward.edgeCount} edges`);
  check('  lookup maps built at load', cduRepo.index.endpointsByFile.size > 0 &&
    pouRepo.index.invocations.length > 0,
    `cdu endpoint files=${cduRepo.index.endpointsByFile.size}, pou invocations=${pouRepo.index.invocations.length}`);
  const reloaded = registry.reload('cdu', quiet);
  check('  reload keeps the repo resident', reloaded !== undefined && registry.has('cdu'));
  check('  unload evicts', registry.unload('cdu', quiet) && !registry.has('cdu'));
  registry.load(cduDto.outputRoot, quiet, 'cdu');
  check('  re-load restores it', registry.has('cdu'));

  /* ================= isConsumed ====================================== */
  section('isConsumed (phase-1 gate)');
  const changedPut = dtoChanges.find((c) => c.id === putBase.id)!;
  const changedPutEndpoint = dtoB.endpointsById.get(putBase.id)!;
  const gate = isConsumed(changedPut, pou.result.manifest, {
    producerEndpoint: changedPutEndpoint,
    logger: quiet,
  });
  check('changed PUT is consumed by POU', gate.consumed, JSON.stringify(gate.signals));
  check(
    '  the dto_shape signal fired',
    gate.signals.some((s) => s.startsWith('dto_shape')),
    JSON.stringify(gate.signals),
  );
  check(
    '  the path_fragment signal fired via the inverted index',
    gate.signals.some((s) => s.startsWith('path_fragment')),
    JSON.stringify(gate.signals),
  );

  const unrelated = isConsumed(
    changedPut,
    {
      dto_shapes: ['deadbeef'],
      dto_fqns: ['com.other.Thing'],
      path_fragments: ['/totally/unrelated'],
      destinations: ['other-topic'],
      logical_names: ['other-service.op'],
      property_keys: ['other.key'],
      unresolved_placeholders: [],
      path_fragment_to_property_keys: { '/totally/unrelated': ['other.key'] },
    },
    { producerEndpoint: changedPutEndpoint, logger: quiet },
  );
  eq('a synthetic unrelated manifest is NOT consumed', unrelated.consumed, false);
  eq('  and reports no signals', unrelated.signals, []);

  /* --- context-path / gateway-prefix matching (regression) -------------
   * A consumer calls `https://host/cdu/tag`; the producer's controller is
   * mapped at `/tag`, because `/cdu` is a servlet context path or gateway
   * prefix that appears nowhere in the producer's source. Prefix-only
   * fragment forms never intersect here, so this silently reported "not
   * consumed" on real repos. */
  const contextPathManifest = {
    dto_shapes: [],
    dto_fqns: [],
    path_fragments: ['/cdu', '/cdu/tag', 'https://s2bfm-csl-hgasjhgd/cdu/tag'],
    destinations: [],
    logical_names: [],
    property_keys: ['cdu.tag.api'],
    unresolved_placeholders: [],
    path_fragment_to_property_keys: { '/cdu/tag': ['cdu.tag.api'] },
  };
  const tagEndpoint = { ...changedPutEndpoint, path_template: '/tag', path_template_normalized: '/tag' };
  const tagChanged = { ...changedPut, path_template: '/tag' };
  const ctx = isConsumed(tagChanged, contextPathManifest, {
    producerEndpoint: tagEndpoint,
    logger: quiet,
  });
  check(
    'endpoint /tag IS consumed by a caller of https://host/cdu/tag (context path stripped)',
    ctx.consumed,
    JSON.stringify(ctx.signals),
  );

  // The suffix widening must not make everything match everything.
  const unrelatedTag = isConsumed(
    { ...changedPut, path_template: '/billing' },
    contextPathManifest,
    { producerEndpoint: { ...changedPutEndpoint, path_template: '/billing', path_template_normalized: '/billing' }, logger: quiet },
  );
  eq('  an unrelated endpoint /billing is still NOT consumed', unrelatedTag.consumed, false);

  /* ================= findInvocations ================================= */
  section('findInvocations (phase-2 join)');
  const pouBundle = pouRepo.bundle;
  const hits = findInvocations(pouBundle, changedPut, {
    producerEndpoint: changedPutEndpoint,
    index: pouRepo.index,
    logger: quiet,
  });
  for (const hit of hits) {
    console.log(
      `      ${short(hit.symbol)} @${hit.file.split('/').pop()}:${hit.line_range[0]}-${hit.line_range[1]} ` +
        `conf=${hit.confidence} via=[${hit.matched_via.join(', ')}] method=${hit.method_name} ` +
        `unresolved=${hit.unresolved.length}`,
    );
  }
  const fetchHit = hitFor(hits, POU_FETCH);
  const updateHit = hitFor(hits, POU_UPDATE);
  check('POU fetchCustomer found', fetchHit !== undefined);
  check('POU updateCustomer found', updateHit !== undefined);
  eq('  each invocation appears exactly ONCE',
    hits.length, new Set(hits.map((h) => h.invocation_id)).size);
  eq('  the dto_shape hit has confidence 0.95', updateHit?.confidence, 0.95);
  check('  updateCustomer matched by MULTIPLE signals, kept once with max confidence',
    (updateHit?.matched_via.length ?? 0) > 1 && updateHit?.confidence === 0.95,
    JSON.stringify(updateHit?.matched_via));
  check('  matched_via contains dto_shape_match',
    updateHit?.matched_via.includes('dto_shape_match') === true, JSON.stringify(updateHit?.matched_via));
  check('  matched_via contains property_value:services.cdu.base-url',
    updateHit?.matched_via.includes('property_value:services.cdu.base-url') === true,
    JSON.stringify(updateHit?.matched_via));
  check('  matched_via contains wired_bean:cduRestTemplate',
    updateHit?.matched_via.includes('wired_bean:cduRestTemplate') === true,
    JSON.stringify(updateHit?.matched_via));
  const via = updateHit?.matched_via ?? [];
  check('  matched_via is deduped and sorted',
    JSON.stringify(via) === JSON.stringify([...new Set(via)].sort()), JSON.stringify(via));
  eq('  line_range uses the call line for both ends', fetchHit?.line_range, [37, 37]);
  eq('  transport carried through', fetchHit?.transport, 'rest');
  eq('  method_name carried through', fetchHit?.method_name, 'getForObject');
  check('  unresolved notes carried through', (fetchHit?.unresolved.length ?? 0) > 0,
    JSON.stringify(fetchHit?.unresolved.map((u) => u.what)));

  // A property-value-only hit: an endpoint declaring no DTOs on either side can
  // only be reached through the resolved-property path fragment.
  const dtolessEndpoint: Endpoint = {
    ...changedPutEndpoint,
    request_dto_fqn: null,
    response_dto_fqn: null,
    request_dto_shape: null,
    response_dto_shape: null,
  };
  const dtolessHits = findInvocations(pouBundle, changedPut, {
    producerEndpoint: dtolessEndpoint,
    index: pouRepo.index,
    logger: quiet,
  });
  const dtolessFetch = hitFor(dtolessHits, POU_FETCH);
  eq('a property-value-driven hit has confidence 0.80', dtolessFetch?.confidence, 0.8);
  check('  its strongest signal is the property value',
    dtolessFetch?.matched_via.includes('property_value:services.cdu.base-url') === true,
    JSON.stringify(dtolessFetch?.matched_via));
  check('  no dto signal fired', dtolessFetch?.matched_via.some((s) => s.startsWith('dto_')) === false,
    JSON.stringify(dtolessFetch?.matched_via));

  /* ================= walkCallers ===================================== */
  section('walkCallers (upward, entry points terminal)');
  const callers = walkCallers(pouBundle, POU_FETCH, 4, {
    entryPoints: pouRepo.index.entryPointsBySymbol,
    logger: quiet,
  });
  for (const node of callers) {
    console.log(
      `      depth ${node.depth}  ${short(node.symbol)}` +
        `${node.is_entry_point ? `  [entry: ${node.entry_kind}]` : ''}` +
        `${node.call_site ? `  @${node.call_site.file.split('/').pop()}:${node.call_site.line}` : ''}`,
    );
  }
  eq('EnrichmentService.enrich at depth 1', nodeAt(callers, POU_ENRICH)?.depth, 1);
  eq('OrderService.process at depth 2', nodeAt(callers, POU_PROCESS)?.depth, 2);
  eq('OrderController.createOrder at depth 3', nodeAt(callers, POU_CREATE_ORDER)?.depth, 3);
  eq('OrderEventListener.onOrderEvent at depth 3', nodeAt(callers, POU_ON_EVENT)?.depth, 3);
  eq('  createOrder marked rest_controller entry point',
    nodeAt(callers, POU_CREATE_ORDER)?.entry_kind, 'rest_controller');
  eq('  onOrderEvent marked kafka_listener entry point',
    nodeAt(callers, POU_ON_EVENT)?.entry_kind, 'kafka_listener');
  check('  both entry points marked is_entry_point',
    nodeAt(callers, POU_CREATE_ORDER)?.is_entry_point === true &&
      nodeAt(callers, POU_ON_EVENT)?.is_entry_point === true);
  check('  entry points are TERMINAL: nothing above them was expanded',
    callers.every((n) => n.depth <= 3),
    `max depth reached = ${Math.max(...callers.map((n) => n.depth))}`);
  check('  call sites resolved through the source map',
    callers.every((n) => n.call_site !== null && n.call_site.file.endsWith('.java')),
    JSON.stringify(callers.map((n) => n.call_site?.file.split('/').pop())));

  section('walkCallers — depth cap and cycle safety');
  const capped = walkCallers(pouBundle, POU_FETCH, 1, {
    entryPoints: pouRepo.index.entryPointsBySymbol,
    logger: quiet,
  });
  eq('maxDepth 1 truncates to the direct callers only', capped.map((n) => n.symbol), [POU_ENRICH]);
  eq('  and every node is at depth 1', capped.every((n) => n.depth === 1), true);

  const cyclic = forwardIndexFrom({
    A: [{ callee: 'B', file_id: 0, line: 1, call_kind: 'direct' }],
    B: [{ callee: 'C', file_id: 0, line: 2, call_kind: 'direct' }],
    C: [{ callee: 'A', file_id: 0, line: 3, call_kind: 'direct' }],
  });
  const cyclicWalk = walkFeeders(pouBundle, 'A', 64, { forward: cyclic, logger: quiet });
  eq('a synthetic A->B->C->A cycle terminates and visits each node once',
    cyclicWalk.downstream.map((n) => n.symbol), ['A', 'B', 'C']);
  eq('  with monotonically increasing depths', cyclicWalk.downstream.map((n) => n.depth), [0, 1, 2]);

  /* ================= walkFeeders ===================================== */
  section('walkFeeders (BOTH directions from a producer handler)');
  const cduRepoNow = registry.get('cdu')!;
  const feeders = walkFeeders(cduRepoNow.bundle, CDU_GET_CUSTOMER, 4, {
    forward: cduRepoNow.forward,
    entryPoints: cduRepoNow.index.entryPointsBySymbol,
    logger: quiet,
  });
  for (const node of feeders.downstream) {
    console.log(
      `      downstream depth ${node.depth}  ${short(node.symbol)}` +
        `${node.is_entry_point ? `  [entry: ${node.entry_kind}]` : ''}` +
        `${node.call_site ? `  @${node.call_site.file.split('/').pop()}:${node.call_site.line}` : ''}`,
    );
  }
  eq('handler itself at depth 0', feeders.downstream[0]?.symbol, CDU_GET_CUSTOMER);
  eq('  marked as a rest_controller entry point', feeders.downstream[0]?.entry_kind, 'rest_controller');
  eq('CustomerService.findById at depth 1', nodeAt(feeders.downstream, CDU_FIND_BY_ID)?.depth, 1);
  eq('CustomerRepository.load at depth 2', nodeAt(feeders.downstream, CDU_LOAD)?.depth, 2);
  eq('upstream is EMPTY for a controller handler (correct, not a failure)',
    feeders.upstream.length, 0);

  const feedersCapped = walkFeeders(cduRepoNow.bundle, CDU_GET_CUSTOMER, 1, {
    forward: cduRepoNow.forward,
    entryPoints: cduRepoNow.index.entryPointsBySymbol,
    logger: quiet,
  });
  eq('maxDepth 1 truncates the downstream chain before the repository',
    feedersCapped.downstream.map((n) => n.symbol), [CDU_GET_CUSTOMER, CDU_FIND_BY_ID]);

  /* ================= getEndpointAt / getInvocationAt ================= */
  section('getEndpointAt / getInvocationAt');
  const controllerFile = putBase.file;
  const lookupFile = pouRepo.index.invocations[0]?.file ?? '';
  eq('endpoint at CustomerController.java:34 is the PUT handler',
    getEndpointAt(cduRepoNow.bundle, controllerFile, 34, {
      endpointsByFile: cduRepoNow.index.endpointsByFile,
    })?.verb, 'PUT');
  eq('  at line 29 it is the GET handler',
    getEndpointAt(cduRepoNow.bundle, controllerFile, 29, {
      endpointsByFile: cduRepoNow.index.endpointsByFile,
    })?.path_template, '/api/v1/customers/{id}');
  eq('  at line 39 it is the addresses handler',
    getEndpointAt(cduRepoNow.bundle, controllerFile, 39, {
      endpointsByFile: cduRepoNow.index.endpointsByFile,
    })?.path_template, '/api/v1/customers/{id}/addresses');
  eq('  a body line just below the declaration still resolves to it',
    getEndpointAt(cduRepoNow.bundle, controllerFile, 35, {
      endpointsByFile: cduRepoNow.index.endpointsByFile,
    })?.verb, 'PUT');
  eq('  off-target line 900 returns null',
    getEndpointAt(cduRepoNow.bundle, controllerFile, 900, {
      endpointsByFile: cduRepoNow.index.endpointsByFile,
    }), null);
  eq('  an unknown file returns null',
    getEndpointAt(cduRepoNow.bundle, 'src/main/java/Nope.java', 29, {
      endpointsByFile: cduRepoNow.index.endpointsByFile,
    }), null);

  const invAt37 = getInvocationAt(pouBundle, lookupFile, 37, {
    invocationsByFile: pouRepo.index.invocationsByFile,
  });
  eq('invocation at CustomerLookupService.java:37 is fetchCustomer',
    invAt37?.enclosing_symbol, POU_FETCH);
  eq('  method_name', invAt37?.method_name, 'getForObject');
  eq('  at line 44 it is updateCustomer',
    getInvocationAt(pouBundle, lookupFile, 44, {
      invocationsByFile: pouRepo.index.invocationsByFile,
    })?.enclosing_symbol, POU_UPDATE);
  eq('  off-target line 900 returns null',
    getInvocationAt(pouBundle, lookupFile, 900, {
      invocationsByFile: pouRepo.index.invocationsByFile,
    }), null);

  /* ================= blastRadius ===================================== */
  section('blastRadius (end to end on the changed PUT)');
  const result: BlastRadiusResult = registry.blastRadius('cdu', ['pou', 'billing-gateway'], putBase.id, {
    changed: changedPut,
    logger: quiet,
  });

  const producer = result.producer_blast_radius;
  eq('changed_endpoint carried through', result.changed_endpoint.id, putBase.id);
  eq('producer repo', producer.repo, 'cdu');
  check('producer feeder_chains (downstream) populated', producer.feeder_chains.length >= 3,
    producer.feeder_chains.map((n) => `${n.depth}:${short(n.symbol)}`).join(' -> '));
  eq('  rooted at the changed handler', producer.feeder_chains[0]?.symbol, CDU_UPDATE_CUSTOMER);
  check('  reaches CustomerService.applyUpdate',
    producer.feeder_chains.some((n) => n.symbol.includes('applyUpdate')));
  check('  reaches CustomerRepository.save',
    producer.feeder_chains.some((n) => n.symbol.includes('CustomerRepository') && n.symbol.includes('save')));
  check('  reaches the kafka producer branch CustomerEventPublisher.publishCustomerUpdated',
    producer.feeder_chains.some((n) => n.symbol.includes('publishCustomerUpdated')));
  eq('  producer caller_chains (upstream) empty for a controller handler',
    producer.caller_chains.length, 0);
  eq('  total_affected_symbols counts distinct symbols',
    producer.total_affected_symbols,
    new Set([...producer.feeder_chains, ...producer.caller_chains].map((n) => n.symbol)).size);

  const pouRadius = result.consumer_blast_radius.find((c) => c.repo === 'pou');
  const missingRadius = result.consumer_blast_radius.find((c) => c.repo === 'billing-gateway');
  eq('every consumer is emitted, including the non-consuming one',
    result.consumer_blast_radius.map((c) => c.repo), ['billing-gateway', 'pou']);
  eq('  a consumer that is not loaded is reported consumed=false, not omitted',
    missingRadius?.consumed, false);
  check('POU consumed', pouRadius?.consumed === true, JSON.stringify(pouRadius?.phase1_signals));
  check('  direct_invocations non-empty', (pouRadius?.direct_invocations.length ?? 0) > 0,
    String(pouRadius?.direct_invocations.length));
  console.log('      POU caller_chains (flat edge list):');
  for (const edge of pouRadius?.caller_chains ?? []) {
    console.log(`        depth ${edge.depth}  ${short(edge.caller)} -> ${short(edge.callee)}  @${edge.file.split('/').pop()}:${edge.line}`);
  }
  const entrySymbols = (pouRadius?.entry_points ?? []).map((e) => e.symbol).sort();
  check('  BOTH entry points reached',
    entrySymbols.includes(POU_CREATE_ORDER) && entrySymbols.includes(POU_ON_EVENT),
    (pouRadius?.entry_points ?? []).map((e) => `${short(e.symbol)}[${e.entry_kind}]`).join(', '));
  check('  caller_chains carries every edge the webview needs to walk upward',
    (pouRadius?.caller_chains ?? []).some((e) => e.caller === POU_ENRICH && e.callee === POU_FETCH) &&
      (pouRadius?.caller_chains ?? []).some((e) => e.caller === POU_PROCESS && e.callee === POU_ENRICH) &&
      (pouRadius?.caller_chains ?? []).some((e) => e.caller === POU_CREATE_ORDER && e.callee === POU_PROCESS) &&
      (pouRadius?.caller_chains ?? []).some((e) => e.caller === POU_ON_EVENT && e.callee === POU_PROCESS));
  check('  total_affected_symbols > 0', (pouRadius?.total_affected_symbols ?? 0) > 0,
    String(pouRadius?.total_affected_symbols));

  section('blastRadius — unresolved aggregation');
  for (const u of result.unresolved_across_analysis) {
    console.log(`      ${u.what}  ${u.context.file.split('/').pop()}:${u.context.line}  ${u.reason.slice(0, 72)}`);
  }
  check('unresolved_across_analysis is non-empty', result.unresolved_across_analysis.length > 0,
    String(result.unresolved_across_analysis.length));
  check('  includes the prod Vault key services.cdu.api-key',
    result.unresolved_across_analysis.some(
      (u) => u.what === 'property_value' && u.partial_info['key'] === 'services.cdu.api-key',
    ));
  check('  includes the dynamically-resolved URL in EnrichmentService',
    result.unresolved_across_analysis.some(
      (u) => u.what === 'url' && u.context.file.endsWith('EnrichmentService.java'),
    ));

  section('blastRadius — result shape');
  let serialized = '';
  try {
    serialized = JSON.stringify(result);
    check('result is JSON-serializable', serialized.length > 0, `${serialized.length} bytes`);
  } catch (err) {
    check('result is JSON-serializable', false, String(err));
  }
  const roundTripped = JSON.parse(serialized) as BlastRadiusResult;
  check('  survives a JSON round trip unchanged', JSON.stringify(roundTripped) === serialized);

  const structural: string[] = [];
  const requireField = (present: boolean, name: string): void => {
    if (!present) {
      structural.push(name);
    }
  };
  const ce = roundTripped.changed_endpoint;
  for (const [name, value] of Object.entries(ce)) {
    requireField(value !== undefined, `changed_endpoint.${name}`);
  }
  requireField(Array.isArray(ce.diff_reason), 'changed_endpoint.diff_reason[]');
  requireField(Array.isArray(ce.diff_details), 'changed_endpoint.diff_details[]');
  const pr = roundTripped.producer_blast_radius;
  requireField(typeof pr.repo === 'string', 'producer.repo');
  requireField(Array.isArray(pr.feeder_chains), 'producer.feeder_chains[]');
  requireField(Array.isArray(pr.caller_chains), 'producer.caller_chains[]');
  requireField(typeof pr.total_affected_symbols === 'number', 'producer.total_affected_symbols');
  for (const node of [...pr.feeder_chains, ...pr.caller_chains]) {
    requireField(typeof node.symbol === 'string', 'ChainNode.symbol');
    requireField(typeof node.depth === 'number', 'ChainNode.depth');
    requireField(node.call_site !== undefined, 'ChainNode.call_site');
    requireField(typeof node.is_entry_point === 'boolean', 'ChainNode.is_entry_point');
    requireField(node.entry_kind !== undefined, 'ChainNode.entry_kind');
  }
  for (const consumer of roundTripped.consumer_blast_radius) {
    requireField(typeof consumer.repo === 'string', 'consumer.repo');
    requireField(typeof consumer.consumed === 'boolean', 'consumer.consumed');
    requireField(Array.isArray(consumer.phase1_signals), 'consumer.phase1_signals[]');
    requireField(Array.isArray(consumer.direct_invocations), 'consumer.direct_invocations[]');
    requireField(Array.isArray(consumer.caller_chains), 'consumer.caller_chains[]');
    requireField(Array.isArray(consumer.entry_points), 'consumer.entry_points[]');
    requireField(typeof consumer.total_affected_symbols === 'number', 'consumer.total_affected_symbols');
    for (const hit of consumer.direct_invocations) {
      requireField(typeof hit.invocation_id === 'string', 'InvocationHit.invocation_id');
      requireField(typeof hit.symbol === 'string', 'InvocationHit.symbol');
      requireField(typeof hit.file === 'string', 'InvocationHit.file');
      requireField(Array.isArray(hit.line_range) && hit.line_range.length === 2, 'InvocationHit.line_range');
      requireField(Array.isArray(hit.matched_via), 'InvocationHit.matched_via[]');
      requireField(typeof hit.confidence === 'number', 'InvocationHit.confidence');
      requireField(typeof hit.transport === 'string', 'InvocationHit.transport');
      requireField(typeof hit.method_name === 'string', 'InvocationHit.method_name');
      requireField(Array.isArray(hit.unresolved), 'InvocationHit.unresolved[]');
    }
    for (const edge of consumer.caller_chains) {
      requireField(typeof edge.caller === 'string', 'CallerEdge.caller');
      requireField(typeof edge.callee === 'string', 'CallerEdge.callee');
      requireField(typeof edge.file === 'string', 'CallerEdge.file');
      requireField(typeof edge.line === 'number', 'CallerEdge.line');
      requireField(typeof edge.depth === 'number', 'CallerEdge.depth');
    }
    for (const entry of consumer.entry_points) {
      requireField(typeof entry.symbol === 'string', 'entry_point.symbol');
      requireField(typeof entry.entry_kind === 'string', 'entry_point.entry_kind');
      requireField(entry.details !== undefined, 'entry_point.details');
    }
  }
  requireField(Array.isArray(roundTripped.unresolved_across_analysis), 'unresolved_across_analysis[]');
  check('  structurally matches BlastRadiusResult (no undefined where the webview expects a value)',
    structural.length === 0, structural.join(', '));

  const outFile = path.join(SCRATCH, 'blast-radius.json');
  fs.writeFileSync(outFile, JSON.stringify(result, null, 2) + '\n');
  check('  written to the scratchpad for diffing against fixtures/sample-blast-radius.json', true, outFile);

  /* ================= determinism of queries ========================== */
  section('Query determinism');
  const again = registry.blastRadius('cdu', ['pou', 'billing-gateway'], putBase.id, {
    changed: changedPut,
    logger: quiet,
  });
  check('two identical blastRadius calls produce byte-identical JSON',
    JSON.stringify(again) === serialized);

  /* ================= fail-open ======================================= */
  section('Fail-open behaviour');
  const emptyRegistry = new IndexRegistry(quiet);
  const emptyResult = blastRadius(emptyRegistry, 'nope', ['also-nope'], 'no-such-id', { logger: quiet });
  check('blastRadius against an empty registry returns a well-formed empty result',
    emptyResult.producer_blast_radius.feeder_chains.length === 0 &&
      emptyResult.consumer_blast_radius.length === 1 &&
      emptyResult.consumer_blast_radius[0]?.consumed === false &&
      emptyResult.unresolved_across_analysis.length === 0);
  eq('  and does not throw', typeof emptyResult.changed_endpoint.id, 'string');
  const missingBundle = loadBundle(path.join(SCRATCH, 'does-not-exist'), quiet);
  eq('walkCallers over an absent bundle returns []',
    walkCallers(missingBundle, POU_FETCH, 4, { logger: quiet }).length, 0);
  eq('detectChanges over absent paths returns []',
    detectChanges(path.join(SCRATCH, 'nope-a'), path.join(SCRATCH, 'nope-b'), { logger: quiet }).length, 0);
  const noForward = walkFeeders(pouBundle, POU_FETCH, 4, { logger: quiet });
  eq('walkFeeders with no forward index yields the seed only',
    noForward.downstream.map((n) => n.symbol), [POU_FETCH]);

  /* ================= reference data for the report =================== */
  section('Reference: changed-DTO record');
  const updateDto = (dtoB.byKind.dto as DtoRecord[]).find(
    (d) => d.fqn === 'com.acme.cdu.dto.UpdateCustomerRequest',
  );
  check('mutated UpdateCustomerRequest shape differs from the base',
    updateDto?.shape !== (base.byKind.dto as DtoRecord[]).find(
      (d) => d.fqn === 'com.acme.cdu.dto.UpdateCustomerRequest',
    )?.shape,
    `${(base.byKind.dto as DtoRecord[]).find((d) => d.fqn === 'com.acme.cdu.dto.UpdateCustomerRequest')?.shape} -> ${updateDto?.shape}`);

  /* ================= Summary ========================================= */
  console.log(`\n${failed === 0 ? 'ALL PASS' : 'FAILURES'}: ${passed} passed, ${failed} failed`);
}

main().catch((err) => {
  consoleLogger.log('QUERY', `daemon sanity run threw: ${String(err)}`);
  console.error(err);
  process.exitCode = 1;
});

/** Referenced so `ChangedEndpoint` stays imported for the structural assertions. */
export type { ChangedEndpoint };
