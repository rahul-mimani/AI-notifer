/**
 * Shared fixture-build helpers for the UI and demo sanity runs.
 *
 * Both suites need the same thing: a WRITABLE COPY of a fixture repo (so a run
 * can mutate sources to simulate an API change) built through the real
 * `buildIndex` against a `MockChatModelProvider` that serves the hand-authored
 * JSON in `fixtures/lm-responses/`.
 *
 * Nothing here imports vscode; these run under plain `node out/sanity/*.js`.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';

import { MockChatModelProvider } from '../lm/provider.js';
import { emptyExtraction } from '../lm/schema.js';
import type { BuildConfig } from '../coordinator/build.js';

export const REPO_ROOT = path.resolve(__dirname, '..', '..');
export const FIXTURES = path.join(REPO_ROOT, 'fixtures');
export const SCRATCH_ROOT =
  '/private/tmp/claude-501/-Users-rahulmimani-Documents-AI-notifer/9ca18e4b-6c95-419c-93f4-3d33304dc826/scratchpad';

export const BUILT_AT = '2026-01-01T00:00:00.000Z';

/** Recursively copy a directory tree. */
export function copyDir(src: string, dst: string): void {
  fs.mkdirSync(dst, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const from = path.join(src, entry.name);
    const to = path.join(dst, entry.name);
    if (entry.isDirectory()) {
      copyDir(from, to);
    } else if (entry.isFile()) {
      fs.copyFileSync(from, to);
    }
  }
}

/** The LM-response file for one source file, in a given response directory. */
export function responsePath(responseDir: string, relativePath: string): string {
  return path.join(responseDir, `${relativePath.split('/').join('__')}.json`);
}

/**
 * A provider serving `responseDir`. Files with no hand-authored response get an
 * empty extraction, which is a valid answer and keeps the build going.
 */
export function makeProvider(responseDir: string): MockChatModelProvider {
  return new MockChatModelProvider((_system, messages) => {
    const prompt = messages[0] ?? '';
    const match = /File path:\n(.+)\n/.exec(prompt);
    const relativePath = match?.[1]?.trim() ?? '';
    const file = responsePath(responseDir, relativePath);
    if (relativePath !== '' && fs.existsSync(file)) {
      return fs.readFileSync(file, 'utf8');
    }
    return JSON.stringify(emptyExtraction());
  });
}

/** The same build config `indexer-sanity.ts` uses, for parity. */
export function configFor(repo: 'cdu' | 'pou'): BuildConfig {
  return {
    packagePrefixes: [`com.acme.${repo}`],
    sourceRoots: ['src/main/java'],
    configServerPaths: [],
    configServerBranches: [],
    configMapPaths: repo === 'pou' ? [path.join(FIXTURES, 'configmap', 'pou-configmap.yaml')] : [],
    messageRouterMarkers: [],
    lmModel: 'mock-model',
    lmMaxConcurrent: 4,
    lmTimeoutSeconds: 60,
    lmTotalBudgetMinutes: 10,
    lmEnabled: true,
  };
}

export interface Workspace {
  /** Writable copy of `fixtures/<repo>`; bundles are written inside it. */
  root: string;
  /** Writable copy of `fixtures/lm-responses/<repo>`. */
  responseDir: string;
}

/**
 * Materialize a writable copy of a fixture repo plus its LM responses under
 * `scratch/<name>`, so a suite can mutate either without touching `fixtures/`.
 */
export function materialize(scratch: string, repo: 'cdu' | 'pou', name = repo): Workspace {
  const root = path.join(scratch, name);
  const responseDir = path.join(scratch, `${name}-lm-responses`);
  fs.rmSync(root, { recursive: true, force: true });
  fs.rmSync(responseDir, { recursive: true, force: true });
  copyDir(path.join(FIXTURES, repo), root);
  copyDir(path.join(FIXTURES, 'lm-responses', repo), responseDir);
  return { root, responseDir };
}

/**
 * Rewrite one LM response through `mutate`, AND touch the corresponding source
 * file so its content hash changes.
 *
 * The second half matters: the LM cache is keyed on a sha256 of the file text,
 * so editing only the canned response would be served from cache and the
 * "change" would never reach the bundle.
 */
export function mutateResponse(
  ws: Workspace,
  relativePath: string,
  mutate: (parsed: Record<string, unknown>) => void,
): void {
  const file = responsePath(ws.responseDir, relativePath);
  const parsed = JSON.parse(fs.readFileSync(file, 'utf8')) as Record<string, unknown>;
  mutate(parsed);
  fs.writeFileSync(file, JSON.stringify(parsed, null, 2));

  const source = path.join(ws.root, ...relativePath.split('/'));
  if (fs.existsSync(source)) {
    fs.appendFileSync(source, `\n// codeindex sanity mutation ${Date.now()}\n`);
  }
}

/** Simple assertion harness shared by both suites. */
export class Checks {
  passed = 0;
  failed = 0;

  check(label: string, ok: boolean, detail = ''): void {
    if (ok) {
      this.passed += 1;
      console.log(`PASS  ${label}${detail === '' ? '' : ` — ${detail}`}`);
    } else {
      this.failed += 1;
      process.exitCode = 1;
      console.log(`FAIL  ${label}${detail === '' ? '' : ` — ${detail}`}`);
    }
  }

  eq(label: string, actual: unknown, expected: unknown): void {
    const a = JSON.stringify(actual);
    const e = JSON.stringify(expected);
    this.check(label, a === e, a === e ? String(a) : `got ${a}, expected ${e}`);
  }

  section(name: string): void {
    console.log(`\n=== ${name} ===`);
  }

  summary(name: string): void {
    console.log(`\n${name}: ${this.passed} passed, ${this.failed} failed`);
  }
}
