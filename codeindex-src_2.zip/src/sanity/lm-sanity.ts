/**
 * Plain-Node sanity harness for the language-model layer.
 *
 * Runs entirely against MockChatModelProvider + an in-memory cache, so it works
 * on machines with no GitHub Copilot. `node out/sanity/lm-sanity.js`.
 */

import { consoleLogger, silentLogger } from '../util/logger.js';
import type { Logger, Stage } from '../util/logger.js';
import {
  MemoryLmCache,
  extractFile,
  extractFiles,
  hashContent,
} from '../lm/extractor.js';
import { LmRateLimitError, MockChatModelProvider } from '../lm/provider.js';
import type { ChatModelInfo } from '../lm/provider.js';
import { REPAIR_MESSAGE } from '../lm/prompts.js';
import { chunkJavaSource, scanBlocks } from '../lm/chunker.js';
import { validateExtraction } from '../lm/schema.js';

// ---------------------------------------------------------------------------
// Assertion plumbing
// ---------------------------------------------------------------------------

let passed = 0;
let failed = 0;

function check(name: string, condition: boolean, detail = ''): void {
  if (condition) {
    passed += 1;
    console.log(`PASS ${name}`);
  } else {
    failed += 1;
    console.log(`FAIL ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

function section(title: string): void {
  console.log(`\n--- ${title} ---`);
}

class RecordingLogger implements Logger {
  readonly lines: string[] = [];
  log(stage: Stage, message: string): void {
    this.lines.push(`[${stage}] ${message}`);
  }
  has(fragment: string): boolean {
    return this.lines.some((l) => l.includes(fragment));
  }
}

const MODEL: ChatModelInfo = { id: 'mock-gpt', maxInputTokens: 64000 };

// ---------------------------------------------------------------------------
// Fixture: a realistic Spring Boot controller
// ---------------------------------------------------------------------------

const CONTROLLER = `package com.acme.orders.web;

import com.acme.orders.dto.OrderRequest;
import com.acme.orders.dto.OrderResponse;
import com.acme.orders.service.OrderService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api/v1/orders")
public class OrderController {

    private final OrderService orderService;
    private final RestTemplate restTemplate;

    @Value("\${pricing.service.base-url}")
    private String pricingBaseUrl;

    public OrderController(OrderService orderService, RestTemplate restTemplate) {
        this.orderService = orderService;
        this.restTemplate = restTemplate;
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<OrderResponse> getOrder(@PathVariable String orderId,
                                                  @RequestParam(required = false) boolean includeItems,
                                                  @RequestHeader("X-Tenant-Id") String tenantId) {
        OrderResponse response = orderService.find(orderId, includeItems, tenantId);
        return ResponseEntity.ok(response);
    }

    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(@RequestBody OrderRequest request) {
        OrderResponse quoted = restTemplate.postForObject(pricingBaseUrl + "/quote", request, OrderResponse.class);
        return ResponseEntity.ok(orderService.create(quoted));
    }
}
`;

function lineOf(source: string, fragment: string): number {
  const lines = source.split('\n');
  const idx = lines.findIndex((l) => l.includes(fragment));
  if (idx === -1) {
    throw new Error(`fixture fragment not found: ${fragment}`);
  }
  return idx + 1;
}

const L_CLASS = lineOf(CONTROLLER, 'public class OrderController');
const L_VALUE = lineOf(CONTROLLER, 'private String pricingBaseUrl');
const L_GET = lineOf(CONTROLLER, 'public ResponseEntity<OrderResponse> getOrder');
const L_POST = lineOf(CONTROLLER, 'public ResponseEntity<OrderResponse> createOrder');
const L_CALL = lineOf(CONTROLLER, 'restTemplate.postForObject');

/** A realistic, schema-valid response for the fixture above. */
function validResponse(): string {
  return JSON.stringify({
    endpoints: [
      {
        transport: 'rest',
        verb: 'GET',
        path_template: '/api/v1/orders/{orderId}',
        destination: null,
        request_dto_fqn: null,
        response_dto_fqn: 'com.acme.orders.dto.OrderResponse',
        path_params: [{ name: 'orderId', type: 'java.lang.String' }],
        query_params: [{ name: 'includeItems', type: 'boolean', required: false }],
        headers: [{ name: 'X-Tenant-Id', type: 'java.lang.String', required: true }],
        // logical_name deliberately omitted: normalization must fill in null.
        handler_class_fqn: 'com.acme.orders.web.OrderController',
        handler_method_name: 'getOrder',
        handler_method_signature: '(Ljava/lang/String;ZLjava/lang/String;)Lorg/springframework/http/ResponseEntity;',
        handler_line: L_GET,
        annotations: {
          GetMapping: { value: '/{orderId}' },
          RequestMapping: { value: '/api/v1/orders' },
        },
        confidence: 0.95,
      },
      {
        transport: 'rest',
        verb: 'POST',
        path_template: '/api/v1/orders',
        destination: null,
        request_dto_fqn: 'com.acme.orders.dto.OrderRequest',
        response_dto_fqn: 'com.acme.orders.dto.OrderResponse',
        path_params: [],
        query_params: [],
        headers: [],
        logical_name: null,
        handler_class_fqn: 'com.acme.orders.web.OrderController',
        handler_method_name: 'createOrder',
        handler_method_signature: '(Lcom/acme/orders/dto/OrderRequest;)Lorg/springframework/http/ResponseEntity;',
        handler_line: L_POST,
        annotations: { PostMapping: {} },
        confidence: 0.93,
      },
    ],
    invocations: [
      {
        transport: 'rest',
        enclosing_class_fqn: 'com.acme.orders.web.OrderController',
        enclosing_method_name: 'createOrder',
        enclosing_method_signature:
          '(Lcom/acme/orders/dto/OrderRequest;)Lorg/springframework/http/ResponseEntity;',
        line: L_CALL,
        literal_url: null,
        path_fragment: '/quote',
        destination: null,
        request_dto_fqn: 'com.acme.orders.dto.OrderRequest',
        response_dto_fqn: 'com.acme.orders.dto.OrderResponse',
        client_bean: 'restTemplate',
        property_key_ref: 'pricing.service.base-url',
        logical_name: null,
        method_name: 'postForObject',
        confidence_hints: ['base url from @Value placeholder', 'literal path suffix'],
        unresolved: [
          {
            what: 'url',
            reason: 'base url comes from a property placeholder, not a literal',
            expression: 'pricingBaseUrl + "/quote"',
          },
        ],
        confidence: 0.8,
      },
    ],
    dtos: [],
    wirings: [
      {
        bean_name: 'pricingBaseUrl',
        bean_class_fqn: null,
        property_key: 'pricing.service.base-url',
        injection: '@Value',
        line: L_VALUE,
        defining_class_fqn: 'com.acme.orders.web.OrderController',
        confidence: 0.98,
      },
    ],
    property_bindings: [],
    method_calls: [
      {
        caller_class_fqn: 'com.acme.orders.web.OrderController',
        caller_method_signature:
          '(Lcom/acme/orders/dto/OrderRequest;)Lorg/springframework/http/ResponseEntity;',
        callee_class_fqn: 'org.springframework.web.client.RestTemplate',
        callee_method_name: 'postForObject',
        callee_signature_guess: '(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;',
        line: L_CALL,
        call_kind: 'direct',
      },
    ],
    unresolved: [],
  });
}

function baseOpts(provider: MockChatModelProvider, cache: MemoryLmCache, logger: Logger) {
  return {
    repoRoot: '/repo',
    relativePath: 'src/main/java/com/acme/orders/web/OrderController.java',
    content: CONTROLLER,
    provider,
    model: MODEL,
    cache,
    logger,
    markers: ['@MessageRouterHandler'],
    timeoutSeconds: 30,
  };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

async function testHappyPath(): Promise<void> {
  section('happy path');
  const provider = new MockChatModelProvider(() => validResponse());
  const cache = new MemoryLmCache();
  const logger = new RecordingLogger();
  const r = await extractFile(baseOpts(provider, cache, logger));

  check('happy: one provider call', provider.callCount === 1, `got ${provider.callCount}`);
  check('happy: no repair', r.repairAttempts === 0, `got ${r.repairAttempts}`);
  check('happy: two endpoints', r.extraction.endpoints.length === 2);
  check('happy: one invocation', r.extraction.invocations.length === 1);
  check('happy: one wiring', r.extraction.wirings.length === 1);
  check('happy: one method_call', r.extraction.method_calls.length === 1);
  check('happy: nothing discarded', r.discarded === 0, `got ${r.discarded}`);
  check(
    'happy: omitted nullable normalized to null',
    r.extraction.endpoints[0]?.logical_name === null,
  );
  check(
    'happy: handler line preserved',
    r.extraction.endpoints[0]?.handler_line === L_GET,
    `expected ${L_GET}`,
  );
  check('happy: raw cached under content hash', cache.entries.has(hashContent(CONTROLLER)));
  check('happy: class line found in fixture', L_CLASS > 0);
}

async function testFencedJson(): Promise<void> {
  section('markdown fences');
  const provider = new MockChatModelProvider(() => '```json\n' + validResponse() + '\n```');
  const r = await extractFile(baseOpts(provider, new MemoryLmCache(), silentLogger));
  check('fenced: accepted', r.extraction.endpoints.length === 2);
  check('fenced: NO repair round-trip', r.repairAttempts === 0, `got ${r.repairAttempts}`);
  check('fenced: exactly one call', provider.callCount === 1, `got ${provider.callCount}`);
}

async function testRepairSucceeds(): Promise<void> {
  section('one repair, then valid');
  let n = 0;
  const provider = new MockChatModelProvider(() => {
    n += 1;
    return n === 1 ? 'Sure! Here are the facts: {not json,,,' : validResponse();
  });
  const logger = new RecordingLogger();
  const r = await extractFile(baseOpts(provider, new MemoryLmCache(), logger));
  check('repair: exactly two calls', provider.callCount === 2, `got ${provider.callCount}`);
  check('repair: one repair attempt recorded', r.repairAttempts === 1);
  check(
    'repair: repair message sent verbatim',
    provider.calls[1]?.messages[2] === REPAIR_MESSAGE,
    JSON.stringify(provider.calls[1]?.messages[2]),
  );
  check('repair: prior output echoed back', provider.calls[1]?.messages.length === 3);
  check('repair: result usable', r.extraction.endpoints.length === 2);
  check('repair: no failure', r.failure === 'none', r.failure);
}

async function testRepairFails(): Promise<void> {
  section('two malformed responses');
  const provider = new MockChatModelProvider(() => 'still {{ not json');
  const logger = new RecordingLogger();
  let threw = false;
  let unresolvedWhat = '';
  try {
    const r = await extractFile(baseOpts(provider, new MemoryLmCache(), logger));
    unresolvedWhat = r.extraction.unresolved[0]?.what ?? '';
    check('double-fail: failure is parse', r.failure === 'parse', r.failure);
    check('double-fail: no endpoints', r.extraction.endpoints.length === 0);
  } catch {
    threw = true;
  }
  check('double-fail: did NOT throw', !threw);
  check('double-fail: exactly one repair (2 calls)', provider.callCount === 2, `got ${provider.callCount}`);
  check('double-fail: extraction_failed unresolved record', unresolvedWhat === 'extraction_failed', unresolvedWhat);
}

async function testSchemaRepairFails(): Promise<void> {
  section('two schema-invalid responses');
  // Parses fine every time, but violates the schema: unknown field + bad enum.
  const schemaInvalid = JSON.stringify({
    endpoints: [
      {
        transport: 'carrier_pigeon',
        verb: 'GET',
        handler_class_fqn: 'com.acme.orders.web.OrderController',
        handler_method_name: 'getOrder',
        handler_method_signature: '()V',
        handler_line: 1,
        vibes: 'immaculate',
      },
    ],
  });
  const provider = new MockChatModelProvider(() => schemaInvalid);
  const logger = new RecordingLogger();
  let threw = false;
  let unresolved: Array<{ what: string; reason: string }> = [];
  let failure = '';
  try {
    const r = await extractFile(baseOpts(provider, new MemoryLmCache(), logger));
    unresolved = r.extraction.unresolved;
    failure = r.failure;
    check('schema-fail: no endpoints kept', r.extraction.endpoints.length === 0);
  } catch {
    threw = true;
  }
  check('schema-fail: did NOT throw', !threw);
  check('schema-fail: exactly one repair (2 calls)', provider.callCount === 2, `got ${provider.callCount}`);
  check('schema-fail: repair message sent', provider.calls[1]?.messages[2] === REPAIR_MESSAGE);
  check('schema-fail: failure is schema', failure === 'schema', failure);
  check(
    'schema-fail: exactly one extraction_failed record',
    unresolved.length === 1 && unresolved[0]?.what === 'extraction_failed',
    JSON.stringify(unresolved),
  );
  check(
    'schema-fail: reason names schema validation',
    (unresolved[0]?.reason ?? '').includes('schema validation failed'),
    unresolved[0]?.reason,
  );
  check(
    'schema-fail: reason carries validator errors',
    (unresolved[0]?.reason ?? '').includes('vibes') ||
      (unresolved[0]?.reason ?? '').includes('transport'),
    unresolved[0]?.reason,
  );
  check('schema-fail: logged at [LM]', logger.has('[LM]') && logger.has('schema validation failed'));
}

function testSchemaViolations(): void {
  section('schema strictness');
  const unknownField = validateExtraction({
    endpoints: [
      {
        transport: 'rest',
        verb: 'GET',
        handler_class_fqn: 'A',
        handler_method_name: 'm',
        handler_method_signature: '()V',
        handler_line: 1,
        totally_made_up: 'nope',
      },
    ],
  });
  check('schema: unknown field rejected', !unknownField.ok);
  check(
    'schema: unknown-field error names the field',
    !unknownField.ok && unknownField.errors.some((e) => e.includes('totally_made_up')),
    !unknownField.ok ? unknownField.errors.join(' | ') : '',
  );

  const badEnum = validateExtraction({
    invocations: [
      {
        transport: 'carrier_pigeon',
        enclosing_class_fqn: 'A',
        enclosing_method_name: 'm',
        enclosing_method_signature: '()V',
        line: 3,
        method_name: 'send',
      },
    ],
  });
  check('schema: bad transport enum rejected', !badEnum.ok);
  check(
    'schema: enum error lists allowed values',
    !badEnum.ok && badEnum.errors.some((e) => e.includes('transport') && e.includes('kafka')),
    !badEnum.ok ? badEnum.errors.join(' | ') : '',
  );

  const badCallKind = validateExtraction({
    method_calls: [
      {
        caller_class_fqn: 'A',
        caller_method_signature: '()V',
        callee_class_fqn: 'B',
        callee_method_name: 'x',
        callee_signature_guess: null,
        line: 2,
        call_kind: 'telepathic',
      },
    ],
  });
  check('schema: bad call_kind rejected', !badCallKind.ok);

  const badInjection = validateExtraction({
    wirings: [{ bean_name: 'b', injection: '@Autowire', line: 1 }],
  });
  check('schema: bad injection rejected', !badInjection.ok);

  const missingArrays = validateExtraction({ endpoints: [] });
  check('schema: missing top-level arrays tolerated', missingArrays.ok);
  check(
    'schema: missing arrays default to empty',
    missingArrays.ok && missingArrays.value.method_calls.length === 0,
  );

  const wrongType = validateExtraction({ dtos: [{ fqn: 42, fields: [], line: 1 }] });
  check('schema: wrong primitive type rejected', !wrongType.ok);
}

async function testOutOfRangeLines(): Promise<void> {
  section('line-range verification');
  const total = CONTROLLER.split('\n').length;
  const bogus = JSON.parse(validResponse()) as Record<string, unknown>;
  (bogus['endpoints'] as Array<Record<string, unknown>>)[0]!['handler_line'] = total + 500;
  (bogus['invocations'] as Array<Record<string, unknown>>)[0]!['line'] = total + 900;
  const provider = new MockChatModelProvider(() => JSON.stringify(bogus));
  const logger = new RecordingLogger();
  const r = await extractFile(baseOpts(provider, new MemoryLmCache(), logger));
  check('range: two records discarded', r.discarded === 2, `got ${r.discarded}`);
  check('range: bad endpoint gone', r.extraction.endpoints.length === 1);
  check('range: bad invocation gone', r.extraction.invocations.length === 0);
  check('range: in-range records kept', r.extraction.wirings.length === 1);
  check('range: discard logged', logger.has('discarded endpoint') && logger.has('discarded invocation'));
}

async function testCacheHit(): Promise<void> {
  section('cache');
  const provider = new MockChatModelProvider(() => validResponse());
  const cache = new MemoryLmCache();
  const logger = new RecordingLogger();
  const first = await extractFile(baseOpts(provider, cache, logger));
  const callsAfterFirst = provider.callCount;
  const second = await extractFile(baseOpts(provider, cache, logger));

  check('cache: first run called the model', callsAfterFirst === 1);
  check('cache: first run not from cache', !first.fromCache);
  check('cache: second run from cache', second.fromCache);
  check(
    'cache: second run made ZERO provider calls',
    provider.callCount === callsAfterFirst,
    `callCount went ${callsAfterFirst} -> ${provider.callCount}`,
  );
  check('cache: cached result identical', JSON.stringify(second.extraction) === JSON.stringify(first.extraction));
  check('cache: hit logged', logger.has('cache hit'));
}

async function testConcurrencyCap(): Promise<void> {
  section('concurrency cap');
  const cap = 3;
  const provider = new MockChatModelProvider(async () => {
    for (let i = 0; i < 5; i += 1) {
      await new Promise<void>((r) => setImmediate(r));
    }
    return '{}';
  });
  const files = Array.from({ length: 9 }, (_, i) => ({
    relativePath: `src/main/java/F${i}.java`,
    content: `package p;\npublic class F${i} {\n    void m${i}() {}\n}\n`,
  }));
  const res = await extractFiles({
    repoRoot: '/repo',
    files,
    provider,
    model: MODEL,
    cache: new MemoryLmCache(),
    logger: silentLogger,
    markers: [],
    maxConcurrent: cap,
  });
  check('concurrency: all files processed', res.results.length === 9, `got ${res.results.length}`);
  check(
    `concurrency: max in-flight <= ${cap}`,
    provider.maxInFlight <= cap,
    `maxInFlight=${provider.maxInFlight}`,
  );
  check(
    'concurrency: actually ran in parallel',
    provider.maxInFlight > 1,
    `maxInFlight=${provider.maxInFlight}`,
  );
}

async function testBudgetExhaustion(): Promise<void> {
  section('wall-clock budget');
  let clock = 0;
  const provider = new MockChatModelProvider(() => {
    clock += 6 * 60_000; // each file burns 6 minutes of the 10-minute budget
    return '{}';
  });
  const logger = new RecordingLogger();
  const files = Array.from({ length: 4 }, (_, i) => ({
    relativePath: `src/main/java/B${i}.java`,
    content: `package p;\npublic class B${i} {}\n`,
  }));
  const progress: Array<{ done: number; total: number; cacheHits: number }> = [];
  const res = await extractFiles({
    repoRoot: '/repo',
    files,
    provider,
    model: MODEL,
    cache: new MemoryLmCache(),
    logger,
    markers: [],
    maxConcurrent: 1,
    totalBudgetMinutes: 10,
    now: () => clock,
    onProgress: (p) => progress.push(p),
  });
  check('budget: returned partial results', res.results.length === 2, `got ${res.results.length}`);
  check('budget: remaining files skipped', res.skipped.length === 2, `got ${res.skipped.length}`);
  check('budget: flagged exhausted', res.budgetExhausted);
  check('budget: warning logged', logger.has('budget of 10m exhausted'));
  check('budget: did not throw and progress reported', progress.length > 0);
  check(
    'budget: final progress covers every file',
    progress[progress.length - 1]?.done === 4,
    JSON.stringify(progress[progress.length - 1]),
  );
}

async function testRateLimitBackoff(): Promise<void> {
  section('rate-limit backoff');
  const provider = new MockChatModelProvider(() => {
    throw new LmRateLimitError('quota exceeded');
  });
  const sleeps: number[] = [];
  const logger = new RecordingLogger();
  const started = Date.now();
  const res = await extractFiles({
    repoRoot: '/repo',
    files: [{ relativePath: 'src/main/java/R.java', content: 'package p;\nclass R {}\n' }],
    provider,
    model: MODEL,
    cache: new MemoryLmCache(),
    logger,
    markers: [],
    maxConcurrent: 1,
    now: () => 0,
    sleep: async (ms) => {
      sleeps.push(ms);
    },
  });
  const elapsed = Date.now() - started;
  const rec = res.results[0];
  check('ratelimit: exponential delays', JSON.stringify(sleeps) === '[1000,2000,4000,8000,16000]', JSON.stringify(sleeps));
  check('ratelimit: never exceeded 30s cap', sleeps.every((s) => s <= 30_000));
  check('ratelimit: no real sleeping', elapsed < 2000, `elapsed=${elapsed}ms`);
  check('ratelimit: file marked rate_limit', rec?.failure === 'rate_limit', rec?.failure);
  check(
    'ratelimit: unresolved marker emitted',
    rec?.extraction.unresolved[0]?.what === 'extraction_failed',
  );
  check('ratelimit: skip logged', logger.has('backoff exhausted'));
}

// ---------------------------------------------------------------------------
// Chunker
// ---------------------------------------------------------------------------

const TRICKY = `package com.acme.tricky;

import java.util.List;

public class Alpha {
    private static final String CLOSE = "}";
    private static final String OPEN = "{";
    /* block comment with { and } braces */
    public String one() {
        String s = "{ nested } braces";
        // } this comment brace must be ignored
        return s + CLOSE + OPEN;
    }

    public String two() {
        char c = '}';
        char d = '{';
        return "" + c + d;
    }
}

class Beta {
    public void go() {
        // }
        String t = "}}}}";
        System.out.println(t);
    }
}
`;

function testChunker(): void {
  section('chunker');
  const blocks = scanBlocks(TRICKY);
  const classes = blocks.filter((b) => b.depth === 0);
  const alphaStart = lineOf(TRICKY, 'public class Alpha');
  const betaStart = lineOf(TRICKY, 'class Beta');
  check('chunker: found exactly two top-level classes', classes.length === 2, `got ${classes.length}`);
  check('chunker: Alpha start line', classes[0]?.startLine === alphaStart, `got ${classes[0]?.startLine} want ${alphaStart}`);
  check('chunker: Beta start line', classes[1]?.startLine === betaStart, `got ${classes[1]?.startLine} want ${betaStart}`);
  check(
    'chunker: Alpha ends before Beta (braces in strings/comments ignored)',
    (classes[0]?.endLine ?? 0) < betaStart,
    `Alpha endLine=${classes[0]?.endLine}`,
  );

  const members = blocks.filter(
    (b) => b.depth === 1 && b.startLine > alphaStart && b.endLine <= (classes[0]?.endLine ?? 0),
  );
  check('chunker: Alpha has two method blocks', members.length === 2, `got ${members.length}`);
  check(
    'chunker: method one() boundary',
    members[0]?.startLine === lineOf(TRICKY, 'public String one()'),
    `got ${members[0]?.startLine}`,
  );
  check(
    'chunker: method two() boundary',
    members[1]?.startLine === lineOf(TRICKY, 'public String two()'),
    `got ${members[1]?.startLine}`,
  );

  // Class-level split.
  const classChunks = chunkJavaSource(TRICKY, 120);
  check('chunker: splits into multiple chunks', classChunks.length >= 2, `got ${classChunks.length}`);
  check(
    'chunker: preserves original line numbers',
    verifyLineNumbers(TRICKY, classChunks),
  );
  check(
    'chunker: every source line covered at least once',
    coverage(TRICKY, classChunks),
  );

  // Method-level split: force a budget too small for a whole class.
  const methodChunks = chunkJavaSource(TRICKY, 60);
  check('chunker: method-level split produces more chunks', methodChunks.length >= classChunks.length, `${methodChunks.length} vs ${classChunks.length}`);
  check('chunker: method-level line numbers still original', verifyLineNumbers(TRICKY, methodChunks));

  // Small file: single chunk, untouched.
  const single = chunkJavaSource(TRICKY, 100000);
  check('chunker: fits-in-budget file is one chunk', single.length === 1);
  check('chunker: single chunk covers whole file', single[0]?.endLine === TRICKY.split('\n').length);
}

function verifyLineNumbers(source: string, chunks: Array<{ numberedSource: string }>): boolean {
  const lines = source.split('\n');
  for (const chunk of chunks) {
    for (const rendered of chunk.numberedSource.split('\n')) {
      const m = /^(\d+): (.*)$/s.exec(rendered);
      if (!m) {
        return false;
      }
      const n = Number(m[1]);
      if (lines[n - 1] !== m[2]) {
        return false;
      }
    }
  }
  return true;
}

function coverage(source: string, chunks: Array<{ lines: number[] }>): boolean {
  const seen = new Set<number>();
  for (const c of chunks) {
    for (const l of c.lines) {
      seen.add(l);
    }
  }
  return seen.size === source.split('\n').length;
}

// ---------------------------------------------------------------------------

export async function main(): Promise<void> {
  consoleLogger.log('LM', 'lm-sanity starting');
  await testHappyPath();
  await testFencedJson();
  await testRepairSucceeds();
  await testRepairFails();
  await testSchemaRepairFails();
  testSchemaViolations();
  await testOutOfRangeLines();
  await testCacheHit();
  await testConcurrencyCap();
  await testBudgetExhaustion();
  await testRateLimitBackoff();
  testChunker();

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) {
    process.exitCode = 1;
  }
}

void main().catch((err: unknown) => {
  console.error('lm-sanity crashed:', err);
  process.exitCode = 1;
});
