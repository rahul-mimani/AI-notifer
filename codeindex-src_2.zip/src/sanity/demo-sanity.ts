/**
 * Demo sanity run — the whole `codeindex.runDemo` flow, headless.
 *
 * This drives `runDemoPipeline` — the SAME function the command calls — against
 * writable copies of the fixture repos, with a `MockChatModelProvider` standing
 * in for Copilot. It is the proof that the demo's logic is correct on a machine
 * where the Extension Development Host cannot be launched: everything except the
 * two folder prompts and the webview `postMessage` is exercised for real.
 *
 * Four runs, in order, because the baseline behaviour is inherently sequential:
 *
 *   RUN 1  no baseline        -> picks the first endpoint, valid result, writes baseline
 *   RUN 2  DTO field retyped  -> `modified` + `dto_field_type_changed`
 *   RUN 3  path renamed       -> `modified` + `path_changed` (NOT add + remove)
 *   RUN 4  nothing touched    -> ZERO changes (proves the baseline was refreshed)
 *
 * RUN 3 is the load-bearing one: `endpointId` hashes the display path, so a
 * rename mints a new id and an id-only diff reports an unrelated add plus an
 * unrelated remove. Recovering `path_changed` requires `detectChanges` to
 * receive BOTH loaded bundles. If the demo ever regresses to passing bare
 * fingerprint paths, RUN 3 fails.
 *
 * Run:  npx tsc --outDir out && node out/sanity/demo-sanity.js
 */

import * as fs from 'node:fs';
import * as path from 'node:path';

import type { ChangedEndpoint, DtoRecord } from '../types.js';
import { silentLogger } from '../util/logger.js';
import { IndexRegistry } from '../daemon/daemon.js';
import { detectChanges } from '../daemon/changes.js';
import { writeBaseline } from '../ui/baseline.js';
import { demoNotification, runDemoPipeline } from '../ui/demo.js';
import type { DemoOutcome } from '../ui/demo.js';
import { validateBlastRadiusResult } from '../ui/pure.js';
import {
  BUILT_AT,
  Checks,
  FIXTURES,
  SCRATCH_ROOT,
  configFor,
  makeProvider,
  materialize,
  mutateResponse,
} from './fixture-build.js';
import type { Workspace } from './fixture-build.js';

const c = new Checks();
const SCRATCH = path.join(SCRATCH_ROOT, 'demo-sanity');

const CDU_API = 'src/main/java/com/acme/cdu/api/CustomerApi.java';
const CDU_CONTROLLER = 'src/main/java/com/acme/cdu/controller/CustomerController.java';
const CDU_UPDATE_REQ = 'src/main/java/com/acme/cdu/dto/UpdateCustomerRequest.java';

interface Endpointish {
  path_template?: string;
  annotations?: Record<string, { value?: string }>;
}

/** One demo run against the two writable fixture copies. */
async function runOnce(
  cdu: Workspace,
  pou: Workspace,
  registry = new IndexRegistry(silentLogger),
): Promise<DemoOutcome | null> {
  return runDemoPipeline({
    producer: {
      root: cdu.root,
      repo: 'cdu',
      config: configFor('cdu'),
      provider: makeProvider(cdu.responseDir),
    },
    consumer: {
      root: pou.root,
      repo: 'pou',
      config: configFor('pou'),
      provider: makeProvider(pou.responseDir),
    },
    registry,
    logger: silentLogger,
    builtAt: BUILT_AT,
    maxDepth: 4,
  });
}

function reasonsOf(changes: readonly ChangedEndpoint[], kind: string): string[] {
  return changes.filter((x) => x.change_kind === kind).flatMap((x) => x.diff_reason);
}

async function main(): Promise<void> {
  fs.rmSync(SCRATCH, { recursive: true, force: true });
  fs.mkdirSync(SCRATCH, { recursive: true });

  const cdu = materialize(SCRATCH, 'cdu');
  const pou = materialize(SCRATCH, 'pou');

  /* ================================================================= *
   * RUN 1 — first run, no baseline
   * ================================================================= */
  c.section('RUN 1 — first run, no baseline');
  const registry1 = new IndexRegistry(silentLogger);
  const run1 = await runOnce(cdu, pou, registry1);
  c.check('the demo produced an outcome', run1 !== null, '');
  if (run1 === null) {
    c.summary('demo-sanity');
    return;
  }

  c.eq('no baseline existed', run1.hadBaseline, false);
  c.eq('change detection was skipped', run1.changes.length, 0);
  c.eq('no change was selected', run1.selectedChange, null);
  c.check('an endpoint was still selected', run1.selectedEndpointId !== '', run1.selectedEndpointId);
  c.eq('the LM path ran (not deterministic-only)', run1.deterministicOnly, false);

  /* --- the payload the webview would receive ------------------------ */
  c.section('RUN 1 — webview payload');
  const payload = run1.result;
  c.eq('payload is a structurally valid BlastRadiusResult', validateBlastRadiusResult(payload), []);
  c.eq('changed_endpoint.id matches the selection', payload.changed_endpoint.id, run1.selectedEndpointId);
  c.eq('producer repo is cdu', payload.producer_blast_radius.repo, 'cdu');
  c.eq('exactly one consumer was analysed', payload.consumer_blast_radius.length, 1);

  c.check(
    'pou is present in the result even when not consumed',
    payload.consumer_blast_radius.some((x) => x.repo === 'pou'),
    '',
  );
  c.check(
    'the producer feeder chain is populated',
    payload.producer_blast_radius.feeder_chains.length > 0,
    `${payload.producer_blast_radius.feeder_chains.length} node(s)`,
  );
  c.check(
    'the demo notification is well formed',
    /^Demo complete — \d+ changed endpoints, \d+ consumers impacted\.$/.test(demoNotification(run1)),
    demoNotification(run1),
  );

  /* ================================================================= *
   * RUN 1 — the cross-repo payload, for an endpoint POU actually calls
   * -----------------------------------------------------------------
   * The demo's no-baseline fallback is "first endpoint in endpoints.jsonl",
   * per spec — and in these fixtures that is CDU's KAFKA publish endpoint,
   * which POU does not consume. The cross-repo assertions below therefore
   * target the REST endpoint POU really calls, computed through the SAME
   * registry the demo just populated, so this still exercises the demo's
   * loaded state end to end.
   * ================================================================= */
  c.section('RUN 1 — cross-repo payload for a consumed REST endpoint');
  const restEndpoint = registry1
    .get('cdu')
    ?.bundle.endpoints.find((e) => e.transport === 'rest' && e.verb === 'GET' && e.path_template === '/api/v1/customers/{id}');
  c.check('cdu exposes GET /api/v1/customers/{id}', restEndpoint !== undefined, restEndpoint?.id ?? 'none');

  const restResult = registry1.blastRadius('cdu', ['pou'], restEndpoint?.id ?? '', { logger: silentLogger });
  c.eq('the REST payload is structurally valid', validateBlastRadiusResult(restResult), []);

  const pouRadius = restResult.consumer_blast_radius.find((x) => x.repo === 'pou');
  c.check('pou is present in the result', pouRadius !== undefined, '');
  c.eq('POU IS CONSUMED', pouRadius?.consumed, true);
  c.check(
    'pou has at least one direct invocation',
    (pouRadius?.direct_invocations.length ?? 0) >= 1,
    `${pouRadius?.direct_invocations.length ?? 0} invocation(s)`,
  );
  c.check(
    'phase-1 signals are reported',
    (pouRadius?.phase1_signals.length ?? 0) > 0,
    pouRadius?.phase1_signals.join(', ') ?? '',
  );

  const entryKinds = (pouRadius?.entry_points ?? []).map((e) => e.entry_kind).sort();
  c.check(
    'BOTH entry points are reached (REST controller + Kafka listener)',
    entryKinds.includes('rest_controller') && entryKinds.includes('kafka_listener'),
    entryKinds.join(', '),
  );
  c.check(
    'the caller chain is a non-empty edge list',
    (pouRadius?.caller_chains.length ?? 0) > 0,
    `${pouRadius?.caller_chains.length ?? 0} edge(s)`,
  );

  /* --- step 6: the caller advances the baseline --------------------- */
  c.section('RUN 1 — baseline written on success');
  const written1 = writeBaseline(run1.producerBundleRoot, silentLogger);
  c.check('fingerprints.prev.jsonl written', written1.fingerprints > 0, `${written1.fingerprints}`);
  c.check('endpoints.prev.jsonl written', written1.endpoints > 0, `${written1.endpoints}`);
  c.check('dtos.prev.jsonl written', written1.dtos > 0, `${written1.dtos}`);
  for (const f of ['fingerprints.prev.jsonl', 'endpoints.prev.jsonl', 'dtos.prev.jsonl']) {
    c.check(`${f} exists on disk`, fs.existsSync(path.join(cdu.root, '.codeindex', f)), '');
  }

  /* ================================================================= *
   * RUN 2 — a DTO field changes type
   * ================================================================= */
  c.section('RUN 2 — DTO field retyped');
  mutateResponse(cdu, CDU_UPDATE_REQ, (parsed) => {
    const dtos = parsed['dtos'] as Array<{ fields: Array<{ name: string; type: string }> }>;
    const field = dtos[0]?.fields.find((f) => f.name === 'displayName');
    if (field !== undefined) {
      field.type = 'java.lang.CharSequence';
    }
  });

  const run2 = await runOnce(cdu, pou);
  c.check('run 2 produced an outcome', run2 !== null, '');
  if (run2 !== null) {
    c.eq('run 2 saw a baseline', run2.hadBaseline, true);
    c.check('run 2 detected changes', run2.changes.length > 0, `${run2.changes.length} change(s)`);

    const modified = run2.changes.filter((x) => x.change_kind === 'modified');
    c.check('the change is reported as modified', modified.length > 0, modified.map((m) => m.id).join(','));

    const allReasons = reasonsOf(run2.changes, 'modified');
    c.check(
      'dto_field_type_changed fired (needs the OLD dto records)',
      allReasons.includes('dto_field_type_changed'),
      allReasons.join(', '),
    );
    c.check(
      'request_dto_shape_changed fired alongside it',
      allReasons.includes('request_dto_shape_changed'),
      allReasons.join(', '),
    );

    const detail = modified
      .flatMap((m) => m.diff_details)
      .find((d) => d.field.endsWith('.displayName'));
    c.check('the before/after field types are reported', detail !== undefined, JSON.stringify(detail));
    c.eq('before type', detail?.before, 'java.lang.String');
    c.eq('after type', detail?.after, 'java.lang.CharSequence');

    c.eq('the selected change is the modified one', run2.selectedChange?.change_kind, 'modified');
    c.eq('run 2 payload is valid', validateBlastRadiusResult(run2.result), []);

    writeBaseline(run2.producerBundleRoot, silentLogger);
  }

  /* ================================================================= *
   * RUN 3 — a path is renamed
   * ================================================================= */
  c.section('RUN 3 — path renamed (the add+remove trap)');
  // NOTE: `normalizeRepo` composes the display path from the MAPPING
  // ANNOTATIONS (class-level @RequestMapping + method-level @GetMapping), not
  // from the response's `path_template` field. Renaming only the latter changes
  // nothing in the bundle — so the annotation is what has to move. Both the
  // interface and the controller copies are updated, because the dedupe keeps
  // the controller as canonical and would otherwise see two different paths.
  const renamePath = (parsed: Record<string, unknown>): void => {
    const endpoints = parsed['endpoints'] as Endpointish[];
    for (const ep of endpoints) {
      const mapping = ep.annotations?.['GetMapping'];
      if (mapping !== undefined && mapping.value === '/{id}/addresses') {
        mapping.value = '/{id}/postal-addresses';
        ep.path_template = '/api/v1/customers/{id}/postal-addresses';
      }
    }
  };
  mutateResponse(cdu, CDU_API, renamePath);
  mutateResponse(cdu, CDU_CONTROLLER, renamePath);

  const run3 = await runOnce(cdu, pou);
  c.check('run 3 produced an outcome', run3 !== null, '');
  if (run3 !== null) {
    const kinds = run3.changes.map((x) => x.change_kind).sort();
    c.check('run 3 detected changes', run3.changes.length > 0, kinds.join(','));

    const renamed = run3.changes.find((x) => x.diff_reason.includes('path_changed'));
    c.check('a path_changed reason was emitted at all', renamed !== undefined, kinds.join(','));
    c.eq('THE RENAME IS `modified`, NOT add+remove', renamed?.change_kind, 'modified');

    const pathDetail = renamed?.diff_details.find((d) => d.field === 'path_template');
    c.eq('before path', pathDetail?.before, '/api/v1/customers/{id}/addresses');
    c.eq('after path', pathDetail?.after, '/api/v1/customers/{id}/postal-addresses');

    c.check(
      'the rename did NOT leak an unpaired added endpoint',
      !run3.changes.some((x) => x.change_kind === 'added' && x.path_template?.includes('addresses') === true),
      kinds.join(','),
    );
    c.check(
      'the rename did NOT leak an unpaired removed endpoint',
      !run3.changes.some((x) => x.change_kind === 'removed' && x.path_template?.includes('addresses') === true),
      kinds.join(','),
    );
    c.eq('run 3 payload is valid', validateBlastRadiusResult(run3.result), []);

    writeBaseline(run3.producerBundleRoot, silentLogger);
  }

  /* ================================================================= *
   * RUN 4 — nothing changed
   * ================================================================= */
  c.section('RUN 4 — baseline refreshed, nothing changed');
  const run4 = await runOnce(cdu, pou);
  c.check('run 4 produced an outcome', run4 !== null, '');
  if (run4 !== null) {
    c.eq('run 4 saw a baseline', run4.hadBaseline, true);
    c.eq(
      'ZERO changes against an unchanged repo (proves the baseline advanced)',
      run4.changes.length,
      0,
    );
    c.eq('with no changes, the first endpoint is analysed', run4.selectedChange, null);
    c.eq('run 4 payload is still valid', validateBlastRadiusResult(run4.result), []);
    c.check(
      'run 4 still reports on pou',
      run4.result.consumer_blast_radius.some((x) => x.repo === 'pou'),
      '',
    );
  }

  /* ================================================================= *
   * The change-list sample the webview harness renders
   * ================================================================= */
  c.section('change-list sample for the webview harness');
  // Regenerate fixtures/sample-change-list.json from a REAL detectChanges run
  // (the coordinator's rule: never hand-author webview sample data).
  // Union of the DTO-retype run and the path-rename run, so the harness shows
  // both a diff_details table and a path_changed row.
  const sampleChanges = [...(run2?.changes ?? []), ...(run3?.changes ?? [])];
  const samplePath = path.join(FIXTURES, 'sample-change-list.json');
  fs.writeFileSync(samplePath, `${JSON.stringify(sampleChanges, null, 2)}\n`);
  c.check('sample-change-list.json regenerated', fs.existsSync(samplePath), `${sampleChanges.length} change(s)`);
  c.check('the sample is non-empty', sampleChanges.length > 0, `${sampleChanges.length}`);
  c.check(
    'every sample entry has the fields the change-list renderer reads',
    sampleChanges.every(
      (x) =>
        typeof x.id === 'string' &&
        typeof x.change_kind === 'string' &&
        Array.isArray(x.diff_reason) &&
        Array.isArray(x.diff_details),
    ),
    '',
  );

  /* ================================================================= *
   * Degraded baseline: fingerprints only
   * ================================================================= */
  c.section('degraded baseline (fingerprints only)');
  // Deleting the endpoint/dto snapshots must degrade the diff, not break it.
  const prevEndpoints = path.join(cdu.root, '.codeindex', 'endpoints.prev.jsonl');
  const prevDtos = path.join(cdu.root, '.codeindex', 'dtos.prev.jsonl');
  fs.rmSync(prevEndpoints, { force: true });
  fs.rmSync(prevDtos, { force: true });
  const run5 = await runOnce(cdu, pou);
  c.check('a fingerprints-only baseline still completes', run5 !== null, '');
  if (run5 !== null) {
    c.eq('and still yields a valid payload', validateBlastRadiusResult(run5.result), []);
  }

  /* ================================================================= *
   * detectChanges bundle-passing, asserted directly
   * ================================================================= */
  c.section('detectChanges degrades without bundles');
  const registry = new IndexRegistry(silentLogger);
  const newBundle = registry.load(cdu.root, silentLogger, 'cdu').bundle;
  const oldFingerprints = JSON.parse(
    JSON.stringify(newBundle.fingerprints),
  ) as Array<{ id: string; path_template: string | null }>;
  const target = oldFingerprints.find((f) => f.path_template?.includes('addresses') === true);
  if (target !== undefined) {
    target.path_template = '/api/v0/customers/{id}/addresses';
    target.id = `${target.id}-old`;
  }
  const withoutBundles = detectChanges(oldFingerprints as never, newBundle.fingerprints, {
    logger: silentLogger,
  });
  const withBundles = detectChanges(oldFingerprints as never, newBundle.fingerprints, {
    oldBundle: null,
    newBundle,
    logger: silentLogger,
  });
  c.check(
    'without bundles a rename reads as add+remove',
    withoutBundles.some((x) => x.change_kind === 'added') &&
      withoutBundles.some((x) => x.change_kind === 'removed'),
    withoutBundles.map((x) => x.change_kind).join(','),
  );
  c.check(
    'the new-side bundle alone is not enough either (the OLD one carries handler_symbol)',
    withBundles.length > 0,
    withBundles.map((x) => x.change_kind).join(','),
  );

  /* --- dto record availability -------------------------------------- */
  const dtoCount = (newBundle.byKind.dto as DtoRecord[]).length;
  c.check('the producer bundle carries dto records to diff against', dtoCount > 0, `${dtoCount}`);

  c.summary('demo-sanity');
}

void main().catch((err: unknown) => {
  console.error(err);
  process.exitCode = 1;
});
