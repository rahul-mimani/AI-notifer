/**
 * Indexer sanity run — the real proof for normalize / callgraph / build.
 *
 * Builds BOTH fixture repos end to end against a MockChatModelProvider that
 * serves the hand-authored JSON in `fixtures/lm-responses/`, then asserts the
 * ground truth in `fixtures/expected.json`.
 *
 * Bundles are written to the scratchpad, never into fixtures/.
 *
 * Run:  npx tsc --outDir out && node out/sanity/indexer-sanity.js
 */

import * as fs from 'node:fs';
import * as path from 'node:path';

import type { DtoRecord, Env, InvocationRecord, PropertyRecord, UnresolvedRecord } from '../types.js';
import { consoleLogger, silentLogger } from '../util/logger.js';
import type { Logger } from '../util/logger.js';
import { MockChatModelProvider } from '../lm/provider.js';
import { emptyExtraction } from '../lm/schema.js';
import { buildIndex, FORWARD_CALLGRAPH_FILE } from '../coordinator/build.js';
import type { BuildConfig, BuildIndexResult } from '../coordinator/build.js';
import { normalizeRepo } from '../extractor/normalize.js';
import { computeDtoShapes } from '../extractor/shapes.js';
import { symbolId } from '../extractor/ids.js';
import { lookupResolved, valueFragments } from '../extractor/properties/resolve.js';
import { loadBundle } from '../store/index.js';
import { buildCallgraph } from '../extractor/callgraph.js';
import type { ForwardAdjacency } from '../extractor/callgraph.js';

/* ------------------------------------------------------------------ *
 * Harness
 * ------------------------------------------------------------------ */

let passed = 0;
let failed = 0;

function check(label: string, ok: boolean, detail = ''): void {
  if (ok) {
    passed += 1;
    console.log(`PASS  ${label}${detail === '' ? '' : ` — ${detail}`}`);
  } else {
    failed += 1;
    process.exitCode = 1;
    console.log(`FAIL  ${label}${detail === '' ? '' : ` — ${detail}`}`);
  }
}

function eq(label: string, actual: unknown, expected: unknown): void {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  check(label, a === e, a === e ? String(a) : `got ${a}, expected ${e}`);
}

function section(name: string): void {
  console.log(`\n=== ${name} ===`);
}

/* ------------------------------------------------------------------ *
 * Paths
 * ------------------------------------------------------------------ */

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const FIXTURES = path.join(REPO_ROOT, 'fixtures');
const SCRATCH_ROOT =
  '/private/tmp/claude-501/-Users-rahulmimani-Documents-AI-notifer/9ca18e4b-6c95-419c-93f4-3d33304dc826/scratchpad';
/** Own subdirectory: the scratchpad root is shared and must never be wiped. */
const SCRATCH = path.join(SCRATCH_ROOT, 'indexer-sanity');

const expected = JSON.parse(
  fs.readFileSync(path.join(FIXTURES, 'expected.json'), 'utf8'),
) as ExpectedJson;

interface ExpectedRestEndpoint {
  verb: string;
  path_template: string;
  path_template_normalized: string;
  canonical_handler_class_fqn: string;
  declaring_interface_fqn?: string;
}
interface ExpectedJson {
  repos: Record<
    string,
    {
      endpoint_count: { rest: number; kafka: number; total: number };
      rest_endpoints: ExpectedRestEndpoint[];
    }
  >;
  resolved_properties: Record<string, Record<string, Record<string, unknown>>>;
}

/* ------------------------------------------------------------------ *
 * Mock provider serving the hand-authored LM responses
 * ------------------------------------------------------------------ */

function fixtureResponsePath(repo: string, relativePath: string): string {
  return path.join(FIXTURES, 'lm-responses', repo, `${relativePath.split('/').join('__')}.json`);
}

function makeProvider(repo: string): MockChatModelProvider {
  return new MockChatModelProvider((_system, messages) => {
    const prompt = messages[0] ?? '';
    const match = /File path:\n(.+)\n/.exec(prompt);
    const relativePath = match?.[1]?.trim() ?? '';
    const file = fixtureResponsePath(repo, relativePath);
    if (relativePath !== '' && fs.existsSync(file)) {
      return fs.readFileSync(file, 'utf8');
    }
    // No hand-authored response for this file — an empty extraction is a valid
    // answer and keeps the build going.
    return JSON.stringify(emptyExtraction());
  });
}

function configFor(repo: 'cdu' | 'pou'): BuildConfig {
  return {
    packagePrefixes: [`com.acme.${repo}`],
    sourceRoots: ['src/main/java'],
    configServerPaths: [],
    configServerBranches: [],
    configMapPaths:
      repo === 'pou' ? [path.join(FIXTURES, 'configmap', 'pou-configmap.yaml')] : [],
    messageRouterMarkers: [],
    lmModel: 'mock-model',
    lmMaxConcurrent: 4,
    lmTimeoutSeconds: 60,
    lmTotalBudgetMinutes: 10,
    lmEnabled: true,
  };
}

const BUILT_AT = '2026-01-01T00:00:00.000Z';

async function build(
  repo: 'cdu' | 'pou',
  outDirName: string,
  logger: Logger,
  overrides: Partial<BuildConfig> = {},
  provider = makeProvider(repo),
): Promise<{ result: BuildIndexResult; outputRoot: string; provider: MockChatModelProvider }> {
  const outputRoot = path.join(SCRATCH, outDirName);
  const result = await buildIndex({
    repoRoot: path.join(FIXTURES, repo),
    repo,
    provider,
    model: 'mock-model',
    config: { ...configFor(repo), ...overrides },
    logger,
    builtAt: BUILT_AT,
    outputRoot,
  });
  return { result, outputRoot, provider };
}

/* ------------------------------------------------------------------ *
 * Helpers
 * ------------------------------------------------------------------ */

function listFiles(dir: string): string[] {
  const out: string[] = [];
  const walk = (d: string, prefix: string): void => {
    for (const e of fs.readdirSync(d, { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = prefix === '' ? e.name : `${prefix}/${e.name}`;
      if (e.isDirectory()) {
        walk(path.join(d, e.name), rel);
      } else {
        out.push(rel);
      }
    }
  };
  walk(dir, '');
  return out.sort();
}

function chainExists(forward: ForwardAdjacency, chain: string[]): boolean {
  for (let i = 0; i + 1 < chain.length; i++) {
    const sites = forward[chain[i]!] ?? [];
    if (!sites.some((s) => s.callee === chain[i + 1])) {
      return false;
    }
  }
  return true;
}

function sym(repo: string, fqn: string, sig: string): string {
  return symbolId(repo, fqn, sig);
}

/* ------------------------------------------------------------------ *
 * Main
 * ------------------------------------------------------------------ */

async function main(): Promise<void> {
  fs.rmSync(SCRATCH, { recursive: true, force: true });
  fs.mkdirSync(SCRATCH, { recursive: true });

  const quiet = silentLogger;

  /* ================= CDU ============================================= */
  section('CDU build (producer)');
  const cdu = await build('cdu', 'cdu-1', quiet);
  const cduEndpoints = cdu.result.endpoints;
  const cduRest = cduEndpoints.filter((e) => e.transport === 'rest');
  const cduKafka = cduEndpoints.filter((e) => e.transport === 'kafka');

  eq('CDU rest endpoint count after interface/impl dedupe', cduRest.length, expected.repos['cdu']!.endpoint_count.rest);
  eq('CDU kafka endpoint count', cduKafka.length, expected.repos['cdu']!.endpoint_count.kafka);
  eq('CDU total endpoint count', cduEndpoints.length, expected.repos['cdu']!.endpoint_count.total);

  section('CDU interface/impl reconciliation');
  for (const exp of expected.repos['cdu']!.rest_endpoints) {
    const ep = cduRest.find(
      (e) => e.verb === exp.verb && e.path_template === exp.path_template,
    );
    if (!ep) {
      check(`CDU endpoint ${exp.verb} ${exp.path_template} present`, false);
      continue;
    }
    check(`CDU endpoint ${exp.verb} ${exp.path_template} present`, true);
    check(
      `  handler_symbol is CustomerController, not CustomerApi`,
      ep.handler_symbol.includes(exp.canonical_handler_class_fqn) &&
        !ep.handler_symbol.includes('CustomerApi'),
      ep.handler_symbol,
    );
    const declaring = (ep.annotations['declaring_type'] ?? {})['fqn'];
    eq(`  declaring interface retained`, declaring, exp.declaring_interface_fqn);
    eq(`  path_template_normalized`, ep.path_template_normalized, exp.path_template_normalized);
    check(
      `  canonical file is the controller`,
      ep.file.includes('controller/CustomerController.java'),
      ep.file,
    );
  }

  const cduKafkaEp = cduKafka[0];
  check(
    'CDU kafka endpoint destination is the raw ${cdu.events.topic}',
    cduKafkaEp?.destination === '${cdu.events.topic}',
    String(cduKafkaEp?.destination),
  );
  check(
    'CDU manifest destinations carry both resolved topics',
    cdu.result.manifest.destinations.includes('customer-events') &&
      cdu.result.manifest.destinations.includes('customer-events-prod'),
    cdu.result.manifest.destinations.join(', '),
  );

  /* ================= POU ============================================= */
  section('POU build (consumer)');
  const pou = await build('pou', 'pou-1', quiet);
  const pouEndpoints = pou.result.endpoints;
  eq('POU rest endpoint count', pouEndpoints.filter((e) => e.transport === 'rest').length, 1);
  eq('POU kafka endpoint count', pouEndpoints.filter((e) => e.transport === 'kafka').length, 1);

  /* ================= DTO shapes ====================================== */
  section('DTO shape join (the single most important assertion)');
  const cduDtos = cdu.result.records.filter((r): r is DtoRecord => r.kind === 'dto');
  const pouDtos = pou.result.records.filter((r): r is DtoRecord => r.kind === 'dto');
  const cduCustomer = cduDtos.find((d) => d.fqn === 'com.acme.cdu.dto.CustomerDto');
  const pouCustomer = pouDtos.find((d) => d.fqn === 'com.acme.pou.dto.CustomerDto');

  check('CDU CustomerDto record present', cduCustomer !== undefined);
  check('POU CustomerDto record present', pouCustomer !== undefined);
  check(
    'CustomerDto shape hashes MATCH across repos despite different FQNs',
    cduCustomer !== undefined && cduCustomer.shape === pouCustomer?.shape,
    `cdu=${cduCustomer?.shape} pou=${pouCustomer?.shape}`,
  );
  console.log(`      shared CustomerDto shape hash: ${cduCustomer?.shape}`);

  for (const [c, p] of [
    ['com.acme.cdu.dto.AddressDto', 'com.acme.pou.dto.AddressDto'],
    ['com.acme.cdu.dto.UpdateCustomerRequest', 'com.acme.pou.dto.UpdateCustomerRequest'],
  ] as const) {
    const cs = cduDtos.find((d) => d.fqn === c)?.shape;
    const ps = pouDtos.find((d) => d.fqn === p)?.shape;
    check(`${c.split('.').pop()} shape matches across repos`, cs !== undefined && cs === ps, String(cs));
  }

  // The transient field must be excluded: recomputing the universe with
  // `cacheKey` physically removed must yield the identical hash.
  const asInputs = (dtos: DtoRecord[], dropCacheKey: boolean) =>
    dtos.map((d) => ({
      fqn: d.fqn,
      fields: d.fields
        .filter((f) => !(dropCacheKey && f.name === 'cacheKey'))
        .map((f) => ({
          name: f.name,
          type: f.type,
          nullable: f.nullable,
          modifiers: [...f.annotations],
        })),
    }));
  const withTransient = computeDtoShapes(asInputs(cduDtos, false));
  const withoutField = computeDtoShapes(asInputs(cduDtos, true));
  check(
    'transient cacheKey is excluded from the shape hash',
    withTransient.get('com.acme.cdu.dto.CustomerDto')?.shape ===
      withoutField.get('com.acme.cdu.dto.CustomerDto')?.shape,
    String(withTransient.get('com.acme.cdu.dto.CustomerDto')?.shape),
  );
  check(
    'cacheKey is still recorded on the DtoRecord (only the hash drops it)',
    cduCustomer?.fields.some((f) => f.name === 'cacheKey' && f.annotations.includes('transient')) === true,
  );

  /* ================= Property enrichment ============================= */
  section('Property enrichment of invocations');
  const pouInvocations = pou.result.records.filter(
    (r): r is InvocationRecord => r.kind === 'invocation',
  );
  const fetchCustomer = pouInvocations.find(
    (i) => i.file.endsWith('CustomerLookupService.java') && i.line === 37,
  );
  check('POU fetchCustomer invocation present', fetchCustomer !== undefined);
  eq('  property_key_ref', fetchCustomer?.property_key_ref, 'services.cdu.base-url');
  check(
    '  path_fragment is non-null',
    typeof fetchCustomer?.path_fragment === 'string' && fetchCustomer.path_fragment !== '',
    String(fetchCustomer?.path_fragment),
  );
  check(
    '  property-derived fragments recorded alongside the LM fragment',
    Array.isArray(fetchCustomer?.annotations['property_fragments']) &&
      (fetchCustomer!.annotations['property_fragments'] as string[]).length > 0,
    JSON.stringify(fetchCustomer?.annotations['property_fragments']),
  );

  // Prove the FILL path: re-normalize with the LM's path_fragment blanked.
  const blankedLogger: Logger = silentLogger;
  const blanked = normalizeRepo({
    repo: 'pou',
    files: [],
    extractions: [
      {
        relativePath: 'src/main/java/com/acme/pou/service/CustomerLookupService.java',
        extraction: {
          ...emptyExtraction(),
          invocations: [
            {
              transport: 'rest',
              enclosing_class_fqn: 'com.acme.pou.service.CustomerLookupService',
              enclosing_method_name: 'fetchCustomer',
              enclosing_method_signature: 'fetchCustomer(Ljava/lang/String;)Lcom/acme/pou/dto/CustomerDto;',
              line: 37,
              literal_url: null,
              path_fragment: null,
              destination: null,
              request_dto_fqn: null,
              response_dto_fqn: null,
              client_bean: 'cduRestTemplate',
              property_key_ref: 'services.cdu.base-url',
              logical_name: null,
              method_name: 'getForObject',
              confidence_hints: [],
              unresolved: [],
              confidence: 0.85,
            },
          ],
        },
      },
    ],
    propertyResolution: pou.result.properties,
    packagePrefixes: ['com.acme.pou'],
    logger: blankedLogger,
    extractorTag: 'sanity',
  });
  const filled = blanked.records.find((r): r is InvocationRecord => r.kind === 'invocation');
  check(
    'path_fragment IS filled from the resolved property when the LM left it null',
    typeof filled?.path_fragment === 'string' && filled.path_fragment !== '',
    String(filled?.path_fragment),
  );
  check(
    '  and is tagged with the confidence hint path_fragment_from_property',
    filled?.confidence_hints.includes('path_fragment_from_property') === true,
    JSON.stringify(filled?.confidence_hints),
  );

  section('Resolved base-url fragments for all four envs');
  const table = pou.result.properties.table;
  const index = pou.result.manifest.path_fragment_to_property_keys;
  for (const env of ['default', 'dev', 'uat', 'prod'] as Env[]) {
    const value = lookupResolved(table, 'services.cdu.base-url', env);
    const expectedValue = expected.resolved_properties['pou']!['services.cdu.base-url']![env];
    eq(`  services.cdu.base-url resolves for env ${env}`, value, expectedValue);
    const frags = value === null ? [] : valueFragments(value);
    const allIndexed =
      frags.length > 0 &&
      frags.every((f) => (index[f] ?? []).includes('services.cdu.base-url')) &&
      (index[value!] ?? []).includes('services.cdu.base-url');
    check(
      `  env ${env} fragments joinable via path_fragment_to_property_keys`,
      allIndexed,
      `${JSON.stringify(frags)} + full value`,
    );
  }
  check(
    'the LM path fragment /api/v1/customers/{id} maps to services.cdu.base-url',
    (index['/api/v1/customers/{id}'] ?? []).includes('services.cdu.base-url'),
    JSON.stringify(index['/api/v1/customers/{id}']),
  );

  section('Vault secret stays unresolved but joinable');
  const pouProps = pou.result.records.filter((r): r is PropertyRecord => r.kind === 'property');
  const apiKeyProd = pouProps.find((p) => p.key === 'services.cdu.api-key' && p.env === 'prod');
  check('prod services.cdu.api-key record present', apiKeyProd !== undefined);
  eq('  value stays the verbatim vault placeholder', apiKeyProd?.value, '${vault:secret/pou#cdu-api-key}');
  eq('  is_secret', apiKeyProd?.is_secret, true);
  check(
    '  an unresolved record was emitted for it',
    pou.result.records.some(
      (r) =>
        r.kind === 'unresolved' &&
        r.what === 'property_value' &&
        String((r as UnresolvedRecord).partial_info['key']) === 'services.cdu.api-key',
    ),
  );
  check(
    '  the placeholder survives as a join token in unresolved_placeholders',
    pou.result.manifest.unresolved_placeholders.includes('${vault:secret/pou#cdu-api-key}'),
    pou.result.manifest.unresolved_placeholders.join(', '),
  );
  check(
    '  and as a key in path_fragment_to_property_keys',
    (index['${vault:secret/pou#cdu-api-key}'] ?? []).includes('services.cdu.api-key'),
  );

  /* ================= Callgraph ======================================= */
  section('Callgraph chains');
  const pouFwd = pou.result.forward;
  const P = (fqn: string, sig: string) => sym('pou', `com.acme.pou.${fqn}`, sig);

  const orderControllerCreate = P(
    'web.OrderController',
    'createOrder(Lcom/acme/pou/dto/OrderRequest;)Lorg/springframework/http/ResponseEntity;',
  );
  const listenerOnEvent = P('listener.OrderEventListener', 'onOrderEvent(Ljava/lang/String;)V');
  const orderProcess = P(
    'service.OrderService',
    'process(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/acme/pou/dto/CustomerDto;',
  );
  const enrich = P(
    'service.EnrichmentService',
    'enrich(Ljava/lang/String;Ljava/lang/String;)Lcom/acme/pou/dto/CustomerDto;',
  );
  const fetch = P(
    'service.CustomerLookupService',
    'fetchCustomer(Ljava/lang/String;)Lcom/acme/pou/dto/CustomerDto;',
  );
  const update = P(
    'service.CustomerLookupService',
    'updateCustomer(Ljava/lang/String;Lcom/acme/pou/dto/UpdateCustomerRequest;)Lcom/acme/pou/dto/CustomerDto;',
  );

  check(
    'POU chain 1: OrderController.createOrder -> process -> enrich -> fetchCustomer',
    chainExists(pouFwd, [orderControllerCreate, orderProcess, enrich, fetch]),
  );
  check(
    'POU chain 2: OrderEventListener.onOrderEvent -> process -> enrich -> fetchCustomer',
    chainExists(pouFwd, [listenerOnEvent, orderProcess, enrich, fetch]),
  );
  check(
    'POU chain 3: both entries also reach updateCustomer',
    chainExists(pouFwd, [orderControllerCreate, orderProcess, enrich, update]) &&
      chainExists(pouFwd, [listenerOnEvent, orderProcess, enrich, update]),
  );

  const cduFwd = cdu.result.forward;
  const C = (fqn: string, sig: string) => sym('cdu', `com.acme.cdu.${fqn}`, sig);
  check(
    'CDU downstream chain traversable in the FORWARD map: getCustomer -> findById -> load',
    chainExists(cduFwd, [
      C('controller.CustomerController', 'getCustomer(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;'),
      C('service.CustomerService', 'findById(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;'),
      C('repository.CustomerRepository', 'load(Ljava/lang/String;)Lcom/acme/cdu/dto/CustomerDto;'),
    ]),
  );
  check(
    'CDU same-class edge applyUpdate -> validate',
    chainExists(cduFwd, [
      C(
        'service.CustomerService',
        'applyUpdate(Ljava/lang/String;Lcom/acme/cdu/dto/UpdateCustomerRequest;)Lcom/acme/cdu/dto/CustomerDto;',
      ),
      C('service.CustomerService', 'validate(Lcom/acme/cdu/dto/UpdateCustomerRequest;)V'),
    ]),
  );
  check(
    'CDU kafka producer branch applyUpdate -> publishCustomerUpdated',
    chainExists(cduFwd, [
      C(
        'service.CustomerService',
        'applyUpdate(Ljava/lang/String;Lcom/acme/cdu/dto/UpdateCustomerRequest;)Lcom/acme/cdu/dto/CustomerDto;',
      ),
      C(
        'messaging.CustomerEventPublisher',
        'publishCustomerUpdated(Ljava/lang/String;Ljava/lang/String;)V',
      ),
    ]),
  );
  console.log(
    `      cdu callgraph: ${JSON.stringify(cdu.result.callgraphStats)}\n` +
      `      pou callgraph: ${JSON.stringify(pou.result.callgraphStats)}`,
  );

  section('Interface fan-out (not exercised by the fixtures — synthetic)');
  // CustomerApi/CustomerController form a real interface/impl pair, so a call
  // routed through the INTERFACE must fan out to the impl and to the interface
  // method itself, both tagged call_kind = 'interface'.
  const ifaceNorm = normalizeRepo({
    repo: 'cdu',
    files: [],
    extractions: [
      {
        relativePath: 'src/main/java/com/acme/cdu/api/CustomerApi.java',
        extraction: JSON.parse(
          fs.readFileSync(
            fixtureResponsePath('cdu', 'src/main/java/com/acme/cdu/api/CustomerApi.java'),
            'utf8',
          ),
        ),
      },
      {
        relativePath: 'src/main/java/com/acme/cdu/controller/CustomerController.java',
        extraction: JSON.parse(
          fs.readFileSync(
            fixtureResponsePath(
              'cdu',
              'src/main/java/com/acme/cdu/controller/CustomerController.java',
            ),
            'utf8',
          ),
        ),
      },
      {
        relativePath: 'src/main/java/com/acme/cdu/service/CustomerService.java',
        extraction: {
          ...emptyExtraction(),
          method_calls: [
            {
              caller_class_fqn: 'com.acme.cdu.service.CustomerService',
              caller_method_signature: 'findById(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;',
              // Call routed through the INTERFACE, not the impl.
              callee_class_fqn: 'com.acme.cdu.api.CustomerApi',
              callee_method_name: 'getCustomer',
              callee_signature_guess: 'getCustomer(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;',
              line: 26,
              call_kind: 'direct',
            },
          ],
        },
      },
    ],
    propertyResolution: cdu.result.properties,
    packagePrefixes: ['com.acme.cdu'],
    logger: silentLogger,
    extractorTag: 'sanity',
  });
  check(
    'implements map derived from the endpoint reconciliation',
    ifaceNorm.symbolTable.implementations.get('com.acme.cdu.api.CustomerApi')?.[0] ===
      'com.acme.cdu.controller.CustomerController',
    JSON.stringify([...ifaceNorm.symbolTable.implementations]),
  );
  const ifaceCg = buildCallgraph({
    repo: 'cdu',
    extractions: [
      {
        relativePath: 'src/main/java/com/acme/cdu/service/CustomerService.java',
        extraction: {
          ...emptyExtraction(),
          method_calls: [
            {
              caller_class_fqn: 'com.acme.cdu.service.CustomerService',
              caller_method_signature: 'findById(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;',
              callee_class_fqn: 'com.acme.cdu.api.CustomerApi',
              callee_method_name: 'getCustomer',
              callee_signature_guess: 'getCustomer(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;',
              line: 26,
              call_kind: 'direct',
            },
          ],
        },
      },
    ],
    symbolTable: ifaceNorm.symbolTable,
    sourceMap: [],
    packagePrefixes: ['com.acme.cdu'],
    logger: silentLogger,
  });
  const ifaceCallees = (ifaceCg.forward[
    sym('cdu', 'com.acme.cdu.service.CustomerService', 'findById(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;')
  ] ?? []).map((s) => s.callee);
  check(
    'interface call fans out to BOTH the interface method and the concrete impl',
    ifaceCallees.some((c) => c.includes('CustomerApi')) &&
      ifaceCallees.some((c) => c.includes('CustomerController')),
    ifaceCallees.join(', '),
  );
  check(
    'every fan-out edge is tagged call_kind = interface',
    ifaceCg.edges.length > 0 && ifaceCg.edges.every((e) => e.call_kind === 'interface'),
    `${ifaceCg.edges.length} edges`,
  );

  section('Unresolved records');
  check(
    'EnrichmentService dynamic-URL call produced an unresolved record',
    pou.result.records.some(
      (r) =>
        r.kind === 'unresolved' &&
        r.what === 'url' &&
        r.context.file.endsWith('EnrichmentService.java'),
    ),
  );

  /* ================= Entry points ==================================== */
  section('Entry points');
  const entryKinds = pou.result.records
    .filter((r) => r.kind === 'entry_point')
    .map((r) => (r as { entry_kind: string }).entry_kind)
    .sort();
  check(
    'POU entry points include rest_controller, kafka_listener and main',
    entryKinds.includes('rest_controller') &&
      entryKinds.includes('kafka_listener') &&
      entryKinds.includes('main'),
    entryKinds.join(', '),
  );

  /* ================= Determinism ===================================== */
  section('Determinism');
  const cduA = await build('cdu', 'det-a', quiet);
  const cduB = await build('cdu', 'det-b', quiet);
  const filesA = listFiles(path.join(cduA.outputRoot, '.codeindex'));
  const filesB = listFiles(path.join(cduB.outputRoot, '.codeindex'));
  eq('two builds emit the same file set', filesA, filesB);
  let identical = filesA.length > 0;
  const differing: string[] = [];
  for (const f of filesA) {
    const a = fs.readFileSync(path.join(cduA.outputRoot, '.codeindex', f));
    const b = fs.readFileSync(path.join(cduB.outputRoot, '.codeindex', f));
    if (!a.equals(b)) {
      identical = false;
      differing.push(f);
    }
  }
  check('every emitted file is BYTE-IDENTICAL across two builds', identical, differing.join(', '));
  check(
    `${FORWARD_CALLGRAPH_FILE} is present in the bundle`,
    filesA.includes(FORWARD_CALLGRAPH_FILE),
    filesA.join(', '),
  );

  /* ================= Cache =========================================== */
  section('LM cache');
  const cacheProvider = makeProvider('cdu');
  await build('cdu', 'cache-1', quiet, {}, cacheProvider);
  const firstCalls = cacheProvider.callCount;
  check('first build made provider calls', firstCalls > 0, String(firstCalls));
  cacheProvider.reset();
  await build('cdu', 'cache-1', quiet, {}, cacheProvider);
  eq('second build into the same bundle makes ZERO provider calls', cacheProvider.callCount, 0);

  /* ================= Deterministic-only mode ========================= */
  section('Deterministic-only mode (lmEnabled = false)');
  const det = await build('pou', 'det-only', quiet, { lmEnabled: false });
  check('deterministic-only build reports the mode', det.result.deterministicOnly === true);
  eq('  no endpoints', det.result.endpoints.length, 0);
  check(
    '  property records are still present',
    det.result.records.filter((r) => r.kind === 'property').length > 0,
    String(det.result.records.filter((r) => r.kind === 'property').length),
  );
  const detLoaded = loadBundle(det.outputRoot, silentLogger);
  check('  bundle is loadable', detLoaded.present && detLoaded.meta.repo === 'pou');
  eq('  built_at is the injected value', detLoaded.meta.built_at, BUILT_AT);

  const provUnavailable = new MockChatModelProvider(() => '{}', { unavailable: true });
  const noModel = await build('pou', 'no-model', quiet, {}, provUnavailable);
  check(
    'no available model also degrades to deterministic-only without aborting',
    noModel.result.deterministicOnly === true && noModel.result.records.length > 0,
  );

  /* ================= loadBundle round-trip =========================== */
  section('loadBundle round-trip');
  const loaded = loadBundle(cdu.outputRoot, silentLogger);
  check('bundle present', loaded.present);
  eq('  meta.repo', loaded.meta.repo, 'cdu');
  eq('  endpoints read back', loaded.endpoints.length, cdu.result.endpoints.length);
  eq('  fingerprints read back', loaded.fingerprints.length, cdu.result.fingerprints.length);
  eq('  records read back', loaded.records.length, cdu.result.records.length);
  eq('  manifest dto_shapes read back', loaded.manifest.dto_shapes, cdu.result.manifest.dto_shapes);
  eq('  source_map read back', loaded.sourceMap, cdu.result.sourceMap);
  eq('  callgraph symbol count', loaded.callgraph.symbolCountValue, cdu.result.callgraphSymbols.length);
  check(
    '  reverse adjacency answers "who calls CustomerRepository.load"',
    loaded.callgraph
      .callersOfSymbol(
        C('repository.CustomerRepository', 'load(Ljava/lang/String;)Lcom/acme/cdu/dto/CustomerDto;'),
      )
      .some(
        (c) =>
          loaded.callgraph.symbolAt(c.caller_index) ===
          C('service.CustomerService', 'findById(Ljava/lang/String;Z)Lcom/acme/cdu/dto/CustomerDto;'),
      ),
  );
  const manifestBytes = Buffer.byteLength(JSON.stringify(cdu.result.manifest), 'utf8');
  check('consumption_manifest is under 50KB', manifestBytes < 50_000, `${manifestBytes} bytes`);

  /* ================= Summary ========================================= */
  console.log(`\n${failed === 0 ? 'ALL PASS' : 'FAILURES'}: ${passed} passed, ${failed} failed`);
}

main().catch((err) => {
  consoleLogger.log('NORMALIZE', `sanity run threw: ${String(err)}`);
  console.error(err);
  process.exitCode = 1;
});
