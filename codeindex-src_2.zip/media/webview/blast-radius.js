/* Blast radius webview controller.
 *
 * Renders a BlastRadiusResult (see src/types.ts) as a filterable, collapsible
 * report. Plain vanilla JS, no build step, no dependencies.
 *
 * SECURITY: every value that originates from the analysis payload (symbol
 * names, DTO FQNs, file paths, reasons, property keys, JSON blobs) is passed
 * through esc() before it reaches innerHTML. Nothing is interpolated raw.
 */
(function () {
  'use strict';

  // ---------------------------------------------------------------- vscode

  var vscode =
    typeof acquireVsCodeApi === 'function'
      ? acquireVsCodeApi()
      : {
          postMessage: function () {},
          getState: function () {
            return undefined;
          },
          setState: function () {}
        };

  // ------------------------------------------------------------- utilities

  var ESCAPES = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  };

  /**
   * HTML-escape any value. Every data-derived string in this file goes
   * through here before being interpolated into markup.
   */
  function esc(value) {
    if (value === null || value === undefined) {
      return '';
    }
    return String(value).replace(/[&<>"']/g, function (ch) {
      return ESCAPES[ch];
    });
  }

  /** Escape a value for use inside a double-quoted HTML attribute. */
  function attr(value) {
    return esc(value);
  }

  function isArray(v) {
    return Object.prototype.toString.call(v) === '[object Array]';
  }

  function arr(v) {
    return isArray(v) ? v : [];
  }

  function shortSymbol(fqn) {
    var s = String(fqn === null || fqn === undefined ? '' : fqn);
    var parts = s.split('.');
    if (parts.length <= 2) {
      return s;
    }
    return parts.slice(-2).join('.');
  }

  function baseName(path) {
    var s = String(path === null || path === undefined ? '' : path);
    var i = s.lastIndexOf('/');
    return i === -1 ? s : s.slice(i + 1);
  }

  // --------------------------------------------------------- shared markup

  var CHEVRON =
    '<span class="chevron" aria-hidden="true">▶</span>';

  var VERB_TONE = {
    GET: 'tone-blue',
    POST: 'tone-green',
    PUT: 'tone-yellow',
    DELETE: 'tone-red',
    PATCH: 'tone-blue'
  };

  var CHANGE_TONE = {
    added: 'tone-green',
    removed: 'tone-red',
    modified: 'tone-yellow'
  };

  function confidenceTone(c) {
    if (c >= 0.9) return 'tone-green';
    if (c >= 0.75) return 'tone-yellow';
    return 'tone-red';
  }

  /** A clickable file:line reference that posts openLocation to the host. */
  function locHtml(file, line, label) {
    if (!file) {
      return '';
    }
    var text = label || baseName(file) + (line ? ':' + line : '');
    return (
      '<button type="button" class="loc" data-file="' +
      attr(file) +
      '" data-line="' +
      attr(line || 1) +
      '" title="' +
      attr(String(file) + (line ? ':' + line : '')) +
      '">' +
      esc(text) +
      '</button>'
    );
  }

  /**
   * Render a match signal chip. MatchSignal values may be plain enums
   * ("dto_shape_match") or prefixed forms ("property_value:services.cdu.base-url",
   * "wired_bean:cduRestTemplate"). The prefix becomes the label, the suffix is
   * shown in monospace.
   */
  function signalChip(signal) {
    var s = String(signal === null || signal === undefined ? '' : signal);
    var idx = s.indexOf(':');
    if (idx === -1) {
      return '<span class="chip chip-signal">' + esc(s) + '</span>';
    }
    var key = s.slice(0, idx);
    var val = s.slice(idx + 1);
    return (
      '<span class="chip chip-signal"><span class="chip-key">' +
      esc(key) +
      '</span><span class="chip-val">' +
      esc(val) +
      '</span></span>'
    );
  }

  function chipsHtml(list, cls) {
    var items = arr(list);
    if (!items.length) {
      return '';
    }
    var out = '<div class="chips">';
    for (var i = 0; i < items.length; i++) {
      out += cls === 'signal'
        ? signalChip(items[i])
        : '<span class="chip">' + esc(items[i]) + '</span>';
    }
    return out + '</div>';
  }

  function confidenceHtml(confidence) {
    var c = typeof confidence === 'number' ? confidence : 0;
    var pct = Math.max(0, Math.min(1, c)) * 100;
    var tone = confidenceTone(c);
    return (
      '<span class="confidence ' +
      tone +
      '" title="confidence ' +
      attr(c.toFixed(2)) +
      '">' +
      '<span class="confidence-track"><span class="confidence-fill" style="width:' +
      attr(pct.toFixed(0)) +
      '%"></span></span>' +
      '<span class="confidence-label">' +
      esc(c.toFixed(2)) +
      '</span></span>'
    );
  }

  function unresolvedNoteHtml(note) {
    if (!note) {
      return '';
    }
    var out =
      '<div class="warn"><span class="warn-what">' +
      esc(note.what) +
      '</span><span>' +
      esc(note.reason);
    if (note.expression) {
      out += ' <code>' + esc(note.expression) + '</code>';
    }
    return out + '</span></div>';
  }

  /** A collapsible section. `id` keys the persisted open/closed state. */
  function sectionHtml(id, titleHtml, metaHtml, bodyHtml, defaultOpen) {
    var open = getOpen(id, defaultOpen);
    return (
      '<section class="section' +
      (open ? ' open' : '') +
      '" data-section="' +
      attr(id) +
      '">' +
      '<button type="button" class="section-header" aria-expanded="' +
      (open ? 'true' : 'false') +
      '">' +
      CHEVRON +
      '<span class="section-title">' +
      titleHtml +
      '</span>' +
      '<span class="section-spacer"></span>' +
      (metaHtml || '') +
      '</button>' +
      '<div class="section-body">' +
      bodyHtml +
      '</div></section>'
    );
  }

  // ------------------------------------------------------ persistent state

  var state = vscode.getState() || {};
  if (!state.open || typeof state.open !== 'object') {
    state.open = {};
  }
  if (typeof state.filter !== 'string') {
    state.filter = '';
  }

  function saveState() {
    vscode.setState(state);
  }

  function getOpen(id, defaultOpen) {
    return Object.prototype.hasOwnProperty.call(state.open, id)
      ? !!state.open[id]
      : !!defaultOpen;
  }

  function setOpen(id, open) {
    state.open[id] = !!open;
    saveState();
  }

  // ---------------------------------------------------------- header block

  function renderChangedEndpoint(ep) {
    if (!ep) {
      return '';
    }
    var verb = ep.verb ? String(ep.verb).toUpperCase() : null;
    var target = ep.path_template || ep.destination || '(unknown target)';

    var html = '<header class="endpoint-header"><div class="endpoint-identity">';
    html +=
      '<span class="badge badge-transport">' + esc(ep.transport) + '</span>';
    if (verb) {
      html +=
        '<span class="badge badge-tone ' +
        toneClass(VERB_TONE, verb) +
        '">' +
        esc(verb) +
        '</span>';
    }
    html += '<span class="endpoint-path">' + esc(target) + '</span>';
    html +=
      '<span class="badge badge-tone badge-change ' +
      toneClass(CHANGE_TONE, ep.change_kind) +
      '">' +
      esc(ep.change_kind) +
      '</span>';
    html += '</div>';

    // DTOs / handler. request_dto_fqn and response_dto_fqn are not part of
    // ChangedEndpoint, so derive the identity line from the handler symbol and
    // surface DTO FQNs found in diff_details field paths.
    html += '<div class="endpoint-dtos">';
    if (ep.handler_symbol) {
      html +=
        '<div><span>handler </span><code>' +
        esc(ep.handler_symbol) +
        '</code> ' +
        locHtml(ep.file, ep.line) +
        '</div>';
    }
    var dtos = collectDtoFqns(ep);
    if (dtos.request) {
      html +=
        '<div><span>request DTO </span><code>' + esc(dtos.request) + '</code></div>';
    }
    if (dtos.response) {
      html +=
        '<div><span>response DTO </span><code>' + esc(dtos.response) + '</code></div>';
    }
    html += '<div><span>id </span><code>' + esc(ep.id) + '</code></div>';
    html += '</div>';

    html += chipsHtml(ep.diff_reason, 'plain');
    html += diffTableHtml(ep.diff_details);
    html += '</header>';
    return html;
  }

  /**
   * ChangedEndpoint carries DTO information only inside diff_details field
   * paths (e.g. "UpdateCustomerRequest.displayName"). Pull out the FQNs that
   * appear as before/after values so the header can name them.
   */
  function collectDtoFqns(ep) {
    var result = { request: null, response: null };
    var details = arr(ep.diff_details);
    for (var i = 0; i < details.length; i++) {
      var f = String(details[i].field || '');
      if (f === 'request_dto_shape' || f === 'request_dto_fqn') {
        result.request = details[i].after || details[i].before;
      } else if (f === 'response_dto_shape' || f === 'response_dto_fqn') {
        result.response = details[i].after || details[i].before;
      } else if (!result.request && f.indexOf('.') > 0) {
        result.request = f.split('.')[0];
      }
    }
    return result;
  }

  function diffValueHtml(value, kind) {
    if (value === null || value === undefined) {
      return '<span class="val-none">' + esc(kind === 'before' ? '(absent)' : '(removed)') + '</span>';
    }
    var cls = kind === 'before' ? 'val-removed' : 'val-added';
    return '<span class="' + cls + '">' + esc(value) + '</span>';
  }

  function diffTableHtml(details) {
    var rows = arr(details);
    if (!rows.length) {
      return '';
    }
    var html =
      '<table class="diff-table"><thead><tr><th>field</th><th>before</th><th>after</th></tr></thead><tbody>';
    for (var i = 0; i < rows.length; i++) {
      var d = rows[i];
      var before = d.before === undefined ? null : d.before;
      var after = d.after === undefined ? null : d.after;
      // Unchanged values are not struck/highlighted.
      var beforeHtml =
        before !== null && before === after
          ? esc(before)
          : diffValueHtml(before, 'before');
      var afterHtml =
        after !== null && before === after ? esc(after) : diffValueHtml(after, 'after');
      html +=
        '<tr><td>' +
        esc(d.field) +
        '</td><td>' +
        beforeHtml +
        '</td><td>' +
        afterHtml +
        '</td></tr>';
    }
    return html + '</tbody></table>';
  }

  // ------------------------------------------------------------ chain trees

  /**
   * Render a depth-indented tree from ChainNode[]. Nodes arrive in traversal
   * order and are indented by their `depth` field.
   */
  function chainTreeHtml(nodes, emptyMessage) {
    var list = arr(nodes);
    if (!list.length) {
      return '<div class="muted-empty">' + esc(emptyMessage) + '</div>';
    }
    var html = '<div class="tree">';
    for (var i = 0; i < list.length; i++) {
      var n = list[i];
      var depth = typeof n.depth === 'number' ? n.depth : 0;
      var site = n.call_site || null;
      var searchable = String(n.symbol || '') + ' ' + (site ? String(site.file || '') : '');
      html +=
        '<div class="node' +
        (n.is_entry_point ? ' node-entry' : '') +
        '" data-depth="' +
        attr(depth) +
        '" data-search="' +
        attr(searchable.toLowerCase()) +
        '">' +
        indentHtml(depth) +
        (n.is_entry_point
          ? '<span class="entry-marker" title="entry point">◆</span>'
          : '<span class="node-arrow">└</span>') +
        '<span class="node-symbol" title="' +
        attr(n.symbol) +
        '">' +
        esc(shortSymbol(n.symbol)) +
        '</span>' +
        (n.is_entry_point && n.entry_kind
          ? '<span class="badge badge-tone tone-green">' + esc(n.entry_kind) + '</span>'
          : '') +
        (site ? locHtml(site.file, site.line) : '') +
        '</div>';
    }
    return html + '</div>';
  }

  function indentHtml(depth) {
    var d = depth > 0 ? depth : 0;
    if (!d) {
      return '';
    }
    return (
      '<span class="node-indent" style="width:' +
      attr(d * 18) +
      'px" aria-hidden="true"></span>'
    );
  }

  // ------------------------------------------------------------- producer

  function renderProducer(producer) {
    if (!producer) {
      return '';
    }
    var body = '';

    body +=
      '<div class="lane lane-down">' +
      '<div class="subsection-title">Downstream <span class="subsection-hint">(what the handler calls)</span></div>' +
      chainTreeHtml(producer.feeder_chains, 'no downstream calls recorded for this handler') +
      '</div>';

    body +=
      '<div class="lane lane-up">' +
      '<div class="subsection-title">Upstream <span class="subsection-hint">(internal callers of the handler)</span></div>' +
      chainTreeHtml(
        producer.caller_chains,
        'no internal callers — this handler is only reached from outside the repo'
      ) +
      '</div>';

    var meta =
      '<span class="badge" title="total affected symbols">' +
      esc(producer.total_affected_symbols) +
      ' symbols</span>';

    var title =
      'Producer blast radius <span class="section-sub">' +
      esc(producer.repo) +
      '</span>';

    return sectionHtml('producer', title, meta, body, true);
  }

  // ------------------------------------------------------------- consumers

  /**
   * ConsumerBlastRadius.caller_chains is a flat edge list for the whole repo.
   * Walk it upward from one invocation's symbol to get the sub-tree that
   * belongs to that invocation, terminating at entry points.
   */
  function chainsForInvocation(consumer, invocationSymbol) {
    var edges = arr(consumer.caller_chains);
    var entryBySymbol = {};
    var entries = arr(consumer.entry_points);
    for (var e = 0; e < entries.length; e++) {
      entryBySymbolSet(entryBySymbol, entries[e]);
    }

    var nodes = [];
    var seen = {};
    var frontier = [String(invocationSymbol || '')];
    var guard = 0;

    while (frontier.length && guard++ < 200) {
      var next = [];
      for (var i = 0; i < frontier.length; i++) {
        var callee = frontier[i];
        for (var j = 0; j < edges.length; j++) {
          var edge = edges[j];
          if (String(edge.callee) !== callee) {
            continue;
          }
          var key = String(edge.caller) + '@' + String(edge.depth);
          if (seen[key]) {
            continue;
          }
          seen[key] = true;
          var entry = entryBySymbol[String(edge.caller)];
          nodes.push({
            symbol: edge.caller,
            depth: typeof edge.depth === 'number' ? edge.depth : 0,
            call_site: { file: edge.file, line: edge.line },
            is_entry_point: !!entry,
            entry_kind: entry ? entry.entry_kind : null
          });
          next.push(String(edge.caller));
        }
      }
      frontier = next;
    }

    nodes.sort(function (a, b) {
      return a.depth - b.depth;
    });
    return nodes;
  }

  function entryBySymbolSet(map, entry) {
    if (entry && entry.symbol) {
      map[String(entry.symbol)] = entry;
    }
  }

  function invocationHtml(consumer, hit, index) {
    var id = 'inv:' + String(consumer.repo) + ':' + String(hit.invocation_id || index);
    var open = getOpen(id, false);
    var range = isArray(hit.line_range) ? hit.line_range : [hit.line_range, hit.line_range];
    var startLine = range[0];
    var searchable = (
      String(hit.symbol || '') +
      ' ' +
      String(hit.file || '') +
      ' ' +
      String(hit.method_name || '')
    ).toLowerCase();

    var html =
      '<div class="inv' +
      (open ? ' open' : '') +
      '" data-inv="' +
      attr(id) +
      '" data-search="' +
      attr(searchable) +
      '">';

    html +=
      '<button type="button" class="inv-header" aria-expanded="' +
      (open ? 'true' : 'false') +
      '">' +
      CHEVRON +
      '<span class="inv-symbol" title="' +
      attr(hit.symbol) +
      '">' +
      esc(shortSymbol(hit.symbol)) +
      '</span>' +
      '<span class="badge badge-transport">' +
      esc(hit.transport) +
      '</span>' +
      '<span class="chip"><span class="chip-key">method</span><span class="chip-val">' +
      esc(hit.method_name) +
      '</span></span>' +
      '<span class="section-spacer"></span>' +
      confidenceHtml(hit.confidence) +
      '</button>';

    html += '<div class="inv-body">';
    html +=
      '<div class="unresolved-line"><span class="section-sub">source </span>' +
      locHtml(
        hit.file,
        startLine,
        baseName(hit.file) + ':' + String(range[0]) + '-' + String(range[1])
      ) +
      '</div>';

    html +=
      '<div><span class="section-sub">matched via</span>' +
      (arr(hit.matched_via).length
        ? chipsHtml(hit.matched_via, 'signal')
        : '<div class="muted-empty">no signals recorded</div>') +
      '</div>';

    var chain = chainsForInvocation(consumer, hit.symbol);
    html +=
      '<div class="lane lane-up"><div class="subsection-title">Callers ' +
      '<span class="subsection-hint">(up to entry points)</span></div>' +
      chainTreeHtml(chain, 'no internal callers — invoked directly from an entry point') +
      '</div>';

    var notes = arr(hit.unresolved);
    for (var i = 0; i < notes.length; i++) {
      html += unresolvedNoteHtml(notes[i]);
    }

    html += '</div></div>';
    return html;
  }

  function renderConsumer(consumer, index) {
    var id = 'consumer:' + String(consumer.repo || index);
    var invocations = arr(consumer.direct_invocations);
    var body = '';

    if (!consumer.consumed) {
      body +=
        '<div class="muted-empty">Not consumed — no invocation of this endpoint was found in ' +
        esc(consumer.repo) +
        '.</div>';
      body +=
        '<div><div class="subsection-title">Signals checked</div>' +
        (arr(consumer.phase1_signals).length
          ? chipsHtml(consumer.phase1_signals, 'signal')
          : '<div class="muted-empty">no candidate signals were available</div>') +
        '</div>';
    } else {
      body +=
        '<div><div class="subsection-title">Phase 1 signals</div>' +
        (arr(consumer.phase1_signals).length
          ? chipsHtml(consumer.phase1_signals, 'signal')
          : '<div class="muted-empty">no signals recorded</div>') +
        '</div>';

      if (invocations.length) {
        body += '<div class="subsection-title">Direct invocations</div>';
        for (var i = 0; i < invocations.length; i++) {
          body += invocationHtml(consumer, invocations[i], i);
        }
      } else {
        body +=
          '<div class="muted-empty">marked consumed but no direct invocation was resolved</div>';
      }

      var entries = arr(consumer.entry_points);
      if (entries.length) {
        body += '<div><div class="subsection-title">Entry points reached</div><div class="chips">';
        for (var e = 0; e < entries.length; e++) {
          body +=
            '<span class="chip chip-signal"><span class="chip-key">' +
            esc(entries[e].entry_kind) +
            '</span><span class="chip-val" title="' +
            attr(entries[e].symbol) +
            '">' +
            esc(shortSymbol(entries[e].symbol)) +
            '</span></span>';
        }
        body += '</div></div>';
      }
    }

    var meta =
      '<span class="badge badge-tone ' +
      (consumer.consumed ? 'tone-red' : 'tone-neutral') +
      '">' +
      (consumer.consumed ? 'consumed' : 'not consumed') +
      '</span>' +
      '<span class="badge">' +
      esc(invocations.length) +
      ' invocation' +
      (invocations.length === 1 ? '' : 's') +
      '</span>';

    var title = 'Consumer <span class="section-sub">' + esc(consumer.repo) + '</span>';
    return sectionHtml(id, title, meta, body, !!consumer.consumed);
  }

  function renderConsumers(consumers) {
    var list = arr(consumers);
    if (!list.length) {
      return (
        '<div class="state-msg">No consumer repositories were analysed — ' +
        'nothing downstream is known to call this endpoint.</div>'
      );
    }
    var html = '';
    for (var i = 0; i < list.length; i++) {
      html += renderConsumer(list[i], i);
    }
    return html;
  }

  // ------------------------------------------------------------ unresolved

  function renderUnresolved(records) {
    var list = arr(records);
    var body = '';
    if (!list.length) {
      body = '<div class="muted-empty">nothing was left unresolved in this analysis</div>';
    } else {
      for (var i = 0; i < list.length; i++) {
        var r = list[i];
        var ctx = r.context || {};
        body += '<div class="unresolved-row">';
        body +=
          '<div class="unresolved-line">' +
          '<span class="chip chip-signal">' +
          esc(r.what) +
          '</span>' +
          locHtml(ctx.file, ctx.line) +
          (ctx.enclosing_symbol
            ? '<span class="section-sub" title="' +
              attr(ctx.enclosing_symbol) +
              '">' +
              esc(shortSymbol(ctx.enclosing_symbol)) +
              '</span>'
            : '') +
          '</div>';
        body += '<div class="unresolved-reason">' + esc(r.reason) + '</div>';
        if (r.partial_info && Object.keys(r.partial_info).length) {
          body +=
            '<details class="partial"><summary>partial info</summary><pre>' +
            esc(safeJson(r.partial_info)) +
            '</pre></details>';
        }
        body += '</div>';
      }
    }
    var meta = '<span class="badge">' + esc(list.length) + '</span>';
    return sectionHtml('unresolved', 'Unresolved', meta, body, false);
  }

  function safeJson(value) {
    try {
      return JSON.stringify(value, null, 2);
    } catch (err) {
      return '(unserializable)';
    }
  }

  // ---------------------------------------------------------------- render

  var root = document.getElementById('root');
  var currentResult = null;

  function renderResult(result) {
    currentResult = result;
    if (!result) {
      root.innerHTML = '<div class="state-msg">No result.</div>';
      return;
    }
    var html = '';
    html += renderChangedEndpoint(result.changed_endpoint);
    html += renderProducer(result.producer_blast_radius);
    html += renderConsumers(result.consumer_blast_radius);
    html += renderUnresolved(result.unresolved_across_analysis);
    root.innerHTML = html;
    applyFilter();
  }

  function renderLoading() {
    currentResult = null;
    root.innerHTML =
      '<div class="state-msg"><span class="spinner"></span>Computing blast radius…</div>';
  }

  function renderError(message) {
    currentResult = null;
    root.innerHTML =
      '<div class="state-msg error">' + esc(message || 'Analysis failed.') + '</div>';
  }

  // ------------------------------------------------------ change-list mode

  /**
   * Change-list mode: pure `detectChanges` output, no blast radius.
   *
   * One card per ChangedEndpoint carrying its change_kind, diff_reason chips
   * and the diff_details before/after table — reusing the exact helpers the
   * full-result header uses, so the escaping story is identical. Each card gets
   * a "Show blast radius" button which posts `requestBlastRadius` back to the
   * extension; the host answers with a normal `{type:'result'}`, which switches
   * this view into the full report.
   *
   * SECURITY: `id`, `transport`, `verb`, `path_template`, `destination`,
   * `handler_symbol`, `file` and every diff_details field/before/after value
   * originate in LM output and are therefore untrusted. Every one of them
   * reaches the DOM through esc()/attr() below or through
   * chipsHtml/diffTableHtml/locHtml, which escape internally.
   */
  function renderChangeList(changes) {
    currentResult = null;
    var list = arr(changes);
    if (!list.length) {
      root.innerHTML =
        '<div class="state-msg">No API changes between those two bundles.</div>';
      return;
    }

    var html =
      '<div class="change-list-header">' +
      '<span class="badge">' +
      esc(list.length) +
      '</span> changed endpoint' +
      (list.length === 1 ? '' : 's') +
      '</div>';

    for (var i = 0; i < list.length; i++) {
      html += changeCardHtml(list[i], i);
    }
    root.innerHTML = html;
    applyFilter();
  }

  /**
   * Look a class name up in a tone table WITHOUT letting a poisoned key reach
   * the class attribute. A bare `TABLE[key]` would resolve inherited keys such
   * as "constructor" or "__proto__" to Object internals and interpolate them
   * into markup, so own-property membership is required.
   */
  function toneClass(table, key) {
    return Object.prototype.hasOwnProperty.call(table, key) ? table[key] : 'tone-neutral';
  }

  function changeCardHtml(ep, index) {
    if (!ep) {
      return '';
    }
    var verb = ep.verb ? String(ep.verb).toUpperCase() : null;
    var target = ep.path_template || ep.destination || '(unknown target)';

    var html =
      '<article class="change-card" data-change-index="' + attr(index) + '">';

    html += '<div class="change-card-identity">';
    html += '<span class="badge badge-transport">' + esc(ep.transport) + '</span>';
    if (verb) {
      html +=
        '<span class="badge badge-tone ' +
        toneClass(VERB_TONE, verb) +
        '">' +
        esc(verb) +
        '</span>';
    }
    html += '<span class="endpoint-path">' + esc(target) + '</span>';
    html +=
      '<span class="badge badge-tone badge-change ' +
      toneClass(CHANGE_TONE, ep.change_kind) +
      '">' +
      esc(ep.change_kind) +
      '</span>';
    html += '<span class="section-spacer"></span>';
    html +=
      '<button type="button" class="blast-btn" data-endpoint-id="' +
      attr(ep.id) +
      '">Show blast radius</button>';
    html += '</div>';

    html += '<div class="endpoint-dtos">';
    if (ep.handler_symbol) {
      html +=
        '<div><span>handler </span><code>' +
        esc(ep.handler_symbol) +
        '</code> ' +
        locHtml(ep.file, ep.line) +
        '</div>';
    }
    html += '<div><span>id </span><code>' + esc(ep.id) + '</code></div>';
    html += '</div>';

    html += chipsHtml(ep.diff_reason, 'plain');
    html += diffTableHtml(ep.diff_details);
    html += '</article>';
    return html;
  }

  // ---------------------------------------------------------------- filter

  /**
   * Live substring filter over invocations and chain nodes. A node matches on
   * symbol or file; matching descendants keep their ancestors visible so the
   * tree shape survives filtering.
   */
  function applyFilter() {
    var needle = String(state.filter || '').trim().toLowerCase();
    document.body.classList.toggle('filter-active', !!needle);

    var nodes = root.querySelectorAll('.node');
    var invs = root.querySelectorAll('.inv');
    var hits = 0;
    var i;

    if (!needle) {
      for (i = 0; i < nodes.length; i++) {
        nodes[i].classList.remove('filtered-out', 'filter-hit');
      }
      for (i = 0; i < invs.length; i++) {
        invs[i].classList.remove('filtered-out', 'filter-hit');
      }
      setFilterCount('');
      return;
    }

    // Per-tree pass so ancestor resolution stays inside one tree.
    var trees = root.querySelectorAll('.tree');
    for (var t = 0; t < trees.length; t++) {
      hits += filterTree(trees[t], needle);
    }

    for (i = 0; i < invs.length; i++) {
      var inv = invs[i];
      var selfMatch = (inv.getAttribute('data-search') || '').indexOf(needle) !== -1;
      var childMatch = inv.querySelectorAll('.node:not(.filtered-out)').length > 0;
      inv.classList.toggle('filter-hit', selfMatch);
      inv.classList.toggle('filtered-out', !selfMatch && !childMatch);
      if (selfMatch) {
        hits++;
      }
      // A self-matching invocation shows its whole chain again.
      if (selfMatch) {
        var kids = inv.querySelectorAll('.node');
        for (var k = 0; k < kids.length; k++) {
          kids[k].classList.remove('filtered-out');
        }
      }
    }

    setFilterCount(hits + ' match' + (hits === 1 ? '' : 'es'));
  }

  function filterTree(tree, needle) {
    var nodes = tree.querySelectorAll('.node');
    var keep = [];
    var hits = 0;
    var i;

    for (i = 0; i < nodes.length; i++) {
      var match = (nodes[i].getAttribute('data-search') || '').indexOf(needle) !== -1;
      keep[i] = match;
      nodes[i].classList.toggle('filter-hit', match);
      if (match) {
        hits++;
      }
    }

    // Walk backwards keeping every ancestor (nearest preceding shallower node)
    // of a kept node visible.
    for (i = nodes.length - 1; i >= 0; i--) {
      if (!keep[i]) {
        continue;
      }
      var depth = parseInt(nodes[i].getAttribute('data-depth') || '0', 10);
      for (var j = i - 1; j >= 0 && depth > 0; j--) {
        var d = parseInt(nodes[j].getAttribute('data-depth') || '0', 10);
        if (d < depth) {
          keep[j] = true;
          depth = d;
        }
      }
    }

    for (i = 0; i < nodes.length; i++) {
      nodes[i].classList.toggle('filtered-out', !keep[i]);
    }
    return hits;
  }

  function setFilterCount(text) {
    var el = document.getElementById('filter-count');
    if (el) {
      el.textContent = text;
    }
  }

  // ----------------------------------------------------------- interaction

  document.addEventListener('click', function (event) {
    var target = event.target;

    // Change-list mode: request the full blast radius for one endpoint. The
    // extension computes it and answers with {type:'result'}, which swaps this
    // view over to the full report.
    var blastBtn = target.closest ? target.closest('.blast-btn') : null;
    if (blastBtn) {
      event.preventDefault();
      event.stopPropagation();
      blastBtn.disabled = true;
      blastBtn.textContent = 'Computing…';
      vscode.postMessage({
        type: 'requestBlastRadius',
        endpointId: blastBtn.getAttribute('data-endpoint-id')
      });
      return;
    }

    var loc = target.closest ? target.closest('.loc') : null;
    if (loc) {
      event.preventDefault();
      event.stopPropagation();
      vscode.postMessage({
        type: 'openLocation',
        file: loc.getAttribute('data-file'),
        line: parseInt(loc.getAttribute('data-line') || '1', 10)
      });
      return;
    }

    var sectionHeader = target.closest ? target.closest('.section-header') : null;
    if (sectionHeader) {
      var section = sectionHeader.parentNode;
      var open = !section.classList.contains('open');
      section.classList.toggle('open', open);
      sectionHeader.setAttribute('aria-expanded', open ? 'true' : 'false');
      setOpen(section.getAttribute('data-section'), open);
      return;
    }

    var invHeader = target.closest ? target.closest('.inv-header') : null;
    if (invHeader) {
      var invEl = invHeader.parentNode;
      var invOpen = !invEl.classList.contains('open');
      invEl.classList.toggle('open', invOpen);
      invHeader.setAttribute('aria-expanded', invOpen ? 'true' : 'false');
      setOpen(invEl.getAttribute('data-inv'), invOpen);
    }
  });

  function setAll(open) {
    var sections = root.querySelectorAll('.section');
    var i;
    for (i = 0; i < sections.length; i++) {
      sections[i].classList.toggle('open', open);
      var h = sections[i].querySelector('.section-header');
      if (h) {
        h.setAttribute('aria-expanded', open ? 'true' : 'false');
      }
      state.open[sections[i].getAttribute('data-section')] = open;
    }
    var invs = root.querySelectorAll('.inv');
    for (i = 0; i < invs.length; i++) {
      invs[i].classList.toggle('open', open);
      var ih = invs[i].querySelector('.inv-header');
      if (ih) {
        ih.setAttribute('aria-expanded', open ? 'true' : 'false');
      }
      state.open[invs[i].getAttribute('data-inv')] = open;
    }
    saveState();
  }

  function wireToolbar() {
    var expand = document.getElementById('expand-all');
    var collapse = document.getElementById('collapse-all');
    var filter = document.getElementById('filter');

    if (expand) {
      expand.addEventListener('click', function () {
        setAll(true);
      });
    }
    if (collapse) {
      collapse.addEventListener('click', function () {
        setAll(false);
      });
    }
    if (filter) {
      filter.value = state.filter || '';
      filter.addEventListener('input', function () {
        state.filter = filter.value;
        saveState();
        applyFilter();
      });
    }
  }

  // -------------------------------------------------------------- messages

  window.addEventListener('message', function (event) {
    var message = event.data || {};
    if (message.type === 'result') {
      renderResult(message.payload);
    } else if (message.type === 'changeList') {
      renderChangeList(message.payload);
    } else if (message.type === 'loading') {
      renderLoading();
    } else if (message.type === 'error') {
      renderError(message.message);
    }
  });

  wireToolbar();
  vscode.postMessage({ type: 'ready' });

  // Exposed for the offline preview harness only.
  window.__blastRadius = {
    render: renderResult,
    renderChangeList: renderChangeList,
    getResult: function () {
      return currentResult;
    }
  };
})();
