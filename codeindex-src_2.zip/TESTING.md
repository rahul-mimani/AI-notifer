# Testing CodeIndex on a machine with real CDU and POU repos

This is the handoff guide for running the extension against real Spring Boot
repositories, on a machine that has GitHub Copilot available.

## 0. Prerequisites

- VS Code 1.103 or newer
- Node 20+ (developed on 24.10)
- **GitHub Copilot signed in and active.** Without it the extension still runs,
  but in deterministic-only mode — you get config/property/wiring records and a
  valid bundle, and you get *no* endpoints, invocations, DTOs or callgraph.
  Everything interesting needs the language model.

## 1. Build

```bash
unzip codeindex-src.zip -d codeindex
cd codeindex
npm install
npm run compile
```

Verify the engine before touching real repos — this takes about a minute and
proves the pipeline works independently of your codebase:

```bash
npx tsc --outDir out
for s in store hash lm properties indexer daemon ui demo; do
  node out/sanity/$s-sanity.js >/dev/null 2>&1 && echo "$s PASS" || echo "$s FAIL"
done
```

All 8 should pass (695 assertions). These run against the bundled `fixtures/cdu`
and `fixtures/pou` pair using a mock model — no Copilot required.

## 2. Launch

Open the `codeindex` folder in VS Code and press **F5**. That opens an Extension
Development Host window with the extension loaded. Everything below happens in
*that* window.

Alternatively, package and install it properly:

```bash
npx @vscode/vsce package --allow-missing-repository --no-dependencies
code --install-extension codeindex-0.1.0.vsix
```

## 3. Smoke test on the bundled fixtures first

Before pointing at real code, confirm the UI works end to end:

1. Click the **CodeIndex** status bar item (or run `CodeIndex: Run End-to-End Demo`).
2. Accept the two default folder paths — they point at `fixtures/cdu` and `fixtures/pou`.
3. The webview should open showing a REST endpoint, the producer downstream tree,
   POU as consumed with invocations at 0.95 confidence, and an unresolved panel.

If this works, the extension is healthy and any later problem is configuration
or extraction on your real repos — a much smaller search space.

## 4. Configure for the real CDU and POU

Open Settings (JSON) in the Extension Development Host and add:

```jsonc
{
  // MUST match your real packages — this gates the callgraph and symbol filter.
  // Get this wrong and the callgraph comes back empty.
  "codeindex.packagePrefixes": ["com.yourorg.cdu", "com.yourorg.pou"],

  // Adjust if your repos are multi-module (see note below).
  "codeindex.sourceRoots": ["src/main/java"],

  // Point at the CONSUMER bundle so the producer can compute blast radius.
  "codeindex.consumerRepos": [
    { "name": "pou", "indexPath": "/abs/path/to/pou/.codeindex" }
  ],

  // Your Message Router annotation/class/method names, if you use one.
  "codeindex.messageRouter.markers": [],

  // Real repos are far bigger than the fixtures — see step 6.
  "codeindex.lm.totalBudgetMinutes": 30,
  "codeindex.lm.maxConcurrent": 4
}
```

**Multi-module repos:** if CDU is a Gradle/Maven multi-module build, the default
`src/main/java` will not exist at the repo root. List each module explicitly:

```jsonc
"codeindex.sourceRoots": ["cdu-api/src/main/java", "cdu-service/src/main/java"]
```

If no configured source root exists, the walker falls back to scanning the whole
repo and logs that it did — check `[WALK]` in the output channel.

**Config Server:** if your properties live in a Config Server checkout:

```jsonc
"codeindex.configServerPaths": ["/abs/path/to/config-repo"],
"codeindex.configServerBranches": ["dev", "uat", "prod"]
```

Branches are read via `git show <branch>:<path>` without touching your working
tree. If the path is not a git repo, it degrades to reading the working tree and
says so in the output channel.

## 5. Index both repos

1. Open the **POU** (consumer) repo. Run `CodeIndex: Build Index for Current Workspace`.
2. Open the **CDU** (producer) repo. Run the same command.

Watch the **CodeIndex** output channel throughout. Stage tags tell you exactly
where time goes and what got skipped:

```
[WALK]      files found
[FILTER]    candidates vs skipped, and which marker matched
[LM]        per-file extraction, cache hit/miss, timing
[YAML]      config parsing and property resolution
[NORMALIZE] id/hash computation
[CALLGRAPH] edges emitted, edges skipped as framework noise
[STORE]     per-file byte counts
```

The first build calls the model once per candidate file and will take a while.
**Rebuilds are cache-first** — unchanged files make zero model calls, so the
second build is fast.

## 6. Expectations on a real codebase

The fixtures are small and hand-verified; your repos are not. Things to watch:

- **Budget.** `lm.totalBudgetMinutes` defaults to 10. On a large repo that will
  truncate and emit a partial index with a warning. Raise it (30–60) for the
  first full build, then lower it once the cache is warm.
- **First-use consent.** The first model call triggers a VS Code consent prompt.
  The output channel explains what gets sent (contents of candidate Java files)
  before any request goes out.
- **Partial results are normal.** Anything the model cannot resolve becomes an
  `unresolved` record with a specific reason rather than being dropped. Check the
  unresolved panel in the webview — it is diagnostic, not decoration.
- **Status bar** shows `$(error) last build had errors` when a partial index was
  emitted. That is informational; the bundle is still usable.

## 7. Run the real analysis

**Blast radius for one endpoint:**
Open a CDU controller, put the cursor on a handler method, run
`CodeIndex: Show Blast Radius for Endpoint at Cursor`.

**The change-detection loop (the interesting one):**

1. Run `CodeIndex: Run End-to-End Demo` once with CDU + POU. This establishes a
   baseline (`fingerprints.prev.jsonl`).
2. Change something breaking in CDU — add a field to a request DTO, change a
   field's type, or rename a path.
3. Run the demo again. It diffs against the baseline, picks the changed endpoint,
   and shows what breaks in POU and how deep the call chain goes.

**Change list without blast radius:**
`CodeIndex: Detect API Changes` → pick "Current vs. previous" → change-list view
with a per-row "Show blast radius" button.

## 8. If something looks wrong

| Symptom | Likely cause |
|---|---|
| No endpoints found | `sourceRoots` wrong, or Copilot unavailable (check status bar) |
| Endpoints found, callgraph empty | `packagePrefixes` does not match your real packages |
| Consumer shows "not consumed" | DTO shapes genuinely differ, or the consumer index is stale — rebuild it |
| Invocation has unresolved target | URL built dynamically; check the unresolved panel for the reason |
| Build truncated | `lm.totalBudgetMinutes` too low |
| Stale/incorrect extraction | `CodeIndex: Clear LM Cache`, then rebuild |

`CodeIndex: Show Raw LM Extraction for Current File` shows exactly what the model
returned for any file — the first thing to check when extraction looks wrong.

## 9. What has NOT been verified

Built and typechecked on a machine with no Copilot and no Extension Development
Host, so these paths are reasoned about but never observed running:

- Real `vscode.lm` calls, the consent modal, extraction against actual Copilot
- Hover cards, code lenses and the webview as the real host renders them
  (CSP enforcement, `asWebviewUri`, real `postMessage`)
- The file/folder picker flows
- **Cancellation actually interrupting in-flight model requests** — the
  token plumbing is wired and typechecked but no request was ever interrupted.
  Worth testing early: start a large build and cancel it.

Everything below the VS Code boundary — indexing, property resolution, change
detection, matching, callgraph walks, blast radius — is covered by the 695
assertions in step 1.
