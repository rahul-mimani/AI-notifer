// @ts-check
const tseslint = require('typescript-eslint');

module.exports = tseslint.config(
  {
    // Generated, vendored, or non-source output.
    ignores: ['out/**', 'dist/**', 'node_modules/**', 'fixtures/**', 'media/**'],
  },
  ...tseslint.configs.recommended,
  {
    files: ['src/**/*.ts'],
    rules: {
      // The store layer legitimately handles arbitrary JSON from LM output and
      // from disk; `any` there is honest rather than a missing type.
      '@typescript-eslint/no-explicit-any': 'warn',
      '@typescript-eslint/no-unused-vars': [
        'error',
        { argsIgnorePattern: '^_', varsIgnorePattern: '^_' },
      ],
      eqeqeq: ['error', 'always'],
      'no-console': 'off',
    },
  },
);
