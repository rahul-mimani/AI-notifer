# CodeIndex

Cross-repo API blast radius for Spring Boot services.

CodeIndex indexes Spring Boot Java repositories into a plain-file bundle under `.codeindex/`. The
index records what each repo *exposes* (REST endpoints, Kafka/JMS destinations, DTO shapes) and what
it *consumes* (outbound invocations, resolved configuration properties, wired beans). Because DTO
shapes are hashed structurally rather than by fully-qualified name, and because outbound URLs are
resolved through the property table rather than requiring a string literal, a producer's endpoint can
be joined against a consumer's call site across repository boundaries. The intended payoff: change an
API in one repo and find out who breaks.

Structural extraction is performed by a language model through the VS Code Language Model API
(`vscode.lm`, i.e. GitHub Copilot) at index-build time. Everything downstream of the model —
normalization, hashing, property resolution, the callgraph, the store — is deterministic and
LM-free.

---

## Implementation status — read this first

**The pipeline and the VS Code command surface are both wired up.** All ten contributed commands
have real implementations, the Java hover and code-lens providers are registered, the blast-radius
webview renders, and `CodeIndex: Run End-to-End Demo` drives producer + consumer indexing, change
detection and the webview from two folder prompts.

| Layer | Status |
|---|---|
| `src/coordinator/` — walk, filter, config discovery, property resolution, LM extraction, normalize, callgraph, store write | **Works.** Proven by `indexer-sanity`. |
| `src/daemon/` — `IndexRegistry`, `detectChanges`, `isConsumed`, `findInvocations`, `walkCallers`/`walkFeeders`, `blastRadius`, point lookups | **Works.** Proven by `daemon-sanity`. |
| Commands (`src/ui/commands.ts`) | **Works.** Ten real implementations; see the [command reference](#command-reference). |
| Hover + code lens (`src/ui/hover.ts`, `src/ui/lens.ts`) | **Works.** Registered for `language:java`, answered from the in-memory registry only — neither ever triggers a build. |
| Blast-radius webview (`src/ui/panel.ts`, `media/webview/`) | **Works.** Two modes: the full result report, and a change-list mode for pure `detectChanges` output. |
| `CodeIndex: Run End-to-End Demo` | **Works.** Prompts default to the last-used paths, falling back to `fixtures/cdu` and `fixtures/pou`. |
| `codeindex.consumerRepos`, `codeindex.maxCallerDepth` | **Now used.** Both settings feed the blast-radius queries. |

### What is NOT verified in this tree

This machine has no GitHub Copilot chat model and no `code` CLI, so the Extension Development Host
was never launched. Everything above is verified headlessly — see
[Verifying it works](#verifying-it-works) — but the following have only been reasoned about, not
observed, and are the first things to check on a machine that has both:

- any real `vscode.lm` call, the consent modal, and therefore end-to-end LM extraction against Copilot;
- hover cards, code lenses and the status bar as rendered by the real host;
- the webview inside VS Code (its rendering, CSP and messaging are verified against a DOM stub, not a live webview);
- `showOpenDialog` / `showQuickPick` / `showWorkspaceFolderPick` prompt flows;
- cancellation actually interrupting in-flight LM requests (the plumbing is asserted; the interruption is not).

### The demo's baseline files

`runDemo` needs a "before" state to diff against, but rebuilding the producer overwrites
`.codeindex/fingerprints.jsonl`. After a **successful** run it therefore snapshots three sibling
files into the producer bundle — and only after the webview has opened, so a failed run leaves the
previous baseline intact for a retry:

| File | Why it exists |
|---|---|
| `fingerprints.prev.jsonl` | The marker: its presence is what "there is a baseline" means. |
| `endpoints.prev.jsonl` | `endpointId` hashes the display path, so a **path rename mints a new id** and an id-only diff reports an unrelated add plus an unrelated remove. The recovery pass that re-pairs them keys on `handler_symbol`, which lives on `Endpoint`, not `Fingerprint`. |
| `dtos.prev.jsonl` | A shape hash says *that* a payload changed, not *what* changed. The field-level reasons (`dto_field_added` / `_removed` / `_type_changed`) come from diffing the DTO records behind the two shapes. |

`readBaseline` reconstructs a minimal `LoadedBundle` from these and passes it to `detectChanges` as
`oldBundle`. A baseline carrying only fingerprints still works — the diff just degrades to id-only
add/remove.

---

## Build

```bash
npm install
npm run compile        # webpack -> dist/extension.js
npm run check-types    # tsc --noEmit
npm run lint           # eslint src
```

Press <kbd>F5</kbd> to launch the Extension Development Host. The extension activates on
`onLanguage:java`, logs one `[DAEMON] activated · …` line, pre-loads any `.codeindex` bundles that
already exist (so hovers work on the first keystroke), and shows a status bar item. Clicking the
status bar item runs the end-to-end demo.

The sanity suites need a plain `tsc` build rather than the webpack bundle:

```bash
npx tsc --outDir out
node out/sanity/<name>.js
```

---

## Requirements and the Copilot caveat

LM extraction requires an available chat model via `vscode.lm.selectChatModels`. Model selection
(`src/lm/vscode-provider.ts`) tries, in order:

1. the exact id in `codeindex.lm.model`, if set;
2. `{ vendor: 'copilot' }`;
3. `{}` — any model at all.

If all three come back empty, or `selectChatModels` throws, `selectModel` returns `null`.

### Deterministic-only mode

`buildIndex` enters **DETERMINISTIC-ONLY MODE** when either `codeindex.lm.enabled` is `false` or
`selectModel` returned `null`. The build is never aborted; it logs the reason at `[LM]` and continues.

**What you still get:**

- The full file walk and pre-filter statistics (`meta.stats.java_files_walked`, `lm_candidates`, …).
- Config source discovery and parsing — `application*.{yml,yaml,properties}`, ConfigMaps, Config
  Server checkouts.
- The complete property resolution pass: `property` records for every (key, env, source), per-env
  materialized views, placeholder resolution, `unresolved` records for what could not be resolved.
- `consumption_manifest.json` with `property_keys`, `unresolved_placeholders`, and
  `path_fragment_to_property_keys` populated from the property pass.
- A valid, loadable bundle: every file is written, `meta.stats.deterministic_only` is `1`, and
  `extractor` on emitted records reads `deterministic`.

**What you lose** — everything that flows from the LM's per-file extraction:

- `endpoints.jsonl` and `fingerprints.jsonl` are empty.
- No `symbol`, `dto`, `invocation`, `wiring`, `property_binding`, `entry_point` or
  `logical_name_ref` records. (Wiring and property-binding records come from the LM's `wirings` /
  `property_bindings` arrays, *not* from the config parser — deterministic-only mode yields none.)
- `callgraph.bin` contains zero symbols and zero edges; `callgraph.fwd.json` is `{}`.
- `manifest.dto_shapes`, `dto_fqns`, `destinations` and `logical_names` are empty, so the cross-repo
  DTO-shape join has nothing to join on.

The indexer sanity suite asserts this mode explicitly: `0` endpoints, `22` property records still
present, bundle loadable, injected `built_at` preserved.

### First-use consent

VS Code shows its own consent modal the first time an extension calls
`LanguageModelChat.sendRequest`. `VsCodeChatModelProvider` takes an optional `onFirstUse` hook, fired
once immediately before the first request of a run, so the extension can explain what is about to
happen. `defaultConsentNotice` is the supplied implementation:

> CodeIndex will send Java source from this workspace to the "\<model id\>" language model for
> structural extraction. Results are cached under .codeindex/lm_cache.

A throw from the hook is swallowed — consent messaging never breaks extraction. Note that because no
command constructs a `VsCodeChatModelProvider` in this tree, this hook is not currently reachable
from the extension host.

If consent is refused, VS Code raises `LanguageModelError.NoPermissions`, which `mapError` translates
to `LmUnavailableError`, which the extractor logs and skips.

---

## Configuration

Every `codeindex.*` setting contributed by `package.json`, with its real default.

| Setting | Type | Default | What it affects |
|---|---|---|---|
| `codeindex.packagePrefixes` | `string[]` | `[]` | In-scope package filter. Gates `noteClass`/`noteMethod` in normalization, callgraph edge admission (**both** endpoints must match), and reference-closure expansion. **Empty means "everything matches"** — not "nothing". |
| `codeindex.sourceRoots` | `string[]` | `["src/main/java"]` | Repo-relative directories walked for `.java` files. If none of them exist on disk, the walker falls back to walking the whole repo. |
| `codeindex.configServerPaths` | `string[]` | `[]` | Local Spring Cloud Config Server git checkouts. Each is read as a flat directory of `*.{yml,yaml,properties}`. |
| `codeindex.configServerBranches` | `string[]` | `["dev","uat","prod"]` | Branches to index from those checkouts. **See caveat below.** |
| `codeindex.configMapPaths` | `string[]` | `[]` | Kubernetes ConfigMap YAML files. Only the top-level `data:` block is read. Each key is emitted verbatim plus its relaxed-binding aliases. |
| `codeindex.consumerRepos` | `{name, indexPath}[]` | `[]` | Consumer repos to evaluate blast radius against. `indexPath` may name the repo root, its `.codeindex` directory, or a file inside it. Loaded into the registry by the blast-radius commands and by the hover/lens providers at activation. |
| `codeindex.messageRouter.markers` | `string[]` | `[]` | Annotation/class/method names identifying Message Router usage. Fed to the pre-filter as extra markers, to the LM prompt as `{MESSAGE_ROUTER_MARKERS}`, and to entry-point classification (matched with a leading `@` stripped). |
| `codeindex.maxCallerDepth` | `number` | `4` | BFS depth for caller and feeder walks. Passed to every `blastRadius` query. |
| `codeindex.lm.model` | `string` | `""` | Preferred model id, passed to `selectChatModels({id})`. Empty string skips straight to the vendor fallbacks. |
| `codeindex.lm.maxConcurrent` | `number` | `4` | Concurrent in-flight LM requests. Floored at 1. |
| `codeindex.lm.timeoutSeconds` | `number` | `60` | Per-request deadline. On expiry the request is aborted and an `LmTimeoutError` is raised. |
| `codeindex.lm.totalBudgetMinutes` | `number` | `10` | Wall-clock budget for LM extraction across one `extractFiles` call. Once exceeded, remaining files are skipped (not failed) and logged as a partial index. |
| `codeindex.lm.enabled` | `boolean` | `true` | `false` forces deterministic-only extraction — no model is even selected. |

**Config Server branch caveat.** `discoverConfigSources` never shells out to git. Branch enumeration
requires a `readBranch(filePath, branch)` hook, which `buildIndex` does not supply. Without it the
working tree is read **once** and labelled with the *first* configured branch; the rest are logged as
not indexed:

```
[YAML] branch enumeration SKIPPED for Config Server <path>: no readBranch hook supplied.
       Reading the working tree once and labelling it 'dev'.
       Configured branches [dev, uat, prod] beyond the first were NOT indexed.
```

### Worked example: a producer/consumer pair

CDU is the producer, POU the consumer. Index each repo separately — a bundle belongs to exactly one
repo root. In CDU's workspace settings:

```jsonc
// cdu/.vscode/settings.json
{
  "codeindex.packagePrefixes": ["com.acme.cdu"],
  "codeindex.sourceRoots": ["src/main/java"],
  "codeindex.lm.enabled": true
}
```

In POU's workspace settings, additionally pointing at POU's ConfigMap and declaring CDU as the
producer whose bundle to join against:

```jsonc
// pou/.vscode/settings.json
{
  "codeindex.packagePrefixes": ["com.acme.pou"],
  "codeindex.sourceRoots": ["src/main/java"],
  "codeindex.configMapPaths": ["../configmap/pou-configmap.yaml"],
  "codeindex.consumerRepos": [
    { "name": "cdu", "indexPath": "../cdu/.codeindex" }
  ],
  "codeindex.lm.maxConcurrent": 4,
  "codeindex.lm.totalBudgetMinutes": 10
}
```

`consumerRepos` is stored and read but, as noted above, nothing consumes it yet.

---

## The demo scenario

`CodeIndex: Run End-to-End Demo` is a stub — it prompts for nothing, runs nothing, and shows no
webview. What follows describes the **bundled fixture scenario** the sanity suites drive, which is
what the demo command is meant to wrap. To run it today:

```bash
npx tsc --outDir out && node out/sanity/indexer-sanity.js
```

That builds both fixture repos end to end through the real `buildIndex`, against a
`MockChatModelProvider` that replays the hand-authored responses in `fixtures/lm-responses/`, and
asserts the ground truth in `fixtures/expected.json`. Bundles are written to a scratchpad directory,
never into `fixtures/`.

Two synthetic Spring Boot repos ship in `fixtures/`:

- **`fixtures/cdu`** — producer, package root `com.acme.cdu`, config in `.properties`.
- **`fixtures/pou`** — consumer, package root `com.acme.pou`, config in `.yml` with `-dev`/`-uat`/`-prod`
  profiles, plus `fixtures/configmap/pou-configmap.yaml`.

The two config formats are deliberate: both parser paths are exercised, and the cross-repo join has
to work across them.

### Edge case 1 — endpoint annotations live on the interface

`cdu/.../controller/CustomerController.java` carries `@RestController` and **no mapping annotations
at all**. Every `@RequestMapping`, `@GetMapping`, `@PutMapping`, `@PathVariable` and `@RequestBody`
lives on `cdu/.../api/CustomerApi.java`, the interface it implements. Spring registers all three
handlers anyway. An extractor that reads only the `@RestController` class finds zero endpoints.

The LM fixtures report each endpoint **twice** — once from the interface file (`confidence` 0.95,
attributes tagged `declared_on`) and once from the controller file (`confidence` 0.80, attributes
tagged `inherited_from`). `reconcileEndpoints` in `src/extractor/normalize.ts` groups them by
`(transport, verb, path_template_normalized, destination)` and picks the concrete controller as
canonical, retaining the interface FQN under the synthetic annotation key `declaring_type`. Result:
**4 endpoints** post-reconciliation (3 REST + 1 Kafka), not 7. See
[SCHEMA.md](SCHEMA.md#interfaceimpl-reconciliation) for the ordered rule list.

### Edge case 2 — no literal URL, reached through a multi-hop chain

`pou/.../service/CustomerLookupService.java` contains no literal absolute URL. The host arrives via
`@Value("${services.cdu.base-url}")`, whose raw value is `${cdu.host}/cdu-service` — itself resolved
recursively through `${cdu.host}`, which differs per environment. Only the path fragment
`/api/v1/customers/{id}` is a literal (a `private static final` constant).

The property enrichment loop in `normalizeRepo` resolves that key across **every** materialized env
and records all four resolutions on the invocation as `annotations.property_fragments`:

```json
["/cdu-service",
 "https://cdu.default.internal/cdu-service",
 "https://cdu.dev.internal/cdu-service",
 "https://cdu.prod.internal/cdu-service",
 "https://cdu.uat.internal/cdu-service"]
```

The calling service sits at the bottom of a chain reachable from **two different entry points** — a
REST controller and a Kafka listener:

```
ENTRY 1 (REST)   OrderController.createOrder ─┐
                                              ├─> OrderService.process
ENTRY 2 (Kafka)  OrderEventListener.onOrderEvent ─┘        │
                                                           v
                                                  EnrichmentService.enrich
                                                           │
                                        ┌──────────────────┴──────────────────┐
                                        v                                     v
                       CustomerLookupService.fetchCustomer     CustomerLookupService.updateCustomer
                                   (GET)                                    (PUT)
```

Also deliberately unresolvable, and asserted as such: `services.cdu.api-key` in `application-prod.yml`
is `${vault:secret/pou#cdu-api-key}` and must stay unresolved with `is_secret: true`; and
`EnrichmentService.enrich` line 28 makes a second `RestTemplate` call whose URL is the return value of
`resolveEndpoint(tenant)`, backed by a runtime-populated registry.

---

## Command reference

Every command id in `package.json`, verbatim.

| Command id | Title | What it actually does |
|---|---|---|
| `codeindex.buildIndex` | CodeIndex: Build Index for Current Workspace | Indexes the current workspace folder (`showWorkspaceFolderPick` when several are open) behind a cancellable notification, reporting each build sub-stage. Cancelling aborts LM work, not just the toast. Loads the bundle into the registry on completion. |
| `codeindex.buildIndexForFolder` | CodeIndex: Build Index for Folder… | `showOpenDialog` for a folder, then the same flow. |
| `codeindex.detectChanges` | CodeIndex: Detect API Changes | **Pure change detection — no blast radius.** Offers "Current vs. previous" as the first choice when the workspace bundle has a `fingerprints.prev.jsonl`, otherwise prompts for two bundles. Opens the webview in **change-list mode**: one card per changed endpoint with its `change_kind`, `diff_reason` chips and `diff_details` before/after table. Each card's "Show blast radius" button computes that one endpoint's radius on demand and switches to the full view. |
| `codeindex.checkConsumerImpact` | CodeIndex: Check Consumer Impact | Prompts for a producer bundle and one or more consumer bundles, runs `isConsumed` for every producer endpoint, and presents a QuickPick summary of which are consumed and by whom (with the signals that fired). |
| `codeindex.blastRadiusAtCursor` | CodeIndex: Show Blast Radius for Endpoint at Cursor | `getEndpointAt` on the active Java editor's cursor; says so plainly when there is no endpoint there. Otherwise runs `blastRadius` against the repos in `codeindex.consumerRepos` and opens the webview. Also the target of the endpoint code lens. |
| `codeindex.blastRadiusAcrossConsumers` | CodeIndex: Show Blast Radius Across Consumers… | Prompts for a producer bundle, consumer bundles and an endpoint (QuickPick showing verb + path), then runs and opens the webview. Invoked directly with a resolved target by the invocation code lens. |
| `codeindex.runDemo` | CodeIndex: Run End-to-End Demo | Two prompts (defaulting to the last-used paths, then `fixtures/cdu` / `fixtures/pou`), index both, diff against the baseline if one exists, pick the first `modified` → `added` → `removed` change (else the first endpoint), run `blastRadius`, open the webview, then advance the baseline. Refuses to start while another build is running. With no chat model it completes in deterministic-only mode, says so, and still opens the webview. Also the status bar item's click action. |
| `codeindex.showRawLmExtraction` | CodeIndex: Show Raw LM Extraction for Current File | Reads `.codeindex/lm_cache/<sha256 of the file's current content>.json` and opens it in an untitled JSON editor, unwrapping the `__codeindex_lm_chunks__` envelope into readable per-chunk blocks. On a miss it explains which of the two causes applies (never indexed vs. edited since). |
| `codeindex.clearLmCache` | CodeIndex: Clear LM Cache | Modal confirmation, then deletes `.codeindex/lm_cache/`, reporting how many entries were removed. |
| `codeindex.configureConsumerRepos` | CodeIndex: Configure Consumer Repos | Runs `workbench.action.openSettings` filtered to `codeindex.consumerRepos`. |

One further command is registered at runtime but **not contributed** in `package.json`, so it does not
appear in the command palette: `codeindex.showOutput`, which reveals the output channel. It is the
click action of the status bar item.

---

## Inspecting what happened

### The output channel

Everything logs to a VS Code output channel named **CodeIndex**, one line per event, prefixed with a
stage tag: `[<STAGE>] <message>`. Click the status bar item, or run `codeindex.showOutput`.

| Tag | Emitted by |
|---|---|
| `[WALK]` | Source-root resolution, per-directory read failures, test exclusion, final file count. Also carries `buildIndex`'s generic progress reports. |
| `[FILTER]` | Candidate/skip counts and a per-marker histogram. |
| `[LM]` | Mode banner, model selection, cache hits, chunk splits, repair attempts, discarded out-of-range lines, rate-limit backoff, budget exhaustion, reference-closure wave expansion. |
| `[YAML]` | Config source discovery, parse failures, shadowed properties, Config Server branch caveat, raw→resolved property counts. |
| `[NORMALIZE]` | DTO shape count, path template join disagreements, endpoint reconciliation decisions (with the rule that fired), property-derived path fragments, oversized manifest warning, final record tally. |
| `[CALLGRAPH]` | Interface-knowledge availability, signature-guess fallbacks, and the final symbol/edge/resolution breakdown. |
| `[STORE]` | Per-file byte counts, bundle summary, LM cache reads/writes. |
| `[DAEMON]` | Extension activation, and every message from `loadBundle` (missing/corrupt artifacts, load timing). |
| `[QUERY]` | **Never emitted.** Declared in the `Stage` union in `src/util/logger.ts` and used nowhere — it belongs to the absent query layer. |

### Status bar

`src/util/status.ts` defines four states. Only `ready` is ever set in this tree — once by
`initStatus` and once by `activate`, both with `repos: 0`.

| State | Text |
|---|---|
| `indexing` | `$(sync~spin) CodeIndex: indexing (<done>/<total> files)` |
| `ready` | `$(check) CodeIndex: ready · <n> repos loaded` |
| `lm-unavailable` | `$(warning) CodeIndex: LM unavailable · deterministic mode` |
| `errors` | `$(error) CodeIndex: last build had errors` |

### Raw LM extraction

`Show Raw LM Extraction for Current File` is a stub. The data it would show is on disk regardless: the
raw model response for a file is written to `.codeindex/lm_cache/<sha256-of-file-content>.json`. To
find the entry for a given file:

```bash
shasum -a 256 src/main/java/com/acme/cdu/dto/CustomerDto.java
cat .codeindex/lm_cache/<that-hash>.json
```

Multi-chunk files are stored under the envelope `{"__codeindex_lm_chunks__": [ … ]}`.

---

## Verifying it works

Eight sanity suites are the executable specification of what this codebase actually guarantees. They
run under plain Node with no VS Code and no Copilot — the LM layer is driven by
`MockChatModelProvider` throughout. This is deliberate, not a workaround: no module under
`src/store`, `src/extractor`, `src/daemon`, `src/coordinator` or `src/lm` imports `vscode` (the sole
exception is `src/lm/vscode-provider.ts`), and the UI layer keeps its logic in the vscode-free
`src/ui/{pure,targets,baseline,demo,exclusive}.ts` so it can be driven the same way.

```bash
npx tsc --noEmit && npx tsc --outDir out
for s in store hash lm properties indexer daemon ui demo; do
  node out/sanity/$s-sanity.js >/dev/null 2>&1 && echo "$s PASS" || echo "$s FAIL"
done
```

Each prints `PASS`/`FAIL` per assertion and sets `process.exitCode = 1` on any failure. Observed on
this tree, all passing:

| Suite | Assertions | Covers |
|---|---|---|
| `hash-sanity` | **96/96 passed** | Symbol ids, method-signature normalization, path normalization / collapsing / fragments, DTO shape hashing (inheritance, generics, transient exclusion, cycles, input-order independence), endpoint ids, fingerprint sensitivity and insensitivity, invocation ids, canonical JSON. |
| `indexer-sanity` | **82 passed, 0 failed** | Both fixture repos through the real `buildIndex`. Interface/impl reconciliation, DTO shape equality across repos, property enrichment, callgraph chains, forward adjacency, LM cache (9 provider calls first build, **0** on rebuild), deterministic-only mode, `loadBundle` round-trip, byte-identical rebuilds, manifest size budget. |
| `lm-sanity` | **83 passed, 0 failed** | Schema validation strictness, code-fence stripping, the single-repair budget, line-range enforcement, cache envelope encode/decode, concurrency cap, wall-clock budget, rate-limit backoff with capped exponential delay, the brace-aware chunker (string/comment/text-block awareness, original line numbers preserved, full line coverage). |
| `properties-sanity` | **94/94 checks passed** | `.properties`, YAML and ConfigMap parsing with true line numbers, line continuation, relaxed binding, env-from-filename, both `${x:d}` and `${x:-d}` forms, recursive defaults, cycles, the depth cap, Vault refs, secret detection, per-env materialized views, and the fixture property tables. |
| `store-sanity` | **45 assertions, 0 failures** | CGRF pack/unpack, reverse-adjacency correctness including multi-caller ordering and out-of-range indices, byte-level determinism (including gzip `mtime=0` and shuffled edge input), LM cache round-trip, and fail-open degradation on bad magic, bad version, truncation, malformed JSONL and a missing bundle. |
| `daemon-sanity` | passing | The query layer: registry load/reload/unload, fingerprint diffing, the phase-1 gate, the phase-2 join, caller/feeder walks and the full three-phase blast radius. |
| `ui-sanity` | **116 passed, 0 failed** | The vscode-free half of the UI layer, against real fixture bundles: lens titles, hover markdown (including the CDU `declaring_type` interface case), LM cache path + multi-chunk envelope formatting, file→repo-root resolution, invocation→endpoint target resolution, blast-radius payload validation, the demo baseline round-trip, **a mechanical diff of the command ids in `package.json` against those registered in `extension.ts`**, and the single-writer re-entrancy guard (including release after a throw and after a cancellation). |
| `demo-sanity` | **61 passed, 0 failed** | The whole `runDemo` flow headlessly, through the same `runDemoPipeline` the command calls. Four sequential runs: no baseline → valid payload + baseline written; a DTO field retype → `modified` + `dto_field_type_changed` with before/after types; a **path rename → `modified` + `path_changed`, not add+remove** (the assertion that proves both bundles reach `detectChanges`); an untouched repo → **zero** changes, proving the baseline advanced. Also asserts POU is consumed, ≥1 invocation, and both entry points reached. |

`store-sanity` prints `all assertions PASSED` rather than a count; the 45 figure is its `PASS` line
count.

---

## Troubleshooting

**"No chat model available" / everything is empty except properties.**
You are in deterministic-only mode. Check the `[LM]` banner in the output channel — it names the
cause. Either `codeindex.lm.enabled` is `false`, or `selectChatModels` returned nothing. Confirm
GitHub Copilot is installed, signed in, and that Copilot chat models are enabled for your account. If
you set `codeindex.lm.model` to a specific id, the log will say if that id was unavailable before it
fell back.

**Empty index / zero files walked.**
Check `[WALK]`. If it says `source root not found, skipping: …` for every configured root, it falls
back to a full-repo walk — which will still find `.java` files, so a genuinely empty result means
there are none outside the pruned directories (`.git`, `.codeindex`, `node_modules`, `target`,
`build`, `out`, `bin`, `.gradle`, `.idea`, `.mvn`) and outside `src/test/`.

**Zero DTO records but endpoints are present.**
Check `codeindex.packagePrefixes`. Prefix matching gates `noteClass`/`noteMethod` and the
reference-closure expansion; a prefix that does not actually match your package root silently drops
everything. An empty array matches everything and is the safe default. Also check `[LM]` for
`reference-closure cap of 6 waves reached` — a deep type graph can exceed the cap.

**Stale results after editing source.**
The LM cache is keyed by the SHA-256 of file *content*, so editing a file invalidates its entry
automatically. A stale result therefore means the cache entry no longer validates (logged as
`cache entry for <file> no longer validates — re-extracting`) or you changed the prompt/schema
without changing the source. `CodeIndex: Clear LM Cache` is a stub; delete the directory by hand:

```bash
rm -rf .codeindex/lm_cache
```

**Rebuilds are not byte-identical.**
They should be. `built_at` is injected by the caller and never generated inside `buildIndex`, gzip is
written with `mtime: 0`, and every collection is sorted. If you see drift, the injected `built_at`
differs between runs — that is the only clock in the bundle.

---

## Further reading

- **[SCHEMA.md](SCHEMA.md)** — the complete `.codeindex/` store reference: every file, every field,
  the byte-exact `callgraph.bin` format, the cross-cutting rules, and the documented deviations from
  the original spec.
- **[PROMPTS.md](PROMPTS.md)** — every LM prompt reproduced exactly as sent, the response schema, the
  validator's strictness rules, the repair protocol, and chunking.
