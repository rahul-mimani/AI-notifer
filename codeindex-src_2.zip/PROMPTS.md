# CodeIndex LM prompts

Every prompt string the extension sends, reproduced exactly as the code sends it.

`src/lm/prompts.ts` is the single source of truth. The strings below are copied from it verbatim —
including any wording that could be improved. Do not "fix" them here; fix them there, and the drift
becomes a diff.

The exported `PROMPT_TEMPLATES` object (`{system, user, schema, repair}`) exists so a doc generator
holds no literals of its own.

---

## Contents

- [Transport](#transport)
- [System prompt](#system-prompt)
- [User prompt template](#user-prompt-template)
- [Rendered example](#rendered-example)
- [Expected response schema](#expected-response-schema)
- [The repair message](#the-repair-message)
- [Validator strictness](#validator-strictness)
- [Code-fence stripping](#code-fence-stripping)
- [Chunking](#chunking)

---

## Transport

`vscode.lm` has no system role. `VsCodeChatModelProvider.sendRequest` sends the system prompt as the
**leading user turn**, which is the documented Copilot pattern:

```ts
const chatMessages = [system, ...messages].map((text) =>
  vscode.LanguageModelChatMessage.User(text),
);
```

So a first-attempt request is two user turns — the system prompt, then the user prompt. A repair
request is four: system prompt, user prompt, the model's previous (bad) output, then the repair
message.

---

## System prompt

`SYSTEM_PROMPT`. Sent on **every** request, first attempt and repair alike. It is a single line with
no embedded newlines:

```text
You are a structural extractor for Spring Boot Java code. You return only valid JSON matching the provided schema. You never emit prose, markdown, code fences, or commentary. If a field cannot be determined from the source, use null and add an entry to the "unresolved" section explaining specifically what could not be resolved and why. You never guess FQNs — if an import cannot be resolved, mark the type unresolved. You never invent line numbers — only report lines that appear in the numbered source provided. You use JVM erased method descriptors for signatures.
```

Note the em dash (`—`, U+2014) in "FQNs — if an import".

---

## User prompt template

`USER_PROMPT_TEMPLATE`, verbatim, placeholders shown as-is:

```text
Extract structural facts from this Spring Boot Java file. Return only JSON matching this schema:
{schema}

Message Router markers to treat as transport="message_router":
{MESSAGE_ROUTER_MARKERS}

File path:
{relative_path}

Numbered source:
{numbered_source}
```

### Placeholder substitution

`buildUserPrompt` fills them in this order, each with a single `String.prototype.replace` (first
occurrence only):

| Placeholder | Filled with |
|---|---|
| `{schema}` | `EXTRACTION_SCHEMA_TEXT` verbatim — see [below](#expected-response-schema). |
| `{MESSAGE_ROUTER_MARKERS}` | `codeindex.messageRouter.markers` joined with `\n`. When the array is empty, the literal string `(none configured)`. |
| `{relative_path}` | The repo-relative, forward-slashed path of the file. |
| `{numbered_source}` | The chunk's numbered source — see [below](#line-numbering). |

Because `{schema}` is substituted first and the schema text itself contains no `{MESSAGE_ROUTER_MARKERS}`,
`{relative_path}` or `{numbered_source}` tokens, the ordering is safe.

### Line numbering

`numberSource(text, startLine = 1)` renders `NNN: <line>`, 1-based, one per source line:

```ts
const width = Math.max(3, String(startLine + lines.length - 1).length);
lines.map((line, i) => `${String(startLine + i).padStart(width, '0')}: ${line}`).join('\n')
```

Width is at least 3 and grows for files over 999 lines so the gutter stays aligned. Padding is with
**`'0'`, not a space** — line 7 renders as `007: `. Chunks always carry **original** line numbers.

---

## Rendered example

The complete user prompt sent for `fixtures/cdu/src/main/java/com/acme/cdu/dto/AddressDto.java`
(41 lines) with `codeindex.messageRouter.markers` at its default `[]`. This is 4,171 characters and is
exactly what goes over the wire, following the system prompt turn.

```text
Extract structural facts from this Spring Boot Java file. Return only JSON matching this schema:
{
  "endpoints": [
    {
      "transport": "rest|kafka|solace|jms|message_router|grpc",
      "verb": "GET|POST|PUT|DELETE|PATCH|null",
      "path_template": "string|null",
      "destination": "string|null",
      "request_dto_fqn": "string|null",
      "response_dto_fqn": "string|null",
      "path_params": [{ "name": "string", "type": "string" }],
      "query_params": [{ "name": "string", "type": "string", "required": true }],
      "headers": [{ "name": "string", "type": "string", "required": true }],
      "logical_name": "string|null",
      "handler_class_fqn": "string",
      "handler_method_name": "string",
      "handler_method_signature": "JVM erased descriptor, e.g. (Ljava/lang/String;)Lcom/acme/Dto;",
      "handler_line": 0,
      "annotations": { "AnnotationName": { "attribute": "value" } },
      "confidence": 0.0
    }
  ],
  "invocations": [
    {
      "transport": "rest|kafka|solace|jms|message_router|grpc",
      "enclosing_class_fqn": "string",
      "enclosing_method_name": "string",
      "enclosing_method_signature": "JVM erased descriptor",
      "line": 0,
      "literal_url": "string|null",
      "path_fragment": "string|null",
      "destination": "string|null",
      "request_dto_fqn": "string|null",
      "response_dto_fqn": "string|null",
      "client_bean": "string|null",
      "property_key_ref": "string|null",
      "logical_name": "string|null",
      "method_name": "string",
      "confidence_hints": ["string"],
      "unresolved": [{ "what": "url|destination|dto_type|bean_wiring|property_value|method_body|extraction_failed|other", "reason": "string", "expression": "string|null" }],
      "confidence": 0.0
    }
  ],
  "dtos": [
    {
      "fqn": "string",
      "fields": [{ "name": "string", "type": "string", "nullable": true, "annotations": ["string"] }],
      "line": 0,
      "is_generated": false,
      "confidence": 0.0
    }
  ],
  "wirings": [
    {
      "bean_name": "string",
      "bean_class_fqn": "string|null",
      "property_key": "string|null",
      "injection": "@Value|@ConfigurationProperties|constructor|setter|field",
      "line": 0,
      "defining_class_fqn": "string|null",
      "confidence": 0.0
    }
  ],
  "property_bindings": [
    {
      "prefix": "string",
      "class_fqn": "string",
      "fields": [{ "name": "string", "type": "string", "property_subkey": "string" }],
      "line": 0,
      "confidence": 0.0
    }
  ],
  "method_calls": [
    {
      "caller_class_fqn": "string",
      "caller_method_signature": "JVM erased descriptor",
      "callee_class_fqn": "string|null",
      "callee_method_name": "string",
      "callee_signature_guess": "string|null",
      "line": 0,
      "call_kind": "direct|interface|lambda|reflective"
    }
  ],
  "unresolved": [
    { "what": "url|destination|dto_type|bean_wiring|property_value|method_body|extraction_failed|other", "reason": "string", "expression": "string|null" }
  ]
}

Message Router markers to treat as transport="message_router":
(none configured)

File path:
src/main/java/com/acme/cdu/dto/AddressDto.java

Numbered source:
001: package com.acme.cdu.dto;
002: 
003: public class AddressDto {
004: 
005:     private String line1;
006:     private String city;
007:     private String postcode;
008:     private String countryCode;
009: 
010:     public String getLine1() {
011:         return line1;
012:     }
013: 
014:     public void setLine1(String line1) {
015:         this.line1 = line1;
016:     }
017: 
018:     public String getCity() {
019:         return city;
020:     }
021: 
022:     public void setCity(String city) {
023:         this.city = city;
024:     }
025: 
026:     public String getPostcode() {
027:         return postcode;
028:     }
029: 
030:     public void setPostcode(String postcode) {
031:         this.postcode = postcode;
032:     }
033: 
034:     public String getCountryCode() {
035:         return countryCode;
036:     }
037: 
038:     public void setCountryCode(String countryCode) {
039:         this.countryCode = countryCode;
040:     }
041: }
042: 
```

Line `042:` is real: the file ends with a trailing newline, so `split('\n')` yields a final empty
element, which `numberSource` renders as an empty numbered line.

With markers configured, e.g. `["@MessageRouterHandler", "MessageRouterClient"]`, the markers block
instead reads:

```text
Message Router markers to treat as transport="message_router":
@MessageRouterHandler
MessageRouterClient
```

---

## Expected response schema

`EXTRACTION_SCHEMA_TEXT`, substituted into `{schema}`. It is an **instruction**, not the enforcement
— [the validator](#validator-strictness) is the enforcement, and it mirrors `LmExtraction` in
`src/lm/schema.ts`.

```json
{
  "endpoints": [
    {
      "transport": "rest|kafka|solace|jms|message_router|grpc",
      "verb": "GET|POST|PUT|DELETE|PATCH|null",
      "path_template": "string|null",
      "destination": "string|null",
      "request_dto_fqn": "string|null",
      "response_dto_fqn": "string|null",
      "path_params": [{ "name": "string", "type": "string" }],
      "query_params": [{ "name": "string", "type": "string", "required": true }],
      "headers": [{ "name": "string", "type": "string", "required": true }],
      "logical_name": "string|null",
      "handler_class_fqn": "string",
      "handler_method_name": "string",
      "handler_method_signature": "JVM erased descriptor, e.g. (Ljava/lang/String;)Lcom/acme/Dto;",
      "handler_line": 0,
      "annotations": { "AnnotationName": { "attribute": "value" } },
      "confidence": 0.0
    }
  ],
  "invocations": [
    {
      "transport": "rest|kafka|solace|jms|message_router|grpc",
      "enclosing_class_fqn": "string",
      "enclosing_method_name": "string",
      "enclosing_method_signature": "JVM erased descriptor",
      "line": 0,
      "literal_url": "string|null",
      "path_fragment": "string|null",
      "destination": "string|null",
      "request_dto_fqn": "string|null",
      "response_dto_fqn": "string|null",
      "client_bean": "string|null",
      "property_key_ref": "string|null",
      "logical_name": "string|null",
      "method_name": "string",
      "confidence_hints": ["string"],
      "unresolved": [{ "what": "url|destination|dto_type|bean_wiring|property_value|method_body|extraction_failed|other", "reason": "string", "expression": "string|null" }],
      "confidence": 0.0
    }
  ],
  "dtos": [
    {
      "fqn": "string",
      "fields": [{ "name": "string", "type": "string", "nullable": true, "annotations": ["string"] }],
      "line": 0,
      "is_generated": false,
      "confidence": 0.0
    }
  ],
  "wirings": [
    {
      "bean_name": "string",
      "bean_class_fqn": "string|null",
      "property_key": "string|null",
      "injection": "@Value|@ConfigurationProperties|constructor|setter|field",
      "line": 0,
      "defining_class_fqn": "string|null",
      "confidence": 0.0
    }
  ],
  "property_bindings": [
    {
      "prefix": "string",
      "class_fqn": "string",
      "fields": [{ "name": "string", "type": "string", "property_subkey": "string" }],
      "line": 0,
      "confidence": 0.0
    }
  ],
  "method_calls": [
    {
      "caller_class_fqn": "string",
      "caller_method_signature": "JVM erased descriptor",
      "callee_class_fqn": "string|null",
      "callee_method_name": "string",
      "callee_signature_guess": "string|null",
      "line": 0,
      "call_kind": "direct|interface|lambda|reflective"
    }
  ],
  "unresolved": [
    { "what": "url|destination|dto_type|bean_wiring|property_value|method_body|extraction_failed|other", "reason": "string", "expression": "string|null" }
  ]
}
```

Note that the schema text's `annotations` field carries a Java-annotation `{name: {attr: value}}`
shape — the model is asked to report `declared_on` / `inherited_from` markers there, which is how
interface/impl reconciliation gets its only structural evidence.

---

## The repair message

`REPAIR_MESSAGE`, verbatim:

```text
Your previous output was not valid JSON matching the schema. Return only valid JSON matching the schema — no prose, no markdown.
```

Again note the em dash before "no prose".

### When it fires

`requestWithRepair` in `src/lm/extractor.ts`:

1. Send the user prompt. Validate the response with `validateRaw` — strip fences, `JSON.parse`, then
   `validateExtraction`.
2. On success, done — zero repairs.
3. On **either** a parse failure **or** a schema failure, log at `[LM]` and send exactly one repair
   turn: `[userPrompt, firstResponse, REPAIR_MESSAGE]`.
4. Validate the repair response. On success, done with `repairAttempts: 1`.
5. On failure, give up.

### One shared budget per chunk

**Parse failures and schema failures share exactly ONE repair round-trip per chunk.** They are not
budgeted separately. The reasoning, from the code: a repair is a single "you got the format wrong,
try again" turn, and the model cannot distinguish "your JSON did not parse" from "your JSON parsed but
broke the schema" in any way that would make a second attempt more likely to succeed — while a second
retry doubles cost and latency on exactly the files that are already the slowest.

So a response that parses but fails validation **spends the budget**; if the repair then comes back
unparseable, that is the end of it. No further attempt.

The budget is **per chunk**, not per file. A file split into three chunks may issue up to three repair
turns in total, one per chunk. `FileExtraction.repairAttempts` is the sum.

### What happens after the budget is spent

**Both failure modes emit an `extraction_failed` unresolved record.** Verified in `extractFile`:

| Final outcome | Log line | Record |
|---|---|---|
| `schema` | `<file> chunk <n>: schema validation failed after one repair attempt: <first 3 errors, truncated at 400 chars>` | `{what: "extraction_failed", reason: <that same message>, expression: null}` |
| `parse` | `<file> chunk <n>: extraction failed (<detail>)` | `{what: "extraction_failed", reason: <detail>, expression: null}` |
| `error` (unexpected throw) | same as `parse` | same as `parse` |

`normalize.ts` turns each of these into an `unresolved` index record with `context.line: 1` and
`partial_info: {expression: null, source: "lm_file_level"}`, so the miss is visible in the index
rather than silently absent.

### Transport errors are not repaired

`LmRateLimitError` and `LmUnavailableError` are **rethrown** out of `extractFile` rather than
consuming the repair budget, so `extractFiles` can apply backoff or skip:

- **Rate limit** — exponential backoff starting at 1000 ms, using `err.retryAfterMs` when supplied.
  Capped at `MAX_BACKOFF_MS = 30_000`; exceeding the cap, or running out of wall-clock budget, skips
  the file.
- **Unavailable** — skipped immediately, no retry.

Either way the file still yields an `extraction_failed` record via `rateLimitedPlaceholder`. Nothing
is dropped silently.

### Line-range enforcement — free, and not a repair

After merging, `enforceLineRange` discards every endpoint, invocation, DTO, wiring, property binding
and method call whose reported line falls outside `1..lineCount` of the real file, logging each:

```
discarded <kind> in <file>: line <n> outside 1..<lineCount>
```

File-level `unresolved` notes are exempt — they carry no line. This costs no repair; it is a silent
integrity filter backing the system prompt's "You never invent line numbers".

---

## Validator strictness

`validateExtraction` in `src/lm/schema.ts`. Hand-written, no ajv — a hand validator lets the error
strings be useful in the repair turn.

| Rule | Behaviour |
|---|---|
| **Unknown fields rejected** | At **every** object level, including the top level. Error: `<path>.<key>: unknown field (allowed: a, b, c)`. |
| **Enums enforced** | `transport`, `verb`, `injection`, `call_kind`, `unresolved.what`. Out-of-range values fail. A fallback is substituted so validation can continue collecting errors, but the result is still `ok: false`. |
| **Missing top-level array tolerated** | Any of the seven top-level arrays may be absent or `null` → becomes `[]`. The **contents** of a present array are validated strictly. |
| **Missing nullable tolerated and normalized** | A missing or `null` nullable field becomes `null`. Models routinely omit nulls. Applies to every `string\|null` field and to nullable enums (`verb`). |
| **Missing required strings rejected** | `reqString` fails with `expected string, got missing`. Covers `handler_class_fqn`, `handler_method_name`, `handler_method_signature`, `enclosing_class_fqn`, `method_name`, `fqn`, `bean_name`, `prefix`, `class_fqn`, `caller_class_fqn`, `callee_method_name`, `reason`, and every `name`/`type`/`property_subkey`. |
| **`confidence` default** | Missing or `null` → **`0.5`**. Present but not a finite number in `[0,1]` → fails, and `0.5` is substituted for continuation. |
| **Line numbers** | Must be a finite **integer ≥ 1**. `0`, negatives, floats and non-numbers all fail. |
| **Booleans default** | `required` defaults to `true`; `nullable` defaults to `true`; `is_generated` defaults to `false`. Present-but-wrong-type fails. |
| **String arrays** | Missing/`null` → `[]`. Non-array fails. Non-string elements fail individually by index. |
| **Annotations map** | Missing/`null` → `{}`. Non-object fails. Each value must itself be a plain object of attributes; a non-object value fails for that key only. **Attribute values inside are `unknown` and are not validated** — that is what lets `declared_on` / `inherited_from` through untouched. |
| **Error cap** | At most 50 errors are collected. Only the **first 3**, `; `-joined, are surfaced in the repair-decision detail string. |

Every validator returns a fully-normalized `LmExtraction` on success — downstream code never sees an
`undefined` where the type says `null`.

---

## Code-fence stripping

`stripCodeFences` runs inside `parseLmJson`, **before** `JSON.parse`. Models keep wrapping JSON in
markdown despite the system prompt forbidding it.

```ts
const trimmed = text.trim();
if (!trimmed.startsWith('```')) return trimmed;
const firstNewline = trimmed.indexOf('\n');
if (firstNewline === -1) return trimmed;
const body = trimmed.slice(firstNewline + 1);
const closing = body.lastIndexOf('```');
return (closing === -1 ? body : body.slice(0, closing)).trim();
```

- The whole first line is discarded, so an info string (` ```json `) is handled.
- The **last** ` ``` ` closes the block, so fences inside the JSON do not truncate it early.
- A missing closing fence is tolerated.

**Stripping a fence costs no repair.** It happens before parsing, so a correctly-fenced valid JSON
response is a first-attempt success. An empty response after stripping is a parse failure with the
detail `empty response`.

---

## Chunking

`src/lm/chunker.ts`. A file is split only when its numbered rendering exceeds the model's usable
input budget.

### When it triggers

```ts
budget = Math.max(1000, model.maxInputTokens - overhead)
overhead = estimateTokens(SYSTEM_PROMPT)
         + estimateTokens(buildUserPrompt({relativePath, numberedSource: '', markers}))
         + 1024
```

The 1,024-token `PROMPT_OVERHEAD_MARGIN_TOKENS` is headroom for the reply. The skeleton prompt
measured includes the full schema text, so the schema's cost is accounted for exactly rather than
estimated. The floor of 1,000 tokens guarantees forward progress even against an absurdly small model.

If `estimateTokens(wholeNumberedFile) <= budget`, one chunk is returned covering the whole file, and
`buildUserPrompt` is called once. Splits are logged:

```
[LM] <file>: split into <n> chunks (budget <b>t)
```

### The token estimate

```ts
export const CHARS_PER_TOKEN = 3.5;
export function estimateTokens(text: string): number {
  return Math.ceil(text.length / CHARS_PER_TOKEN);
}
```

An **estimate only** — roughly BPE-average for Java source. It is explicitly not to be trusted
exactly, which is why callers leave headroom on top of it.

### Class-then-method splitting

1. `scanBlocks` performs a brace-depth scan that is aware of `//` line comments, `/* */` block
   comments, `"…"` strings, `'…'` chars and `"""…"""` text blocks — otherwise a brace inside a string
   desynchronises depth tracking and the split lands mid-method. It returns blocks opened at depth 0
   (top-level types) and depth 1 (members). An unterminated literal bails at the newline rather than
   corrupting the whole scan.
2. **Class boundaries first.** One unit per top-level class. Each class is expanded to swallow the
   blank lines and comments between it and the previous class (and, for the last class, the file
   tail), so the units together cover **every line** of the file.
3. **Method boundaries second.** A class that alone overflows is split at its depth-1 members, each
   member likewise expanded to absorb preceding blank lines and comments.
4. Units are packed greedily into chunks: append until adding the next unit would exceed budget, then
   flush.
5. **Fail-open.** A file with no detectable top-level class, or one that cannot be split at all, is
   emitted whole and may be truncated by the model. `chunkJavaSource` always returns at least one
   chunk. If chunking throws, the extractor retries with an effectively infinite budget, which yields
   the whole file as one chunk.

### Original line numbers are preserved

The file is numbered **once** up front and chunks select lines out of that array:

```ts
const numbered = numberSource(content).split('\n');
const render = (lines: number[]) => lines.map((l) => numbered[l - 1] ?? '').join('\n');
```

A line rendered in chunk 3 carries the same number it had in chunk 1. Every line the model reports is
therefore valid against the real file — and `enforceLineRange` checks it against the real file length,
not the chunk's. Asserted by `lm-sanity`: original numbers preserved at both class and method split
levels, and every source line covered at least once.

### Prelude and class-header repetition

- **Prelude** — lines 1 through `firstClass.startLine - 1`, i.e. `package` and `import` declarations,
  are prepended to **every** chunk so FQNs stay resolvable.
- **Class header** — for a method-level split, every unit carries the class declaration line through
  the first member's line minus one, **plus the class's closing brace line**, so each chunk is still
  recognisably that class.

Chunk line lists are deduped and sorted, so overlapping frames never duplicate a line within a chunk.

### Merging

`mergeExtractions` concatenates per-chunk extractions, dropping records byte-identical to one already
present. Duplicates are expected — the repeated prelude and class header mean the same DTO or wiring
can be reported by several chunks. Identity uses `stableKey`, a key-order-independent stringify, so
`{a:1,b:2}` and `{b:2,a:1}` dedupe against each other.

### The multi-chunk cache envelope

The raw responses of all chunks are stored under **one** cache key — the SHA-256 of the whole file's
content:

```json
{"__codeindex_lm_chunks__": ["<raw response chunk 0>", "<raw response chunk 1>"]}
```

A single-chunk file stores its bare response with no envelope. `decodeCacheEnvelope` returns `[raw]`
for anything that is not a recognizable envelope, so both forms round-trip.

On a cache hit every part is re-validated. If **all** parts still validate, they are merged,
line-range-checked and returned with `fromCache: true` and **zero provider calls**. If any part no
longer validates, the whole file is re-extracted:

```
[LM] cache entry for <file> no longer validates — re-extracting
```

`FileLmCache` unwraps the envelope into real JSON on write so the cache file is human-readable rather
than a doubly-escaped JSON string, and re-serializes it on read. The chunk strings themselves are
preserved byte-for-byte.

The zero-call cache-hit guarantee is asserted by `indexer-sanity`: 9 provider calls on the first
build of the CDU fixture, **0** on a second build into the same bundle.
