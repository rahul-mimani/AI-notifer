package com.acme.cdu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CduApplication {

    public static void main(String[] args) {
        SpringApplication.run(CduApplication.class, args);
    }
}
