package com.acme.cdu.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.acme.cdu.dto.AddressDto;
import com.acme.cdu.dto.CustomerDto;
import com.acme.cdu.dto.UpdateCustomerRequest;
import com.acme.cdu.messaging.CustomerEventPublisher;
import com.acme.cdu.repository.CustomerRepository;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;
    private final CustomerEventPublisher customerEventPublisher;

    public CustomerService(CustomerRepository customerRepository,
                           CustomerEventPublisher customerEventPublisher) {
        this.customerRepository = customerRepository;
        this.customerEventPublisher = customerEventPublisher;
    }

    public CustomerDto findById(String id, boolean expand) {
        CustomerDto customer = customerRepository.load(id);
        if (expand) {
            customer.setAddresses(customerRepository.loadAddresses(id));
        }
        return customer;
    }

    public CustomerDto applyUpdate(String id, UpdateCustomerRequest body) {
        validate(body);
        CustomerDto saved = customerRepository.save(id, body);
        customerEventPublisher.publishCustomerUpdated(id, saved.getDisplayName());
        return saved;
    }

    public List<AddressDto> addressesFor(String id) {
        return customerRepository.loadAddresses(id);
    }

    private void validate(UpdateCustomerRequest body) {
        if (body == null || body.getDisplayName() == null || body.getDisplayName().isEmpty()) {
            throw new IllegalArgumentException("displayName is required");
        }
    }
}
