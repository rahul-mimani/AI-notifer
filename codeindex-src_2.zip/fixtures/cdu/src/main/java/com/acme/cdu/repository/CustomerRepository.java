package com.acme.cdu.repository;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Repository;

import com.acme.cdu.dto.AddressDto;
import com.acme.cdu.dto.CustomerDto;
import com.acme.cdu.dto.UpdateCustomerRequest;

@Repository
public class CustomerRepository {

    private final Map<String, CustomerDto> store = new ConcurrentHashMap<>();

    public CustomerDto load(String id) {
        CustomerDto dto = store.get(id);
        if (dto == null) {
            dto = new CustomerDto();
            dto.setId(id);
            dto.setDisplayName("Unknown");
            dto.setUpdatedAt(Instant.now());
        }
        return dto;
    }

    public CustomerDto save(String id, UpdateCustomerRequest body) {
        CustomerDto dto = load(id);
        dto.setDisplayName(body.getDisplayName());
        dto.setPrimaryAddress(body.getPrimaryAddress());
        dto.setUpdatedAt(Instant.now());
        store.put(id, dto);
        return dto;
    }

    public List<AddressDto> loadAddresses(String id) {
        CustomerDto dto = store.get(id);
        if (dto == null || dto.getAddresses() == null) {
            return new ArrayList<>();
        }
        return dto.getAddresses();
    }
}
