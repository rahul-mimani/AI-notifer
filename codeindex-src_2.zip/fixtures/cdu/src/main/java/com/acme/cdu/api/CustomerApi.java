package com.acme.cdu.api;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.acme.cdu.dto.AddressDto;
import com.acme.cdu.dto.CustomerDto;
import com.acme.cdu.dto.UpdateCustomerRequest;

/**
 * HTTP contract for the customer resource.
 *
 * <p>EDGE CASE: every mapping annotation for this service lives HERE, on the
 * interface. The {@code @RestController} implementation carries none of them.
 * Spring still registers the handlers because the implementing class inherits
 * the annotated interface methods.
 */
@RequestMapping("/api/v1/customers")
public interface CustomerApi {

    @GetMapping("/{id}")
    CustomerDto getCustomer(@PathVariable("id") String id,
                            @RequestParam(value = "expand", required = false) boolean expand);

    @PutMapping("/{id}")
    CustomerDto updateCustomer(@PathVariable("id") String id,
                               @RequestBody UpdateCustomerRequest body);

    @GetMapping("/{id}/addresses")
    List<AddressDto> listAddresses(@PathVariable("id") String id);
}
