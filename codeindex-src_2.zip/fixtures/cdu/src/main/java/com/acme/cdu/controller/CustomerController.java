package com.acme.cdu.controller;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import com.acme.cdu.api.CustomerApi;
import com.acme.cdu.dto.AddressDto;
import com.acme.cdu.dto.CustomerDto;
import com.acme.cdu.dto.UpdateCustomerRequest;
import com.acme.cdu.service.CustomerService;

/**
 * EDGE CASE: this class deliberately carries NO mapping annotations. Not
 * {@code @RequestMapping}, not {@code @GetMapping}, not {@code @PathVariable}.
 * All of them are inherited from {@link CustomerApi}. An extractor that only
 * reads this file finds zero endpoints.
 */
@RestController
public class CustomerController implements CustomerApi {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @Override
    public CustomerDto getCustomer(String id, boolean expand) {
        return customerService.findById(id, expand);
    }

    @Override
    public CustomerDto updateCustomer(String id, UpdateCustomerRequest body) {
        return customerService.applyUpdate(id, body);
    }

    @Override
    public List<AddressDto> listAddresses(String id) {
        return customerService.addressesFor(id);
    }
}
