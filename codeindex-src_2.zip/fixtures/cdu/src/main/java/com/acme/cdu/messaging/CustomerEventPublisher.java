package com.acme.cdu.messaging;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 * Non-REST producer surface: publishes customer change events to Kafka.
 */
@Service
public class CustomerEventPublisher {

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Value("${cdu.events.topic}")
    private String customerEventsTopic;

    public CustomerEventPublisher(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publishCustomerUpdated(String customerId, String displayName) {
        String payload = "{\"customerId\":\"" + customerId + "\",\"displayName\":\"" + displayName + "\"}";
        kafkaTemplate.send(customerEventsTopic, customerId, payload);
    }
}
