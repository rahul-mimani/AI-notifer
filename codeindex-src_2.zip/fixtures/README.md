# Synthetic Spring Boot fixtures: CDU (producer) and POU (consumer)

Two hand-authored Spring Boot repos plus hand-authored mock LM extraction data.
They exist to exercise two specific hard cases that a naive extractor gets wrong,
and to give the cross-repo join pass a known-good ground truth to be asserted
against.

```
fixtures/
  cdu/                       PRODUCER, package root com.acme.cdu, config = .properties
  pou/                       CONSUMER, package root com.acme.pou, config = .yml
  configmap/                 k8s ConfigMap for POU
  lm-responses/<repo>/...    one JSON per .java file, path separators -> "__"
  expected.json              machine-readable ground truth
  README.md                  this file
```

---

## Edge case 1 (producer): endpoint annotations live on an INTERFACE

`cdu/src/main/java/com/acme/cdu/controller/CustomerController.java` is annotated
`@RestController` and **carries no mapping annotations at all** — no
`@RequestMapping`, no `@GetMapping`/`@PutMapping`, no `@PathVariable`, no
`@RequestBody`. Every one of them lives on
`cdu/src/main/java/com/acme/cdu/api/CustomerApi.java`, the interface the
controller implements.

Spring still registers all three handlers, because the implementing class
inherits the annotated interface methods. An extractor that reads only the
`@RestController` class finds **zero endpoints** — that is the whole point.

### How the LM fixtures report it (important)

The endpoints are reported **twice**, deliberately:

| Reported in | `handler_class_fqn` | `handler_line` | `confidence` |
|---|---|---|---|
| `CustomerApi.java` | `com.acme.cdu.api.CustomerApi` | interface method decl (28 / 32 / 36) | 0.95 |
| `CustomerController.java` | `com.acme.cdu.controller.CustomerController` | controller method decl (29 / 34 / 39) | 0.80 |

The controller copies carry the mapping attributes with an `inherited_from`
marker in their `annotations` map, and a lower confidence reflecting the
indirection. The interface copies carry `declared_on`.

**The downstream pipeline must reconcile these two.** The intended resolution is
to dedupe on `(verb, path_template_normalized)` and keep the **controller** as
the canonical handler (that is what actually serves traffic and what a stack
trace will show), while retaining the interface FQN as the declaring type.
`expected.json` records both, and states the post-dedupe endpoint count.

---

## Edge case 2 (consumer): no literal URL, plus a deep call chain

`pou/src/main/java/com/acme/pou/service/CustomerLookupService.java` contains **no
literal absolute URL anywhere**. The host comes from
`@Value("${services.cdu.base-url}")`, and that property itself resolves
recursively through `${cdu.host}`. Only the path fragment
`/api/v1/customers/{id}` is a literal (a `private static final` constant).

Both outbound calls are therefore only resolvable by combining:
static path fragment + resolved property value.

The calling service sits at the bottom of a chain reachable from **two different
entry points**:

```
ENTRY 1 (REST)   OrderController.createOrder
ENTRY 2 (Kafka)  OrderEventListener.onOrderEvent
                        |
                        v
                 OrderService.process
                        |
                        v
                 EnrichmentService.enrich
                        |
          +-------------+-------------+
          v                           v
CustomerLookupService          CustomerLookupService
      .fetchCustomer (GET)        .updateCustomer (PUT)
```

---

## Config formats: .properties AND .yml on purpose

The two repos deliberately use **different config formats** so both parser paths
are exercised end to end, and so the cross-repo join has to work across formats:

- **CDU uses `.properties`** — `application.properties` +
  `application-prod.properties`. It includes `#` comment lines, a backslash
  line-continuation value (`cdu.events.description`, three physical lines that
  must join into one logical value), and a `${VAR:default}` placeholder
  (`cdu.instance.region`).
- **POU uses `.yml`** — `application.yml` plus `-dev` / `-uat` / `-prod`
  profiles, a recursive placeholder, a `${VAR:-default}` placeholder, and a
  Vault reference.

Env vars are **never read from the real environment** during indexing, for build
determinism. `${VAR:default}` and `${VAR:-default}` always resolve to their
inline default.

### POU — resolved `services.cdu.base-url` per env

Raw value: `${cdu.host}/cdu-service`

| Env | `cdu.host` | Resolved `services.cdu.base-url` |
|---|---|---|
| default | `https://cdu.default.internal` | `https://cdu.default.internal/cdu-service` |
| dev | `https://cdu.dev.internal` | `https://cdu.dev.internal/cdu-service` |
| uat | `https://cdu.uat.internal` | `https://cdu.uat.internal/cdu-service` |
| prod | `https://cdu.prod.internal` | `https://cdu.prod.internal/cdu-service` |

Other POU keys:

| Key | default / dev / uat | prod |
|---|---|---|
| `services.cdu.timeout-ms` | `3000` (ConfigMap overrides to `5000`) | `3000` (ConfigMap `5000`) |
| `services.cdu.api-key` | `changeme` (inline default) | **unresolved**, `is_secret: true` |
| `pou.orders.topic` | `pou-orders` | `pou-orders` |

`fixtures/configmap/pou-configmap.yaml` sets `SERVICES_CDU_TIMEOUT_MS: "5000"`,
which relaxed binding maps onto `services.cdu.timeout-ms` and which outranks
`application.yml` at runtime.

The prod api-key is `${vault:secret/pou#cdu-api-key}`. It **must remain
unresolved** and be marked `is_secret: true` — never inlined into the index.

### CDU — resolved `.properties` values per env

| Key | default | prod |
|---|---|---|
| `spring.application.name` | `cdu-service` | `cdu-service` |
| `server.port` | `8081` | `8081` |
| `cdu.events.topic` | `customer-events` | `customer-events-prod` |
| `cdu.instance.region` | `eu-west-1` | `eu-central-1` |
| `cdu.events.partitions` | `6` | `24` |
| `cdu.events.description` | `customer lifecycle events emitted by cdu-service for downstream consumers` | same |

`cdu.instance.region` resolves to its **inline default** in both envs
(`${CDU_REGION:eu-west-1}` / `${CDU_REGION:eu-central-1}`) because env vars are
never read from the real environment.

---

## Expected call chains

### POU (consumer, upward from each invocation to each entry point)

```
OrderController.createOrder   -> OrderService.process -> EnrichmentService.enrich -> CustomerLookupService.fetchCustomer
OrderEventListener.onOrderEvent -> OrderService.process -> EnrichmentService.enrich -> CustomerLookupService.fetchCustomer
OrderController.createOrder   -> OrderService.process -> EnrichmentService.enrich -> CustomerLookupService.updateCustomer
OrderEventListener.onOrderEvent -> OrderService.process -> EnrichmentService.enrich -> CustomerLookupService.updateCustomer
```

### CDU (producer, downward from each handler to the repository)

```
CustomerController.getCustomer    -> CustomerService.findById     -> CustomerRepository.load
CustomerController.updateCustomer -> CustomerService.applyUpdate  -> CustomerRepository.save
CustomerController.listAddresses  -> CustomerService.addressesFor -> CustomerRepository.loadAddresses
```

Plus a **same-class edge**: `CustomerService.applyUpdate -> CustomerService.validate`,
and a Kafka producer branch
`CustomerService.applyUpdate -> CustomerEventPublisher.publishCustomerUpdated`.

---

## Cross-repo join signals that should fire

1. **`dto_shape`** — POU's `CustomerDto`, `AddressDto` and `UpdateCustomerRequest`
   are field-for-field shape-identical to CDU's (same names, types, order, same
   nested `AddressDto`, same `transient cacheKey`). Only the package differs, so
   the join must be driven by the recursive shape hash, not the FQN. The
   `transient cacheKey` field **must be excluded** from the hash — it is present
   in both DTOs and marked with `"transient"` in its `annotations` array so the
   hasher can drop it.
2. **`path_fragment` via property value** — POU's invocations expose
   `path_fragment: "/api/v1/customers/{id}"` and
   `property_key_ref: "services.cdu.base-url"`. Resolving that property yields
   `https://cdu.<env>.internal/cdu-service`, whose path component matches CDU's
   `spring.application.name` (`cdu-service`); the fragment then matches CDU's
   `GET` and `PUT /api/v1/customers/{id}` endpoints.
3. **`destination` (Kafka)** — CDU publishes to `customer-events` /
   `customer-events-prod`; POU consumes `pou-orders`. These are **different
   topics**, so no Kafka link should fire between the two repos here. Reporting
   one is a false positive, and `expected.json` asserts `must_match: false`.

---

## Deliberately unresolvable cases

Both must produce `unresolved` records rather than a guess:

1. `services.cdu.api-key` in `application-prod.yml` — `${vault:secret/pou#cdu-api-key}`,
   `is_secret: true`.
2. `EnrichmentService.enrich` line 28 — a second `RestTemplate` call whose URL is
   the return value of `resolveEndpoint(tenant)`, backed by a runtime-populated
   `TenantRegistry`. No static value is derivable.

---

## LM response fixtures

One JSON file per `.java` file, at
`lm-responses/<repo>/<repo-relative path with "/" replaced by "__">.json`.

Top-level keys are exactly: `endpoints`, `invocations`, `dtos`, `wirings`,
`property_bindings`, `method_calls`, `unresolved` (each an array, `[]` when
nothing applies). The shapes match `src/lm/schema.ts` exactly — that validator
rejects unknown fields at every object level.

**Every `line` / `handler_line` is a true 1-based line number** in the
checked-in Java source. Method signatures use JVM erased descriptor style and
are byte-identical between the `method_calls` caller/callee entries and the
`endpoints`/`invocations` entries, because the callgraph resolver joins on those
exact strings — a mismatch silently drops the edge.
