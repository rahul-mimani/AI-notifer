package com.acme.pou.service;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Runtime-populated tenant table. Deliberately opaque to static analysis: the
 * URLs it returns are never written as literals in the source tree.
 */
public final class TenantRegistry {

    private static final Map<String, Tenant> TENANTS = new ConcurrentHashMap<>();

    private TenantRegistry() {
    }

    public static Tenant lookup(String tenant) {
        return TENANTS.get(tenant);
    }

    public static final class Tenant {

        private final String profileUrl;

        public Tenant(String profileUrl) {
            this.profileUrl = profileUrl;
        }

        public String profileUrl() {
            return Objects.toString(profileUrl, "");
        }
    }
}
