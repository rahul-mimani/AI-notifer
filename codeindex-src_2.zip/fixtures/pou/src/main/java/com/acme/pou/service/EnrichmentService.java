package com.acme.pou.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.acme.pou.dto.AddressDto;
import com.acme.pou.dto.CustomerDto;
import com.acme.pou.dto.UpdateCustomerRequest;

@Service
public class EnrichmentService {

    private final CustomerLookupService customerLookupService;
    private final RestTemplate restTemplate;

    public EnrichmentService(CustomerLookupService customerLookupService,
                             RestTemplate cduRestTemplate) {
        this.customerLookupService = customerLookupService;
        this.restTemplate = cduRestTemplate;
    }

    public CustomerDto enrich(String customerId, String tenant) {
        CustomerDto customer = customerLookupService.fetchCustomer(customerId);

        // Deliberately unresolvable: the URL comes from a method return value,
        // so no static extractor can determine the target of this call.
        String endpoint = resolveEndpoint(tenant);
        String tenantProfile = restTemplate.getForObject(endpoint, String.class);
        customer.setCacheKey(tenantProfile);

        if (customer.getDisplayName() == null) {
            UpdateCustomerRequest patch = new UpdateCustomerRequest();
            patch.setDisplayName("pending-" + tenant);
            patch.setPrimaryAddress(new AddressDto());
            customer = customerLookupService.updateCustomer(customerId, patch);
        }
        return customer;
    }

    private String resolveEndpoint(String tenant) {
        return TenantRegistry.lookup(tenant).profileUrl();
    }
}
