package com.acme.pou.dto;

public class UpdateCustomerRequest {

    private String displayName;
    private AddressDto primaryAddress;

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public AddressDto getPrimaryAddress() {
        return primaryAddress;
    }

    public void setPrimaryAddress(AddressDto primaryAddress) {
        this.primaryAddress = primaryAddress;
    }
}
