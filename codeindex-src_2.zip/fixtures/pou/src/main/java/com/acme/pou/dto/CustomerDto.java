package com.acme.pou.dto;

import java.time.Instant;
import java.util.List;

/**
 * Shape-identical to com.acme.cdu.dto.CustomerDto: same field names, same
 * types, same declaration order, same nested AddressDto, same transient field.
 * Only the package differs -- this is what makes the dto_shape join fire.
 */
public class CustomerDto {

    private String id;
    private String displayName;
    private AddressDto primaryAddress;
    private List<AddressDto> addresses;
    private Instant updatedAt;

    /** Client-side only; must NOT contribute to the DTO shape hash. */
    private transient String cacheKey;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public AddressDto getPrimaryAddress() {
        return primaryAddress;
    }

    public void setPrimaryAddress(AddressDto primaryAddress) {
        this.primaryAddress = primaryAddress;
    }

    public List<AddressDto> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<AddressDto> addresses) {
        this.addresses = addresses;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCacheKey() {
        return cacheKey;
    }

    public void setCacheKey(String cacheKey) {
        this.cacheKey = cacheKey;
    }
}
