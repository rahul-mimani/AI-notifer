package com.acme.pou.service;

import org.springframework.stereotype.Service;

import com.acme.pou.dto.CustomerDto;

@Service
public class OrderService {

    private final EnrichmentService enrichmentService;

    public OrderService(EnrichmentService enrichmentService) {
        this.enrichmentService = enrichmentService;
    }

    public CustomerDto process(String orderId, String customerId, String tenant) {
        return enrichmentService.enrich(customerId, tenant);
    }
}
