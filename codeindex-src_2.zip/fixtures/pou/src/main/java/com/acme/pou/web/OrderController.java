package com.acme.pou.web;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.acme.pou.dto.CustomerDto;
import com.acme.pou.dto.OrderRequest;
import com.acme.pou.service.OrderService;

/** ENTRY POINT 1: HTTP. */
@RestController
@RequestMapping("/api/v1/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping
    public ResponseEntity<CustomerDto> createOrder(@RequestBody OrderRequest body) {
        CustomerDto enriched = orderService.process(body.getOrderId(), body.getCustomerId(), body.getTenant());
        return ResponseEntity.ok(enriched);
    }
}
