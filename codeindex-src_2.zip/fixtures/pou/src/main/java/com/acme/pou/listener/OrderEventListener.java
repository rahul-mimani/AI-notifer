package com.acme.pou.listener;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.acme.pou.service.OrderService;

/**
 * ENTRY POINT 2: Kafka. Reaches exactly the same downstream chain as
 * {@code OrderController.createOrder}.
 */
@Component
public class OrderEventListener {

    private final OrderService orderService;

    public OrderEventListener(OrderService orderService) {
        this.orderService = orderService;
    }

    @KafkaListener(topics = "${pou.orders.topic}", groupId = "pou-order-consumer")
    public void onOrderEvent(String message) {
        String[] parts = message.split(",");
        orderService.process(parts[0], parts[1], parts[2]);
    }
}
