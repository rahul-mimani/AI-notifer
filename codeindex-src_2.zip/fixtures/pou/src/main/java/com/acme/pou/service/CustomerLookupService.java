package com.acme.pou.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.acme.pou.dto.CustomerDto;
import com.acme.pou.dto.UpdateCustomerRequest;

/**
 * EDGE CASE: there is no literal absolute URL anywhere in this file. The host
 * and context path come from the property {@code services.cdu.base-url}, which
 * itself resolves recursively through {@code cdu.host}.
 */
@Service
public class CustomerLookupService {

    private static final String CUSTOMER_PATH = "/api/v1/customers/{id}";

    private final RestTemplate restTemplate;

    @Value("${services.cdu.base-url}")
    private String cduBaseUrl;

    public CustomerLookupService(RestTemplate cduRestTemplate) {
        this.restTemplate = cduRestTemplate;
    }

    public CustomerDto fetchCustomer(String id) {
        String url = UriComponentsBuilder.fromHttpUrl(cduBaseUrl)
                .path(CUSTOMER_PATH)
                .toUriString();
        return restTemplate.getForObject(url, CustomerDto.class, id);
    }

    public CustomerDto updateCustomer(String id, UpdateCustomerRequest body) {
        String url = cduBaseUrl + CUSTOMER_PATH;
        HttpEntity<UpdateCustomerRequest> request = new HttpEntity<>(body);
        ResponseEntity<CustomerDto> response =
                restTemplate.exchange(url, HttpMethod.PUT, request, CustomerDto.class, id);
        return response.getBody();
    }
}
